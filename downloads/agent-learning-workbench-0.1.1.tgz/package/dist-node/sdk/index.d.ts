type DocumentMetadata = {
    id: string;
    path: string;
    title: string;
    summary: string;
    stage?: string;
    tags?: string[];
    prerequisites?: string[];
    related?: string[];
};
type LearnManifest = {
    version: 1;
    site: {
        title: string;
        description?: string;
    };
    contentRoots: string[];
    documents: DocumentMetadata[];
};
type DocumentSnapshot = DocumentMetadata & {
    body: string;
    contentHash: string;
    modifiedAt: string;
};
type WorkspaceSnapshot = {
    site: LearnManifest["site"];
    documents: DocumentMetadata[];
    manifestHash: string;
    runtime: RuntimeHealth;
};
type RuntimeHealth = {
    adapter: string;
    available: boolean;
    version?: string;
    message?: string;
};
type QuestionIntent = "answer" | "revise" | "auto";
type EditTarget = {
    from: number;
    to: number;
    baseHash: string;
    blockId?: string;
    ifHash?: string;
};
type TextAnchor = {
    exactQuote: string;
    prefix?: string;
    suffix?: string;
    headingPath?: string[];
    snapshotHash?: string;
};
type QuestionRequest = {
    documentId?: string;
    conversationId?: string;
    question: string;
    intent: QuestionIntent;
    anchor?: TextAnchor;
    target?: EditTarget;
};
type RuntimeRequest = QuestionRequest & {
    document?: DocumentSnapshot;
    documents?: DocumentMetadata[];
    contentRoots?: string[];
    siteTitle: string;
    conversation?: Array<Pick<TurnRecord, "question" | "answerMarkdown" | "status" | "error" | "appliedEdits">>;
};
type RuntimeResult = {
    answerMarkdown: string;
    evidence: EvidenceReference[];
    proposal: null | {
        summary: string;
        replacementMarkdown: string;
    };
    structureProposal: null | {
        summary: string;
        operations: StructureOperation[];
    };
};
type EvidenceReference = {
    state: "verified" | "inferred" | "unknown";
    label: string;
    path?: string;
    line?: number;
    detail?: string;
    capturedHash?: string;
    stale?: boolean;
};
type StructureOperation = {
    type: "create";
    document: DocumentMetadata;
    body: string;
} | {
    type: "update";
    documentId: string;
    title: string;
    summary: string;
} | {
    type: "rename";
    documentId: string;
    nextPath: string;
    title?: string;
} | {
    type: "delete";
    documentId: string;
};
type StructureProposal = {
    id: string;
    turnId: string;
    baseManifestHash: string;
    summary: string;
    operations: StructureOperation[];
    status: "pending" | "accepted" | "rejected" | "conflict";
    createdAt: string;
};
type StructureMutationResult = {
    manifestHash: string;
    documents: DocumentMetadata[];
    changedPaths: string[];
    warnings?: string[];
};
type SearchResult = {
    document: DocumentMetadata;
    score: number;
    snippet: string;
};
type WorkspaceInsights = {
    disconnectedDocumentIds: string[];
    duplicateQuestionGroups: Array<{
        normalizedQuestion: string;
        turnIds: string[];
    }>;
};
type Proposal = {
    id: string;
    turnId: string;
    documentId: string;
    baseHash: string;
    baseMarkdown: string;
    blockOperation?: {
        type: "insert";
        after: string;
        markdown: string;
    } | {
        type: "replace";
        blockId: string;
        ifHash: string;
        markdown: string;
    };
    summary: string;
    replacementMarkdown: string;
    status: "pending" | "accepted" | "rejected" | "conflict";
    createdAt: string;
};
type TurnRecord = {
    id: string;
    conversationId: string;
    documentId?: string;
    documentIds?: string[];
    question: string;
    intent: QuestionIntent;
    anchor?: TextAnchor;
    target?: EditTarget;
    status: "running" | "completed" | "failed" | "cancelled";
    answerMarkdown?: string;
    appliedEdits?: number;
    evidence?: EvidenceReference[];
    proposalId?: string;
    structureProposalId?: string;
    duplicateOfTurnId?: string;
    error?: string;
    createdAt: string;
};
type LearnEvent = {
    sequence: number;
    type: string;
    at: string;
    payload: Record<string, unknown>;
};
type ReceiptBase = {
    id: string;
    at: string;
};
type TurnReceipt = ReceiptBase & {
    kind: "turn";
    turn: TurnRecord;
    proposal?: Proposal;
    structureProposal?: StructureProposal;
};
type ConversationMetadata = {
    id: string;
    title: string;
    pinned: boolean;
    archived: boolean;
};
type ConversationSummary = ConversationMetadata & {
    createdAt: string;
    updatedAt: string;
    documentId?: string;
    status: TurnRecord["status"];
};
type ConversationReceipt = ReceiptBase & {
    kind: "conversation";
    conversation: ConversationMetadata;
};
type DecisionReceipt = ReceiptBase & {
    kind: "decision";
    proposalKind: "document" | "structure";
    proposalId: string;
    turnId: string;
    decision: "accepted" | "rejected";
};
type MutationReceipt = ReceiptBase & {
    kind: "mutation";
    source: "human" | "proposal" | "structure" | "revert";
    summary: string;
    files: string[];
    git: {
        status: "committed";
        commit: string;
    } | {
        status: "unavailable" | "failed";
        message: string;
    };
    revertedReceiptId?: string;
};
type AuditReceipt = TurnReceipt | DecisionReceipt | MutationReceipt | ConversationReceipt;
type RevertPreview = {
    receiptId: string;
    commit: string;
    files: string[];
    patch: string;
    canApply: boolean;
    conflict?: string;
};

type DocumentBlock = {
    id: string;
    markdown: string;
    hash: string;
    sourceOnly: boolean;
    from: number;
    to: number;
};
type BlockOperation = {
    type: "insert";
    after: string | null;
    markdown: string;
} | {
    type: "replace" | "delete";
    blockId: string;
    ifHash: string;
    markdown?: string;
};
type DocumentEditOperation = {
    type: "insert";
    after: string | null;
} | {
    type: "replace";
    blockId: string;
    ifHash: string;
};
type DocumentEditEvent = {
    editId: string;
} & ({
    type: "started";
    operation: DocumentEditOperation;
} | {
    type: "delta";
    delta: string;
    offset: number;
} | {
    type: "committed";
    revision: number;
    blockIds: string[];
} | {
    type: "aborted";
    reason: string;
});
type CollaborationSnapshot = {
    state: string;
    vector: string;
    revision: number;
    blocks: DocumentBlock[];
    document: DocumentSnapshot;
};
interface CollaborationPort {
    read(id: string): Promise<CollaborationSnapshot>;
    sync(id: string, update: string, vector: string): Promise<CollaborationSnapshot>;
    operate(id: string, operations: BlockOperation[], signal?: AbortSignal): Promise<CollaborationSnapshot & {
        insertedBlockIds: string[];
    }>;
    replace(id: string, body: string, expectedHash: string): Promise<DocumentSnapshot>;
}

type EventSink = (event: LearnEvent) => void;
interface EventPort {
    publish(type: string, payload: Record<string, unknown>): LearnEvent;
    subscribe(sink: EventSink, after?: number): () => void;
    close(): void;
}

type RuntimeDocument = Pick<CollaborationSnapshot, "revision" | "blocks"> & {
    document?: DocumentSnapshot;
};
type RuntimeCallbacks = {
    onProgress: (message: string) => void;
    onDelta: (delta: string) => void;
    onEdit?: (event: DocumentEditEvent) => void;
    document?: {
        read(): Promise<RuntimeDocument>;
        apply(operation: BlockOperation): Promise<RuntimeDocument & {
            insertedBlockIds: string[];
        }>;
    };
    workspace?: {
        open(documentId: string): Promise<RuntimeDocument>;
        create(document: DocumentMetadata, body: string): Promise<RuntimeDocument>;
        update(title: string, summary: string): Promise<RuntimeDocument>;
    };
};
interface RuntimePort {
    readonly available: boolean;
    health(): Promise<RuntimeHealth>;
    run(request: RuntimeRequest, callbacks: RuntimeCallbacks, signal: AbortSignal): Promise<RuntimeResult>;
    close(): void;
}

interface WorkspacePort {
    readonly site: LearnManifest["site"];
    readonly manifestHash: string;
    readonly documentRoots: string[];
    initialize(): Promise<void>;
    listDocuments(): DocumentMetadata[];
    getWatchPaths(): string[];
    getDocument(id: string): Promise<DocumentSnapshot>;
    saveDocument(id: string, body: string, expectedHash: string): Promise<DocumentSnapshot>;
    applyStructure(operations: StructureOperation[], expectedManifestHash: string): Promise<StructureMutationResult>;
    searchDocuments(query: string, limit?: number): Promise<SearchResult[]>;
    fingerprintDocument(relativePath: string): Promise<string>;
}

type GitCommitResult = {
    status: "committed";
    commit: string;
} | {
    status: "unavailable" | "failed";
    message: string;
};
interface HistoryPort {
    initialize(): Promise<void>;
    commit(files: string[], message: string): Promise<GitCommitResult>;
    previewRevert(receiptId: string, commit: string, files: string[]): Promise<RevertPreview>;
    applyRevert(receiptId: string, commit: string, files: string[]): Promise<GitCommitResult>;
}

interface ReceiptPort {
    initialize(): Promise<void>;
    append(receipt: AuditReceipt): Promise<void>;
    list(): AuditReceipt[];
    get(id: string): AuditReceipt | undefined;
}

declare class LearnEngine {
    readonly store: WorkspacePort;
    readonly events: EventPort;
    runtime: RuntimePort;
    readonly receipts: ReceiptPort;
    readonly history: HistoryPort;
    readonly collaboration?: CollaborationPort | undefined;
    private readonly turns;
    private readonly proposals;
    private readonly structureProposals;
    private readonly hashes;
    private runtimeHealth;
    private activeTurnId?;
    private activeAbortController?;
    private changingRuntime;
    private conversationWrites;
    private lastReceiptTime;
    constructor(store: WorkspacePort, events: EventPort, runtime: RuntimePort, receipts?: ReceiptPort, history?: HistoryPort, collaboration?: CollaborationPort | undefined);
    initialize(): Promise<void>;
    getWorkspace(): WorkspaceSnapshot;
    changeRuntime(next: RuntimePort, persist: () => Promise<void>): Promise<RuntimeHealth>;
    saveDocument(id: string, body: string, expectedHash: string, source?: "human" | "proposal"): Promise<DocumentSnapshot>;
    listReceipts(): AuditReceipt[];
    listConversations(query?: string): ConversationSummary[];
    updateConversation(id: string, input: Record<string, unknown>): Promise<ConversationSummary>;
    previewRevert(receiptId: string): Promise<RevertPreview>;
    revertReceipt(receiptId: string): Promise<{
        receipt: MutationReceipt;
        workspace: WorkspaceSnapshot;
    }>;
    documentChangedExternally(id: string): Promise<void>;
    createQuestion(request: QuestionRequest): TurnRecord;
    getTurn(id: string): TurnRecord;
    getProposal(id: string): Proposal;
    getStructureProposal(id: string): StructureProposal;
    search(query: string, limit?: number): Promise<SearchResult[]>;
    getInsights(): WorkspaceInsights;
    acceptProposal(id: string): Promise<{
        proposal: Proposal;
        document: DocumentSnapshot;
    }>;
    rejectProposal(id: string): Promise<Proposal>;
    acceptStructureProposal(id: string): Promise<{
        proposal: StructureProposal;
        workspace: StructureMutationResult;
    }>;
    rejectStructureProposal(id: string): Promise<StructureProposal>;
    refreshEvidence(turnId: string): Promise<EvidenceReference[]>;
    cancelTurn(id: string): Promise<TurnRecord>;
    close(): void;
    private executeTurn;
    private refreshDocumentHashes;
    private recordMutation;
    private recordDecision;
    private persistTurn;
    private appendReceipt;
    private requireMutationReceipt;
    private captureEvidence;
    private normalizeQuestion;
    private validateAnchor;
}

declare function createLearnEngine(options: {
    repositoryRoot: string;
    profile?: "interactive" | "static";
    runtime?: RuntimePort;
}): Promise<LearnEngine>;

type QuestionOutcome = {
    turn: TurnRecord;
    proposal?: Proposal;
    structureProposal?: StructureProposal;
};
declare class LearnWorkbenchSdk {
    private readonly engine;
    constructor(engine: Awaited<ReturnType<typeof createLearnEngine>>);
    blocks(id: string): Promise<CollaborationSnapshot>;
    applyOperations(id: string, operations: BlockOperation[]): Promise<CollaborationSnapshot & {
        insertedBlockIds: string[];
    }>;
    workspace(): WorkspaceSnapshot;
    document(id: string): Promise<DocumentSnapshot>;
    search(query: string, limit?: number): Promise<SearchResult[]>;
    insights(): WorkspaceInsights;
    saveDocument(id: string, body: string, expectedHash: string): Promise<DocumentSnapshot>;
    acceptProposal(id: string): Promise<{
        proposal: Proposal;
        document: DocumentSnapshot;
    }>;
    rejectProposal(id: string): Promise<Proposal>;
    acceptStructureProposal(id: string): Promise<{
        proposal: StructureProposal;
        workspace: StructureMutationResult;
    }>;
    rejectStructureProposal(id: string): Promise<StructureProposal>;
    refreshEvidence(turnId: string): Promise<EvidenceReference[]>;
    receipts(): AuditReceipt[];
    previewRevert(receiptId: string): Promise<RevertPreview>;
    revertReceipt(receiptId: string): Promise<{
        receipt: MutationReceipt;
        workspace: WorkspaceSnapshot;
    }>;
    subscribe(listener: (event: LearnEvent) => void, afterSequence?: number): () => void;
    ask(request: QuestionRequest, options?: {
        signal?: AbortSignal;
        timeoutMs?: number;
    }): Promise<QuestionOutcome>;
    close(): void;
}
declare function createLearnWorkbench(options: {
    repositoryRoot: string;
    runtime?: RuntimePort;
}): Promise<LearnWorkbenchSdk>;

export { type AuditReceipt, type BlockOperation, type CollaborationSnapshot, type DocumentBlock, type DocumentSnapshot, type EditTarget, type EvidenceReference, type LearnEvent, LearnWorkbenchSdk, type MutationReceipt, type Proposal, type QuestionOutcome, type QuestionRequest, type RevertPreview, type RuntimeCallbacks, type RuntimePort, type SearchResult, type StructureProposal, type TurnRecord, type WorkspaceInsights, type WorkspaceSnapshot, createLearnWorkbench };
