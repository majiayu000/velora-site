#!/usr/bin/env node
import {
  createLearnWorkbench
} from "../chunk-UUGBXLTX.js";
import {
  initializeWorkspace,
  startLocalServer
} from "../chunk-QMVRR7PV.js";
import {
  LearnError,
  WorkspaceStore,
  asLearnError,
  createRuntimeAdapter,
  readLearnConfig,
  redactDiagnostic
} from "../chunk-GGWWOELB.js";

// src/cli/main.ts
import { realpathSync } from "fs";
import path from "path";
import { pathToFileURL } from "url";

// src/integrations/deep-link.ts
function createLearningLink(input) {
  const origin = input.origin ?? "http://127.0.0.1:4178";
  const parsed = new URL(origin);
  if (!["127.0.0.1", "localhost"].includes(parsed.hostname) || parsed.protocol !== "http:") throw new LearnError("INVALID_LINK_ORIGIN", "Deep-link origin must be loopback HTTP", 422);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(input.documentId)) throw new LearnError("INVALID_DOCUMENT_ID", "documentId must use lowercase kebab-case", 422);
  const params = new URLSearchParams();
  if (input.edit) params.set("edit", "1");
  if (input.question?.trim()) params.set("ask", input.question.trim());
  if (input.path?.trim()) params.set("path", input.path.trim());
  if (input.line !== void 0) {
    if (!Number.isInteger(input.line) || input.line < 1) throw new LearnError("INVALID_LINE", "line must be a positive integer", 422);
    params.set("line", String(input.line));
  }
  return `${parsed.origin}/#/doc/${encodeURIComponent(input.documentId)}${params.size ? `?${params}` : ""}`;
}

// src/diagnostics/doctor.ts
import { spawn } from "child_process";
function command(command2, args, cwd, timeoutMs = 5e3) {
  return new Promise((resolve) => {
    const child = spawn(command2, args, { cwd, stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    let settled = false;
    const settleCommand = (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      resolve({ code, stdout, stderr });
    };
    const timeout = setTimeout(() => {
      child.kill("SIGTERM");
      settleCommand(124);
    }, timeoutMs);
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk) => {
      stdout = `${stdout}${chunk}`.slice(-2e3);
    });
    child.stderr.on("data", (chunk) => {
      stderr = `${stderr}${chunk}`.slice(-2e3);
    });
    child.once("error", (error) => {
      stderr = error.message;
      settleCommand(127);
    });
    child.once("close", (code) => settleCommand(code ?? 1));
  });
}
async function runDoctor(repositoryRoot) {
  const checks = [];
  const [major, minor] = process.versions.node.split(".").map(Number);
  const nodeSupported = major === 20 && minor >= 19 || major >= 22 && major < 27 && (major !== 22 || minor >= 12);
  checks.push({ name: "node", status: nodeSupported ? "pass" : "fail", message: `Node ${process.versions.node}; supported range is ^20.19.0 or >=22.12.0 <27` });
  try {
    const { config, manifestPath } = await readLearnConfig(repositoryRoot);
    checks.push({ name: "config", status: "pass", message: "learn.config.json satisfies v1 and manifest containment rules" });
    const store = new WorkspaceStore(repositoryRoot, manifestPath, config.documentSizeLimitBytes);
    await store.initialize();
    checks.push({ name: "workspace", status: "pass", message: `${store.listDocuments().length} registered Markdown document(s) validated` });
    const git = await command("git", ["rev-parse", "--is-inside-work-tree"], repositoryRoot);
    const gitAvailable = git.code === 0 && git.stdout.trim() === "true";
    checks.push({ name: "git", status: gitAvailable ? "pass" : "warn", message: gitAvailable ? "Git worktree available for exact-file history" : "Git unavailable; receipts work but reviewed revert is disabled" });
    const runtime = createRuntimeAdapter(repositoryRoot, "interactive", config.runtime);
    try {
      const health = await runtime.health();
      checks.push({ name: "runtime", status: health.available ? "pass" : "fail", message: health.available ? `${health.adapter}${health.version ? ` ${health.version}` : ""} is ready` : redactDiagnostic(health.message ?? "Runtime unavailable") });
    } finally {
      runtime.close();
    }
  } catch (error) {
    const message = redactDiagnostic(error instanceof Error ? error.message : String(error));
    const name = checks.some((check) => check.name === "config") ? "workspace" : "config";
    checks.push({ name, status: "fail", message });
  }
  return { ok: checks.every((check) => check.status !== "fail"), checks };
}

// src/cli/main.ts
function takeOption(args, name) {
  const index = args.indexOf(name);
  if (index < 0) return void 0;
  const value = args[index + 1];
  if (!value || value.startsWith("--")) throw new Error(`${name} requires a value`);
  args.splice(index, 2);
  return value;
}
async function runCli(argv, io = { stdout: console.log, stderr: console.error }) {
  const args = [...argv];
  let root;
  try {
    root = path.resolve(takeOption(args, "--root") ?? process.cwd());
  } catch (error) {
    io.stderr(error instanceof Error ? error.message : String(error));
    return 2;
  }
  const command2 = args.shift();
  if (!command2 || command2 === "help" || command2 === "--help") {
    io.stdout("learn-workbench [--root PATH] init --title TITLE | doctor | serve [--port 4178] | dev [--port 4178] | build-site --documents ID,ID [--site-url URL] [--out DIR] | link DOCUMENT [QUESTION] [--path FILE --line N] | workspace | document ID | search QUERY | insights | ask DOCUMENT QUESTION [--revise] [--accept]");
    return 0;
  }
  try {
    if (command2 === "init") {
      const title = takeOption(args, "--title");
      const description = takeOption(args, "--description");
      if (!title || args.length) throw new Error("init requires --title and accepts optional --description");
      io.stdout(JSON.stringify({ created: await initializeWorkspace(root, { title, description }) }, null, 2));
      return 0;
    }
    if (command2 === "link") {
      const pathValue = takeOption(args, "--path");
      const lineRaw = takeOption(args, "--line");
      const origin = takeOption(args, "--origin");
      const editIndex = args.indexOf("--edit");
      const edit = editIndex >= 0;
      if (edit) args.splice(editIndex, 1);
      const documentId = args.shift();
      if (!documentId) throw new Error("link requires a document ID");
      io.stdout(createLearningLink({ origin, documentId, question: args.join(" ") || void 0, path: pathValue, line: lineRaw ? Number(lineRaw) : void 0, edit }));
      return 0;
    }
    if (command2 === "doctor") {
      if (args.length) throw new Error("doctor takes no arguments");
      const report = await runDoctor(root);
      io.stdout(JSON.stringify(report, null, 2));
      return report.ok ? 0 : 1;
    }
    if (command2 === "build-site") {
      const out = path.resolve(root, takeOption(args, "--out") ?? ".learn/site");
      const documents = takeOption(args, "--documents");
      const siteUrl = takeOption(args, "--site-url");
      if (!documents?.trim()) throw new LearnError("PUBLIC_DOCUMENTS_REQUIRED", "\u8BF7\u7528 --documents \u9009\u62E9\u516C\u5F00\u6587\u6863 ID\uFF0C\u591A\u4E2A ID \u7528\u9017\u53F7\u5206\u9694", 422);
      if (args.length) throw new Error("build-site accepts --documents, --site-url and --out");
      const { buildStandaloneSite } = await import("../standalone-vite-JY3GBQ3X.js");
      await buildStandaloneSite(root, out, { documentIds: documents.split(",").map((id) => id.trim()).filter(Boolean), siteUrl });
      io.stdout(JSON.stringify({ outDir: out }, null, 2));
      return 0;
    }
    if (command2 === "dev" || command2 === "serve") {
      const portRaw = takeOption(args, "--port") ?? process.env.LEARN_PORT;
      if (args.length) throw new Error(`${command2} accepts only --port`);
      const port = portRaw ? Number(portRaw) : 4178;
      if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("port must be between 1 and 65535");
      const server = command2 === "dev" ? await (await import("../standalone-vite-JY3GBQ3X.js")).startStandaloneDevServer(root, port) : await startLocalServer([root], { port });
      io.stdout(`${server.origin}/`);
      await new Promise((resolve) => {
        const stop = () => {
          process.off("SIGINT", stop);
          process.off("SIGTERM", stop);
          void server.close().then(resolve);
        };
        process.on("SIGINT", stop);
        process.on("SIGTERM", stop);
      });
      return 0;
    }
  } catch (error) {
    const known = asLearnError(error);
    io.stderr(JSON.stringify({ error: { code: known.code, message: known.message, details: known.details } }));
    return known.status >= 500 ? 1 : 2;
  }
  let sdk;
  try {
    sdk = await createLearnWorkbench({ repositoryRoot: root });
    let result;
    if (command2 === "workspace") result = sdk.workspace();
    else if (command2 === "document") {
      const id = args.shift();
      if (!id || args.length) throw new Error("document requires exactly one ID");
      result = await sdk.document(id);
    } else if (command2 === "search") {
      if (!args.length) throw new Error("search requires a query");
      result = await sdk.search(args.join(" "));
    } else if (command2 === "insights") {
      if (args.length) throw new Error("insights takes no arguments");
      result = sdk.insights();
    } else if (command2 === "ask") {
      const revise = args.includes("--revise");
      const accept = args.includes("--accept");
      const positional = args.filter((arg) => arg !== "--revise" && arg !== "--accept");
      const documentId = positional.shift();
      if (!documentId || !positional.length) throw new Error("ask requires a document ID and question");
      const outcome = await sdk.ask({ documentId, question: positional.join(" "), intent: revise ? "revise" : "answer" });
      if (accept) {
        if (outcome.proposal) result = { ...outcome, accepted: await sdk.acceptProposal(outcome.proposal.id) };
        else if (outcome.structureProposal) result = { ...outcome, accepted: await sdk.acceptStructureProposal(outcome.structureProposal.id) };
        else throw new Error("Runtime did not return a proposal to accept");
      } else result = outcome;
    } else throw new Error(`Unknown command: ${command2}`);
    io.stdout(JSON.stringify(result, null, 2));
    return 0;
  } catch (error) {
    const known = asLearnError(error);
    io.stderr(JSON.stringify({ error: { code: known.code, message: known.message, details: known.details } }));
    return known.status >= 500 ? 1 : 2;
  } finally {
    sdk?.close();
  }
}
if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  process.exitCode = await runCli(process.argv.slice(2));
}
export {
  runCli
};
//# sourceMappingURL=main.js.map