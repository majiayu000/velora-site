import {
  LearnError,
  createLearnEngine
} from "./chunk-GGWWOELB.js";

// src/sdk/index.ts
var LearnWorkbenchSdk = class {
  constructor(engine) {
    this.engine = engine;
  }
  blocks(id) {
    if (!this.engine.collaboration) throw new LearnError("STATIC_BUILD", "Collaboration is unavailable", 405);
    return this.engine.collaboration.read(id);
  }
  applyOperations(id, operations) {
    if (!this.engine.collaboration) throw new LearnError("STATIC_BUILD", "Collaboration is unavailable", 405);
    return this.engine.collaboration.operate(id, operations);
  }
  workspace() {
    return this.engine.getWorkspace();
  }
  document(id) {
    return this.engine.store.getDocument(id);
  }
  search(query, limit) {
    return this.engine.search(query, limit);
  }
  insights() {
    return this.engine.getInsights();
  }
  saveDocument(id, body, expectedHash) {
    return this.engine.saveDocument(id, body, expectedHash);
  }
  acceptProposal(id) {
    return this.engine.acceptProposal(id);
  }
  rejectProposal(id) {
    return this.engine.rejectProposal(id);
  }
  acceptStructureProposal(id) {
    return this.engine.acceptStructureProposal(id);
  }
  rejectStructureProposal(id) {
    return this.engine.rejectStructureProposal(id);
  }
  refreshEvidence(turnId) {
    return this.engine.refreshEvidence(turnId);
  }
  receipts() {
    return this.engine.listReceipts();
  }
  previewRevert(receiptId) {
    return this.engine.previewRevert(receiptId);
  }
  revertReceipt(receiptId) {
    return this.engine.revertReceipt(receiptId);
  }
  subscribe(listener, afterSequence = 0) {
    return this.engine.events.subscribe(listener, afterSequence);
  }
  async ask(request, options = {}) {
    const timeoutMs = options.timeoutMs ?? 12e4;
    let turnId = "";
    let unsubscribe = () => void 0;
    let timeout;
    let abortListener;
    try {
      const outcome = new Promise((resolve, reject) => {
        const finalizeTurn = (error) => {
          if (!turnId) return;
          const turn2 = this.engine.getTurn(turnId);
          if (turn2.status === "running") return;
          if (error) {
            reject(error);
            return;
          }
          if (turn2.status === "failed") {
            reject(new LearnError("TURN_FAILED", turn2.error ?? "Agent turn failed", 502));
            return;
          }
          if (turn2.status === "cancelled") {
            reject(new LearnError("TURN_CANCELLED", turn2.error ?? "Agent turn cancelled", 409));
            return;
          }
          resolve({
            turn: turn2,
            proposal: turn2.proposalId ? this.engine.getProposal(turn2.proposalId) : void 0,
            structureProposal: turn2.structureProposalId ? this.engine.getStructureProposal(turn2.structureProposalId) : void 0
          });
        };
        unsubscribe = this.engine.events.subscribe((event) => {
          if (["turn.completed", "turn.failed", "turn.cancelled"].includes(event.type) && event.payload.turn?.id === turnId) finalizeTurn();
        });
        const turn = this.engine.createQuestion(request);
        turnId = turn.id;
        timeout = setTimeout(() => {
          void this.engine.cancelTurn(turnId).finally(() => reject(new LearnError("TURN_TIMEOUT", "Agent turn timed out", 504)));
        }, timeoutMs);
        abortListener = () => {
          void this.engine.cancelTurn(turnId);
        };
        options.signal?.addEventListener("abort", abortListener, { once: true });
      });
      return await outcome;
    } finally {
      unsubscribe();
      if (timeout) clearTimeout(timeout);
      if (abortListener) options.signal?.removeEventListener("abort", abortListener);
    }
  }
  close() {
    this.engine.close();
  }
};
async function createLearnWorkbench(options) {
  return new LearnWorkbenchSdk(await createLearnEngine({ repositoryRoot: options.repositoryRoot, runtime: options.runtime }));
}

export {
  LearnWorkbenchSdk,
  createLearnWorkbench
};
//# sourceMappingURL=chunk-UUGBXLTX.js.map