import {
  LearnError,
  WorkspaceStore,
  asLearnError,
  createLearnEngine,
  createRuntimeAdapter,
  readLearnConfig
} from "./chunk-GGWWOELB.js";

// src/installer/init-workspace.ts
import { promises as fs } from "fs";
import path from "path";
import { randomUUID } from "crypto";
async function initializeWorkspace(rootInput, options) {
  const root = await fs.realpath(rootInput);
  const title = options.title.trim();
  if (!title || title.length > 160) throw new LearnError("INVALID_TITLE", "title must contain 1 to 160 characters", 422);
  const targets = ["learn.config.json", "learn.manifest.json", "docs/learn/start-here.md"];
  for (const relative of targets) {
    try {
      await fs.lstat(path.join(root, relative));
      throw new LearnError("INIT_TARGET_EXISTS", `\u6587\u4EF6\u5939\u4E2D\u5DF2\u6709 ${relative}\uFF0C\u5DF2\u4FDD\u7559\u539F\u6587\u4EF6\u3002\u8BF7\u68C0\u67E5\u662F\u5426\u4E3A\u672A\u5B8C\u6210\u7684\u5B66\u4E60\u7A7A\u95F4\u3002`, 409);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }
  const stage = path.join(root, `.learn-init-${randomUUID()}`);
  const created = [];
  const config = { version: 1, manifest: "learn.manifest.json", documentSizeLimitBytes: 1048576, runtime: { adapter: "codex-app-server", command: "codex" } };
  const manifest = { version: 1, site: { title, description: options.description?.trim() || "Evidence-backed notes about this project" }, contentRoots: ["docs"], documents: [{ id: "start-here", path: "docs/learn/start-here.md", title: "Start Here", summary: "What this project does and how to learn it", stage: "00", tags: ["overview"], prerequisites: [], related: [] }] };
  const starter = `# Start Here

> \u8FD9\u91CC\u4FDD\u5B58\u56F4\u7ED5 ${title} \u9010\u6B65\u79EF\u7D2F\u7684\u5B66\u4E60\u5185\u5BB9\u3002Agent \u901A\u8FC7\u5DE5\u4F5C\u53F0\u63D0\u4F9B\u7684\u6587\u6863\u548C\u6307\u5357\u670D\u52A1\uFF0C\u4E0D\u8BFB\u53D6\u672C\u5730\u6E90\u7801\u3002

## \u4ECE\u4E00\u4E2A\u95EE\u9898\u5F00\u59CB

- \u6211\u5E0C\u671B\u7406\u89E3\u4EC0\u4E48\uFF1F
- \u5DF2\u6709\u54EA\u4E9B\u6750\u6599\u548C\u524D\u7F6E\u77E5\u8BC6\uFF1F
- \u600E\u6837\u7528\u4E00\u4E2A\u4F8B\u5B50\u6216\u7EC3\u4E60\u68C0\u9A8C\u7406\u89E3\uFF1F

\u63D0\u51FA\u5177\u4F53\u95EE\u9898\uFF0C\u7ED3\u5408\u63D0\u4F9B\u7684\u6750\u6599\u533A\u5206\u5DF2\u786E\u8BA4\u4FE1\u606F\u3001\u63A8\u65AD\u548C\u672A\u77E5\uFF0C\u518D\u628A\u6709\u4EF7\u503C\u7684\u5185\u5BB9\u4FDD\u5B58\u5230\u5B66\u4E60\u6587\u6863\u4E2D\u3002
`;
  try {
    await fs.mkdir(path.join(stage, "docs/learn"), { recursive: true, mode: 448 });
    await fs.writeFile(path.join(stage, "learn.config.json"), `${JSON.stringify(config, null, 2)}
`, { encoding: "utf8", flag: "wx", mode: 384 });
    await fs.writeFile(path.join(stage, "learn.manifest.json"), `${JSON.stringify(manifest, null, 2)}
`, { encoding: "utf8", flag: "wx", mode: 384 });
    await fs.writeFile(path.join(stage, "docs/learn/start-here.md"), starter, { encoding: "utf8", flag: "wx", mode: 384 });
    await fs.mkdir(path.join(root, "docs/learn"), { recursive: true });
    for (const relative of targets) {
      await fs.link(path.join(stage, relative), path.join(root, relative));
      created.push(relative);
    }
    return targets;
  } catch (error) {
    for (const relative of created.reverse()) await fs.rm(path.join(root, relative), { force: true });
    throw new LearnError("INIT_FAILED", "\u65E0\u6CD5\u5728\u6587\u4EF6\u5939\u4E2D\u521B\u5EFA\u5B66\u4E60\u7A7A\u95F4\uFF0C\u8BF7\u68C0\u67E5\u5199\u5165\u6743\u9650\u548C\u73B0\u6709\u6587\u4EF6\u3002", 500, {
      cause: error instanceof Error ? error.message : String(error)
    });
  } finally {
    await fs.rm(stage, { recursive: true, force: true });
  }
}

// src/server/local-server.ts
import { promises as fs4 } from "fs";
import { createServer } from "http";
import path5 from "path";
import { fileURLToPath } from "url";

// src/server/local-workbench.ts
import { randomBytes } from "crypto";
import { promises as fs3, watch } from "fs";
import path4 from "path";

// src/server/native-folder-picker.ts
import { execFile } from "child_process";
import { randomUUID as randomUUID2 } from "crypto";
import { mkdtemp, readFile, rm } from "fs/promises";
import { tmpdir } from "os";
import path2 from "path";
import { promisify } from "util";
var exec = promisify(execFile);
var pickerApp;
var script = `use framework "Foundation"
use scripting additions
on run
  set args to current application's NSProcessInfo's processInfo()'s arguments()
  if (args's |count|()) < 2 then return
  set outputPath to (args's objectAtIndex:1) as text
  set reply to current application's NSMutableDictionary's dictionary()
  activate
  try
    set selectedPath to POSIX path of (choose folder with prompt "\u9009\u62E9\u5B66\u4E60\u7A7A\u95F4\u6587\u4EF6\u5939")
    reply's setObject:selectedPath forKey:"root"
  on error errorMessage number errorNumber
    if errorNumber is -128 then
      reply's setObject:"" forKey:"root"
    else
      reply's setObject:errorMessage forKey:"error"
    end if
  end try
  set outputData to current application's NSJSONSerialization's dataWithJSONObject:reply options:0 |error|:(missing value)
  outputData's writeToFile:outputPath atomically:true
end run`;
async function createPickerApp() {
  const directory = await mkdtemp(path2.join(tmpdir(), "headwater-folder-picker-"));
  const app = path2.join(directory, "HeadwaterFolderPicker.app");
  await exec("/usr/bin/osacompile", ["-o", app, "-e", script], { timeout: 2e4 });
  const plist = path2.join(app, "Contents", "Info.plist");
  await exec("/usr/bin/plutil", ["-insert", "CFBundleIdentifier", "-string", "local.headwater.folder-picker", plist]);
  await exec("/usr/bin/plutil", ["-insert", "CFBundleDisplayName", "-string", "\u89C2\u6F9C\u6587\u4EF6\u5939\u9009\u62E9", plist]);
  await exec("/usr/bin/codesign", ["--force", "--sign", "-", app]);
  return app;
}
async function chooseLocalFolder() {
  if (process.platform !== "darwin") throw new LearnError("FOLDER_PICKER_UNAVAILABLE", "\u7CFB\u7EDF\u6587\u4EF6\u5939\u9009\u62E9\u5668\u5F53\u524D\u652F\u6301 macOS\uFF0C\u8BF7\u624B\u52A8\u8F93\u5165\u8DEF\u5F84\u3002", 501);
  let output;
  try {
    pickerApp ??= createPickerApp().catch((error) => {
      pickerApp = void 0;
      throw error;
    });
    const app = await pickerApp;
    output = path2.join(path2.dirname(app), `${randomUUID2()}.json`);
    await exec("/usr/bin/open", ["-W", "-n", app, "--args", output]);
    const result = JSON.parse(await readFile(output, "utf8"));
    if (result.error) throw new Error(result.error);
    return result.root || null;
  } catch (error) {
    throw new LearnError("FOLDER_PICKER_FAILED", "\u65E0\u6CD5\u6253\u5F00\u7CFB\u7EDF\u6587\u4EF6\u5939\u9009\u62E9\u5668\uFF0C\u8BF7\u91CD\u8BD5\u6216\u624B\u52A8\u8F93\u5165\u8DEF\u5F84\u3002", 500, {
      cause: error instanceof Error ? error.message : String(error)
    });
  } finally {
    if (output) await rm(output, { force: true });
  }
}

// src/server/space-registry.ts
import { createHash } from "crypto";
import { promises as fs2 } from "fs";
import path3 from "path";
function publicSummary(record) {
  const { manifestPath: _manifestPath, ...summary } = record;
  return { ...summary };
}
var SpaceRegistry = class {
  spaces = /* @__PURE__ */ new Map();
  idsByRoot = /* @__PURE__ */ new Map();
  async register(candidateRoot, options = {}) {
    if (!path3.isAbsolute(candidateRoot)) {
      throw new LearnError("INVALID_SPACE_ROOT", "\u8BF7\u8F93\u5165\u5B8C\u6574\u7684\u6587\u4EF6\u5939\u8DEF\u5F84\uFF0C\u6216\u70B9\u51FB\u201C\u6D4F\u89C8\u6587\u4EF6\u5939\u201D\u9009\u62E9\u3002", 422);
    }
    const root = await fs2.realpath(candidateRoot).catch((error) => {
      throw new LearnError(
        "INVALID_SPACE_ROOT",
        "\u65E0\u6CD5\u8BBF\u95EE\u8FD9\u4E2A\u6587\u4EF6\u5939\uFF0C\u8BF7\u786E\u8BA4\u5B83\u4ECD\u7136\u5B58\u5728\u4E14\u6709\u8BBF\u95EE\u6743\u9650\u3002",
        422,
        { cause: error instanceof Error ? error.message : String(error) }
      );
    });
    if (!(await fs2.stat(root)).isDirectory()) throw new LearnError("INVALID_SPACE_ROOT", "\u8BF7\u9009\u62E9\u6587\u4EF6\u5939\uFF0C\u800C\u4E0D\u662F\u6587\u4EF6\u3002", 422);
    const { config, manifestPath } = await readLearnConfig(root).catch(async (error) => {
      if (!options.initialize || !(error instanceof LearnError) || error.code !== "WORKSPACE_NOT_INITIALIZED") throw error;
      await initializeWorkspace(root, { title: path3.basename(root).slice(0, 160) || "\u5B66\u4E60\u7A7A\u95F4" });
      return readLearnConfig(root);
    });
    const existingId = this.idsByRoot.get(root);
    if (existingId) return publicSummary(this.spaces.get(existingId));
    const store = new WorkspaceStore(root, manifestPath, config.documentSizeLimitBytes);
    await store.initialize();
    const id = createHash("sha256").update(root).digest("hex").slice(0, 16);
    const record = {
      id,
      root,
      title: store.site.title,
      ...store.site.description ? { description: store.site.description } : {},
      manifestPath
    };
    this.spaces.set(id, record);
    this.idsByRoot.set(root, id);
    return publicSummary(record);
  }
  list() {
    return [...this.spaces.values()].map(publicSummary);
  }
  require(id) {
    const record = this.spaces.get(id);
    if (!record) throw new LearnError("SPACE_NOT_FOUND", `Unknown learning space: ${id}`, 404);
    return publicSummary(record);
  }
};

// src/server/local-workbench.ts
function sendJson(response, status, value) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  response.end(JSON.stringify(value));
}
function writeSseEvent(response, event) {
  response.write(`id: ${event.sequence}
`);
  response.write(`event: ${event.type}
`);
  response.write(`data: ${JSON.stringify(event)}

`);
}
function streamEvents(response, events, after) {
  response.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no"
  });
  response.write(": connected\n\n");
  const unsubscribe = events.subscribe((event) => writeSseEvent(response, event), after);
  const heartbeat = setInterval(() => response.write(": heartbeat\n\n"), 2e4);
  response.once("close", () => {
    clearInterval(heartbeat);
    unsubscribe();
  });
}
async function readJson(request, limit = 1024 * 1024 + 16384) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    size += buffer.length;
    if (size > limit) throw new LearnError("REQUEST_TOO_LARGE", "Request body is too large", 413);
    chunks.push(buffer);
  }
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Expected object");
    return parsed;
  } catch {
    throw new LearnError("INVALID_JSON", "Request body must be a JSON object", 400);
  }
}
function normalizedIfMatch(value) {
  if (!value) return "";
  return value.replace(/^W\//, "").replace(/^"|"$/g, "");
}
function assertLocalRequest(request, token) {
  const host = request.headers.host ?? "";
  if (!/^(127\.0\.0\.1|localhost):\d+$/.test(host)) {
    throw new LearnError("INVALID_HOST", "Velora only accepts loopback hosts", 403);
  }
  const origin = request.headers.origin;
  if (origin && origin !== `http://${host}`) {
    throw new LearnError("INVALID_ORIGIN", "Cross-origin write access is forbidden", 403);
  }
  if (request.headers.authorization !== `Bearer ${token}`) {
    throw new LearnError("UNAUTHORIZED", "Missing or invalid workspace token", 401);
  }
}
function createLocalWorkbench(initialRoots, options = {}) {
  const token = randomBytes(32).toString("base64url");
  const registry = new SpaceRegistry();
  const presence = /* @__PURE__ */ new Map();
  const enginePromises = /* @__PURE__ */ new Map();
  const watchPathsBySpace = /* @__PURE__ */ new Map();
  let initialSpacesPromise;
  const watchers = /* @__PURE__ */ new Map();
  const streams = /* @__PURE__ */ new Set();
  async function ensureInitialSpaces() {
    if (!initialSpacesPromise) {
      initialSpacesPromise = (async () => {
        for (const root of initialRoots) await registry.register(root);
      })();
    }
    return initialSpacesPromise;
  }
  async function engine(spaceId) {
    await ensureInitialSpaces();
    const space = registry.require(spaceId);
    let enginePromise = enginePromises.get(spaceId);
    if (!enginePromise) {
      enginePromise = (async () => {
        const instance = await createLearnEngine({
          repositoryRoot: space.root,
          profile: "interactive",
          runtime: options.runtimeFactory?.(space.root)
        });
        refreshWatchPaths(spaceId, instance);
        instance.events.subscribe((event) => {
          if (event.type === "workspace.changed") refreshWatchPaths(spaceId, instance);
        });
        return instance;
      })();
      enginePromises.set(spaceId, enginePromise);
    }
    return enginePromise;
  }
  function refreshWatchPaths(spaceId, app) {
    const paths = new Set(app.store.getWatchPaths());
    watchPathsBySpace.set(spaceId, paths);
    for (const file of paths) {
      const directory = path4.dirname(file);
      if (watchers.has(directory)) continue;
      const watcher = watch(directory, (_event, name) => {
        if (!name) return;
        const changed = path4.join(directory, String(name));
        for (const [id, files] of watchPathsBySpace) {
          if (!files.has(changed)) continue;
          void enginePromises.get(id)?.then(async (instance) => {
            const document = instance.store.listDocuments().find((item) => path4.resolve(registry.require(id).root, item.path) === changed);
            if (document) await instance.documentChangedExternally(document.id);
          }).catch((error) => console.error("Learn file watcher:", error));
        }
      });
      watcher.on("error", (error) => console.error("Learn file watcher:", error));
      watchers.set(directory, watcher);
    }
  }
  async function handleApi(request, response) {
    const host = request.headers.host ?? "127.0.0.1";
    const url = new URL(request.url ?? "/", `http://${host}`);
    if (!url.pathname.startsWith("/api/v1/")) return false;
    assertLocalRequest(request, token);
    const method = request.method ?? "GET";
    if (url.pathname === "/api/v1/folders/choose" && method === "POST") {
      sendJson(response, 200, { root: await chooseLocalFolder() });
      return true;
    }
    if (url.pathname === "/api/v1/spaces" && method === "GET") {
      await ensureInitialSpaces();
      sendJson(response, 200, { spaces: registry.list() });
      return true;
    }
    if (url.pathname === "/api/v1/spaces" && method === "POST") {
      await ensureInitialSpaces();
      const body = await readJson(request);
      if (typeof body.root !== "string" || !body.root.trim()) {
        throw new LearnError("INVALID_SPACE_ROOT", "root must be a non-empty absolute path", 422);
      }
      const space = await registry.register(body.root, { initialize: body.initialize === true });
      sendJson(response, 201, { space });
      return true;
    }
    const spaceRoute = url.pathname.match(/^\/api\/v1\/spaces\/([^/]+)(\/.*)?$/);
    if (!spaceRoute) throw new LearnError("NOT_FOUND", `Unknown API endpoint: ${method} ${url.pathname}`, 404);
    const spaceId = decodeURIComponent(spaceRoute[1]);
    registry.require(spaceId);
    const route = spaceRoute[2] ?? "/";
    const app = await engine(spaceId);
    if (route === "/settings" && method === "GET") {
      const { config } = await readLearnConfig(registry.require(spaceId).root);
      sendJson(response, 200, { runtime: config.runtime });
      return true;
    }
    if (route === "/settings" && method === "PUT") {
      const body = await readJson(request);
      const runtime = body.runtime;
      if (!runtime || typeof runtime !== "object" || typeof runtime.adapter !== "string" || typeof runtime.command !== "string" || !runtime.command.trim() || runtime.args !== void 0 && (!Array.isArray(runtime.args) || runtime.args.some((arg) => typeof arg !== "string"))) {
        throw new LearnError("INVALID_CONFIG", "\u8BF7\u9009\u62E9 Agent \u5E76\u586B\u5199\u6709\u6548\u7684\u7A0B\u5E8F\u8DEF\u5F84\u3002", 422);
      }
      const root = registry.require(spaceId).root;
      const selected = { adapter: runtime.adapter, command: runtime.command.trim(), ...runtime.args ? { args: runtime.args } : {} };
      const next = createRuntimeAdapter(root, "interactive", selected);
      const health = await app.changeRuntime(next, async () => {
        const { configPath } = await readLearnConfig(root);
        const config = JSON.parse(await fs3.readFile(configPath, "utf8"));
        config.runtime = selected;
        const temporary = `${configPath}.${randomBytes(8).toString("hex")}.tmp`;
        try {
          await fs3.writeFile(temporary, `${JSON.stringify(config, null, 2)}
`, { mode: 384 });
          await fs3.rename(temporary, configPath);
        } finally {
          await fs3.rm(temporary, { force: true });
        }
      });
      sendJson(response, 200, { runtime: selected, health });
      return true;
    }
    if (method === "GET" && route === "/health") {
      sendJson(response, 200, { ok: true, runtime: app.getWorkspace().runtime });
      return true;
    }
    if (method === "GET" && route === "/workspace") {
      sendJson(response, 200, app.getWorkspace());
      return true;
    }
    if (method === "GET" && route === "/documents") {
      sendJson(response, 200, { documents: app.getWorkspace().documents });
      return true;
    }
    if (method === "GET" && route === "/search") {
      sendJson(response, 200, { results: await app.search(url.searchParams.get("q") ?? "", Number(url.searchParams.get("limit") ?? 20)) });
      return true;
    }
    if (method === "GET" && route === "/insights") {
      sendJson(response, 200, app.getInsights());
      return true;
    }
    const collaborationMatch = route.match(/^\/documents\/([^/]+)\/(collaboration|operations)$/);
    if (collaborationMatch && app.collaboration) {
      const id = decodeURIComponent(collaborationMatch[1]);
      if (method === "GET" && collaborationMatch[2] === "collaboration") {
        sendJson(response, 200, await app.collaboration.read(id));
        return true;
      }
      if (method === "POST") {
        const body = await readJson(request, 13 * 1024 * 1024);
        const result = collaborationMatch[2] === "operations" ? await app.collaboration.operate(id, body.operations) : await app.collaboration.sync(id, body.update, body.vector);
        const key = `${spaceId}:${id}`;
        const peers = presence.get(key) ?? /* @__PURE__ */ new Map();
        presence.set(key, peers);
        const person = body.presence;
        if (person && typeof person.session === "string" && /^[a-f0-9-]{36}$/.test(person.session)) peers.set(person.session, { session: person.session, blockId: typeof person.blockId === "string" ? person.blockId.slice(0, 100) : void 0, at: Date.now() });
        for (const [session, peer] of peers) if (Date.now() - peer.at > 1e4) peers.delete(session);
        sendJson(response, 200, { ...result, peers: [...peers.values()] });
        return true;
      }
    }
    const documentMatch = route.match(/^\/documents\/([^/]+)$/);
    if (documentMatch && method === "GET") {
      sendJson(response, 200, await app.store.getDocument(decodeURIComponent(documentMatch[1])));
      return true;
    }
    if (documentMatch && method === "PUT") {
      const body = await readJson(request);
      if (typeof body.body !== "string") throw new LearnError("INVALID_DOCUMENT", "body must be a string", 400);
      const snapshot = await app.saveDocument(
        decodeURIComponent(documentMatch[1]),
        body.body,
        normalizedIfMatch(request.headers["if-match"])
      );
      sendJson(response, 200, snapshot);
      return true;
    }
    if (method === "POST" && route === "/questions") {
      const body = await readJson(request);
      const turn = app.createQuestion({
        documentId: body.documentId,
        conversationId: body.conversationId,
        question: body.question,
        intent: body.intent,
        anchor: body.anchor,
        target: body.target
      });
      sendJson(response, 202, { turn });
      return true;
    }
    const turnMatch = route.match(/^\/turns\/([^/]+)$/);
    if (turnMatch && method === "GET") {
      sendJson(response, 200, { turn: app.getTurn(decodeURIComponent(turnMatch[1])) });
      return true;
    }
    const cancelMatch = route.match(/^\/turns\/([^/]+)\/cancel$/);
    if (cancelMatch && method === "POST") {
      sendJson(response, 202, { turn: await app.cancelTurn(decodeURIComponent(cancelMatch[1])) });
      return true;
    }
    const proposalMatch = route.match(/^\/proposals\/([^/]+)$/);
    if (proposalMatch && method === "GET") {
      sendJson(response, 200, { proposal: app.getProposal(decodeURIComponent(proposalMatch[1])) });
      return true;
    }
    const acceptMatch = route.match(/^\/proposals\/([^/]+)\/accept$/);
    if (acceptMatch && method === "POST") {
      sendJson(response, 200, await app.acceptProposal(decodeURIComponent(acceptMatch[1])));
      return true;
    }
    const rejectMatch = route.match(/^\/proposals\/([^/]+)\/reject$/);
    if (rejectMatch && method === "POST") {
      sendJson(response, 200, { proposal: await app.rejectProposal(decodeURIComponent(rejectMatch[1])) });
      return true;
    }
    const structureProposalMatch = route.match(/^\/structure-proposals\/([^/]+)$/);
    if (structureProposalMatch && method === "GET") {
      sendJson(response, 200, { proposal: app.getStructureProposal(decodeURIComponent(structureProposalMatch[1])) });
      return true;
    }
    const structureAcceptMatch = route.match(/^\/structure-proposals\/([^/]+)\/accept$/);
    if (structureAcceptMatch && method === "POST") {
      const result = await app.acceptStructureProposal(decodeURIComponent(structureAcceptMatch[1]));
      sendJson(response, 200, result);
      return true;
    }
    const structureRejectMatch = route.match(/^\/structure-proposals\/([^/]+)\/reject$/);
    if (structureRejectMatch && method === "POST") {
      sendJson(response, 200, { proposal: await app.rejectStructureProposal(decodeURIComponent(structureRejectMatch[1])) });
      return true;
    }
    if (method === "GET" && route === "/conversations") {
      sendJson(response, 200, { conversations: app.listConversations(url.searchParams.get("q") ?? "") });
      return true;
    }
    const conversationMatch = route.match(/^\/conversations\/([^/]+)$/);
    if (conversationMatch && method === "PATCH") {
      sendJson(response, 200, { conversation: await app.updateConversation(decodeURIComponent(conversationMatch[1]), await readJson(request)) });
      return true;
    }
    if (method === "GET" && route === "/history") {
      sendJson(response, 200, { receipts: app.listReceipts() });
      return true;
    }
    const revertPreviewMatch = route.match(/^\/history\/([^/]+)\/revert-preview$/);
    if (revertPreviewMatch && method === "GET") {
      sendJson(response, 200, await app.previewRevert(decodeURIComponent(revertPreviewMatch[1])));
      return true;
    }
    const revertMatch = route.match(/^\/history\/([^/]+)\/revert$/);
    if (revertMatch && method === "POST") {
      const result = await app.revertReceipt(decodeURIComponent(revertMatch[1]));
      sendJson(response, 200, result);
      return true;
    }
    const evidenceRefreshMatch = route.match(/^\/turns\/([^/]+)\/evidence\/refresh$/);
    if (evidenceRefreshMatch && method === "POST") {
      sendJson(response, 200, { evidence: await app.refreshEvidence(decodeURIComponent(evidenceRefreshMatch[1])) });
      return true;
    }
    if (method === "GET" && route === "/events") {
      const after = Number(url.searchParams.get("after") ?? request.headers["last-event-id"] ?? 0);
      streams.add(response);
      response.once("close", () => streams.delete(response));
      streamEvents(response, app.events, Number.isFinite(after) ? after : 0);
      return true;
    }
    throw new LearnError("NOT_FOUND", `Unknown API endpoint: ${method} ${url.pathname}`, 404);
  }
  return {
    bootstrapScript: () => `window.__LEARN_BOOTSTRAP__=${JSON.stringify({ mode: "development", apiBase: "/api/v1", token }).replaceAll("<", "\\u003c")};`,
    initialize: ensureInitialSpaces,
    async handle(request, response) {
      try {
        return await handleApi(request, response);
      } catch (error) {
        if (response.headersSent) response.end();
        else {
          const known = asLearnError(error);
          sendJson(response, known.status, { error: { code: known.code, message: known.message, details: known.details } });
        }
        return true;
      }
    },
    async close() {
      const apps = await Promise.all(enginePromises.values());
      for (const watcher of watchers.values()) watcher.close();
      watchers.clear();
      for (const stream of streams) stream.end();
      streams.clear();
      for (const app of apps) app.close();
      enginePromises.clear();
    }
  };
}

// src/server/local-server.ts
async function bundledSiteRoot() {
  const here = path5.dirname(fileURLToPath(import.meta.url));
  for (const candidate of [path5.resolve(here, "../learn"), path5.resolve(here, "../../learn")]) {
    try {
      if ((await fs4.stat(path5.join(candidate, "index.html"))).isFile()) return candidate;
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }
  throw new LearnError("WEB_ASSETS_MISSING", "Canonical web assets are missing from this installation", 500);
}
var contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf"
};
async function startLocalServer(initialRoots, options) {
  if (!Number.isInteger(options.port) || options.port < 0 || options.port > 65535) throw new LearnError("INVALID_PORT", "port must be between 0 and 65535", 422);
  const webRoot = await fs4.realpath(options.webRoot ?? path5.join(await bundledSiteRoot(), "app-dist")).catch((error) => {
    if (error.code === "ENOENT") throw new LearnError("WEB_ASSETS_MISSING", "\u53EF\u7F16\u8F91\u754C\u9762\u5C1A\u672A\u6784\u5EFA\uFF0C\u8BF7\u5148\u8FD0\u884C npm run build:app", 500);
    throw error;
  });
  const indexHtml = await fs4.readFile(path5.join(webRoot, "index.html"), "utf8");
  const workbench = createLocalWorkbench(initialRoots, options);
  await workbench.initialize();
  const server = createServer((request, response) => {
    void (async () => {
      const host = request.headers.host ?? "";
      const url = new URL(request.url ?? "/", `http://${host}`);
      if (await workbench.handle(request, response)) return;
      if (!/^(127\.0\.0\.1|localhost):\d+$/.test(host)) throw new LearnError("INVALID_HOST", "Only loopback hosts are accepted", 403);
      if (request.headers.origin && request.headers.origin !== `http://${host}`) throw new LearnError("INVALID_ORIGIN", "Cross-origin access is forbidden", 403);
      if (request.method !== "GET" && request.method !== "HEAD") throw new LearnError("NOT_FOUND", "Not found", 404);
      response.setHeader("Cache-Control", "no-store");
      response.setHeader("X-Content-Type-Options", "nosniff");
      if (url.pathname === "/favicon.ico") {
        response.writeHead(204);
        response.end();
        return;
      }
      if (url.pathname === "/__learn_bootstrap__.js") {
        const site = request.headers["sec-fetch-site"];
        if (site && site !== "same-origin" && site !== "none") throw new LearnError("INVALID_ORIGIN", "Cross-origin session access is forbidden", 403);
        response.setHeader("Cross-Origin-Resource-Policy", "same-origin");
        response.setHeader("Content-Type", "text/javascript; charset=utf-8");
        response.end(request.method === "HEAD" ? void 0 : workbench.bootstrapScript());
        return;
      }
      if (url.pathname === "/" || url.pathname === "/index.html") {
        response.setHeader("Content-Type", contentTypes[".html"]);
        const html = indexHtml.includes('src="/__learn_bootstrap__.js"') ? indexHtml : indexHtml.replace("<head>", '<head><script src="/__learn_bootstrap__.js"></script>');
        response.end(request.method === "HEAD" ? void 0 : html);
        return;
      }
      const resourcePath = path5.posix.normalize(decodeURIComponent(url.pathname));
      if (!resourcePath.startsWith("/assets/") && !resourcePath.startsWith("/fonts/")) throw new LearnError("NOT_FOUND", "Not found", 404);
      const file = await fs4.realpath(path5.resolve(webRoot, `.${resourcePath}`)).catch((error) => {
        if (error.code === "ENOENT" || error.code === "ENOTDIR") throw new LearnError("NOT_FOUND", "Not found", 404);
        throw error;
      });
      const relative = path5.relative(webRoot, file);
      if (relative.startsWith("..") || path5.isAbsolute(relative) || !(await fs4.stat(file)).isFile()) throw new LearnError("NOT_FOUND", "Not found", 404);
      response.setHeader("Content-Type", contentTypes[path5.extname(file)] ?? "application/octet-stream");
      response.end(request.method === "HEAD" ? void 0 : await fs4.readFile(file));
    })().catch((error) => {
      if (response.headersSent) {
        response.end();
        return;
      }
      const known = asLearnError(error);
      response.writeHead(known.status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
      response.end(JSON.stringify({ error: { code: known.code, message: known.message } }));
    });
  });
  try {
    await new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(options.port, "127.0.0.1", () => {
        server.off("error", reject);
        resolve();
      });
    });
  } catch (error) {
    await workbench.close();
    throw error;
  }
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("Local server did not expose a TCP address");
  return {
    origin: `http://127.0.0.1:${address.port}`,
    async close() {
      const closed = new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
      server.closeAllConnections();
      await workbench.close();
      await closed;
    }
  };
}

export {
  initializeWorkspace,
  bundledSiteRoot,
  startLocalServer
};
//# sourceMappingURL=chunk-QMVRR7PV.js.map