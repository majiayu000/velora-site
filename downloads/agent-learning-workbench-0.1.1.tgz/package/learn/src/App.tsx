import { forwardRef, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState, type FormEvent, type CSSProperties } from "react";
import staticWorkspaceRaw from "virtual:project-learning-content";
import { ApiError, createSpaceApi, isDevelopmentWorkspace, SpaceApiContext, subscribeToEvents, workbenchApi } from "./api";
import { ArtifactPanel, type ArtifactRoute as Route } from "./ArtifactPanel";
import { ConversationPanel } from "./ConversationPanel";
import { LocalSettings } from "./LocalSettings";
import { WorkbenchSidebar } from "./WorkbenchSidebar";
import { ExportSpaceDialog, SpaceMenu } from "./SpaceActions";
import { updateAiEdits, type AiEdits } from "./ai-edit";
import { SelectionActions } from "./SelectionActions";
import { captureSelectionAnchor, questionAnchor, type PositionedTextAnchor } from "./selection-anchor";
import type { ConversationSummary, EditTarget, DocumentMetadata, DocumentSnapshot, LearningSpaceSummary, LearnEvent, Proposal, StructureProposal, Turn, Workspace } from "./types";
import { closeSpaceTab, normalizeDocumentTabs, normalizeSpaceTabs, normalizeStoredWorkbench, openDocumentTab, openSpaceTab, type TabsState } from "./workbench-state";

const staticWorkspace: Workspace = staticWorkspaceRaw;
const SPACES_KEY = "learn-workbench:spaces:v2";

function readStoredTabs(key: string): unknown {
  try {
    const value = window.localStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  } catch {
    return null;
  }
}

function spaceIdFromHash(): string | undefined {
  const match = window.location.hash.match(/^#\/space\/([^/?]+)/);
  return match ? decodeURIComponent(match[1]!) : undefined;
}

function routeFromHash(spaceId?: string): Route {
  const escapedSpaceId = spaceId?.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const scoped = escapedSpaceId ? window.location.hash.match(new RegExp(`^#/space/${escapedSpaceId}/doc/([^?]+)`)) : null;
  const legacy = window.location.hash.match(/^#\/doc\/([^?]+)/);
  const match = scoped ?? legacy;
  const params = new URLSearchParams(window.location.hash.split("?")[1] ?? "");
  const base = spaceId ? `#/space/${encodeURIComponent(spaceId)}` : "#";
  const routePath = window.location.hash.split("?")[0];
  const line = Number(params.get("line"));
  return {
    documentId: match ? decodeURIComponent(match[1]) : undefined,
    conversationId: params.get("conversation") || undefined,
    edit: isDevelopmentWorkspace && !!match,
    rich: isDevelopmentWorkspace && !!match && (params.get("edit") !== "1" || params.get("mode") === "page"),
    home: isDevelopmentWorkspace && !match && !/\/(map|history|documents)$/.test(routePath),
    index: /\/documents$/.test(routePath) || (!isDevelopmentWorkspace && !match && !/\/(map|history)$/.test(routePath)),
    map: routePath === `${base}/map` || (!spaceId && routePath === "#/map"),
    history: routePath === `${base}/history` || (!spaceId && routePath === "#/history"),
    ask: params.get("ask") || undefined,
    evidencePath: params.get("path") || undefined,
    evidenceLine: Number.isInteger(line) && line > 0 ? line : undefined,
  };
}

function documentFromStatic(id: string): DocumentSnapshot | undefined {
  const candidate = staticWorkspace.documents.find((document) => document.id === id);
  if (!candidate || !("body" in candidate)) return undefined;
  return candidate as DocumentSnapshot;
}

export type LearningSpaceHandle = { requestTransition: (action: () => void) => void };

type LearningSpaceViewProps = {
  pauseEvents?: boolean;
  space?: LearningSpaceSummary;
  spaces?: LearningSpaceSummary[];
  onActivateSpace?: (id: string | null, newQuestion?: boolean) => void;
  onNavigateSpace?: (id: string, destination: string) => void;
  onOpenSpace?: () => void;
  onCloseSpace?: (id: string) => void;
};

const LearningSpaceView = forwardRef<LearningSpaceHandle, LearningSpaceViewProps>(function LearningSpaceView({ space, spaces = [], onActivateSpace, onNavigateSpace, onOpenSpace, onCloseSpace, pauseEvents = false }, ref) {
  const spaceId = space?.id;
  const api = useMemo(() => createSpaceApi(spaceId ?? "static"), [spaceId]);
  const initialWorkspace = space
    ? { site: { title: space.title, description: space.description }, documents: [], manifestHash: "", runtime: { adapter: "loading", available: false } }
    : staticWorkspace;
  const [workspace, setWorkspace] = useState<Workspace>(initialWorkspace);
  const [workspaceReady, setWorkspaceReady] = useState(!space);
  const [route, setRoute] = useState<Route>(() => routeFromHash(spaceId));
  const [documentTabs, setDocumentTabs] = useState<TabsState>({ tabs: [], active: null });
  const [document, setDocument] = useState<DocumentSnapshot>();
  const [draft, setDraft] = useState("");
  const [dirty, setDirty] = useState(false);
  const [loadingDocument, setLoadingDocument] = useState(false);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved">("idle");
  const [conflict, setConflict] = useState<string>();
  const [externalChange, setExternalChange] = useState(false);
  const [connected, setConnected] = useState(!isDevelopmentWorkspace);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [proposals, setProposals] = useState<Record<string, Proposal>>({});
  const [structureProposals, setStructureProposals] = useState<Record<string, StructureProposal>>({});
  const [progress, setProgress] = useState<Record<string, string>>({});
  const [streamingAnswers, setStreamingAnswers] = useState<Record<string, string>>({});
  const [aiEdits, setAiEdits] = useState<AiEdits>({});
  const [question, setQuestion] = useState("");
  const [anchor, setAnchor] = useState<PositionedTextAnchor>();
  const [target, setTarget] = useState<EditTarget>();
  const [questionError, setQuestionError] = useState<string>();
  const [proposalPreview, setProposalPreview] = useState<string>();
  const [proposalDecision, setProposalDecision] = useState<string>();
  const [toast, setToast] = useState<string>();
  const [panelMode, setPanelMode] = useState<"open" | "collapsed" | "max">("open");
  const [panelWidth, setPanelWidth] = useState(600);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerQuery, setPickerQuery] = useState("");
  const [sourcePreview, setSourcePreview] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [conversationMetadata, setConversationMetadata] = useState<Record<string, ConversationSummary>>({});
  const [conversationRevision, setConversationRevision] = useState(0);
  const receiveConversations = useCallback((items: ConversationSummary[]) => {
    setConversationMetadata(current => ({ ...current, ...Object.fromEntries(items.map(item => [item.id, item])) }));
  }, []);
  const pickerTriggerRef = useRef<HTMLButtonElement>(null);
  const [resizing, setResizing] = useState(false);
  const [focusedTurnId, setFocusedTurnId] = useState<string>();
  const layoutRef = useRef<HTMLDivElement>(null);
  const articleRef = useRef<HTMLDivElement>(null);
  const questionRef = useRef<HTMLTextAreaElement>(null);
  const sequenceRef = useRef(0);
  const documentLoadRef = useRef(0);
  const consumedDeepLinkRef = useRef("");
  const routeRef = useRef(route);
  const contextDocumentId = route.documentId;
  const conversationTurns = turns.filter(turn => route.conversationId && turn.conversationId === route.conversationId);
  const conversations = useMemo(() => {
    const grouped = new Map<string, Turn>();
    for (const turn of [...turns].sort((a, b) => b.createdAt.localeCompare(a.createdAt))) {
      if (!turn.conversationId) continue;
      const latest = grouped.get(turn.conversationId);
      grouped.set(turn.conversationId, latest ? { ...latest, question: turn.question } : turn);
    }
    return [...grouped.values()].filter(turn => !conversationMetadata[turn.conversationId]?.archived)
      .map(turn => ({ ...turn, question: conversationMetadata[turn.conversationId]?.title ?? turn.question }));
  }, [turns, conversationMetadata]);
  const isHome = !!route.home && !route.conversationId;
  const effectivePanelMode = isHome ? "collapsed" : panelMode;
  const dirtyRef = useRef(dirty);
  const pendingTransitionRef = useRef<(() => void) | null>(null);
  const [transitionPending, setTransitionPending] = useState(false);
  const documentRef = useRef(document);
  const draftRef = useRef(draft);
  documentRef.current = document;
  draftRef.current = draft;
  routeRef.current = route;
  dirtyRef.current = dirty;

  const documentsById = useMemo(
    () => new Map(workspace.documents.map((item) => [item.id, item as DocumentMetadata])),
    [workspace.documents],
  );
  const activeTurn = turns.find((turn) => turn.status === "running");
  const currentProposal = proposalPreview ? proposals[proposalPreview] : undefined;
  const guardedProposal = proposalDecision ? proposals[proposalDecision] : undefined;

  useEffect(() => {
    window.document.documentElement.lang = "zh-CN";
    window.document.title = workspace.site.title;
  }, [workspace.site.title]);

  useEffect(() => {
    if (!isDevelopmentWorkspace || !connected) return;
    let disposed = false;
    void api.history().then(({ receipts }) => {
      if (disposed) return;
      const savedProposals = Object.fromEntries(receipts.flatMap(receipt => receipt.kind === "turn" && receipt.proposal ? [[receipt.proposal.id, receipt.proposal]] : []));
      const savedStructures = Object.fromEntries(receipts.flatMap(receipt => receipt.kind === "turn" && receipt.structureProposal ? [[receipt.structureProposal.id, receipt.structureProposal]] : []));
      setProposals(current => ({ ...current, ...savedProposals, ...Object.fromEntries(Object.entries(current).filter(([, proposal]) => proposal.status === "accepted" || proposal.status === "rejected")) }));
      setStructureProposals(current => ({ ...current, ...savedStructures, ...Object.fromEntries(Object.entries(current).filter(([, proposal]) => proposal.status === "accepted" || proposal.status === "rejected")) }));
      const restored = receipts.flatMap(receipt => receipt.kind === "turn" ? [receipt.turn] : []);
      setTurns(current => {
        const merged = new Map(restored.map(turn => [turn.id, turn]));
        for (const turn of current) {
          if (turn.status !== "running" || !merged.has(turn.id) || merged.get(turn.id)!.status === "running") merged.set(turn.id, turn);
        }
        return [...merged.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      });
    }).catch(error => { if (!disposed) setQuestionError(`对话历史读取失败：${error.message}`); });
    return () => { disposed = true; };
  }, [api, connected]);

  useEffect(() => {
    if (!isDevelopmentWorkspace) return;
    api.workspace().then((next) => {
      setWorkspace(next);
      const ids = next.documents.map((item) => item.id);
      const stored = normalizeDocumentTabs(readStoredTabs(`learn-workbench:document-tabs:${spaceId}:v1`), ids);
      const initialRoute = routeFromHash(spaceId);
      const requested = initialRoute.documentId;
      const restored = requested ? openDocumentTab(stored, requested, ids) : stored;
      setDocumentTabs(restored);
      setWorkspaceReady(true);
      if (!requested && !initialRoute.conversationId && !initialRoute.map && !initialRoute.history && !initialRoute.index && !/\/new$/.test(window.location.hash) && restored.active) {
        window.location.hash = `#/space/${encodeURIComponent(spaceId!)}/doc/${encodeURIComponent(restored.active)}`;
      }
    }).catch((error) => setQuestionError(error.message));
  }, [api, spaceId]);

  useEffect(() => {
    const listener = () => setRoute(routeFromHash(spaceId));
    window.addEventListener("hashchange", listener);
    return () => window.removeEventListener("hashchange", listener);
  }, [spaceId]);

  useEffect(() => {
    if (!spaceId || !workspaceReady) return;
    window.localStorage.setItem(`learn-workbench:document-tabs:${spaceId}:v1`, JSON.stringify(documentTabs));
  }, [documentTabs, spaceId, workspaceReady]);

  const loadDocument = useCallback(async (id: string, preserveDraft = false) => {
    const request = ++documentLoadRef.current;
    setLoadingDocument(true);
    try {
      const snapshot = isDevelopmentWorkspace ? await api.document(id) : documentFromStatic(id);
      if (request !== documentLoadRef.current) return;
      if (!snapshot) throw new Error(`找不到文档 ${id}`);
      setDocument(snapshot);
      if (!preserveDraft) {
        setDraft(snapshot.body);
        setDirty(false);
        setConflict(undefined);
        setExternalChange(false);
        setAnchor(undefined);
        setTarget(undefined);
        setProposalDecision(undefined);
      }
    } catch (error) {
      if (request === documentLoadRef.current) setQuestionError(error instanceof Error ? error.message : String(error));
    } finally {
      if (request === documentLoadRef.current) setLoadingDocument(false);
    }
  }, [api]);

  useEffect(() => {
    setAiEdits({});
    if (!contextDocumentId) { setDocument(undefined); setDraft(""); setLoadingDocument(false); setDirty(false); setAnchor(undefined); setTarget(undefined); return; }
    void loadDocument(contextDocumentId);
    return () => { documentLoadRef.current += 1; };
  }, [contextDocumentId, loadDocument]);

  useEffect(() => {
    if (!route.documentId || !route.ask) return;
    const key = `${route.documentId}\n${route.ask}\n${route.evidencePath ?? ""}\n${route.evidenceLine ?? ""}`;
    if (consumedDeepLinkRef.current === key) return;
    consumedDeepLinkRef.current = key;
    const evidence = route.evidencePath ? `\n\n请优先检查证据：${route.evidencePath}${route.evidenceLine ? `:${route.evidenceLine}` : ""}` : "";
    setQuestion(`${route.ask}${evidence}`);
  }, [route.ask, route.documentId, route.evidenceLine, route.evidencePath]);

  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => {
      event.preventDefault();
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);

  const handleEvent = useCallback((event: LearnEvent) => {
    const gap = sequenceRef.current > 0 && event.sequence > sequenceRef.current + 1;
    sequenceRef.current = Math.max(sequenceRef.current, event.sequence);
    const payload = event.payload;
    const eventDocumentId = (payload.turn as Turn | undefined)?.documentId ?? payload.documentId;
    if (eventDocumentId === routeRef.current.documentId) setAiEdits(items => updateAiEdits(gap ? {} : items, event));
    else if (gap) setAiEdits({});
    if (event.type === "conversation.updated") {
      const conversation = payload.conversation as ConversationSummary;
      setConversationMetadata(current => ({ ...current, [conversation.id]: conversation }));
      setConversationRevision(current => current + 1);
    }
    if (event.type === "turn.started") {
      const turn = payload.turn as Turn;
      setTurns((items) => [turn, ...items.filter((item) => item.id !== turn.id)]);
    }
    if (event.type === "turn.progress") {
      setProgress((items) => ({ ...items, [String(payload.turnId)]: String(payload.message) }));
    }
    if (event.type === "turn.edited") {
      setTurns(items => items.map(turn => turn.id === payload.turnId ? { ...turn, appliedEdits: Number(payload.appliedEdits), documentIds: payload.documentIds as string[] } : turn));
    }
    if (event.type === "turn.document") {
      const turn = payload.turn as Turn;
      const saved = payload.document as DocumentSnapshot;
      setTurns(items => [turn, ...items.filter(item => item.id !== turn.id)]);
      if (turn.conversationId === routeRef.current.conversationId && !dirtyRef.current) {
        setDocument(current => current?.id === saved.id ? { ...current, title: saved.title, summary: saved.summary } : saved);
        setPanelMode("open");
        const base = spaceId ? `#/space/${encodeURIComponent(spaceId)}` : "#";
        const params = new URLSearchParams({ conversation: turn.conversationId });
        if (routeRef.current.documentId === saved.id && routeRef.current.edit && !routeRef.current.rich) params.set("edit", "1");
        const hash = `${base}/doc/${encodeURIComponent(saved.id)}?${params}`;
        window.history.replaceState(null, "", hash);
        const next = routeFromHash(spaceId);
        routeRef.current = next;
        setRoute(next);
        setDocumentTabs(current => openDocumentTab(current, saved.id, [...current.tabs, saved.id]));
      }
    }
    if (event.type === "turn.output.delta") {
      const turnId = String(payload.turnId);
      const delta = String(payload.delta ?? "");
      setStreamingAnswers((items) => ({ ...items, [turnId]: `${items[turnId] ?? ""}${delta}` }));
    }
    if (event.type === "proposal.created" || event.type === "proposal.updated") {
      const proposal = payload.proposal as Proposal;
      setProposals((items) => ({ ...items, [proposal.id]: proposal }));
    }
    if (event.type === "structure-proposal.created") {
      const proposal = payload.proposal as StructureProposal;
      setStructureProposals((items) => ({ ...items, [proposal.id]: proposal }));
    }
    if (event.type === "structure-proposal.accepted" || event.type === "structure-proposal.rejected") {
      const id = String(payload.proposalId);
      setStructureProposals(items => items[id] ? { ...items, [id]: { ...items[id], status: event.type === "structure-proposal.accepted" ? "accepted" : "rejected" } } : items);
    }
    if (event.type === "workspace.changed") {
      const documents = payload.documents as Workspace["documents"];
      setWorkspace(current => ({ ...current, documents, manifestHash: String(payload.manifestHash) }));
      setDocument(current => {
        const metadata = documents.find(item => item.id === current?.id);
        return current && metadata ? { ...current, ...metadata } : current;
      });
    }
    if (event.type === "runtime.changed") {
      setWorkspace(current => ({ ...current, runtime: payload.runtime as Workspace["runtime"] }));
    }
    if (event.type === "turn.evidence.refreshed") {
      setTurns((items) => items.map((turn) => turn.id === payload.turnId ? { ...turn, evidence: payload.evidence as Turn["evidence"] } : turn));
    }
    if (event.type === "turn.completed" || event.type === "turn.failed" || event.type === "turn.cancelled") {
      const turn = payload.turn as Turn;
      setTurns((items) => [turn, ...items.filter((item) => item.id !== turn.id)]);
      setStreamingAnswers((items) => {
        const { [turn.id]: _completed, ...remaining } = items;
        return remaining;
      });
    }
    if ((event.type === "document.changed" || event.type === "document.saved") && payload.documentId === contextDocumentId) {
      if (payload.contentHash === documentRef.current?.contentHash) return;
      if (dirtyRef.current) setExternalChange(true);
      else if (contextDocumentId && !routeRef.current.rich) void loadDocument(contextDocumentId);
    }
    if (event.type === "proposal.conflict") {
      setProposals((items) => {
        const id = String(payload.proposalId);
        return items[id] ? { ...items, [id]: { ...items[id], status: "conflict" } } : items;
      });
    }
    if (event.type === "structure-proposal.conflict") {
      setStructureProposals((items) => {
        const id = String(payload.proposalId);
        return items[id] ? { ...items, [id]: { ...items[id], status: "conflict" } } : items;
      });
    }
    if (event.type === "history.warning") setQuestionError(String(payload.message ?? "历史记录失败"));
  }, [loadDocument, contextDocumentId, spaceId]);

  useEffect(() => spaceId && !pauseEvents ? subscribeToEvents(spaceId, sequenceRef.current, handleEvent, value => {
    setConnected(value);
    if (!value) { setAiEdits({}); sequenceRef.current = 0; }
  }) : () => undefined, [handleEvent, spaceId, pauseEvents]);

  const onAiEditSynced = useCallback((editId: string) => setAiEdits(items => {
    const { [editId]: _synced, ...remaining } = items;
    return remaining;
  }), []);

  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(undefined), 2600);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  useEffect(() => {
    if (!dirty) setProposalDecision(undefined);
  }, [dirty]);

  const requestTransition = useCallback((action: () => void) => {
    if (!dirtyRef.current) {
      action();
      return;
    }
    pendingTransitionRef.current = action;
    setTransitionPending(true);
  }, []);

  useImperativeHandle(ref, () => ({ requestTransition }), [requestTransition]);

  const performNavigate = useCallback((id?: string, edit = false, rich = false) => {
    setPanelMode(mode => mode === "collapsed" ? "open" : mode);
    setPickerOpen(false);
    setPickerQuery("");
    if (spaceId && id) {
      const ids = workspace.documents.map((item) => item.id);
      setDocumentTabs((current) => openDocumentTab(current, id, ids));
    } else if (spaceId) {
      setDocumentTabs((current) => ({ ...current, active: null }));
    }
    const base = spaceId ? `#/space/${encodeURIComponent(spaceId)}` : "#";
    const params = new URLSearchParams();
    if (edit) { params.set("edit", "1"); if (rich) params.set("mode", "page"); }
    if (routeRef.current.conversationId) params.set("conversation", routeRef.current.conversationId);
    window.location.hash = `${id ? `${base}/doc/${encodeURIComponent(id)}` : `${base}/documents`}${params.size ? `?${params}` : ""}`;
  }, [spaceId, workspace.documents]);

  const navigate = (id?: string, edit = false, rich = false) => {
    const action = () => performNavigate(id, edit, rich);
    if (id !== route.documentId) requestTransition(action);
    else action();
  };

  const toggleEdit = () => {
    if (!route.documentId || !isDevelopmentWorkspace) return;
    requestTransition(() => performNavigate(route.documentId, route.rich));
  };

  const save = useCallback(async (): Promise<boolean> => {
    if (!document || !dirty || !isDevelopmentWorkspace) return false;
    setSaveState("saving");
    setConflict(undefined);
    try {
      const saved = await api.saveDocument(document.id, draft, document.contentHash);
      documentRef.current = saved;
      setDocument(saved);
      const keptTyping = draftRef.current !== draft;
      if (!keptTyping) setDraft(saved.body);
      setDirty(keptTyping && draftRef.current !== saved.body);
      setExternalChange(false);
      setSaveState("saved");
      setToast("Markdown 已写回");
      window.setTimeout(() => setSaveState("idle"), 1600);
      return !keptTyping || draftRef.current === saved.body;
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) {
        setConflict("磁盘上的文档已经变化。你的草稿仍在内存中，没有被覆盖。");
      } else {
        setConflict(error instanceof Error ? error.message : String(error));
      }
      setSaveState("idle");
      return false;
    }
  }, [document, dirty, draft]);

  const overwriteAfterConflict = async () => {
    if (!document || !window.confirm("将以当前草稿覆盖最新磁盘内容。这个动作是显式覆盖，确定继续吗？")) return;
    const latest = await api.document(document.id);
    try {
      const saved = await api.saveDocument(document.id, draft, latest.contentHash);
      setDocument(saved);
      setDraft(saved.body);
      setDirty(false);
      setConflict(undefined);
      setExternalChange(false);
      setToast("已用草稿覆盖最新磁盘版本");
    } catch (error) {
      setConflict(error instanceof Error ? error.message : String(error));
    }
  };

  const onSharedSnapshot = useCallback((snapshot: DocumentSnapshot) => {
    if (snapshot.id !== routeRef.current.documentId) return;
    documentRef.current = snapshot; setDocument(snapshot); setDraft(snapshot.body); setDirty(false); setExternalChange(false);
  }, []);

  const submitQuestion = async () => {
    if ((contextDocumentId && (loadingDocument || document?.id !== contextDocumentId)) || !isDevelopmentWorkspace || !workspace.runtime.available || !question.trim() || activeTurn) return;
    setQuestionError(undefined);
    if (dirty) { setQuestionError("先保存或放弃当前 Markdown 草稿，再让 Agent 处理文档"); return; }
    try {
      const conversationId = routeRef.current.conversationId ?? crypto.randomUUID();
      const [path, query = ""] = window.location.hash.split("?");
      const params = new URLSearchParams(query);
      params.set("conversation", conversationId);
      window.history.replaceState(null, "", `${path}?${params}`);
      routeRef.current = routeFromHash(spaceId);
      setRoute(routeRef.current);
      const { turn } = await api.ask({
        conversationId,
        documentId: contextDocumentId,
        question: question.trim(),
        intent: "auto",
        anchor: anchor ? questionAnchor(anchor) : undefined,
        target,
      });
      // SSE may already have delivered edits or completion before this response.
      setTurns(items => items.some(item => item.id === turn.id) ? items : [turn, ...items]);
      setQuestion("");
      setAnchor(undefined);
      setTarget(undefined);
    } catch (error) {
      setQuestionError(error instanceof Error ? error.message : String(error));
    }
  };

  const cancelTurn = async (turn: Turn) => {
    setQuestionError(undefined);
    try {
      await api.cancelTurn(turn.id);
    } catch (error) {
      setQuestionError(error instanceof Error ? error.message : String(error));
    }
  };

  const acceptProposal = async (proposal: Proposal) => {
    const draftAtAcceptance = draftRef.current;
    try {
      const result = await api.acceptProposal(proposal.id);
      setProposals((items) => ({ ...items, [proposal.id]: result.proposal }));
      if (document?.id === result.document.id) {
        documentRef.current = result.document;
        setDocument(result.document);
        const keptTyping = draftRef.current !== draftAtAcceptance;
        if (!keptTyping) setDraft(result.document.body);
        setDirty(keptTyping && draftRef.current !== result.document.body);
        setExternalChange(false);
        setConflict(undefined);
      }
      setProposalPreview(undefined);
      setProposalDecision(undefined);
      setToast("提案已审核落盘");
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) {
        setProposals((items) => ({ ...items, [proposal.id]: { ...proposal, status: "conflict" } }));
        setProposalDecision(undefined);
      }
      setQuestionError(error instanceof Error ? error.message : String(error));
    }
  };

  const requestProposalAcceptance = (proposal: Proposal) => {
    if (dirty && document?.id === proposal.documentId) {
      setProposalDecision(proposal.id);
      return;
    }
    void acceptProposal(proposal);
  };

  const rejectProposal = async (proposal: Proposal) => {
    try {
      const result = await api.rejectProposal(proposal.id);
      setProposals((items) => ({ ...items, [proposal.id]: result.proposal }));
      if (proposalPreview === proposal.id) setProposalPreview(undefined);
      if (proposalDecision === proposal.id) setProposalDecision(undefined);
    } catch (error) {
      setQuestionError(error instanceof Error ? error.message : String(error));
    }
  };

  const acceptStructureProposal = async (proposal: StructureProposal) => {
    const touchesCurrent = proposal.operations.some((operation) => operation.type !== "create" && operation.documentId === document?.id);
    if (dirty && touchesCurrent && !window.confirm("结构提案会移动或删除当前页面。你的未保存草稿不会自动合并；放弃草稿并继续吗？")) return;
    try {
      const result = await api.acceptStructureProposal(proposal.id);
      setStructureProposals((items) => ({ ...items, [proposal.id]: result.proposal }));
      setWorkspace((current) => ({ ...current, documents: result.workspace.documents, manifestHash: result.workspace.manifestHash }));
      if (result.workspace.warnings?.length) setQuestionError(result.workspace.warnings.join("\n"));
      if (proposal.operations.some((operation) => operation.type === "delete" && operation.documentId === document?.id)) navigate();
      else if (document?.id && result.workspace.documents.some((candidate) => candidate.id === document.id)) await loadDocument(document.id);
      setToast("站点结构已审核落盘");
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) setStructureProposals((items) => ({ ...items, [proposal.id]: { ...proposal, status: "conflict" } }));
      setQuestionError(error instanceof Error ? error.message : String(error));
    }
  };

  const rejectStructureProposal = async (proposal: StructureProposal) => {
    try {
      const result = await api.rejectStructureProposal(proposal.id);
      setStructureProposals((items) => ({ ...items, [proposal.id]: result.proposal }));
    } catch (error) {
      setQuestionError(error instanceof Error ? error.message : String(error));
    }
  };

  const refreshEvidence = async (turn: Turn) => {
    try {
      const result = await api.refreshEvidence(turn.id);
      setTurns((items) => items.map((item) => item.id === turn.id ? { ...item, evidence: result.evidence } : item));
    } catch (error) {
      setQuestionError(error instanceof Error ? error.message : String(error));
    }
  };

  const captureSelection = () => {
    const content = articleRef.current?.querySelector<HTMLElement>(".page-editor, .markdown") ?? null;
    setAnchor(captureSelectionAnchor(content, window.getSelection(), window.innerWidth, document?.contentHash));
  };

  const routeBase = spaceId ? `#/space/${encodeURIComponent(spaceId)}` : "#";
  const showPanel = (view: "map" | "history" | "documents") => requestTransition(() => {
    setPanelMode(mode => mode === "max" ? "max" : "open");
    setPickerOpen(false);
    setAnchor(undefined);
    setTarget(undefined);
    window.location.hash = `${routeBase}/${view}${route.conversationId ? `?conversation=${encodeURIComponent(route.conversationId)}` : ""}`;
  });
  const openPicker = () => {
    if (isHome) showPanel("documents");
    setPanelMode(mode => mode === "max" ? "max" : "open");
    setPickerQuery("");
    setPickerOpen(true);
  };
  const openConversation = (turn: Pick<Turn, "conversationId" | "documentId">) => requestTransition(() => {
    setFocusedTurnId(undefined);
    setQuestion(""); setAnchor(undefined); setTarget(undefined);
    setPanelMode(turn.documentId ? "open" : "collapsed");
    window.location.hash = `${routeBase}/${turn.documentId ? `doc/${encodeURIComponent(turn.documentId)}` : "new"}?conversation=${encodeURIComponent(turn.conversationId)}`;
  });
  const startQuestion = () => requestTransition(() => {
    setPanelMode("collapsed");
    setPickerOpen(false);
    setFocusedTurnId(undefined);
    setQuestion("");
    setAnchor(undefined);
    setTarget(undefined);
    window.location.hash = `${routeBase}/new`;
    requestAnimationFrame(() => questionRef.current?.focus());
  });

  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "n") {
        event.preventDefault();
        startQuestion();
      }
    };
    window.addEventListener("keydown", listener);
    return () => window.removeEventListener("keydown", listener);
  }, []);

  useEffect(() => {
    if (!pickerOpen) return;
    const close = (event: PointerEvent) => {
      if (event.target instanceof Element && !event.target.closest(".document-picker, .panel-picker-trigger")) setPickerOpen(false);
    };
    window.document.addEventListener("pointerdown", close);
    return () => window.document.removeEventListener("pointerdown", close);
  }, [pickerOpen]);

  useEffect(() => {
    if (!pickerOpen || isHome) return;
    const frame = requestAnimationFrame(() => layoutRef.current?.querySelector<HTMLInputElement>(".picker-search input")?.focus());
    return () => cancelAnimationFrame(frame);
  }, [pickerOpen, isHome]);

  const visibleBody = currentProposal && document ? currentProposal.replacementMarkdown : document?.body ?? "";

  const viewTitle = route.map ? "知识地图" : route.history ? "生长记录" : route.index ? "全部文档" : documentsById.get(route.documentId ?? "")?.title ?? "学习文档";
  const pickerDocuments = workspace.documents.filter(item => [item.title, item.summary, ...(item.tags ?? [])].join(" ").toLocaleLowerCase().includes(pickerQuery.trim().toLocaleLowerCase()));
  const documentBar = (
    <header className="document-bar">
      <button ref={pickerTriggerRef} className="panel-picker-trigger" aria-label="切换文档" aria-expanded={pickerOpen} aria-haspopup="listbox" onClick={() => { setPickerOpen(!pickerOpen); setPickerQuery(""); }}><span>{viewTitle}</span><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg></button>
      {route.documentId && isDevelopmentWorkspace && <span className={`save-indicator ${dirty ? "is-dirty" : ""}`}>{saveState === "saving" ? "保存中…" : dirty ? "未保存" : "已保存"}</span>}
      <div className="toolbar-actions">
        <button className="export-button" aria-label="导出学习空间" onClick={() => { setPickerOpen(false); setExportOpen(true); }}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="M12 3v13m-5-5 5 5 5-5M5 16v5h14v-5" /></svg>导出</button>
        {route.documentId && isDevelopmentWorkspace && <>
          {route.rich ? <button className="view-mode" aria-label="编辑 Markdown" onClick={toggleEdit}>源码</button> : <>
            <button className="view-mode" aria-label="返回文档" onClick={toggleEdit}>文档</button>
            <button className={`view-mode ${sourcePreview ? "is-active" : ""}`} aria-pressed={sourcePreview} onClick={() => setSourcePreview(!sourcePreview)}>预览</button>
            {dirty && <button className="primary-button" onClick={() => void save()} disabled={saveState === "saving"}>保存 ⌘S</button>}
          </>}
        </>}
        <button className="icon-button" aria-label={panelMode === "max" ? "退出最大化" : "最大化文档面板"} title={panelMode === "max" ? "退出最大化" : "最大化"} onClick={() => setPanelMode(panelMode === "max" ? "open" : "max")}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d={panelMode === "max" ? "M4 14h6v6M20 10h-6V4M10 14l-6 6M14 10l6-6" : "M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"} /></svg></button>
        <button className="icon-button" aria-label="收起文档面板" title="收起" onClick={() => { setPanelMode("collapsed"); setPickerOpen(false); }}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18" /></svg></button>
      </div>
    </header>
  );
  const picker = pickerOpen && <div className="document-picker" onKeyDown={event => {
    if (event.key === "Escape") { event.preventDefault(); setPickerOpen(false); pickerTriggerRef.current?.focus(); }
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      const options = [...event.currentTarget.querySelectorAll<HTMLButtonElement>('[role="option"]')];
      const index = options.indexOf(window.document.activeElement as HTMLButtonElement);
      const next = index < 0 ? event.key === "ArrowDown" ? 0 : options.length - 1 : (index + (event.key === "ArrowDown" ? 1 : -1) + options.length) % options.length;
      options[next]?.focus();
    }
  }}>
    <label className="picker-search"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg><span className="sr-only">搜索文档</span><input type="search" autoFocus value={pickerQuery} onChange={event => setPickerQuery(event.target.value)} placeholder="搜索文档" /></label>
    <div role="listbox" aria-label="切换文档" className="picker-options">
      {pickerDocuments.map(item => <button role="option" aria-selected={route.documentId === item.id} key={item.id} onClick={() => navigate(item.id)}><span className="picker-stage">{item.stage ?? "—"}</span><span>{item.title}</span></button>)}
      {!pickerDocuments.length && <p className="picker-empty">没有找到相关文档</p>}
      <div className="picker-divider" />
      <button role="option" aria-selected={!!route.index} onClick={() => showPanel("documents")}><span aria-hidden="true">▤</span>全部文档</button>
      <button role="option" aria-selected={!!route.map} onClick={() => showPanel("map")}><span aria-hidden="true">◇</span>知识地图</button>
      {isDevelopmentWorkspace && <button role="option" aria-selected={!!route.history} onClick={() => showPanel("history")}><span aria-hidden="true">◷</span>生长记录</button>}
    </div>
  </div>;

  return (
    <SpaceApiContext.Provider value={api}>
    <section className="learning-space-view">
      <nav className="mobile-workbench-nav" aria-label="工作台导航"><button onClick={startQuestion}>新问题</button><button onClick={openPicker}>文档</button><button onClick={() => showPanel("map")}>知识地图</button>{isDevelopmentWorkspace && <button onClick={() => showPanel("history")}>生长记录</button>}<button onClick={() => setSettingsOpen(true)}>{isDevelopmentWorkspace ? "本地设置" : "空间信息"}</button></nav>
      <div ref={layoutRef} className={`workbench has-document ${isHome ? "is-question-home" : ""} panel-${effectivePanelMode} ${resizing ? "is-resizing" : ""}`} style={{ "--document-width": `${panelWidth}px` } as CSSProperties}>
      <WorkbenchSidebar
        spaces={spaces.length ? spaces : [{ id: "static", title: workspace.site.title, root: "" }]}
        activeSpaceId={spaceId ?? "static"} selectedId={route.conversationId}
        refreshKey={`${conversationRevision}|${turns.map(turn => `${turn.id}:${turn.status}:${turn.documentId ?? ""}`).join("|")}`}
        onHome={() => onActivateSpace ? onActivateSpace(null) : navigate()}
        onNew={startQuestion} onAddSpace={onOpenSpace} onCloseSpace={onCloseSpace}
        onSearchDocuments={openPicker} onLoaded={receiveConversations}
        onNavigate={(id, destination) => {
          if (id !== (spaceId ?? "static")) onNavigateSpace?.(id, destination);
          else if (destination === "new") startQuestion();
          else showPanel("documents");
        }}
        onConversation={(id, conversation) => {
          if (id === spaceId) openConversation({ conversationId: conversation.id, documentId: conversation.documentId });
          else onNavigateSpace?.(id, `${conversation.documentId ? `doc/${encodeURIComponent(conversation.documentId)}` : "new"}?conversation=${encodeURIComponent(conversation.id)}`);
        }}
        footer={<>
          <div className="sidebar-current-label" title={workspace.site.title}>{workspace.site.title}</div>
          <button className="sidebar-nav" aria-current={route.map ? "page" : undefined} onClick={() => showPanel("map")}><span aria-hidden="true">◇</span>知识地图</button>
          {isDevelopmentWorkspace && <button className="sidebar-nav" aria-current={route.history ? "page" : undefined} onClick={() => showPanel("history")}><span aria-hidden="true">◷</span>生长记录</button>}
          <SpaceMenu workspace={workspace} root={space?.root} connected={connected} onOpen={onOpenSpace} onDocuments={() => showPanel("documents")} onExport={() => setExportOpen(true)} onSettings={() => setSettingsOpen(true)} />
        </>}
      />
      <ConversationPanel
        workspace={workspace}
        home={isHome}
        chooseDocument={openPicker}
        openSpace={onOpenSpace}
        openSettings={() => setSettingsOpen(true)}
        focusedTurnId={focusedTurnId}
        title={(route.conversationId && conversationMetadata[route.conversationId]?.title) || conversationTurns.at(-1)?.question || "新问题"}
        panelCollapsed={panelMode === "collapsed"}
        openDocumentPanel={() => setPanelMode("open")}
        turns={conversationTurns}
        openDocument={navigate}
        proposals={proposals}
        structureProposals={structureProposals}
        progress={progress}
        streamingAnswers={streamingAnswers}
        document={document?.id === contextDocumentId && !loadingDocument ? document : undefined}
        articleRef={articleRef}
        visibleBody={visibleBody}
        activeTurn={activeTurn}
        questionError={questionError}
        clearQuestionError={() => setQuestionError(undefined)}
        target={target}
        clearTarget={() => setTarget(undefined)}
        question={question}
        setQuestion={setQuestion}
        anchor={anchor}
        setAnchor={setAnchor}
        questionRef={questionRef}
        proposalPreview={proposalPreview}
        setProposalPreview={setProposalPreview}
        submitQuestion={submitQuestion}
        cancelTurn={cancelTurn}
        acceptProposal={requestProposalAcceptance}
        rejectProposal={(proposal) => void rejectProposal(proposal)}
        acceptStructureProposal={(proposal) => void acceptStructureProposal(proposal)}
        rejectStructureProposal={(proposal) => void rejectStructureProposal(proposal)}
        refreshEvidence={(turn) => void refreshEvidence(turn)}
        navigateHistory={() => showPanel("history")}
      />

      <div className="panel-resize-handle" role="separator" aria-orientation="vertical" aria-label="拖动调整文档宽度" tabIndex={0} aria-valuemin={380} aria-valuemax={Math.max(380, window.innerWidth - 640)} aria-valuenow={Math.max(380, Math.min(window.innerWidth - 640, panelWidth))}
        onPointerDown={event => { if (event.button !== 0) return; event.currentTarget.setPointerCapture(event.pointerId); setResizing(true); }}
        onPointerMove={event => {
          if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
          const bounds = layoutRef.current?.getBoundingClientRect();
          if (bounds) setPanelWidth(Math.max(380, Math.min(bounds.width - 640, Math.round(bounds.right - event.clientX - 8))));
        }}
        onPointerUp={event => { event.currentTarget.releasePointerCapture(event.pointerId); setResizing(false); }}
        onLostPointerCapture={() => setResizing(false)}
        onDoubleClick={() => setPanelWidth(600)}
        onKeyDown={event => {
          if (event.key === "ArrowLeft" || event.key === "ArrowRight") { event.preventDefault(); setPanelWidth(width => Math.max(380, Math.min(window.innerWidth - 640, width + (event.key === "ArrowLeft" ? 24 : -24)))); }
          if (event.key === "Home") { event.preventDefault(); setPanelWidth(600); }
        }}><i /></div>
      <section className="document-dock" aria-label="文档面板">
      {documentBar}
      {picker}
      <ArtifactPanel sourcePreview={sourcePreview} recentTurns={conversations} onOpenConversation={openConversation} lastDocumentId={contextDocumentId} route={route} workspace={workspace} document={document} draft={draft} dirty={dirty} loadingDocument={loadingDocument} guardedProposal={guardedProposal} currentProposal={currentProposal} conflict={conflict} externalChange={externalChange} visibleBody={visibleBody} documentsById={documentsById} articleRef={articleRef} navigate={navigate} save={save} setDraft={setDraft} setDirty={setDirty} setProposalDecision={setProposalDecision} setProposalPreview={setProposalPreview} setToast={setToast} acceptProposal={acceptProposal} loadDocument={loadDocument} overwriteAfterConflict={overwriteAfterConflict} onSharedSnapshot={onSharedSnapshot} aiEdits={aiEdits} onAiEditSynced={onAiEditSynced} onRequestEdit={(from, to, block) => {
        if (!document) return;
        if (dirty) { setToast("先保存草稿，再选择要交给 Agent 的段落"); return; }
        setPanelMode("open");
        setTarget({ from, to, baseHash: document.contentHash, ...block });
        setAnchor(undefined);
        setQuestion(from === to ? "请在这里补充一段教程内容：" : "请修改这一段：");
        requestAnimationFrame(() => questionRef.current?.focus());
      }} onCaptureSelection={captureSelection} onHistoryReverted={(next) => { setWorkspace(next); setToast("已创建反向提交并恢复工作区"); }} navigateMap={() => showPanel("map")} navigateHistory={() => showPanel("history")} />
      </section>
      {anchor && <SelectionActions anchor={anchor} edit={route.edit && !route.rich} questionRef={questionRef} setQuestion={setQuestion} />}
      {exportOpen && <ExportSpaceDialog workspace={workspace} onClose={() => setExportOpen(false)} />}
      {settingsOpen && <LocalSettings workspace={workspace} root={space?.root} busy={Boolean(activeTurn)} onRuntimeChange={runtime => setWorkspace(current => ({ ...current, runtime }))} onClose={() => setSettingsOpen(false)} />}
      {toast && <div className="toast">✓ {toast}</div>}
      {transitionPending && <div className="modal-backdrop">
        <section className="transition-dialog" role="alertdialog" aria-labelledby="unsaved-title">
          <span>未保存的修改</span>
          <h2 id="unsaved-title">这篇文档还有未保存内容</h2>
          <p>先决定如何处理当前草稿，再继续切换标签。</p>
          <div>
            <button onClick={() => { pendingTransitionRef.current = null; setTransitionPending(false); }}>取消</button>
            <button className="danger-button" onClick={() => {
              const action = pendingTransitionRef.current;
              pendingTransitionRef.current = null;
              setTransitionPending(false);
              setDirty(false);
              setDraft(documentRef.current?.body ?? "");
              action?.();
            }}>放弃并切换</button>
            <button className="primary-button" onClick={() => void save().then((saved) => {
              if (!saved) return;
              const action = pendingTransitionRef.current;
              pendingTransitionRef.current = null;
              setTransitionPending(false);
              action?.();
            })}>保存并切换</button>
          </div>
        </section>
      </div>}
      </div>
    </section>
    </SpaceApiContext.Provider>
  );
});

export default function App() {
  const [spaces, setSpaces] = useState<LearningSpaceSummary[]>([]);
  const [recentSpaces, setRecentSpaces] = useState<LearningSpaceSummary[]>([]);
  const [restoreErrors, setRestoreErrors] = useState<Record<string, string>>({});
  const [spaceTabs, setSpaceTabs] = useState<TabsState>({ tabs: [], active: null });
  const [loading, setLoading] = useState(isDevelopmentWorkspace);
  const [loadError, setLoadError] = useState<string>();
  const [openDialog, setOpenDialog] = useState(false);
  const [root, setRoot] = useState("");
  const [openError, setOpenError] = useState<string>();
  const [opening, setOpening] = useState(false);
  const [choosingFolder, setChoosingFolder] = useState(false);
  const activeView = useRef<LearningSpaceHandle>(null);
  const initialized = useRef(false);

  useEffect(() => {
    if (!isDevelopmentWorkspace || initialized.current) return;
    initialized.current = true;
    const stored = normalizeStoredWorkbench(readStoredTabs(SPACES_KEY));
    void workbenchApi.spaces().then(async ({ spaces: serverSpaces }) => {
      const availableByRoot = new Map(serverSpaces.map((space) => [space.root, space]));
      const errors: Record<string, string> = {};
      for (const saved of stored.spaces) {
        if (availableByRoot.has(saved.root)) continue;
        try {
          const { space } = await workbenchApi.openSpace(saved.root);
          availableByRoot.set(space.root, space);
        } catch (error) {
          errors[saved.root] = error instanceof Error ? error.message : String(error);
        }
      }
      const available = [...availableByRoot.values()];
      const catalog = stored.spaces.map((saved) => availableByRoot.get(saved.root) ?? saved);
      for (const space of available) {
        if (!catalog.some((saved) => saved.root === space.root)) catalog.push(space);
      }
      setSpaces(available);
      setRecentSpaces(catalog);
      setRestoreErrors(errors);
      let restored = normalizeSpaceTabs(stored, available.map((space) => space.id));
      const routedSpaceId = spaceIdFromHash();
      if (routedSpaceId && available.some((space) => space.id === routedSpaceId)) {
        restored = openSpaceTab(restored, routedSpaceId);
      } else if (!readStoredTabs(SPACES_KEY) && available[0]) {
        restored = { tabs: available.map(space => space.id), active: available[0].id };
      }
      setSpaceTabs(restored);
    }).catch((error) => setLoadError(error instanceof Error ? error.message : String(error))).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (isDevelopmentWorkspace && !loading) {
      window.localStorage.setItem(SPACES_KEY, JSON.stringify({ spaces: recentSpaces, ...spaceTabs }));
    }
  }, [loading, recentSpaces, spaceTabs]);

  useEffect(() => {
    if (isDevelopmentWorkspace && !spaceTabs.active) window.document.title = "观澜 Velora · 学习空间";
  }, [spaceTabs.active]);
  if (!isDevelopmentWorkspace) return <LearningSpaceView ref={activeView} />;

  const activeSpace = spaces.find((space) => space.id === spaceTabs.active);
  const transition = (action: () => void) => {
    if (activeView.current) activeView.current.requestTransition(action);
    else action();
  };
  const activate = (spaceId: string | null, newQuestion = false) => transition(() => {
    window.location.hash = spaceId ? `#/space/${encodeURIComponent(spaceId)}/${newQuestion ? "new" : ""}` : "#/";
    setSpaceTabs((current) => spaceId ? openSpaceTab(current, spaceId) : { ...current, active: null });
  });
  const navigateSpace = (id: string, destination: string) => transition(() => {
    window.location.hash = `#/space/${encodeURIComponent(id)}/${destination}`;
    setSpaceTabs(current => openSpaceTab(current, id));
  });
  const showOpenDialog = () => transition(() => {
    setOpenError(undefined);
    setChoosingFolder(false);
    setOpenDialog(true);
  });
  const closeSpace = (spaceId: string) => {
    const action = () => {
      const next = closeSpaceTab(spaceTabs, spaceId);
      if (spaceTabs.active === spaceId) window.location.hash = next.active ? `#/space/${encodeURIComponent(next.active)}/` : "#/";
      setSpaceTabs(next);
    };
    if (spaceTabs.active === spaceId) transition(action);
    else action();
  };
  const browseFolder = async () => {
    setChoosingFolder(true);
    setOpenError(undefined);
    try {
      const { root: selectedRoot } = await workbenchApi.chooseFolder();
      if (selectedRoot !== null) setRoot(selectedRoot);
    } catch (error) {
      setOpenError(error instanceof Error ? error.message : String(error));
    } finally {
      setChoosingFolder(false);
    }
  };
  const submitOpen = async (event: FormEvent) => {
    event.preventDefault();
    if (choosingFolder || opening || !root.trim()) return;
    setOpening(true);
    setOpenError(undefined);
    try {
      const { space } = await workbenchApi.openSpace(root.trim(), true);
      setSpaces((current) => current.some((item) => item.id === space.id) ? current : [...current, space]);
      setRecentSpaces((current) => current.some((item) => item.root === space.root)
        ? current.map((item) => item.root === space.root ? space : item)
        : [...current, space]);
      setRestoreErrors((current) => {
        const next = { ...current };
        delete next[space.root];
        return next;
      });
      window.location.hash = `#/space/${encodeURIComponent(space.id)}/`;
      setSpaceTabs((current) => openSpaceTab(current, space.id));
      setRoot("");
      setOpenDialog(false);
    } catch (error) {
      setOpenError(error instanceof Error ? error.message : String(error));
    } finally {
      setOpening(false);
    }
  };

  return <main className="workbench-shell">
    <header className="space-bar">
      <button className="workbench-mark" role="tab" aria-selected={!spaceTabs.active} onClick={() => activate(null)}>
        <span>澜</span><strong>观澜 <small>Velora</small></strong>
      </button>
      <nav className="space-tabs" role="tablist" aria-label="学习空间">
        {spaceTabs.tabs.map((id) => {
          const space = spaces.find((item) => item.id === id);
          if (!space) return null;
          return <span className="space-tab" key={id}>
            <button role="tab" aria-selected={spaceTabs.active === id} className={spaceTabs.active === id ? "is-active" : ""} title={space.root} onClick={() => activate(id)}>{space.title}</button>
            <button className="tab-close" aria-label={`关闭学习空间 ${space.title}`} onClick={() => closeSpace(id)}>×</button>
          </span>;
        })}
      </nav>
      <span className="local-mode-badge">本地版 · 无需账号</span>
      <button className="open-space-button" aria-label="打开学习空间" onClick={showOpenDialog}>＋</button>
    </header>

    {loading ? <div className="shell-state">正在读取学习空间…</div>
      : loadError ? <div className="shell-state is-error">{loadError}</div>
      : activeSpace ? <LearningSpaceView key={activeSpace.id} ref={activeView} space={activeSpace} spaces={spaces.filter(item => spaceTabs.tabs.includes(item.id))} pauseEvents={openDialog} onActivateSpace={activate} onNavigateSpace={navigateSpace} onOpenSpace={showOpenDialog} onCloseSpace={closeSpace} />
      : <section className="workbench-home">
        <section className="spaces-intro">
          <p className="eyebrow">观澜 · VELORA</p>
          <h1>从一个问题，<br />到一片自己的知识。</h1>
          <p className="spaces-description">边问，边写，边理解。让每一次对话，都成为下次学习的起点。</p>
          <button className="primary-button" onClick={showOpenDialog}>＋ 打开学习空间</button>
          <small>文档保存在你的本地文件夹中。提问时，相关内容会发送给配置的模型。</small>
        </section>
        <section className="recent-spaces"><h2>最近在学</h2>
        <div className="space-cards">
          {recentSpaces.map((space) => {
            const available = spaces.some((item) => item.id === space.id);
            const restoreError = restoreErrors[space.root];
            return <button key={space.root} onClick={() => {
              if (available) activate(space.id);
              else {
                setRoot(space.root);
                setOpenError(restoreError);
                setOpenDialog(true);
              }
            }} className={restoreError ? "is-missing" : ""}><strong>{space.title}</strong><p>{space.description || "从上次停下的地方，继续探索与学习。"}</p><small>{restoreError ? "这个文件夹暂时找不到了" : "继续学习 →"}</small>{restoreError && <em>无法重新打开：{restoreError}</em>}</button>;
          })}
          <button className="new-space-card" onClick={showOpenDialog}><strong>＋ 打开学习空间</strong><small>打开本地文件夹，继续一段学习</small></button>
        </div></section>
        <section className="how-it-works" aria-label="如何使用观澜">
          <div><h2>问</h2><p>哪里没懂就问哪里。也可以在文档里选中一句话，接着问。</p></div>
          <div><h2>写</h2><p>讲明白的部分，Agent 会写进文档。你也可以直接动手改。</p></div>
          <div><h2>回来</h2><p>下次打开，从上次停下的地方接着问。</p></div>
        </section>
      </section>}

    {openDialog && <div className="modal-backdrop">
      <form className="open-space-dialog" role="dialog" aria-modal="true" aria-labelledby="open-space-title" onSubmit={(event) => void submitOpen(event)}>
        <span>本地学习空间</span>
        <h2 id="open-space-title">打开学习空间</h2>
        <p>选择任意本地文件夹，也可以直接输入路径。首次打开会自动创建学习空间，学习笔记保存在文件夹的 docs/learn 中。</p>
        <label htmlFor="space-root">学习空间路径</label>
        <div className="space-path-picker">
          <input id="space-root" autoFocus value={root} disabled={choosingFolder || opening} onChange={(event) => setRoot(event.target.value)} placeholder="/Users/name/code/my-project" />
          <button type="button" disabled={choosingFolder || opening} onClick={() => void browseFolder()}>{choosingFolder ? "选择文件夹…" : "浏览文件夹"}</button>
        </div>
        {openError && <div className="dialog-error" role="alert">{openError}</div>}
        <div><button type="button" disabled={choosingFolder || opening} onClick={() => setOpenDialog(false)}>取消</button><button className="primary-button" disabled={choosingFolder || opening || !root.trim()}>{opening ? "正在打开…" : "打开"}</button></div>
      </form>
    </div>}
  </main>;
}
