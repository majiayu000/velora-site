export type DocumentMetadata = {
  id: string;
  path: string;
  title: string;
  summary: string;
  stage?: string;
  tags?: string[];
  prerequisites?: string[];
  related?: string[];
};

export type LearnManifest = {
  version: 1;
  site: { title: string; description?: string };
  contentRoots: string[];
  documents: DocumentMetadata[];
};

export type DocumentSnapshot = DocumentMetadata & {
  body: string;
  contentHash: string;
  modifiedAt: string;
};

export type WorkspaceSnapshot = {
  site: LearnManifest["site"];
  documents: DocumentMetadata[];
  manifestHash: string;
  runtime: RuntimeHealth;
};

export type RuntimeHealth = {
  adapter: string;
  available: boolean;
  version?: string;
  message?: string;
};

export type QuestionIntent = "answer" | "revise" | "auto";

export type EditTarget = { from: number; to: number; baseHash: string; blockId?: string; ifHash?: string };

export type TextAnchor = {
  exactQuote: string;
  prefix?: string;
  suffix?: string;
  headingPath?: string[];
  snapshotHash?: string;
};

export type QuestionRequest = {
  documentId?: string;
  conversationId?: string;
  question: string;
  intent: QuestionIntent;
  anchor?: TextAnchor;
  target?: EditTarget;
};

export type RuntimeRequest = QuestionRequest & {
  document?: DocumentSnapshot;
  documents?: DocumentMetadata[];
  contentRoots?: string[];
  siteTitle: string;
  conversation?: Array<Pick<TurnRecord, "question" | "answerMarkdown" | "status" | "error" | "appliedEdits">>;
};

export type RuntimeResult = {
  answerMarkdown: string;
  evidence: EvidenceReference[];
  proposal: null | {
    summary: string;
    replacementMarkdown: string;
  };
  structureProposal: null | {
    summary: string;
    operations: StructureOperation[];
  };
};

export type EvidenceReference = {
  state: "verified" | "inferred" | "unknown";
  label: string;
  path?: string;
  line?: number;
  detail?: string;
  capturedHash?: string;
  stale?: boolean;
};

export type StructureOperation =
  | { type: "create"; document: DocumentMetadata; body: string }
  | { type: "update"; documentId: string; title: string; summary: string }
  | { type: "rename"; documentId: string; nextPath: string; title?: string }
  | { type: "delete"; documentId: string };

export type StructureProposal = {
  id: string;
  turnId: string;
  baseManifestHash: string;
  summary: string;
  operations: StructureOperation[];
  status: "pending" | "accepted" | "rejected" | "conflict";
  createdAt: string;
};

export type StructureMutationResult = {
  manifestHash: string;
  documents: DocumentMetadata[];
  changedPaths: string[];
  warnings?: string[];
};

export type SearchResult = {
  document: DocumentMetadata;
  score: number;
  snippet: string;
};

export type WorkspaceInsights = {
  disconnectedDocumentIds: string[];
  duplicateQuestionGroups: Array<{ normalizedQuestion: string; turnIds: string[] }>;
};

export type Proposal = {
  id: string;
  turnId: string;
  documentId: string;
  baseHash: string;
  baseMarkdown: string;
  blockOperation?: { type: "insert"; after: string; markdown: string } | { type: "replace"; blockId: string; ifHash: string; markdown: string };
  summary: string;
  replacementMarkdown: string;
  status: "pending" | "accepted" | "rejected" | "conflict";
  createdAt: string;
};

export type TurnRecord = {
  id: string;
  conversationId: string;
  documentId?: string;
  documentIds?: string[];
  question: string;
  intent: QuestionIntent;
  anchor?: TextAnchor;
  target?: EditTarget;
  status: "running" | "completed" | "failed" | "cancelled";
  answerMarkdown?: string;
  appliedEdits?: number;
  evidence?: EvidenceReference[];
  proposalId?: string;
  structureProposalId?: string;
  duplicateOfTurnId?: string;
  error?: string;
  createdAt: string;
};

export type LearnEvent = {
  sequence: number;
  type: string;
  at: string;
  payload: Record<string, unknown>;
};

export type ReceiptBase = { id: string; at: string };

export type TurnReceipt = ReceiptBase & {
  kind: "turn";
  turn: TurnRecord;
  proposal?: Proposal;
  structureProposal?: StructureProposal;
};

export type ConversationMetadata = { id: string; title: string; pinned: boolean; archived: boolean };
export type ConversationSummary = ConversationMetadata & {
  createdAt: string;
  updatedAt: string;
  documentId?: string;
  status: TurnRecord["status"];
};
export type ConversationReceipt = ReceiptBase & { kind: "conversation"; conversation: ConversationMetadata };

export type DecisionReceipt = ReceiptBase & {
  kind: "decision";
  proposalKind: "document" | "structure";
  proposalId: string;
  turnId: string;
  decision: "accepted" | "rejected";
};

export type MutationReceipt = ReceiptBase & {
  kind: "mutation";
  source: "human" | "proposal" | "structure" | "revert";
  summary: string;
  files: string[];
  git: { status: "committed"; commit: string } | { status: "unavailable" | "failed"; message: string };
  revertedReceiptId?: string;
};

export type AuditReceipt = TurnReceipt | DecisionReceipt | MutationReceipt | ConversationReceipt;

export type RevertPreview = {
  receiptId: string;
  commit: string;
  files: string[];
  patch: string;
  canApply: boolean;
  conflict?: string;
};
