import { randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";
import { LearnError } from "../../domain/errors";
import type { AuditReceipt } from "../../domain/types";
import type { ReceiptPort } from "../../ports/receipt-port";

// A proposal receipt includes both the base and replacement of a 1 MiB document.
const MAX_RECEIPT_BYTES = 4 * 1024 * 1024;

function within(candidate: string, parent: string): boolean {
  const relative = path.relative(parent, candidate);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

export class FileReceiptStore implements ReceiptPort {
  private directory = "";
  private receipts = new Map<string, AuditReceipt>();

  constructor(private readonly repositoryRoot: string) {}

  async initialize(): Promise<void> {
    const root = await fs.realpath(this.repositoryRoot);
    const learnDirectory = path.join(root, ".learn");
    await fs.mkdir(learnDirectory, { recursive: true, mode: 0o700 });
    const realLearn = await fs.realpath(learnDirectory);
    if (!within(realLearn, root)) throw new LearnError("PATH_ESCAPE", ".learn directory escapes repository", 500);
    const directory = path.join(realLearn, "receipts");
    await fs.mkdir(directory, { recursive: true, mode: 0o700 });
    this.directory = await fs.realpath(directory);
    if (!within(this.directory, root)) throw new LearnError("PATH_ESCAPE", "Receipt directory escapes repository", 500);
    const entries = (await fs.readdir(this.directory)).filter((name) => /^[a-f0-9-]+\.json$/.test(name)).sort();
    if (entries.length > 10_000) throw new LearnError("RECEIPT_LIMIT", "Receipt directory exceeds 10000 entries", 500);
    const loaded = new Map<string, AuditReceipt>();
    for (const entry of entries) {
      const file = path.join(this.directory, entry);
      const stat = await fs.stat(file);
      if (!stat.isFile() || stat.size > MAX_RECEIPT_BYTES) throw new LearnError("INVALID_RECEIPT", `Invalid receipt file: ${entry}`, 500);
      const receipt = JSON.parse(await fs.readFile(file, "utf8")) as AuditReceipt;
      if (!receipt || typeof receipt.id !== "string" || `${receipt.id}.json` !== entry || !["turn", "decision", "mutation", "conversation"].includes(receipt.kind)) {
        throw new LearnError("INVALID_RECEIPT", `Malformed receipt: ${entry}`, 500);
      }
      loaded.set(receipt.id, receipt);
    }
    this.receipts = loaded;
  }

  async append(receipt: AuditReceipt): Promise<void> {
    if (!this.directory) throw new LearnError("RECEIPTS_NOT_INITIALIZED", "Receipt store is not initialized", 500);
    if (this.receipts.has(receipt.id)) throw new LearnError("RECEIPT_EXISTS", `Receipt already exists: ${receipt.id}`, 409);
    const raw = `${JSON.stringify(receipt, null, 2)}\n`;
    if (Buffer.byteLength(raw, "utf8") > MAX_RECEIPT_BYTES) throw new LearnError("RECEIPT_TOO_LARGE", "Receipt exceeds 4 MiB", 413);
    const target = path.join(this.directory, `${receipt.id}.json`);
    const temporary = path.join(this.directory, `.${receipt.id}.${randomUUID()}.tmp`);
    const handle = await fs.open(temporary, "wx", 0o600);
    try { await handle.writeFile(raw, "utf8"); await handle.sync(); } finally { await handle.close(); }
    try { await fs.rename(temporary, target); }
    catch (error) {
      try { await fs.unlink(temporary); }
      catch (cleanupError) {
        throw new LearnError("RECEIPT_CLEANUP_FAILED", "Receipt write and temporary-file cleanup both failed", 500, {
          writeError: error instanceof Error ? error.message : String(error),
          cleanupError: cleanupError instanceof Error ? cleanupError.message : String(cleanupError),
        });
      }
      throw error;
    }
    const directoryHandle = await fs.open(this.directory, "r");
    try { await directoryHandle.sync(); } finally { await directoryHandle.close(); }
    this.receipts.set(receipt.id, structuredClone(receipt));
  }

  list(): AuditReceipt[] { return [...this.receipts.values()].sort((left, right) => right.at.localeCompare(left.at)).map((receipt) => structuredClone(receipt)); }
  get(id: string): AuditReceipt | undefined { const receipt = this.receipts.get(id); return receipt ? structuredClone(receipt) : undefined; }
}
