import type { BlockOperation, CollaborationPort, DocumentEditOperation } from "../ports/collaboration-port";
import { randomUUID } from "node:crypto";
import { validateEvidenceReferences } from "../domain/evidence";
import { LearnError, asLearnError } from "../domain/errors";
import { validateStructureOperations } from "../domain/structure";
import type { AuditReceipt, DocumentSnapshot, EvidenceReference, MutationReceipt, Proposal, QuestionRequest, RevertPreview, RuntimeHealth, SearchResult, StructureOperation, StructureProposal, TextAnchor, TurnRecord, WorkspaceInsights, WorkspaceSnapshot } from "../domain/types";
import type { EventPort } from "../ports/event-port";
import type { RuntimeCallbacks, RuntimePort } from "../ports/runtime-port";
import type { WorkspacePort } from "../ports/workspace-port";
import type { HistoryPort } from "../ports/history-port";
import type { ReceiptPort } from "../ports/receipt-port";
import type { ConversationMetadata, ConversationSummary } from "../domain/types";

class MemoryReceiptPort implements ReceiptPort {
  private readonly receipts = new Map<string, AuditReceipt>();
  async initialize(): Promise<void> {}
  async append(receipt: AuditReceipt): Promise<void> { this.receipts.set(receipt.id, structuredClone(receipt)); }
  list(): AuditReceipt[] { return [...this.receipts.values()].sort((left, right) => right.at.localeCompare(left.at)); }
  get(id: string): AuditReceipt | undefined { return this.receipts.get(id); }
}

class UnavailableHistoryPort implements HistoryPort {
  async initialize(): Promise<void> {}
  async commit() { return { status: "unavailable" as const, message: "Git history adapter is not configured" }; }
  async previewRevert(receiptId: string, commit: string, files: string[]): Promise<RevertPreview> { return { receiptId, commit, files, patch: "", canApply: false, conflict: "Git history adapter is not configured" }; }
  async applyRevert() { return { status: "unavailable" as const, message: "Git history adapter is not configured" }; }
}

export class LearnEngine {
  private readonly turns = new Map<string, TurnRecord>();
  private readonly proposals = new Map<string, Proposal>();
  private readonly structureProposals = new Map<string, StructureProposal>();
  private readonly hashes = new Map<string, string>();
  private runtimeHealth: RuntimeHealth = { adapter: "unknown", available: false, message: "Runtime 尚未检查" };
  private activeTurnId?: string;
  private activeAbortController?: AbortController;
  private changingRuntime = false;
  private conversationWrites = Promise.resolve();
  private lastReceiptTime = 0;

  constructor(
    readonly store: WorkspacePort,
    readonly events: EventPort,
    public runtime: RuntimePort,
    readonly receipts: ReceiptPort = new MemoryReceiptPort(),
    readonly history: HistoryPort = new UnavailableHistoryPort(),
    readonly collaboration?: CollaborationPort,
  ) {}

  async initialize(): Promise<void> {
    await this.store.initialize();
    await this.receipts.initialize();
    for (const receipt of this.receipts.list().sort((a, b) => a.at.localeCompare(b.at))) {
      this.lastReceiptTime = Math.max(this.lastReceiptTime, Date.parse(receipt.at));
      if (receipt.kind === "turn") {
        this.turns.set(receipt.turn.id, structuredClone(receipt.turn));
        if (receipt.proposal) this.proposals.set(receipt.proposal.id, structuredClone(receipt.proposal));
        if (receipt.structureProposal) this.structureProposals.set(receipt.structureProposal.id, structuredClone(receipt.structureProposal));
      }
      if (receipt.kind === "decision") {
        const proposal = receipt.proposalKind === "document" ? this.proposals.get(receipt.proposalId) : this.structureProposals.get(receipt.proposalId);
        if (proposal) proposal.status = receipt.decision;
      }
    }
    for (const turn of this.turns.values()) {
      if (turn.status !== "running") continue;
      turn.status = "failed";
      turn.error = "服务已重启，上一个 Agent 回合已中断。已保存的文档修改仍保留，请检查后继续提问。";
      await this.persistTurn(turn);
    }
    await this.history.initialize();
    for (const document of this.store.listDocuments()) {
      const snapshot = await this.store.getDocument(document.id);
      this.hashes.set(document.id, snapshot.contentHash);
    }
    this.runtimeHealth = await this.runtime.health();
  }

  getWorkspace(): WorkspaceSnapshot {
    return {
      site: this.store.site,
      documents: this.store.listDocuments(),
      manifestHash: this.store.manifestHash,
      runtime: this.runtimeHealth,
    };
  }

  async changeRuntime(next: RuntimePort, persist: () => Promise<void>): Promise<RuntimeHealth> {
    if (this.activeTurnId || this.changingRuntime) {
      next.close();
      throw new LearnError("RUNTIME_BUSY", "请等待当前 Agent 回合或设置保存完成后再切换。", 409);
    }
    this.changingRuntime = true;
    try {
      const health = await next.health();
      if (!health.available) throw new LearnError("RUNTIME_UNAVAILABLE", health.message ?? "所选 Agent 暂不可用，请检查安装和登录状态。", 503);
      await persist();
      const previous = this.runtime;
      this.runtime = next;
      this.runtimeHealth = health;
      previous.close();
      this.events.publish("runtime.changed", { runtime: health });
      return health;
    } catch (error) {
      next.close();
      throw error;
    } finally {
      this.changingRuntime = false;
    }
  }

  async saveDocument(id: string, body: string, expectedHash: string, source: "human" | "proposal" = "human") {
    const before = await this.store.getDocument(id);
    const snapshot = this.collaboration ? await this.collaboration.replace(id, body, expectedHash) : await this.store.saveDocument(id, body, expectedHash);
    this.hashes.set(id, snapshot.contentHash);
    this.events.publish("document.saved", {
      documentId: id,
      contentHash: snapshot.contentHash,
      source,
    });
    try {
      await this.recordMutation(source, source === "human" ? `Human saved ${snapshot.title}` : `Accepted document proposal for ${snapshot.title}`, [before.path]);
    } catch (error) {
      const known = asLearnError(error);
      throw new LearnError(known.code, `Markdown 已写入，但历史记录失败：${known.message}`, known.status, {
        ...known.details,
        mutationApplied: true,
        documentId: id,
      });
    }
    return snapshot;
  }

  listReceipts(): AuditReceipt[] {
    const seen = new Set<string>();
    return this.receipts.list().sort((a, b) => b.at.localeCompare(a.at)).filter(receipt => {
      if (receipt.kind !== "turn") return true;
      if (seen.has(receipt.turn.id)) return false;
      seen.add(receipt.turn.id);
      return true;
    }).map(receipt => receipt.kind === "turn" ? {
      ...receipt,
      proposal: receipt.turn.proposalId ? structuredClone(this.proposals.get(receipt.turn.proposalId)) : undefined,
      structureProposal: receipt.turn.structureProposalId ? structuredClone(this.structureProposals.get(receipt.turn.structureProposalId)) : undefined,
    } : receipt);
  }

  listConversations(query = ""): ConversationSummary[] {
    const metadata = new Map<string, ConversationMetadata>();
    for (const receipt of this.receipts.list().sort((a, b) => a.at.localeCompare(b.at))) {
      if (receipt.kind === "conversation") metadata.set(receipt.conversation.id, receipt.conversation);
    }
    const conversations = new Map<string, ConversationSummary>();
    const matches = new Set<string>();
    const needle = query.trim().toLocaleLowerCase();
    for (const turn of [...this.turns.values()].sort((a, b) => a.createdAt.localeCompare(b.createdAt))) {
      if (!turn.conversationId) continue;
      const previous = conversations.get(turn.conversationId);
      conversations.set(turn.conversationId, {
        id: turn.conversationId, title: previous?.title ?? turn.question,
        pinned: false, archived: false, ...metadata.get(turn.conversationId),
        createdAt: previous?.createdAt ?? turn.createdAt, updatedAt: turn.createdAt,
        documentId: turn.documentId ?? previous?.documentId, status: turn.status,
      });
      if (`${turn.question}\n${turn.answerMarkdown ?? ""}`.toLocaleLowerCase().includes(needle)) matches.add(turn.conversationId);
    }
    return [...conversations.values()]
      .filter(item => !needle || matches.has(item.id) || item.title.toLocaleLowerCase().includes(needle))
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt.localeCompare(a.updatedAt));
  }

  updateConversation(id: string, input: Record<string, unknown>): Promise<ConversationSummary> {
    const write = this.conversationWrites.then(async () => {
      const current = this.listConversations().find(item => item.id === id);
      if (!current) throw new LearnError("NOT_FOUND", "找不到这段对话", 404);
      const patch: Partial<ConversationMetadata> = {};
      if ("title" in input) {
        if (typeof input.title !== "string" || !input.title.trim() || input.title.trim().length > 200) throw new LearnError("INVALID_REQUEST", "对话名称须为 1–200 个字符", 422);
        patch.title = input.title.trim();
      }
      for (const field of ["pinned", "archived"] as const) {
        if (!(field in input)) continue;
        if (typeof input[field] !== "boolean") throw new LearnError("INVALID_REQUEST", `${field} must be boolean`, 422);
        patch[field] = input[field];
      }
      if (!Object.keys(patch).length) throw new LearnError("INVALID_REQUEST", "请指定名称、置顶或归档状态", 422);
      const conversation: ConversationMetadata = { id, title: current.title, pinned: current.pinned, archived: current.archived, ...patch };
      await this.appendReceipt({ id: randomUUID(), kind: "conversation", at: new Date().toISOString(), conversation });
      const result = { ...current, ...conversation };
      this.events.publish("conversation.updated", { conversation: result });
      return result;
    });
    this.conversationWrites = write.then(() => {}, () => {});
    return write;
  }

  async previewRevert(receiptId: string): Promise<RevertPreview> {
    const receipt = this.requireMutationReceipt(receiptId);
    if (receipt.git.status !== "committed") return { receiptId, commit: "", files: receipt.files, patch: "", canApply: false, conflict: receipt.git.message };
    return this.history.previewRevert(receiptId, receipt.git.commit, receipt.files);
  }

  async revertReceipt(receiptId: string): Promise<{ receipt: MutationReceipt; workspace: WorkspaceSnapshot }> {
    const original = this.requireMutationReceipt(receiptId);
    if (original.git.status !== "committed") throw new LearnError("HISTORY_UNAVAILABLE", original.git.message, 409);
    const committed = await this.history.applyRevert(receiptId, original.git.commit, original.files);
    if (committed.status !== "committed") throw new LearnError("HISTORY_COMMIT_FAILED", committed.message, 500);
    await this.store.initialize();
    await this.refreshDocumentHashes();
    const receipt: MutationReceipt = {
      id: randomUUID(), kind: "mutation", at: new Date().toISOString(), source: "revert",
      summary: `Reverted receipt ${receiptId}`, files: original.files, git: committed, revertedReceiptId: receiptId,
    };
    try {
      await this.appendReceipt(receipt);
    } catch (error) {
      const known = asLearnError(error);
      throw new LearnError(known.code, `撤销提交已经应用，但审计收据写入失败：${known.message}`, known.status, {
        ...known.details,
        mutationApplied: true,
        receiptId,
      });
    }
    const workspace = this.getWorkspace();
    this.events.publish("workspace.changed", { manifestHash: workspace.manifestHash, documents: workspace.documents });
    this.events.publish("history.reverted", { receipt, revertedReceiptId: receiptId });
    return { receipt, workspace };
  }

  async documentChangedExternally(id: string): Promise<void> {
    if (this.collaboration) await this.collaboration.read(id);
    const snapshot = await this.store.getDocument(id);
    if (this.hashes.get(id) === snapshot.contentHash) return;
    this.hashes.set(id, snapshot.contentHash);
    this.events.publish("document.changed", { documentId: id, contentHash: snapshot.contentHash });
  }

  createQuestion(request: QuestionRequest): TurnRecord {
    if (this.changingRuntime) throw new LearnError("RUNTIME_BUSY", "正在切换 Agent，请稍后再发送问题。", 409);
    if (!this.runtimeHealth.available) {
      throw new LearnError("RUNTIME_UNAVAILABLE", this.runtimeHealth.message ?? "Agent Runtime 当前不可用", 503);
    }
    if (this.activeTurnId) throw new LearnError("TURN_ALREADY_RUNNING", "已有一个 Agent 回合正在运行", 409);
    if (!request || typeof request.question !== "string" || (request.documentId !== undefined && (typeof request.documentId !== "string" || !request.documentId))) {
      throw new LearnError("INVALID_QUESTION", "问题与文档上下文格式无效", 400);
    }
    if (request.conversationId !== undefined && (typeof request.conversationId !== "string" || !/^[a-zA-Z0-9-]{1,80}$/.test(request.conversationId))) {
      throw new LearnError("INVALID_QUESTION", "会话标识无效", 400);
    }
    const conversationId = request.conversationId ?? randomUUID();
    const previous = [...this.turns.values()].filter(turn => turn.conversationId === conversationId && turn.documentId).sort((a, b) => a.createdAt.localeCompare(b.createdAt)).at(-1);
    const documentId = request.documentId ?? previous?.documentId;
    if ((request.target || request.intent === "revise") && !documentId) throw new LearnError("INVALID_QUESTION", "局部修订需要文档上下文", 400);
    const question = request.question.trim();
    if (!question || question.length > 8000) throw new LearnError("INVALID_QUESTION", "问题必须为 1 到 8000 个字符", 400);
    if (request.intent !== "answer" && request.intent !== "revise" && request.intent !== "auto") {
      throw new LearnError("INVALID_QUESTION", "intent must be answer, revise or auto", 400);
    }
    const anchor = this.validateAnchor(request.anchor);
    const target = request.target;
    if (target !== undefined && (!target || !Number.isInteger(target.from) || !Number.isInteger(target.to) || target.from < 0 || target.to < target.from || typeof target.baseHash !== "string" || !/^sha256:[a-f0-9]{64}$/.test(target.baseHash))) {
      throw new LearnError("INVALID_EDIT_TARGET", "修订范围无效，请重新选择正文", 400);
    }
    // Keep persisted turn order stable when successive requests share a millisecond.
    const previousTime = [...this.turns.values()].reduce((latest, turn) => Math.max(latest, Date.parse(turn.createdAt)), 0);
    const turn: TurnRecord = {
      id: randomUUID(),
      conversationId,
      documentId,
      question,
      intent: request.intent,
      anchor,
      target: target ? { ...target } : undefined,
      status: "running",
      createdAt: new Date(Math.max(Date.now(), previousTime + 1)).toISOString(),
    };
    const normalizedQuestion = this.normalizeQuestion(question);
    turn.duplicateOfTurnId = [...this.turns.values()].find((candidate) =>
      candidate.conversationId === conversationId && this.normalizeQuestion(candidate.question) === normalizedQuestion,
    )?.id;
    this.turns.set(turn.id, turn);
    this.activeTurnId = turn.id;
    const abortController = new AbortController();
    this.activeAbortController = abortController;
    this.events.publish("turn.started", { turn });
    void this.executeTurn(turn, { ...request, conversationId, documentId, question, anchor, target: turn.target }, abortController.signal);
    return turn;
  }

  getTurn(id: string): TurnRecord {
    const turn = this.turns.get(id);
    if (!turn) throw new LearnError("TURN_NOT_FOUND", `Unknown turn: ${id}`, 404);
    return turn;
  }

  getProposal(id: string): Proposal {
    const proposal = this.proposals.get(id);
    if (!proposal) throw new LearnError("PROPOSAL_NOT_FOUND", `Unknown proposal: ${id}`, 404);
    return proposal;
  }

  getStructureProposal(id: string): StructureProposal {
    const proposal = this.structureProposals.get(id);
    if (!proposal) throw new LearnError("STRUCTURE_PROPOSAL_NOT_FOUND", `Unknown structure proposal: ${id}`, 404);
    return proposal;
  }

  async search(query: string, limit?: number): Promise<SearchResult[]> {
    return this.store.searchDocuments(query, limit);
  }

  getInsights(): WorkspaceInsights {
    const documents = this.store.listDocuments();
    const linked = new Set<string>();
    for (const document of documents) {
      for (const id of [...(document.prerequisites ?? []), ...(document.related ?? [])]) {
        linked.add(document.id);
        linked.add(id);
      }
    }
    const questions = new Map<string, string[]>();
    for (const turn of this.turns.values()) {
      const normalizedQuestion = this.normalizeQuestion(turn.question);
      questions.set(normalizedQuestion, [...(questions.get(normalizedQuestion) ?? []), turn.id]);
    }
    return {
      disconnectedDocumentIds: documents.filter((document) => !linked.has(document.id)).map((document) => document.id),
      duplicateQuestionGroups: [...questions].filter(([, ids]) => ids.length > 1).map(([normalizedQuestion, turnIds]) => ({ normalizedQuestion, turnIds })),
    };
  }

  async acceptProposal(id: string): Promise<{ proposal: Proposal; document: DocumentSnapshot }> {
    const proposal = this.getProposal(id);
    if (proposal.status !== "pending" && proposal.status !== "conflict") {
      throw new LearnError("PROPOSAL_NOT_PENDING", "This proposal can no longer be accepted", 409);
    }
    try {
      const document = proposal.blockOperation && this.collaboration
        ? (await this.collaboration.operate(proposal.documentId, [proposal.blockOperation])).document
        : await this.saveDocument(proposal.documentId, proposal.replacementMarkdown, proposal.baseHash, "proposal");
      if (proposal.blockOperation) {
        proposal.status = "accepted";
        try { await this.recordMutation("proposal", `Accepted block proposal for ${document.title}`, [document.path]); }
        catch (error) {
          const known = asLearnError(error);
          throw new LearnError(known.code, `段落已写入，但历史记录失败：${known.message}`, known.status, { ...known.details, mutationApplied: true, documentId: document.id });
        }
      }
      proposal.status = "accepted";
      await this.recordDecision("document", proposal.id, proposal.turnId, "accepted");
      this.events.publish("proposal.accepted", { proposalId: id, documentId: proposal.documentId });
      return { proposal, document };
    } catch (error) {
      const known = asLearnError(error);
      if (known.details?.mutationApplied === true) proposal.status = "accepted";
      if (known.code === "DOCUMENT_CONFLICT" || known.code === "GUARD_MISMATCH") {
        proposal.status = "conflict";
        this.events.publish("proposal.conflict", { proposalId: id, documentId: proposal.documentId });
      }
      if (proposal.status === "accepted" || proposal.status === "conflict") {
        try { await this.persistTurn(this.getTurn(proposal.turnId)); }
        catch (auditError) {
          const audit = asLearnError(auditError);
          throw new LearnError(audit.code, `${known.message}；${audit.message}`, audit.status, {
            ...audit.details, ...(proposal.status === "accepted" ? { mutationApplied: true } : {}),
          });
        }
      }
      throw new LearnError(known.code, known.message, known.status, {
        ...known.details, ...(proposal.status === "accepted" ? { mutationApplied: true } : {}),
      });
    }
  }

  async rejectProposal(id: string): Promise<Proposal> {
    const proposal = this.getProposal(id);
    if (proposal.status !== "pending" && proposal.status !== "conflict") {
      throw new LearnError("PROPOSAL_NOT_PENDING", "This proposal can no longer be rejected", 409);
    }
    await this.recordDecision("document", proposal.id, proposal.turnId, "rejected");
    proposal.status = "rejected";
    this.events.publish("proposal.rejected", { proposalId: id, documentId: proposal.documentId });
    return proposal;
  }

  async acceptStructureProposal(id: string) {
    const proposal = this.getStructureProposal(id);
    if (proposal.status !== "pending" && proposal.status !== "conflict") {
      throw new LearnError("STRUCTURE_PROPOSAL_NOT_PENDING", "This structure proposal can no longer be accepted", 409);
    }
    try {
      const workspace = await this.store.applyStructure(proposal.operations, proposal.baseManifestHash);
      proposal.status = "accepted";
      this.hashes.clear();
      for (const document of this.store.listDocuments()) {
        const snapshot = await this.store.getDocument(document.id);
        this.hashes.set(document.id, snapshot.contentHash);
      }
      this.events.publish("structure-proposal.accepted", { proposalId: id, workspace, warnings: workspace.warnings });
      this.events.publish("workspace.changed", { manifestHash: workspace.manifestHash, documents: workspace.documents });
      try {
        await this.recordMutation("structure", proposal.summary, workspace.changedPaths);
      } catch (error) {
        const known = asLearnError(error);
        throw new LearnError(known.code, `结构变更已经应用，但历史记录失败：${known.message}`, known.status, {
          ...known.details,
          mutationApplied: true,
          proposalId: proposal.id,
        });
      }
      await this.recordDecision("structure", proposal.id, proposal.turnId, "accepted");
      return { proposal, workspace };
    } catch (error) {
      const known = asLearnError(error);
      if (known.code === "MANIFEST_CONFLICT" || known.code === "DOCUMENT_EXISTS") {
        proposal.status = "conflict";
        this.events.publish("structure-proposal.conflict", { proposalId: id, code: known.code });
      }
      if (proposal.status === "accepted" || proposal.status === "conflict") {
        try { await this.persistTurn(this.getTurn(proposal.turnId)); }
        catch (auditError) {
          const audit = asLearnError(auditError);
          throw new LearnError(audit.code, `${known.message}；${audit.message}`, audit.status, {
            ...audit.details, ...(proposal.status === "accepted" ? { mutationApplied: true } : {}),
          });
        }
      }
      throw new LearnError(known.code, known.message, known.status, {
        ...known.details, ...(proposal.status === "accepted" ? { mutationApplied: true } : {}),
      });
    }
  }

  async rejectStructureProposal(id: string): Promise<StructureProposal> {
    const proposal = this.getStructureProposal(id);
    if (proposal.status !== "pending" && proposal.status !== "conflict") {
      throw new LearnError("STRUCTURE_PROPOSAL_NOT_PENDING", "This structure proposal can no longer be rejected", 409);
    }
    await this.recordDecision("structure", proposal.id, proposal.turnId, "rejected");
    proposal.status = "rejected";
    this.events.publish("structure-proposal.rejected", { proposalId: id });
    return proposal;
  }

  async refreshEvidence(turnId: string): Promise<EvidenceReference[]> {
    const turn = this.getTurn(turnId);
    if (!turn.evidence) return [];
    turn.evidence = await Promise.all(turn.evidence.map(async (evidence) => {
      if (evidence.state !== "verified" || !evidence.path || !evidence.capturedHash) return evidence;
      try {
        const currentHash = await this.store.fingerprintDocument(evidence.path);
        return { ...evidence, stale: currentHash !== evidence.capturedHash };
      } catch {
        return { ...evidence, stale: true };
      }
    }));
    this.events.publish("turn.evidence.refreshed", { turnId, evidence: turn.evidence });
    return turn.evidence;
  }

  async cancelTurn(id: string): Promise<TurnRecord> {
    const turn = this.getTurn(id);
    if (turn.status !== "running") return turn;
    if (this.activeTurnId !== id || !this.activeAbortController) {
      throw new LearnError("TURN_NOT_ACTIVE", "This turn is no longer the active runtime owner", 409);
    }
    this.activeAbortController.abort();
    return turn;
  }

  close(): void {
    this.activeAbortController?.abort();
    this.runtime.close();
    this.events.close();
  }

  private async executeTurn(turn: TurnRecord, request: QuestionRequest, signal: AbortSignal): Promise<void> {
    let finalStatus: TurnRecord["status"] = "completed";
    try {
      await this.persistTurn(turn);
      let document = request.documentId ? await this.store.getDocument(request.documentId) : undefined;
      const currentDocument = () => {
        if (!document) throw new LearnError("DOCUMENT_NOT_FOUND", "先打开已有文档或创建新文档", 409);
        return document;
      };
      let target = request.target;
      if (target?.blockId) {
        if (!this.collaboration) throw new LearnError("COLLABORATION_UNAVAILABLE", "Block editing requires collaboration", 409);
        const snapshot = await this.collaboration.read(currentDocument().id);
        const block = snapshot.blocks.find(b => b.id === target!.blockId);
        if (!block) throw new LearnError("BLOCK_NOT_FOUND", "Selected block no longer exists", 404);
        if (block.hash !== target.ifHash) throw new LearnError("GUARD_MISMATCH", "Selected block changed; select it again", 409);
        const insert = target.from === target.to;
        document = snapshot.document;
        target = { ...target, from: insert ? block.to : block.from, to: block.to, baseHash: document.contentHash };
      }
      if (target && (target.baseHash !== currentDocument().contentHash || target.to > currentDocument().body.length)) {
        throw new LearnError("DOCUMENT_CONFLICT", "选择范围的文档已变化，请重新读取并选择", 409);
      }
      let baseManifestHash = this.store.manifestHash;
      let toolFailure: Error | undefined;
      let acceptingOperations = true;
      let operationQueue = Promise.resolve();
      const collaboration = this.collaboration;
      const allowed = new Set(target?.blockId && target.from !== target.to ? [target.blockId] : []);
      const anchors = new Set(target?.blockId ? [target.blockId] : []);
      const checkActive = () => {
        if (toolFailure) throw toolFailure;
        if (signal.aborted || !acceptingOperations) throw new LearnError("TURN_CANCELLED", "Agent 回合已结束或取消", 409);
      };
      const checkScope = (operation: BlockOperation | DocumentEditOperation) => {
        if (target && (!operation || (operation.type === "insert" ? !anchors.has(operation.after ?? "") : !allowed.has(operation.blockId)))) {
          throw new LearnError("INVALID_SCOPED_PROPOSAL", "只能修改选定段落，或在指定位置继续插入", 422);
        }
      };
      const documentTools: RuntimeCallbacks["document"] = request.intent === "auto" && collaboration && (!target || target.blockId) ? {
        read: async () => { checkActive(); const { revision, blocks, document: snapshot } = await collaboration.read(currentDocument().id); return { revision, blocks, document: snapshot }; },
        apply: operation => {
          const task = operationQueue.then(async () => {
            checkActive();
            checkScope(operation);
            const selected = currentDocument();
            let applied = false;
            try {
              const next = await collaboration.operate(selected.id, [operation], signal);
              applied = true;
              for (const id of next.insertedBlockIds) { allowed.add(id); anchors.add(id); }
              this.hashes.set(selected.id, next.document.contentHash);
              await this.recordMutation("proposal", `Agent edited a block in ${selected.title}`, [selected.path]);
              return { revision: next.revision, blocks: next.blocks, insertedBlockIds: next.insertedBlockIds };
            } catch (error) {
              const known = asLearnError(error);
              applied ||= known.details?.mutationApplied === true;
              if (applied) {
                toolFailure = new LearnError(known.code, `段落修改已写入，但后续保存或历史记录失败：${known.message}`, known.status, { ...known.details, mutationApplied: true });
                throw toolFailure;
              }
              throw error;
            } finally {
              if (applied) {
                turn.appliedEdits = (turn.appliedEdits ?? 0) + 1;
                turn.documentIds = [...new Set([...(turn.documentIds ?? []), selected.id])];
                this.events.publish("turn.edited", { turnId: turn.id, appliedEdits: turn.appliedEdits, documentIds: turn.documentIds });
              }
            }
          });
          operationQueue = task.then(() => {}, () => {});
          return task;
        },
      } : undefined;
      const bindDocument = async (id: string) => {
        document = await this.store.getDocument(id);
        turn.documentId = id;
        this.events.publish("turn.document", { turn: { ...turn }, document });
        if (!collaboration) return { document, revision: 0, blocks: [] };
        const snapshot = await collaboration.read(id);
        return { document: snapshot.document, revision: snapshot.revision, blocks: snapshot.blocks };
      };
      const mutateStructure = async (operation: StructureOperation, id: string) => {
        checkActive();
        let applied = false;
        try {
          const next = await this.store.applyStructure([operation], baseManifestHash);
          applied = true;
          baseManifestHash = next.manifestHash;
          turn.documentIds = [...new Set([...(turn.documentIds ?? []), id])];
          this.events.publish("workspace.changed", { manifestHash: next.manifestHash, documents: next.documents });
          const snapshot = await bindDocument(id);
          if (next.warnings?.length) this.events.publish("history.warning", { message: next.warnings.join("\n") });
          await this.recordMutation("structure", `Agent ${operation.type} ${snapshot.document.title}`, next.changedPaths);
          return snapshot;
        } catch (error) {
          const known = asLearnError(error);
          if (applied || known.details?.mutationApplied) {
            toolFailure = new LearnError(known.code, `文档变更已写入，但后续处理失败：${known.message}`, known.status, { ...known.details, mutationApplied: true, documentId: id });
            throw toolFailure;
          }
          throw error;
        }
      };
      const workspaceTools: RuntimeCallbacks["workspace"] = documentTools && !target ? {
        open: async id => { await operationQueue; checkActive(); return bindDocument(id); },
        create: async (metadata, body) => { await operationQueue; return mutateStructure({ type: "create", document: metadata, body }, metadata.id); },
        update: async (title, summary) => { await operationQueue; return mutateStructure({ type: "update", documentId: currentDocument().id, title, summary }, currentDocument().id); },
      } : undefined;
      const conversation = [...this.turns.values()]
        .filter(previous => previous.id !== turn.id && previous.conversationId === turn.conversationId && previous.status !== "running")
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt)).slice(-12)
        .map(({ question, answerMarkdown, status, error, appliedEdits }) => ({ question: question.slice(0, 4000), answerMarkdown: answerMarkdown?.slice(0, 8000), status, error, appliedEdits }));
      const result = await this.runtime.run(
        { ...request, target, document, documents: this.store.listDocuments(), contentRoots: this.store.documentRoots, siteTitle: this.store.site.title, conversation },
        {
          onProgress: (message) => this.events.publish("turn.progress", { turnId: turn.id, message }),
          onDelta: (delta) => this.events.publish("turn.output.delta", { turnId: turn.id, delta }),
          onEdit: event => {
            if (!documentTools) throw new LearnError("INVALID_TOOL_CALL", "本回合不接受正文编辑", 403);
            if (event.type === "started") { checkActive(); checkScope(event.operation); }
            this.events.publish(`document.edit.${event.type}`, { ...event, documentId: currentDocument().id, turnId: turn.id });
          },
          document: documentTools,
          workspace: workspaceTools,
        },
        signal,
      ).finally(async () => { acceptingOperations = false; await operationQueue; });
      if (toolFailure) throw toolFailure;
      if (signal.aborted) throw new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409);
      if ((turn.appliedEdits || turn.documentIds?.length) && (result.proposal || result.structureProposal)) throw new LearnError("AMBIGUOUS_PROPOSAL", "段落修改已经写入，本回合不能再提交整篇或结构提案", 422);
      if (result.proposal && result.structureProposal) throw new LearnError("AMBIGUOUS_PROPOSAL", "A turn cannot propose body and site structure changes together", 422);
      if (target && result.structureProposal) {
        throw new LearnError("INVALID_SCOPED_PROPOSAL", "局部修订不能改变页面结构", 422);
      }
      turn.answerMarkdown = result.answerMarkdown;
      turn.evidence = await this.captureEvidence(validateEvidenceReferences(result.evidence));
      if (result.proposal) {
        document = currentDocument();
        const proposal: Proposal = {
          id: randomUUID(),
          turnId: turn.id,
          documentId: document.id,
          baseHash: document.contentHash,
          baseMarkdown: document.body,
          summary: result.proposal.summary,
          ...(target?.blockId ? { blockOperation: target.from === target.to
            ? { type: "insert" as const, after: target.blockId, markdown: result.proposal.replacementMarkdown }
            : { type: "replace" as const, blockId: target.blockId, ifHash: target.ifHash!, markdown: result.proposal.replacementMarkdown } } : {}),
          replacementMarkdown: target
            ? document.body.slice(0, target.from) + result.proposal.replacementMarkdown + document.body.slice(target.to)
            : result.proposal.replacementMarkdown,
          status: "pending",
          createdAt: new Date().toISOString(),
        };
        this.proposals.set(proposal.id, proposal);
        turn.proposalId = proposal.id;
        await this.persistTurn(turn);
        this.events.publish("proposal.created", { proposal });
        if (request.intent === "auto") {
          if (signal.aborted) throw new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409);
          try { await this.acceptProposal(proposal.id); }
          finally {
            this.events.publish("proposal.updated", { proposal });
            if (proposal.status === "accepted") {
              turn.documentIds = [document.id];
              await bindDocument(document.id);
            }
          }
        }
      }
      if (result.structureProposal) {
        const proposal: StructureProposal = {
          id: randomUUID(),
          turnId: turn.id,
          baseManifestHash,
          summary: result.structureProposal.summary.trim(),
          operations: validateStructureOperations(result.structureProposal.operations),
          status: "pending",
          createdAt: new Date().toISOString(),
        };
        if (!proposal.summary) throw new LearnError("INVALID_STRUCTURE_PROPOSAL", "Structure proposal summary is required", 422);
        this.structureProposals.set(proposal.id, proposal);
        turn.structureProposalId = proposal.id;
        await this.persistTurn(turn);
        this.events.publish("structure-proposal.created", { proposal });
        if (request.intent === "auto" && proposal.operations.every(operation => operation.type === "create" || operation.type === "update")) {
          if (signal.aborted) throw new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409);
          try { await this.acceptStructureProposal(proposal.id); }
          finally {
            if (proposal.status === "accepted") {
              turn.documentIds = proposal.operations.map(operation => operation.type === "create" ? operation.document.id : operation.documentId);
              await bindDocument(turn.documentIds[0]!);
            }
          }
        }
      }
    } catch (error) {
      const known = asLearnError(error);
      finalStatus = known.code === "TURN_CANCELLED" ? "cancelled" : "failed";
      turn.error = known.message;
    } finally {
      try {
        await this.persistTurn({ ...turn, status: finalStatus });
      } catch (error) {
        const known = asLearnError(error);
        finalStatus = "failed";
        turn.error = `回答已结束，但审计收据写入失败：${known.message}`;
      }
      turn.status = finalStatus;
      if (this.activeTurnId === turn.id) {
        this.activeTurnId = undefined;
        this.activeAbortController = undefined;
      }
      const terminalEvent = turn.status === "completed" ? "turn.completed" : turn.status === "cancelled" ? "turn.cancelled" : "turn.failed";
      this.events.publish(terminalEvent, { turn });
    }
  }

  private async refreshDocumentHashes(): Promise<void> {
    this.hashes.clear();
    for (const document of this.store.listDocuments()) this.hashes.set(document.id, (await this.store.getDocument(document.id)).contentHash);
  }

  private async recordMutation(source: MutationReceipt["source"], summary: string, files: string[]): Promise<MutationReceipt> {
    let git: MutationReceipt["git"];
    try { git = await this.history.commit(files, `learn: ${source} ${summary}`); }
    catch (error) { git = { status: "failed", message: error instanceof Error ? error.message : String(error) }; }
    const receipt: MutationReceipt = { id: randomUUID(), kind: "mutation", at: new Date().toISOString(), source, summary, files, git };
    await this.appendReceipt(receipt);
    if (git.status === "failed") throw new LearnError("HISTORY_COMMIT_FAILED", git.message, 500, { receiptId: receipt.id });
    if (git.status === "unavailable") this.events.publish("history.warning", { message: git.message, receiptId: receipt.id });
    return receipt;
  }

  private async recordDecision(proposalKind: "document" | "structure", proposalId: string, turnId: string, decision: "accepted" | "rejected"): Promise<void> {
    await this.appendReceipt({ id: randomUUID(), kind: "decision", at: new Date().toISOString(), proposalKind, proposalId, turnId, decision });
  }

  private async persistTurn(turn: TurnRecord): Promise<void> {
    await this.appendReceipt({
      id: randomUUID(), kind: "turn", at: new Date().toISOString(), turn: structuredClone(turn),
      proposal: turn.proposalId ? structuredClone(this.proposals.get(turn.proposalId)) : undefined,
      structureProposal: turn.structureProposalId ? structuredClone(this.structureProposals.get(turn.structureProposalId)) : undefined,
    });
  }

  private async appendReceipt(receipt: AuditReceipt): Promise<void> {
    this.lastReceiptTime = Math.max(Date.now(), Date.parse(receipt.at), this.lastReceiptTime + 1);
    receipt.at = new Date(this.lastReceiptTime).toISOString();
    try {
      await this.receipts.append(receipt);
      this.events.publish("receipt.created", { receipt });
    } catch (error) {
      const known = asLearnError(error);
      throw new LearnError("AUDIT_RECEIPT_FAILED", `审计收据写入失败：${known.message}`, 500, { causeCode: known.code });
    }
  }

  private requireMutationReceipt(id: string): MutationReceipt {
    const receipt = this.receipts.get(id);
    if (!receipt) throw new LearnError("RECEIPT_NOT_FOUND", `Unknown receipt: ${id}`, 404);
    if (receipt.kind !== "mutation") throw new LearnError("RECEIPT_NOT_REVERTIBLE", "Only mutation receipts can be reverted", 422);
    return receipt;
  }

  private async captureEvidence(evidence: EvidenceReference[]): Promise<EvidenceReference[]> {
    return Promise.all(evidence.map(async (item) => {
      if (item.state !== "verified" || !item.path) return item;
      try {
        return { ...item, capturedHash: await this.store.fingerprintDocument(item.path), stale: false };
      } catch (error) {
        if (!(error instanceof LearnError) || error.code !== "EVIDENCE_NOT_FOUND") throw error;
        return { ...item, state: "unknown" as const, path: undefined, line: undefined, detail: error.message };
      }
    }));
  }

  private normalizeQuestion(question: string): string {
    return question.trim().toLocaleLowerCase().replace(/[\s，。！？、,.!?;；:：]+/g, " ").trim();
  }

  private validateAnchor(anchor: TextAnchor | undefined): TextAnchor | undefined {
    if (!anchor) return undefined;
    if (typeof anchor.exactQuote !== "string" || !anchor.exactQuote.trim() || anchor.exactQuote.length > 1200) {
      throw new LearnError("INVALID_ANCHOR", "Selected quote must contain 1 to 1200 characters", 400);
    }
    for (const [name, value] of [["prefix", anchor.prefix], ["suffix", anchor.suffix]] as const) {
      if (value !== undefined && (typeof value !== "string" || value.length > 500)) {
        throw new LearnError("INVALID_ANCHOR", `${name} must contain at most 500 characters`, 400);
      }
    }
    if (anchor.headingPath !== undefined) {
      if (
        !Array.isArray(anchor.headingPath) ||
        anchor.headingPath.length > 12 ||
        anchor.headingPath.some((heading) => typeof heading !== "string" || heading.length > 200)
      ) {
        throw new LearnError("INVALID_ANCHOR", "headingPath is malformed", 400);
      }
    }
    if (anchor.snapshotHash !== undefined && !/^sha256:[a-f0-9]{64}$/.test(anchor.snapshotHash)) {
      throw new LearnError("INVALID_ANCHOR", "snapshotHash must use the workspace SHA-256 content hash format", 400);
    }
    return {
      exactQuote: anchor.exactQuote.trim(),
      prefix: anchor.prefix?.trim() || undefined,
      suffix: anchor.suffix?.trim() || undefined,
      headingPath: anchor.headingPath?.map((heading) => heading.trim()).filter(Boolean),
      snapshotHash: anchor.snapshotHash,
    };
  }
}
