# 观澜 · Velora

**Learn from your materials with an AI agent. Keep what you learn as editable, local documentation.**

[![CI](https://github.com/majiayu000/agent-learning-workbench/actions/workflows/ci.yml/badge.svg)](https://github.com/majiayu000/agent-learning-workbench/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

[中文使用说明](docs/usage.zh-CN.md) · [Quick start](#quick-start) · [Use your own project](#use-your-own-project)

Ask a learning question, work with your supplied materials, and turn the answer into a learning page. Select a paragraph to ask a follow-up or request an edit. You and the agent work on the same document; changes stay on your machine. The agent works through framework document tools and guides, with no source-code or general filesystem access.

![Velora: conversation, code evidence, and a shared editable document](docs/assets/workbench.png)

[Watch the one-minute walkthrough](docs/assets/demo.mp4) · [Animated preview](docs/assets/demo.gif)

The walkthrough records an earlier preview with real model calls. The current agent works only with supplied learning documents and workbench guides. Playback is accelerated to fit one minute. [Recording details](docs/launch.md#demo)

## Quick start

You need Git, **Node.js 22.x (22.12+) or 24.x**, and a working, signed-in **Codex CLI** for agent features. Reading and manual editing remain available when the agent is unavailable. The current interface is in Chinese.

```bash
git clone https://github.com/majiayu000/agent-learning-workbench.git
cd agent-learning-workbench
npm install
npm run dev
```

Open **http://127.0.0.1:4178**. The bundled LLM inference tutorial is a sample workspace; it is separate from the workbench itself. Installation builds the CLI automatically.

For everyday use without Vite, run `npm run build` once, then `npm start`. This starts the local Node service and serves the compiled app at the same address. `npm run dev` starts the file backend separately from Vite's frontend lifecycle; frontend reloads preserve open workspaces and running agent turns. Both commands accept `LEARN_PORT`.

This open-source edition runs locally and needs no Velora account or GitHub sign-in. Agent features use the credentials of your configured local runtime. Local settings let you select Codex or Claude Code, configure the executable, and apply the selection immediately for the current space; the document toolbar exports saved Markdown. Hosted accounts, repository authorization, billing, and online sharing belong to the planned separate cloud edition. See [edition boundaries and cloud implementation plan](docs/local-and-cloud.md).

Try this:

1. Open a learning page and ask a question in the left panel.
2. Hover over a paragraph and choose **Agent 修改此段** to request a focused edit.
3. Click the document to add your own notes. Reload to check that they were saved.

If the agent is unavailable, check `codex --version`, sign in with `codex login`, then restart the server. The real-model flow was tested with Codex CLI 0.160.1. If the port is occupied, run `LEARN_PORT=5584 npm run dev` and open that port.

## Install the packaged preview

The website build provides a real `.tgz` download, with a SHA-256 file beside it. After downloading `agent-learning-workbench-0.1.0.tgz`, run these commands from the directory containing it:

```bash
mkdir velora-local
cd velora-local
npm init -y
npm install ../agent-learning-workbench-0.1.0.tgz
mkdir notes
npx --no-install learn-workbench --root ./notes init --title "My Learning Space"
npx --no-install learn-workbench --root ./notes serve
```

Open **http://127.0.0.1:4178**. Later, return to `velora-local` and run the last command again. Installing dependencies needs network access. The package includes the compiled local interface; Git, a source checkout, and a local frontend build are not required for this path. Agent features use your separately installed and signed-in Codex or Claude Code.

## Use your own project

In the workbench, choose **打开学习空间**, select any local project folder, and click **打开**. The first open creates the learning-space config and a starter note under `docs/learn`; existing files are preserved. You can also initialize a project explicitly from the CLI:

From your Velora checkout:

```bash
node dist-node/cli/main.js --root /absolute/path/to/your-project init --title "My Project"
node dist-node/cli/main.js --root /absolute/path/to/your-project dev
```

This adds `learn.config.json`, `learn.manifest.json`, and a starter page under `docs/learn/`. Initialization refuses to overwrite existing setup files. The workbench uses its own frontend; it does not copy the sample tutorial into your project.

After building the app, replace `dev` with `serve` to use the compiled interface with the standalone local backend.

Start with: “Explain one concept using the learning materials I provided, and distinguish confirmed information from inference.” Then ask the agent to preserve the useful explanation in the current learning page.

## What it does

- **Questions with evidence.** Answers can cite registered learning documents and distinguish verified information, inference, and unknowns. General explanations need no local-file references. Follow-up questions retain recent conversation context.
- **A shared document.** Edit rich text directly; ask the agent to generate or revise one paragraph at a time. Completed writes remain saved when generation stops.
- **Edits with checks.** Replacements use stable block IDs and hashes. Conflicting edits are rejected for rereading. Page creation, renaming, and deletion use reviewed structure proposals.
- **Local content.** Markdown exports, collaboration state, and history stay in your project. Export a read-only static site to share the resulting tutorial.
- **Agent access.** SDK, CLI, and MCP use the same engine. MCP exposes `learn_guide` for on-demand creation, editing, diagrams, and recovery instructions.

This is an **early preview**. It is a local learning workbench, with no hosted accounts or remote sharing permissions. The Codex adapter sends context to the service configured by your CLI; local storage does not mean offline inference. Collaborative rich-text editing works across connected browser sessions, but selections spanning separate paragraph editors remain a known gap. Static exports support reading, not live editing or agent chat.

## Publish selected learning pages

Choose the document IDs you have reviewed for publication. The exporter generates a reading homepage, individual HTML articles, working links, a local-use guide, and a 404 page. Article content is readable without JavaScript; search and diagram controls are progressively enhanced.

```bash
node dist-node/cli/main.js --root /absolute/path/to/your-project build-site \
  --documents start-here,inference-mental-model \
  --out /absolute/path/to/public-site
```

Without a domain this produces a `noindex` preview. When the final URL is known, add `--site-url https://your-domain.example/` to generate canonical URLs, sharing metadata, and `sitemap.xml`. Subdirectory URLs such as `https://your-domain.example/course/` are supported. Only the selected registered documents enter the output; unselected document bodies and related-page metadata are excluded.

The output must be a dedicated directory. Successful exports replace the complete previously generated site, including removed pages and assets. A failed build preserves the previous site. A nonempty directory that was not created by this exporter is refused. Deploy the complete new output and configure the host to serve `404.html` with HTTP 404 for missing pages; remove old deployed assets or CDN copies when withdrawing content.

For the bundled public tutorial, run `npm run build:web` and `npm --prefix learn run preview`, then open **http://127.0.0.1:4179**. Its seven sample pages are selected explicitly. Set `LEARN_SITE_URL` when building this sample for a final URL. The local editable application continues to use `npm run dev` or `npm start`.

## Build the product website and downloadable release

```bash
npm run build:website
npm run verify:release
npm run verify:website
npm --prefix learn run preview:website
```

Open **http://127.0.0.1:4180**. The product homepage links to the tutorial directory at `/learn/`, the installation guide, and the actual versioned package in `/downloads/`. Artifacts are written to `dist-release/` and `learn/website-dist/`; no registry publication happens. Set `LEARN_SITE_URL` for a final domain, otherwise pages remain `noindex` previews.

`verify:release` installs the tarball in an independent temporary project and checks initialization, the compiled server, manual saving, a deterministic test runtime, and static export. It does not use paid inference. `verify:website` checks the download bytes, navigation, mobile layout, keyboard FAQ, and reading without JavaScript using installed Google Chrome.

## Develop and verify

The quick start needs only the root installation. Install the browser test dependencies when contributing:

```bash
npm --prefix learn ci
npm run typecheck
npm test
npm run test:e2e
npm run build
```

Browser tests use installed Google Chrome. `npm run test:runtime-real` and `npm run test:e2e-real-codex` are opt-in checks that make real model calls using your signed-in CLI.

[Full usage and MCP instructions](docs/usage.zh-CN.md) · [Architecture](ARCHITECTURE.md) · [Live document editing](docs/live-docs.md)

## Try it and report what happened

Try it on a repository you actually want to understand. Tell us where setup failed, which explanation was useful, and whether you would use it again. [Open an issue](https://github.com/majiayu000/agent-learning-workbench/issues/new) or use the [short feedback prompts](docs/launch.md#first-user-trial).
