import {
  bundledSiteRoot,
  startLocalServer
} from "./chunk-BZ5URMYA.js";
import {
  LearnError,
  WorkspaceStore,
  readLearnConfig
} from "./chunk-YCOHAXJI.js";

// src/server/standalone-vite.ts
import path3 from "path";
import { promises as fs2 } from "fs";
import react from "@vitejs/plugin-react";
import { build, createServer } from "vite";

// src/server/learn-dev-plugin.ts
import path2 from "path";
import { promises as fs } from "fs";
import { createHash as createHash2 } from "crypto";

// src/server/public-site.ts
import { createHash } from "crypto";
import path from "path";
import createDOMPurify from "dompurify";
import { JSDOM } from "jsdom";

// src/adapters/markdown/markdown-renderer.ts
import DOMPurify from "dompurify";
import { Marked } from "marked";

// src/adapters/markdown/flowcharts.ts
var escape = (value) => value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
function renderFlowChart(source, prefix) {
  const chart = JSON.parse(source);
  if (!chart || typeof chart.title !== "string" || !Array.isArray(chart.rows) || !chart.rows.length || !Array.isArray(chart.edges)) throw new Error("\u9700\u8981 title\u3001rows \u548C edges");
  const ids = /* @__PURE__ */ new Set();
  const text = (value) => value === void 0 || typeof value === "string";
  if (!text(chart.description)) throw new Error("description \u9700\u8981\u662F\u6587\u5B57");
  for (const row of chart.rows) {
    if (!row || typeof row.title !== "string" || !Array.isArray(row.nodes) || !row.nodes.length) throw new Error("\u6BCF\u4E2A\u5206\u7EC4\u9700\u8981 title \u548C\u975E\u7A7A nodes");
    for (const node of row.nodes) {
      if (!node || typeof node.id !== "string" || !node.id || ids.has(node.id) || typeof node.title !== "string" || !text(node.summary) || !text(node.detail)) throw new Error("\u8282\u70B9\u9700\u8981\u552F\u4E00 id\u3001title \u548C\u6587\u5B57\u8BF4\u660E");
      ids.add(node.id);
    }
  }
  for (const edge of chart.edges) {
    if (!edge || !ids.has(edge.from) || !ids.has(edge.to) || !text(edge.label) || edge.dashed !== void 0 && typeof edge.dashed !== "boolean" || edge.route !== void 0 && edge.route !== "left" && edge.route !== "right") throw new Error("\u8FDE\u63A5\u9700\u8981\u6709\u6548\u7684 from / to\uFF1Broute \u53EF\u4E3A left \u6216 right");
  }
  if (chart.paths !== void 0 && (!Array.isArray(chart.paths) || chart.paths.some((path4) => !path4 || typeof path4.title !== "string" || !Array.isArray(path4.nodes) || path4.nodes.some((id) => !ids.has(id))))) throw new Error("\u6D41\u7A0B\u9700\u8981 title \u548C\u6709\u6548\u8282\u70B9\u5217\u8868");
  const paths = chart.paths?.length ? `<div class="flow-paths" role="group" aria-label="\u9009\u62E9\u6D41\u7A0B"><button type="button" data-flow-path="" aria-pressed="true">\u5168\u90E8\u5173\u7CFB</button>${chart.paths.map((path4) => `<button type="button" data-flow-path="${escape(JSON.stringify(path4.nodes))}" aria-pressed="false">${escape(path4.title)}</button>`).join("")}</div>` : "";
  const marker = `${prefix}-arrow`;
  const content = `<div class="flow-canvas"><svg class="flow-connections" aria-hidden="true"><defs><marker id="${marker}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#91a398"/></marker></defs><g>${chart.edges.map((edge) => `<path data-from="${escape(edge.from)}" data-to="${escape(edge.to)}"${edge.route ? ` data-route="${edge.route}"` : ""} fill="none" stroke="#91a398" stroke-width="1.6"${edge.dashed ? ' stroke-dasharray="5 4"' : ""} marker-end="url(#${marker})"/>`).join("")}</g>${chart.edges.map((edge) => edge.label ? `<text data-edge-label="" data-from="${escape(edge.from)}" data-to="${escape(edge.to)}" font-size="11" fill="#61716a" text-anchor="middle">${escape(edge.label)}</text>` : "").join("")}</svg>${chart.rows.map((row) => `<section class="flow-row"><h3>${escape(row.title)}</h3><div class="flow-nodes">${row.nodes.map((node) => `<button type="button" class="flow-node" data-node="${escape(node.id)}" aria-pressed="false" aria-label="${escape(node.title)}"><strong>${escape(node.title)}</strong><span class="flow-node-summary">${escape(node.summary || "")}</span><span class="flow-node-detail" hidden>${escape(node.detail || node.summary || node.title)}</span></button>`).join("")}</div></section>`).join("")}</div>`;
  return { title: chart.title, description: chart.description || "\u70B9\u51FB\u5361\u7247\u67E5\u770B\u8BF4\u660E\uFF1B\u7A97\u53E3\u53D8\u5316\u65F6\u8FDE\u7EBF\u968F\u8282\u70B9\u4F4D\u7F6E\u66F4\u65B0\u3002", content, paths };
}

// src/adapters/markdown/markdown-renderer.ts
function escapeHtml(value) {
  return value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}
function renderDirectives(markdown, parse) {
  return markdown.replace(/^:::(note|warning|experiment)(?:\s+([^\n]+))?\n([\s\S]*?)\n:::\s*$/gm, (_match, kind, title, body) => {
    const renderedBody = parse(body);
    const label = title?.trim() || ({ note: "\u5B66\u4E60\u63D0\u793A", warning: "\u6CE8\u610F", experiment: "\u53EF\u505A\u5B9E\u9A8C" }[kind] ?? "\u5B66\u4E60\u5757");
    return `<aside class="learn-directive directive-${kind}" data-directive="${kind}"><strong>${escapeHtml(label)}</strong>${renderedBody}</aside>`;
  });
}
function sanitizeDiagram(source, prefix, environment) {
  const parsed = environment.parseSvg(source);
  const svg = parsed.documentElement;
  if (parsed.doctype || parsed.querySelector("parsererror") || svg.localName !== "svg" || svg.namespaceURI !== "http://www.w3.org/2000/svg") return;
  environment.purifier.sanitize(svg, {
    IN_PLACE: true,
    USE_PROFILES: { svg: true },
    FORBID_TAGS: ["style", "foreignObject", "image", "use", "a", "animate", "animateMotion", "animateTransform", "set"],
    FORBID_ATTR: ["style", "href", "xlink:href"],
    ALLOW_DATA_ATTR: false,
    ADD_ATTR: ["data-node", "data-from", "data-to"]
  });
  const bounds = (svg.getAttribute("viewBox") ?? "").trim().split(/[\s,]+/).map(Number);
  if (bounds.length !== 4 || bounds.some((value) => !Number.isFinite(value)) || bounds[2] <= 0 || bounds[3] <= 0) return;
  for (const element of [svg, ...svg.querySelectorAll("*")]) {
    for (const attribute of [...element.attributes]) {
      if (attribute.name === "id") element.setAttribute("id", `${prefix}-${attribute.value}`);
      else if (/url\s*\(/i.test(attribute.value)) {
        if (/^url\(#[\w.-]+\)$/.test(attribute.value)) element.setAttribute(attribute.name, attribute.value.replace("url(#", `url(#${prefix}-`));
        else element.removeAttribute(attribute.name);
      }
    }
  }
  svg.setAttribute("role", svg.querySelector("[data-node]") ? "group" : "img");
  svg.setAttribute("aria-label", svg.querySelector("title")?.textContent || "\u6D41\u7A0B\u56FE");
  svg.removeAttribute("width");
  svg.removeAttribute("height");
  return svg;
}
function renderMarkdown(markdown, namespace = "learn", environment = {
  purifier: DOMPurify,
  parseSvg: (source) => new DOMParser().parseFromString(source, "image/svg+xml")
}) {
  const diagrams = [];
  const parser = new Marked();
  const figure = (label, description, content, paths = "") => `<figure class="learn-diagram"><figcaption>${escapeHtml(label)}</figcaption>${paths}<div class="diagram-tools" role="group" aria-label="\u56FE\u8868\u9605\u8BFB\u5DE5\u5177"><button type="button" data-diagram-action="fit">\u9002\u5E94\u5BBD\u5EA6</button><button type="button" data-diagram-action="out" aria-label="\u7F29\u5C0F\u56FE\u8868">\u2212</button><output aria-live="polite">100%</output><button type="button" data-diagram-action="in" aria-label="\u653E\u5927\u56FE\u8868">\uFF0B</button><button type="button" data-diagram-action="expand" aria-expanded="false">\u5C55\u5F00\u9605\u8BFB</button></div><div class="diagram-viewport" tabindex="0" aria-label="${escapeHtml(label)}\uFF0C\u653E\u5927\u540E\u53EF\u6EDA\u52A8\u67E5\u770B">${content}</div><p class="diagram-description" aria-live="polite">${escapeHtml(description)}</p></figure>`;
  parser.use({ renderer: { code(token) {
    if (token.lang?.trim() === "flow") {
      const slot2 = `${namespace}-diagram-${diagrams.length}`;
      try {
        const chart = renderFlowChart(token.text, slot2);
        diagrams.push({ slot: slot2, html: figure(chart.title, chart.description, chart.content, chart.paths) });
        return `<div data-learn-svg="${slot2}"></div>`;
      } catch (error) {
        return `<p class="diagram-error">\u6D41\u7A0B\u56FE\u672A\u663E\u793A\uFF1A${escapeHtml(error instanceof Error ? error.message : String(error))}\u3002\u539F\u6587\u4FDD\u7559\u5728\u4E0B\u65B9\u3002</p><pre><code>${escapeHtml(token.text)}</code></pre>`;
      }
    }
    if (token.lang?.trim() !== "svg") return false;
    const slot = `${namespace}-diagram-${diagrams.length}`;
    const svg = sanitizeDiagram(token.text, slot, environment);
    if (!svg) return `<p class="diagram-error">SVG \u672A\u663E\u793A\uFF1A\u9700\u8981\u6709\u6548\u7684 SVG \u548C\u6B63\u5C3A\u5BF8 viewBox\u3002\u539F\u6587\u4FDD\u7559\u5728\u4E0B\u65B9\u3002</p><pre><code>${escapeHtml(token.text)}</code></pre>`;
    const label = svg.querySelector("title")?.textContent || "\u6D41\u7A0B\u56FE";
    const description = svg.querySelector(":scope > desc")?.textContent || "\u70B9\u51FB\u8282\u70B9\u67E5\u770B\u8BF4\u660E\u4E0E\u5173\u8054\u8FDE\u7EBF\u3002";
    diagrams.push({ slot, html: figure(label, description, svg.outerHTML) });
    return `<div data-learn-svg="${slot}"></div>`;
  } } });
  const parse = (body) => parser.parse(body);
  let html = environment.purifier.sanitize(parse(renderDirectives(markdown, parse)), { USE_PROFILES: { html: true } });
  for (const diagram of diagrams) html = html.replace(`<div data-learn-svg="${diagram.slot}"></div>`, diagram.html);
  return html;
}

// src/server/product-pages.ts
var escape2 = (value) => value.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
function renderProductHome(release, href, examples) {
  const download = href(`downloads/${release.fileName}`);
  return `<main id="main" class="product-home" tabindex="-1">
    <section class="product-hero">
      <div class="product-introduction"><p class="eyebrow">\u89C2\u6F9C VELORA \xB7 \u672C\u5730\u5B66\u4E60\u5DE5\u4F5C\u53F0</p>
        <h1>\u628A\u6BCF\u6B21\u7406\u89E3\uFF0C<br>\u7559\u6210\u7EE7\u7EED\u751F\u957F\u7684\u6587\u6863\u3002</h1>
        <p class="product-lead">\u5E26\u4E0A\u4F60\u60F3\u5B66\u7684\u6750\u6599\uFF0C\u548C Agent \u4E00\u8FB9\u63D0\u95EE\u3001\u4E00\u8FB9\u6574\u7406\u3002\u89E3\u91CA\u3001\u4F8B\u5B50\u548C\u81EA\u5DF1\u7684\u7B14\u8BB0\uFF0C\u56DE\u5230\u540C\u4E00\u4EFD\u53EF\u4EE5\u7EE7\u7EED\u7F16\u8F91\u7684\u6587\u6863\u3002</p>
        <div class="product-actions"><a class="download-button" href="${download}" download>\u4E0B\u8F7D\u672C\u5730\u5DE5\u4F5C\u53F0 <span aria-hidden="true">\u2193</span></a><a class="secondary-link" href="${href("learn/")}">\u5148\u770B\u5B66\u4E60\u793A\u4F8B \u2197</a></div>
        <p class="release-note">v${escape2(release.version)} \u9884\u89C8\u7248 \xB7 \u9700\u8981 Node.js 22.12+ \u6216 24 \xB7 \u65E0\u9700\u89C2\u6F9C\u8D26\u53F7</p>
      </div>
      <figure class="learning-illustration" aria-label="\u5B66\u4E60\u8FC7\u7A0B\u793A\u610F"><figcaption>\u4ECE\u95EE\u9898\uFF0C\u5230\u81EA\u5DF1\u7684\u7406\u89E3 <span>\u793A\u610F</span></figcaption>
        <div class="illustration-question"><span class="illustration-label">\u4E00\u4E2A\u771F\u95EE\u9898</span><p>\u4E3A\u4EC0\u4E48 KV Cache \u80FD\u8BA9\u751F\u6210\u66F4\u5FEB\uFF1F</p></div>
        <div class="illustration-connection" aria-hidden="true">\u2193</div>
        <div class="illustration-document"><span class="illustration-label">\u4E00\u7BC7\u4F1A\u751F\u957F\u7684\u6587\u6863</span><h2>\u7406\u89E3\u7F13\u5B58\uFF0C\u7406\u89E3\u63A8\u7406</h2><p>\u5148\u62C6\u5F00 Prefill \u548C Decode\uFF0C\u518D\u7528\u4E00\u4E2A\u5C0F\u4F8B\u5B50\u89C2\u5BDF\u8BA1\u7B97\u5982\u4F55\u88AB\u590D\u7528\u3002</p><div class="illustration-chapters"><span>\u6982\u5FF5\u89E3\u91CA</span><span>\u53EF\u8FD0\u884C\u7684\u4F8B\u5B50</span><span>\u6211\u7684\u7B14\u8BB0</span></div><div class="illustration-note"><span aria-hidden="true">\u21B3</span> \u9009\u4E2D\u4E00\u6BB5\uFF0C\u7EE7\u7EED\u95EE\uFF0C\u7EE7\u7EED\u6539\u3002</div></div>
      </figure>
    </section>
    <section class="product-workflow" aria-labelledby="workflow-title"><div class="section-intro"><p class="eyebrow">\u56F4\u7ED5\u540C\u4E00\u4EFD\u6587\u6863\uFF0C\u6301\u7EED\u5B66\u4E60</p><h2 id="workflow-title">\u95EE\u8FC7\u7684\u95EE\u9898\uFF0C\u7559\u4E0B\u4E0B\u4E00\u6B21\u7684\u8D77\u70B9\u3002</h2></div><ol>
      <li><span>01</span><h3>\u63D0\u4F9B\u6750\u6599</h3><p>\u628A\u5DF2\u6709\u8D44\u6599\u653E\u8FDB\u5B66\u4E60\u6587\u6863\uFF0C\u8BF4\u660E\u60F3\u7406\u89E3\u7684\u95EE\u9898\u548C\u5DF2\u77E5\u80CC\u666F\u3002</p></li>
      <li><span>02</span><h3>\u8FB9\u95EE\uFF0C\u8FB9\u6574\u7406</h3><p>\u8BA9 Agent \u89E3\u91CA\u6982\u5FF5\u3001\u8865\u5145\u4F8B\u5B50\uFF0C\u6216\u9009\u4E2D\u4E00\u6BB5\u8BF7\u6C42\u4FEE\u6539\u3002\u81EA\u5DF1\u4E5F\u80FD\u76F4\u63A5\u7F16\u8F91\u3002</p></li>
      <li><span>03</span><h3>\u5E26\u7740\u7406\u89E3\u56DE\u6765</h3><p>\u7EE7\u7EED\u8FFD\u95EE\uFF0C\u4FEE\u8BA2\u65E7\u89E3\u91CA\uFF0C\u628A\u76F8\u5173\u77E5\u8BC6\u8FDE\u8D77\u6765\u3002\u6587\u6863\u4FDD\u5B58\u5728\u81EA\u5DF1\u7684\u76EE\u5F55\u4E2D\u3002</p></li>
    </ol></section>
    <section class="product-example-section" aria-labelledby="examples-title"><div class="section-intro"><p class="eyebrow">\u5148\u8BFB\u4E00\u6BB5\uFF0C\u518D\u51B3\u5B9A</p><h2 id="examples-title">\u4E00\u6761\u771F\u5B9E\u7684\u5B66\u4E60\u8DEF\u5F84</h2><p>\u4ECE\u63A8\u7406\u6027\u80FD\u5FC3\u667A\u6A21\u578B\u51FA\u53D1\uFF0C\u9010\u6B65\u7406\u89E3 CPU\u3001GPU \u4E0E\u5B9E\u9A8C\u65B9\u6CD5\u3002</p></div><div class="product-examples">${examples.map((example) => `<a href="${escape2(example.url)}"><span class="eyebrow">\u516C\u5F00\u5B66\u4E60\u6587\u7AE0</span><h3>${escape2(example.title)}</h3><p>${escape2(example.summary)}</p><span class="example-arrow" aria-hidden="true">\u2197</span></a>`).join("")}</div><a class="text-link" href="${href("learn/")}">\u6D4F\u89C8\u5168\u90E8\u5B66\u4E60\u6587\u7AE0 \u2197</a></section>
    <section id="download" class="product-download" aria-labelledby="download-title"><div><p class="eyebrow">\u5728\u81EA\u5DF1\u7684\u7535\u8111\u4E0A\u5F00\u59CB</p><h2 id="download-title">\u8BA9\u4E0B\u4E00\u6B21\u5B66\u4E60\uFF0C\u6709\u5730\u65B9\u7EE7\u7EED\u3002</h2><p>\u672C\u5730\u4FDD\u5B58\u6587\u6863\uFF0C\u4F7F\u7528\u81EA\u5DF1\u914D\u7F6E\u7684 Codex \u6216 Claude Code\u3002\u9605\u8BFB\u3001\u624B\u5DE5\u7F16\u8F91\u548C\u5BFC\u51FA\u4E5F\u53EF\u4EE5\u72EC\u7ACB\u4F7F\u7528\u3002</p></div><div class="download-details"><a class="download-button" href="${download}" download>\u4E0B\u8F7D v${escape2(release.version)} <span aria-hidden="true">\u2193</span></a><p>Node.js \u547D\u4EE4\u884C\u5B89\u88C5\u5305 \xB7 ${(release.bytes / 1024 / 1024).toFixed(1)} MB</p><a href="${href("getting-started/")}">\u67E5\u770B\u5B89\u88C5\u548C\u9996\u6B21\u4F7F\u7528\u6307\u5357 \u2197</a><a class="checksum-link" href="${href(`downloads/${release.fileName}.sha256`)}" download>\u4E0B\u8F7D SHA-256 \u6821\u9A8C\u503C</a></div></section>
    <section class="product-faq" aria-labelledby="faq-title"><div class="section-intro"><p class="eyebrow">\u5F00\u59CB\u4E4B\u524D</p><h2 id="faq-title">\u4F60\u53EF\u80FD\u60F3\u5148\u786E\u8BA4</h2></div>
      <details><summary>\u6253\u5F00\u4E00\u4E2A\u6587\u4EF6\u5939\uFF0CAgent \u5C31\u4F1A\u8BFB\u53D6\u91CC\u9762\u7684\u6E90\u7801\u5417\uFF1F</summary><p>\u4E0D\u4F1A\u3002Agent \u53EA\u4F7F\u7528\u5DE5\u4F5C\u53F0\u63D0\u4F9B\u7684\u5B66\u4E60\u6587\u6863\u3001\u6307\u5357\u548C\u53D7\u63A7\u6587\u6863\u5DE5\u5177\u3002\u8BF7\u5148\u63D0\u4F9B\u8981\u5B66\u4E60\u7684\u6750\u6599\uFF0C\u518D\u56F4\u7ED5\u8FD9\u4E9B\u6750\u6599\u63D0\u95EE\u3002</p></details>
      <details><summary>\u9700\u8981\u767B\u5F55\u89C2\u6F9C\uFF0C\u6216\u8D2D\u4E70\u5E73\u53F0\u989D\u5EA6\u5417\uFF1F</summary><p>\u672C\u5730\u5DE5\u4F5C\u53F0\u65E0\u9700\u89C2\u6F9C\u8D26\u53F7\u3002Agent \u529F\u80FD\u4F7F\u7528\u4F60\u5728\u672C\u673A\u914D\u7F6E\u5E76\u767B\u5F55\u7684\u6A21\u578B\u670D\u52A1\uFF0C\u63A8\u7406\u7531\u5BF9\u5E94\u670D\u52A1\u5904\u7406\uFF1B\u672C\u5730\u4FDD\u5B58\u6587\u6863\u4E0D\u7B49\u4E8E\u79BB\u7EBF\u63A8\u7406\u3002</p></details>
      <details><summary>\u8FD9\u4E2A\u7F51\u7AD9\u53EF\u4EE5\u76F4\u63A5\u804A\u5929\u548C\u7F16\u8F91\u5417\uFF1F</summary><p>\u8FD9\u91CC\u5C55\u793A\u516C\u5F00\u7684\u53EA\u8BFB\u5B66\u4E60\u6587\u7AE0\u3002\u4E0B\u8F7D\u672C\u5730\u5DE5\u4F5C\u53F0\u540E\uFF0C\u53EF\u4EE5\u63D0\u95EE\u3001\u7F16\u8F91\u3001\u67E5\u770B\u5386\u53F2\uFF0C\u5E76\u9009\u62E9\u7BC7\u76EE\u5BFC\u51FA\u81EA\u5DF1\u7684\u516C\u5F00\u5B66\u4E60\u7AD9\u3002</p></details>
    </section>
  </main>`;
}
function renderReleaseInstall(release, href) {
  return `<h2 id="install">\u4E0B\u8F7D\u5E76\u5B89\u88C5</h2><p>\u51C6\u5907 Node.js 22.12+ \u6216 24 \u4E0E npm\u3002\u4E0B\u8F7D\u540E\uFF0C\u5728\u5B89\u88C5\u5305\u6240\u5728\u7684\u76EE\u5F55\u6253\u5F00\u7EC8\u7AEF\uFF0C\u6267\u884C\u4EE5\u4E0B\u547D\u4EE4\u3002\u5B89\u88C5\u4F9D\u8D56\u9700\u8981\u8054\u7F51\u3002</p><p><a class="download-button" href="${href(`downloads/${release.fileName}`)}" download>\u4E0B\u8F7D v${escape2(release.version)} \u5B89\u88C5\u5305 \u2193</a></p><pre><code>mkdir velora-local
cd velora-local
npm init -y
npm install ../${escape2(release.fileName)}
mkdir notes
npx --no-install learn-workbench --root ./notes init --title "\u6211\u7684\u5B66\u4E60\u7A7A\u95F4"
npx --no-install learn-workbench --root ./notes serve</code></pre><p>\u6253\u5F00 <a href="http://127.0.0.1:4178">http://127.0.0.1:4178</a> \u5373\u53EF\u4F7F\u7528\u3002\u4E0B\u6B21\u56DE\u5230 <code>velora-local</code> \u76EE\u5F55\uFF0C\u91CD\u65B0\u6267\u884C\u6700\u540E\u4E00\u6761\u547D\u4EE4\u5C31\u80FD\u7EE7\u7EED\u3002</p><p>\u7B2C\u4E00\u6B21\u4F7F\u7528 Agent \u524D\uFF0C\u8BF7\u5B89\u88C5\u5E76\u767B\u5F55\u672C\u673A\u7684 Codex \u6216 Claude Code\uFF0C\u7136\u540E\u5728\u5DE5\u4F5C\u53F0\u7684\u672C\u5730\u8BBE\u7F6E\u4E2D\u9009\u62E9\u3002\u6CA1\u6709\u53EF\u7528 Agent \u65F6\uFF0C\u4ECD\u80FD\u9605\u8BFB\u3001\u624B\u5DE5\u7F16\u8F91\u548C\u5BFC\u51FA\u3002</p><details class="release-checksum"><summary>\u6838\u5BF9\u5B89\u88C5\u5305</summary><p>\u6587\u4EF6\u540D\uFF1A<code>${escape2(release.fileName)}</code><br>\u7248\u672C\uFF1A<code>${escape2(release.version)}</code><br>SHA-256\uFF1A</p><pre><code>${release.sha256}</code></pre><p><a href="${href(`downloads/${release.fileName}.sha256`)}" download>\u4E0B\u8F7D\u6821\u9A8C\u503C\u6587\u4EF6</a>\u3002\u8FD9\u4EFD\u5B89\u88C5\u5305\u5305\u542B\u7F16\u8BD1\u540E\u7684\u672C\u5730\u754C\u9762\u3001CLI\u3001SDK\u3001MCP \u4E0E\u6E90\u7801\uFF0C\u6309\u9879\u76EE MIT \u8BB8\u53EF\u5206\u53D1\u3002</p></details>`;
}

// src/server/public-site.ts
function publicSiteAddress(input) {
  if (!input) return void 0;
  let url;
  try {
    url = new URL(input);
  } catch {
    throw new LearnError("INVALID_SITE_URL", "\u7AD9\u70B9\u7F51\u5740\u9700\u8981\u662F\u5B8C\u6574\u7684 http \u6216 https \u5730\u5740", 422);
  }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
    throw new LearnError("INVALID_SITE_URL", "\u7AD9\u70B9\u7F51\u5740\u4E0D\u80FD\u5305\u542B\u51ED\u636E\u3001\u67E5\u8BE2\u53C2\u6570\u6216\u7247\u6BB5", 422);
  }
  url.pathname = url.pathname.replace(/\/?$/, "/");
  return url;
}
var escape3 = (value) => value.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
var json = (value) => JSON.stringify(value).replace(/</g, "\\u003c");
var articlePath = (id) => `learn/${encodeURIComponent(id)}/`;
async function renderPublicSite(root, options, address, assets, release) {
  if (!options.documentIds?.length) throw new LearnError("PUBLIC_DOCUMENTS_REQUIRED", "\u8BF7\u7528 --documents \u660E\u786E\u9009\u62E9\u516C\u5F00\u6587\u6863 ID\uFF0C\u591A\u4E2A ID \u7528\u9017\u53F7\u5206\u9694", 422);
  const { config, manifestPath } = await readLearnConfig(root);
  const store = new WorkspaceStore(root, manifestPath, config.documentSizeLimitBytes);
  await store.initialize();
  const dom = new JSDOM();
  try {
    const { site } = store;
    const documents = await Promise.all([...new Set(options.documentIds)].map((id) => store.getDocument(id)));
    const byId = new Map(documents.map((document2) => [document2.id, document2]));
    const base = address?.pathname ?? "/";
    const collectionPath = release ? "learn/" : "";
    const brand = release ? "\u89C2\u6F9C Velora" : site.title;
    const href = (relative = "") => `${base}${relative}`;
    const absolute = (relative = "") => address ? new URL(relative, address).href : void 0;
    const files = /* @__PURE__ */ new Map();
    const environment = {
      purifier: createDOMPurify(dom.window),
      parseSvg: (source) => new dom.window.DOMParser().parseFromString(source, "image/svg+xml")
    };
    const links = documents.map((document2) => `<a href="${href(articlePath(document2.id))}">${escape3(document2.title)}</a>`).join("");
    const shell = (title, description, relative, content, structuredData, noindex = false) => {
      const url = absolute(relative);
      const ld = json(structuredData);
      const hash = createHash("sha256").update(ld).digest("base64");
      const pageTitle = relative ? `${title} \xB7 ${brand}` : title;
      return `<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="color-scheme" content="light"><meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'sha256-${hash}'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'"><title>${escape3(pageTitle)}</title><meta name="description" content="${escape3(description)}">${!address || noindex ? '<meta name="robots" content="noindex,follow">' : ""}${url ? `<link rel="canonical" href="${escape3(url)}"><meta property="og:url" content="${escape3(url)}">` : ""}<meta property="og:title" content="${escape3(pageTitle)}"><meta property="og:description" content="${escape3(description)}"><meta property="og:type" content="${relative.startsWith("learn/") ? "article" : "website"}"><meta property="og:locale" content="zh_CN"><meta name="twitter:card" content="summary"><meta name="twitter:title" content="${escape3(pageTitle)}"><meta name="twitter:description" content="${escape3(description)}"><link rel="icon" href="${href("favicon.svg")}" type="image/svg+xml">${assets}<script type="application/ld+json">${ld}</script></head><body><a class="skip-link" href="#main">\u8DF3\u5230\u6B63\u6587</a><header class="public-header"><a class="public-brand" href="${href()}"><span aria-hidden="true">\u6F9C</span><strong>${escape3(brand)}</strong></a><nav class="header-links" aria-label="\u4E3B\u5BFC\u822A"><a href="${href(collectionPath)}#articles">\u5168\u90E8\u6587\u7AE0</a><a href="${href("getting-started/")}">\u672C\u5730\u4F7F\u7528\u6307\u5357 <span aria-hidden="true">\u2197</span></a></nav></header>${content}<footer class="public-footer"><a href="${href()}">${escape3(brand)}</a><span>\u4F7F\u7528\u89C2\u6F9C Velora \u6574\u7406\u4E0E\u53D1\u5E03</span><a href="${href("getting-started/")}">\u7EE7\u7EED\u6784\u5EFA\u81EA\u5DF1\u7684\u5B66\u4E60\u6587\u6863 \u2197</a></footer></body></html>`;
    };
    const listItem = (document2, index) => `<li data-public-article data-search="${escape3([document2.title, document2.summary, ...document2.tags ?? []].join(" ").toLocaleLowerCase())}"><a class="article-link" href="${href(articlePath(document2.id))}"><span class="article-number">${String(index + 1).padStart(2, "0")}</span><div><h2>${escape3(document2.title)}</h2><p>${escape3(document2.summary)}</p><div class="article-tags">${(document2.tags ?? []).map((tag) => `<span>${escape3(tag)}</span>`).join("")}</div></div><span class="article-arrow" aria-hidden="true">\u2197</span></a></li>`;
    files.set(`${collectionPath}index.html`, shell(site.title, site.description ?? site.title, collectionPath, `<main id="main" class="public-home" tabindex="-1"><section class="public-intro"><p class="eyebrow">\u89C2\u6F9C \xB7 \u516C\u5F00\u5B66\u4E60\u7B14\u8BB0</p><h1>${escape3(site.title)}</h1><p class="intro-description">${escape3(site.description ?? "\u4ECE\u4E00\u4E2A\u95EE\u9898\u5F00\u59CB\uFF0C\u628A\u7406\u89E3\u7559\u6210\u53EF\u4EE5\u7EE7\u7EED\u9605\u8BFB\u7684\u77E5\u8BC6\u3002")}</p><a class="text-link" href="#articles">\u5F00\u59CB\u9605\u8BFB <span aria-hidden="true">\u2193</span></a></section><section id="articles" aria-labelledby="articles-title"><div class="collection-heading"><div><p class="eyebrow">\u6CBF\u7740\u95EE\u9898\uFF0C\u9010\u6B65\u7406\u89E3</p><h2 id="articles-title">\u5B66\u4E60\u6587\u7AE0 <span data-result-count>${documents.length}</span></h2></div><label class="public-search"><span class="sr-only">\u641C\u7D22\u6587\u7AE0\u6807\u9898\u548C\u6458\u8981</span><input type="search" placeholder="\u641C\u7D22\u6807\u9898\u3001\u6458\u8981\u548C\u6807\u7B7E" aria-label="\u641C\u7D22\u6587\u7AE0\u6807\u9898\u548C\u6458\u8981"></label></div><ol class="article-list">${documents.map(listItem).join("")}</ol><p class="search-empty" hidden>\u6CA1\u6709\u627E\u5230\u76F8\u5173\u6587\u7AE0\uFF0C\u8BD5\u8BD5\u5176\u4ED6\u5173\u952E\u8BCD\u3002</p><noscript><p>\u53EF\u4F7F\u7528\u6D4F\u89C8\u5668\u7684\u201C\u5728\u9875\u9762\u4E2D\u67E5\u627E\u201D\u5BFB\u627E\u6587\u7AE0\u3002</p></noscript></section></main>`, { "@context": "https://schema.org", "@type": "CollectionPage", name: site.title, description: site.description, ...address ? { url: absolute(collectionPath) } : {}, inLanguage: "zh-CN" }));
    if (release) {
      const examples = documents.slice(0, 3).map((document2) => ({ title: document2.title, summary: document2.summary, url: href(articlePath(document2.id)) }));
      files.set("index.html", shell("\u89C2\u6F9C Velora \xB7 \u628A\u7406\u89E3\u7559\u6210\u5B66\u4E60\u6587\u6863", "\u5728\u81EA\u5DF1\u7684\u7535\u8111\u4E0A\uFF0C\u548C Agent \u4E00\u8FB9\u63D0\u95EE\u3001\u4E00\u8FB9\u628A\u63D0\u4F9B\u7684\u6750\u6599\u6574\u7406\u6210\u53EF\u4EE5\u6301\u7EED\u7F16\u8F91\u7684\u5B66\u4E60\u6587\u6863\u3002", "", renderProductHome(release, href, examples), { "@context": "https://schema.org", "@type": "SoftwareApplication", name: "\u89C2\u6F9C Velora", applicationCategory: "EducationalApplication", operatingSystem: "Node.js", softwareVersion: release.version, inLanguage: "zh-CN", ...address ? { url: absolute() } : {} }));
    }
    for (let index = 0; index < documents.length; index++) {
      const document2 = documents[index];
      const body = dom.window.document.createElement("div");
      body.innerHTML = renderMarkdown(document2.body, `article-${document2.id}`, environment);
      const first = body.firstElementChild;
      if (first?.tagName === "H1" && first.textContent?.trim() === document2.title.trim()) first.remove();
      for (const heading of body.querySelectorAll("h1")) {
        const replacement = dom.window.document.createElement("h2");
        replacement.innerHTML = heading.innerHTML;
        heading.replaceWith(replacement);
      }
      const headings = [];
      const headingIds = /* @__PURE__ */ new Set();
      for (const [number, heading] of [...body.querySelectorAll("h2,h3")].filter((node) => !node.closest(".learn-diagram")).entries()) {
        const slug = heading.id || (heading.textContent ?? "").toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-|-$/g, "") || `section-${number + 1}`;
        let id = slug;
        for (let suffix = 2; headingIds.has(id); suffix++) id = `${slug}-${suffix}`;
        heading.id = id;
        headingIds.add(id);
        headings.push(`<a class="toc-${heading.tagName.toLowerCase()}" href="#${escape3(encodeURIComponent(id))}">${escape3(heading.textContent ?? "")}</a>`);
      }
      for (const link of body.querySelectorAll("a[href]")) {
        const target = link.getAttribute("href");
        const [file, fragment] = target.split("#");
        if (!file?.endsWith(".md") || /^[a-z][\w+.-]*:/i.test(target)) continue;
        const resolved = path.posix.normalize(path.posix.join(path.posix.dirname(document2.path), file));
        const published = documents.find((candidate) => candidate.path === resolved);
        if (published) link.setAttribute("href", href(articlePath(published.id)) + (fragment ? `#${fragment}` : ""));
        else link.replaceWith(...link.childNodes);
      }
      const related = [.../* @__PURE__ */ new Set([...document2.prerequisites ?? [], ...document2.related ?? []])].map((id) => byId.get(id)).filter((item) => !!item);
      const neighbors = [documents[index - 1], documents[index + 1]];
      const relative = articlePath(document2.id);
      const structuredData = { "@context": "https://schema.org", "@graph": [{ "@type": "Article", headline: document2.title, description: document2.summary, dateModified: document2.modifiedAt, inLanguage: "zh-CN", ...address ? { url: absolute(relative) } : {} }, { "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: site.title, ...address ? { item: absolute(collectionPath) } : {} }, { "@type": "ListItem", position: 2, name: document2.title, ...address ? { item: absolute(relative) } : {} }] }] };
      const article = `<div class="reading-layout"><main id="main" class="public-article" tabindex="-1"><nav class="breadcrumbs" aria-label="\u9762\u5305\u5C51"><a href="${href(collectionPath)}">\u5168\u90E8\u6587\u7AE0</a><span aria-hidden="true">/</span><span>${escape3(document2.title)}</span></nav><header class="article-heading"><p class="eyebrow">${escape3(document2.stage ? `\u5B66\u4E60\u8DEF\u5F84 ${document2.stage}` : "\u5B66\u4E60\u7B14\u8BB0")}</p><h1>${escape3(document2.title)}</h1><p class="article-summary">${escape3(document2.summary)}</p><p class="article-meta">\u66F4\u65B0\u4E8E <time datetime="${escape3(document2.modifiedAt)}">${escape3(document2.modifiedAt.slice(0, 10))}</time><span>\xB7</span>${Math.max(1, Math.ceil((body.textContent ?? "").length / 500))} \u5206\u949F\u9605\u8BFB</p></header><details class="mobile-directory"><summary>\u5B66\u4E60\u76EE\u5F55</summary><nav aria-label="\u5B66\u4E60\u76EE\u5F55">${links}</nav></details><article class="markdown public-markdown">${body.innerHTML}</article>${related.length ? `<section class="related-reading"><h2>\u7EE7\u7EED\u7406\u89E3</h2>${related.map((item) => `<a href="${href(articlePath(item.id))}"><strong>${escape3(item.title)}</strong><span>${escape3(item.summary)}</span></a>`).join("")}</section>` : ""}<nav class="article-pagination" aria-label="\u4E0A\u4E0B\u7BC7">${neighbors.map((item, number) => item ? `<a href="${href(articlePath(item.id))}"><small>${number === 0 ? "\u4E0A\u4E00\u7BC7" : "\u4E0B\u4E00\u7BC7"}</small><strong>${escape3(item.title)}</strong></a>` : "<span></span>").join("")}</nav></main><aside class="reading-sidebar"><nav class="table-of-contents" aria-label="\u672C\u9875\u76EE\u5F55"><p>\u672C\u9875\u5185\u5BB9</p>${headings.join("")}</nav><nav class="reading-directory" aria-label="\u5B66\u4E60\u76EE\u5F55"><p>\u5B66\u4E60\u8DEF\u5F84</p>${documents.map((item) => `<a href="${href(articlePath(item.id))}"${item.id === document2.id ? ' aria-current="page"' : ""}>${escape3(item.title)}</a>`).join("")}</nav></aside></div>`;
      files.set(`${relative}index.html`, shell(document2.title, document2.summary, relative, article, structuredData));
    }
    const installation = release ? renderReleaseInstall(release, href) : `<h2>\u8FD0\u884C\u5DE5\u4F5C\u53F0</h2><p>\u51C6\u5907 Git\u3001Node.js 22.12+ \u6216 24\uFF0C\u4EE5\u53CA\u5DF2\u5B89\u88C5\u5E76\u767B\u5F55\u7684 Codex \u6216 Claude Code\u3002\u5F53\u524D\u7248\u672C\u901A\u8FC7\u9879\u76EE\u6E90\u7801\u8FD0\u884C\uFF0C\u9700\u8981\u5148\u53D6\u5F97\u4ED3\u5E93\u8BBF\u95EE\u6743\u9650\u3002</p><pre><code>git clone https://github.com/majiayu000/agent-learning-workbench.git
cd agent-learning-workbench
npm install
npm run dev</code></pre><p>\u6253\u5F00 <code>http://127.0.0.1:4178</code>\uFF0C\u521B\u5EFA\u5B66\u4E60\u7A7A\u95F4\uFF0C\u63D0\u4F9B\u8981\u5B66\u4E60\u7684\u6750\u6599\uFF0C\u518D\u63D0\u51FA\u7B2C\u4E00\u4E2A\u95EE\u9898\u3002\u6CA1\u6709\u53EF\u7528 Agent \u65F6\uFF0C\u4ECD\u53EF\u624B\u52A8\u9605\u8BFB\u3001\u7F16\u8F91\u548C\u5BFC\u51FA\u3002</p>`;
    const guide = `<main id="main" class="public-article standalone-page" tabindex="-1"><nav class="breadcrumbs" aria-label="\u9762\u5305\u5C51"><a href="${href(collectionPath)}">\u5168\u90E8\u6587\u7AE0</a><span aria-hidden="true">/</span><span>\u672C\u5730\u4F7F\u7528\u6307\u5357</span></nav><header class="article-heading"><p class="eyebrow">\u89C2\u6F9C Velora</p><h1>\u8BA9\u7406\u89E3\u6210\u4E3A\u4E0B\u4E00\u6B21\u5B66\u4E60\u7684\u8D77\u70B9</h1><p class="article-summary">\u5728\u81EA\u5DF1\u7684\u7535\u8111\u4E0A\uFF0C\u548C Agent \u4E00\u8D77\u628A\u63D0\u4F9B\u7684\u6750\u6599\u6574\u7406\u6210\u53EF\u4EE5\u6301\u7EED\u7F16\u8F91\u7684\u5B66\u4E60\u6587\u6863\u3002</p></header><article class="markdown"><h2>\u9605\u8BFB\u8FD9\u91CC\uFF0C\u521B\u4F5C\u5728\u672C\u5730</h2><p>\u8FD9\u4E2A\u7F51\u7AD9\u662F\u516C\u5F00\u5B66\u4E60\u6587\u6863\u7684\u53EA\u8BFB\u7248\u672C\u3002\u672C\u5730\u5DE5\u4F5C\u53F0\u652F\u6301\u5BF9\u8BDD\u3001\u76F4\u63A5\u7F16\u8F91\u3001\u6BB5\u843D\u4FEE\u6539\u3001\u5386\u53F2\u548C\u5BFC\u51FA\u3002\u6587\u6863\u4FDD\u5B58\u5728\u81EA\u5DF1\u7684\u6587\u4EF6\u5939\u4E2D\uFF0CAgent \u7684\u56DE\u7B54\u4F7F\u7528\u4F60\u914D\u7F6E\u7684\u672C\u673A\u6A21\u578B\u670D\u52A1\u3002</p>${installation}<h2>\u5F00\u59CB\u7B2C\u4E00\u7BC7\u5B66\u4E60\u6587\u6863</h2><ol><li>\u6253\u5F00\u6216\u65B0\u5EFA\u4E00\u4E2A\u5B66\u4E60\u7A7A\u95F4\uFF0C\u628A\u5DF2\u6709\u6750\u6599\u6574\u7406\u5230\u5B66\u4E60\u6587\u6863\u4E2D\u3002</li><li>\u63D0\u51FA\u5177\u4F53\u95EE\u9898\uFF0C\u8BF7 Agent \u7ED3\u5408\u63D0\u4F9B\u7684\u8D44\u6599\u89E3\u91CA\u5E76\u5199\u5165\u6587\u6863\u3002</li><li>\u9605\u8BFB\u4FDD\u5B58\u7ED3\u679C\uFF0C\u52A0\u5165\u81EA\u5DF1\u7684\u4F8B\u5B50\uFF0C\u9009\u4E2D\u6BB5\u843D\u7EE7\u7EED\u8FFD\u95EE\u6216\u4FEE\u6539\u3002</li></ol><p>Agent \u53EA\u8BBF\u95EE\u5DE5\u4F5C\u53F0\u63D0\u4F9B\u7684\u5B66\u4E60\u6587\u6863\u548C\u53D7\u63A7\u5DE5\u5177\u3002\u6253\u5F00\u6587\u4EF6\u5939\u4E0D\u7B49\u4E8E\u5DF2\u7ECF\u8BFB\u53D6\u91CC\u9762\u7684\u6E90\u7801\u3002Codex \u652F\u6301\u9010\u6BB5\u5B9E\u65F6\u7F16\u8F91\uFF1BClaude \u751F\u6210\u4FEE\u6539\u540E\u7531\u5DE5\u4F5C\u53F0\u4FDD\u5B58\u3002</p><h2>\u5BFC\u51FA\u4E0E\u5907\u4EFD</h2><p>Markdown \u5BFC\u51FA\u9002\u5408\u5206\u4EAB\u5DF2\u4FDD\u5B58\u7684\u6B63\u6587\u3002\u6062\u590D\u6574\u4E2A\u5DE5\u4F5C\u53F0\u8FD8\u9700\u8981\u4FDD\u5B58 manifest\u3001\u914D\u7F6E\u4EE5\u53CA <code>.learn/</code> \u4E2D\u7684\u534F\u4F5C\u72B6\u6001\u548C\u5386\u53F2\u3002\u516C\u5F00\u53D1\u5E03\u524D\uFF0C\u9009\u62E9\u5E76\u5BA1\u9605\u8981\u516C\u5F00\u7684\u7BC7\u76EE\u3002</p></article></main>`;
    files.set("getting-started/index.html", shell("\u672C\u5730\u4F7F\u7528\u6307\u5357", "\u5728\u672C\u5730\u4F7F\u7528\u89C2\u6F9C Velora\uFF0C\u628A\u63D0\u4F9B\u7684\u6750\u6599\u6574\u7406\u6210\u53EF\u4EE5\u6301\u7EED\u7F16\u8F91\u7684\u5B66\u4E60\u6587\u6863\u3002", "getting-started/", guide, { "@context": "https://schema.org", "@type": "WebPage", name: "\u672C\u5730\u4F7F\u7528\u6307\u5357", inLanguage: "zh-CN" }));
    files.set("404.html", shell("\u627E\u4E0D\u5230\u8FD9\u7BC7\u6587\u7AE0", "\u8FD9\u7BC7\u6587\u7AE0\u4E0D\u5B58\u5728\u6216\u5DF2\u505C\u6B62\u516C\u5F00\u3002", "404.html", `<main id="main" class="public-article standalone-page" tabindex="-1"><p class="eyebrow">404</p><h1>\u8FD9\u7BC7\u6587\u7AE0\u6682\u65F6\u627E\u4E0D\u5230\u4E86</h1><p>\u5B83\u53EF\u80FD\u5DF2\u7ECF\u79FB\u52A8\uFF0C\u6216\u4E0D\u518D\u516C\u5F00\u3002</p><a class="text-link" href="${href(collectionPath)}">\u8FD4\u56DE\u5168\u90E8\u6587\u7AE0 \u2197</a></main>`, { "@context": "https://schema.org", "@type": "WebPage", name: "\u627E\u4E0D\u5230\u8FD9\u7BC7\u6587\u7AE0" }, true));
    files.set("favicon.svg", '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><rect width="40" height="40" rx="10" fill="#191b20"/><text x="20" y="27" text-anchor="middle" fill="white" font-size="24">\u6F9C</text></svg>');
    files.set("robots.txt", `User-agent: *
Allow: /
${address ? `Sitemap: ${absolute("sitemap.xml")}
` : ""}`);
    if (address) files.set("sitemap.xml", `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${escape3(absolute())}</loc></url><url><loc>${escape3(absolute("getting-started/"))}</loc></url>${release ? `<url><loc>${escape3(absolute(collectionPath))}</loc></url>` : ""}${documents.map((document2) => `<url><loc>${escape3(absolute(articlePath(document2.id)))}</loc><lastmod>${escape3(document2.modifiedAt)}</lastmod></url>`).join("")}</urlset>`);
    return files;
  } finally {
    dom.window.close();
  }
}

// src/server/learn-dev-plugin.ts
function learnWorkbenchPlugin(initialRoots, backendOrigin, publicSite) {
  const virtualId = "virtual:project-learning-content";
  const resolvedVirtualId = `\0${virtualId}`;
  let command = "serve";
  const address = publicSiteAddress(publicSite?.siteUrl);
  return {
    name: "agent-learning-workbench-ui",
    enforce: "pre",
    config(config, environment) {
      return {
        ...!backendOrigin ? { base: address?.pathname ?? "/" } : {},
        resolve: { dedupe: ["yjs", "@tiptap/core", "@tiptap/y-tiptap", "prosemirror-model", "prosemirror-state", "prosemirror-view", "prosemirror-transform"] },
        ...backendOrigin ? {
          // Different frontend proxies have different dependency hashes. Sharing
          // their cache can replace React chunks under another running server.
          cacheDir: path2.resolve(config.root ?? ".", "node_modules", `.vite-workbench-${config.server?.port ?? "build"}`),
          server: { proxy: {
            "/api/v1": { target: backendOrigin, changeOrigin: false },
            "/__learn_bootstrap__.js": { target: backendOrigin, changeOrigin: false }
          } }
        } : {}
      };
    },
    configResolved(config) {
      command = config.command;
    },
    resolveId(id) {
      return id === virtualId ? resolvedVirtualId : null;
    },
    load: (id) => {
      if (id !== resolvedVirtualId) return null;
      return `export default ${JSON.stringify({
        site: { title: "\u89C2\u6F9C Velora" },
        documents: [],
        manifestHash: "",
        runtime: { adapter: "loading", available: false }
      })};`;
    },
    transformIndexHtml: { order: "pre", handler() {
      if (command === "build" && !backendOrigin) {
        return '<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><script type="module" src="/src/public.ts"></script></head><body></body></html>';
      }
      if (!backendOrigin) return [];
      return [{ tag: "script", attrs: { src: "/__learn_bootstrap__.js" }, injectTo: "head-prepend" }];
    } },
    configurePreviewServer(server) {
      if (backendOrigin) return;
      const directory = path2.resolve(server.config.root, server.config.build.outDir);
      server.middlewares.use((request, response, next) => {
        void (async () => {
          const pathname = new URL(request.url ?? "/", "http://localhost").pathname;
          const base = server.config.base;
          const relative = pathname.startsWith(base) ? pathname.slice(base.length) : "../";
          const file = path2.resolve(directory, !relative || relative.endsWith("/") ? `${relative}index.html` : relative);
          const within = !path2.relative(directory, file).startsWith("..") && !path2.isAbsolute(path2.relative(directory, file));
          const exists = within && await fs.stat(file).then((stat) => stat.isFile(), (error) => {
            if (["ENOENT", "ENOTDIR"].includes(error.code)) return false;
            throw error;
          });
          if (exists && ["GET", "HEAD"].includes(request.method ?? "GET")) {
            next();
            return;
          }
          response.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
          response.end(request.method === "HEAD" ? void 0 : await fs.readFile(path2.join(directory, "404.html")));
        })().catch(next);
      });
    },
    generateBundle: { order: "post", async handler(_options, bundle) {
      if (backendOrigin) return;
      if (initialRoots.length !== 1) throw new LearnError("STATIC_MULTISPACE_UNSUPPORTED", "Static builds require exactly one learning space", 422);
      if (!publicSite) throw new LearnError("PUBLIC_DOCUMENTS_REQUIRED", "\u516C\u5F00\u6784\u5EFA\u9700\u8981\u660E\u786E\u9009\u62E9\u6587\u6863", 422);
      const index = bundle["index.html"];
      if (!index || index.type !== "asset") throw new Error("Public build did not emit its HTML entry");
      const assets = String(index.source).match(/<script\b[^>]*>[\s\S]*?<\/script>|<link\b[^>]*rel="stylesheet"[^>]*>/g)?.join("") ?? "";
      const binary = publicSite.release ? await fs.readFile(publicSite.release.file) : void 0;
      const release = binary && publicSite.release ? { version: publicSite.release.version, fileName: path2.basename(publicSite.release.file), bytes: binary.length, sha256: createHash2("sha256").update(binary).digest("hex") } : void 0;
      const pages = await renderPublicSite(initialRoots[0], publicSite, address, assets, release);
      if (release && binary) {
        this.emitFile({ type: "asset", fileName: `downloads/${release.fileName}`, source: binary });
        this.emitFile({ type: "asset", fileName: `downloads/${release.fileName}.sha256`, source: `${release.sha256}  ${release.fileName}
` });
      }
      index.source = pages.get("index.html");
      for (const [fileName, source] of pages) if (fileName !== "index.html") this.emitFile({ type: "asset", fileName, source });
    } }
  };
}

// src/server/standalone-vite.ts
async function startStandaloneDevServer(repositoryRoot, port) {
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new LearnError("INVALID_PORT", "port must be between 1 and 65535", 422);
  const siteRoot = await bundledSiteRoot();
  const backend = await startLocalServer([repositoryRoot], { port: 0, webRoot: siteRoot });
  let frontend;
  const startFrontend = async () => {
    frontend = await createServer({
      root: siteRoot,
      configFile: false,
      plugins: [react(), learnWorkbenchPlugin([], backend.origin)],
      server: { host: "127.0.0.1", port, strictPort: true }
    });
    await frontend.listen();
  };
  try {
    await startFrontend();
  } catch (error) {
    await frontend?.close();
    await backend.close();
    throw error;
  }
  const address = frontend.httpServer.address();
  if (!address || typeof address === "string") throw new Error("Frontend did not expose a TCP address");
  return {
    origin: `http://127.0.0.1:${address.port}`,
    backendOrigin: backend.origin,
    async restartFrontend() {
      await frontend?.close();
      await startFrontend();
    },
    async close() {
      await frontend?.close();
      await backend.close();
    }
  };
}
async function buildStandaloneSite(repositoryRoot, outDir, options) {
  const root = await fs2.realpath(repositoryRoot);
  const requestedOutput = path3.resolve(outDir);
  await fs2.mkdir(path3.dirname(requestedOutput), { recursive: true });
  const output = path3.join(await fs2.realpath(path3.dirname(requestedOutput)), path3.basename(requestedOutput));
  const rootFromOutput = path3.relative(output, root);
  if (rootFromOutput === "" || !rootFromOutput.startsWith("..") && !path3.isAbsolute(rootFromOutput)) {
    throw new LearnError(
      "UNSAFE_OUTPUT_DIRECTORY",
      "Build output must not be the repository root or one of its parent directories",
      422
    );
  }
  const marker = ".velora-static";
  let exists = false;
  try {
    const stat = await fs2.lstat(output);
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw new LearnError("UNSAFE_OUTPUT_DIRECTORY", "\u8F93\u51FA\u8DEF\u5F84\u5FC5\u987B\u662F\u4E13\u7528\u7AD9\u70B9\u76EE\u5F55", 422);
    exists = true;
    if ((await fs2.readdir(output)).length && await fs2.readFile(path3.join(output, marker), "utf8").catch((error) => {
      if (error.code === "ENOENT") return "";
      throw error;
    }) !== "velora-public-site\n") throw new LearnError("UNSAFE_OUTPUT_DIRECTORY", "\u8F93\u51FA\u76EE\u5F55\u5305\u542B\u5176\u4ED6\u6587\u4EF6\uFF0C\u8BF7\u6307\u5B9A\u65B0\u7684\u4E13\u7528\u7AD9\u70B9\u76EE\u5F55", 422);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  const staging = await fs2.mkdtemp(path3.join(path3.dirname(output), `.${path3.basename(output)}-build-`));
  const previous = `${staging}-previous`;
  try {
    await build({
      root: await bundledSiteRoot(),
      configFile: false,
      plugins: [react(), learnWorkbenchPlugin([root], void 0, options)],
      build: { outDir: staging, emptyOutDir: false }
    });
    await fs2.writeFile(path3.join(staging, marker), "velora-public-site\n");
    if (exists) await fs2.rename(output, previous);
    try {
      await fs2.rename(staging, output);
    } catch (error) {
      if (exists) await fs2.rename(previous, output);
      throw error;
    }
    if (exists) await fs2.rm(previous, { recursive: true });
  } finally {
    await fs2.rm(staging, { recursive: true, force: true });
  }
}
export {
  buildStandaloneSite,
  startStandaloneDevServer
};
//# sourceMappingURL=standalone-vite-56V56CXV.js.map