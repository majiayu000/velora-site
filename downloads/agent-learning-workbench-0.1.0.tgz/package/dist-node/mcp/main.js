#!/usr/bin/env node
import {
  createLearnWorkbench
} from "../chunk-UNSZJ2UQ.js";
import {
  asLearnError,
  documentInstructions,
  readDocumentGuides
} from "../chunk-YCOHAXJI.js";

// src/mcp/main.ts
import { serveStdio } from "@modelcontextprotocol/server/stdio";

// src/mcp/server.ts
import { McpServer } from "@modelcontextprotocol/server";
import * as z from "zod/v4";
function result(value) {
  return { content: [{ type: "text", text: JSON.stringify(value, null, 2) }], structuredContent: value };
}
function failure(error) {
  const known = asLearnError(error);
  return {
    content: [{ type: "text", text: `${known.code}: ${known.message}${known.details ? `
${JSON.stringify(known.details)}` : ""}` }],
    isError: true,
    ...known.details ? { structuredContent: { code: known.code, message: known.message, ...known.details } } : {}
  };
}
function createLearnMcpServer(sdk) {
  const server = new McpServer(
    { name: "learn-workbench", version: "0.1.0" },
    { instructions: documentInstructions("mcp") }
  );
  server.registerTool("learn_guide", {
    description: "Read document workflow guides on demand. Start with topic.index; read topic.creating before creating pages, topic.editing before edits, topic.diagram/topic.charts for visuals, topic.skill for tutorial authoring, or refusal.<actual error code> after failure.",
    annotations: { readOnlyHint: true },
    inputSchema: z.object({ items: z.array(z.string().min(1)).min(1).max(20).describe("Guide topics to read together; fetch only those needed for the current task.") })
  }, async ({ items }) => {
    try {
      return result(readDocumentGuides(items, "mcp"));
    } catch (error) {
      return failure(error);
    }
  });
  server.registerTool("learn_workspace", { description: "List the learning site and registered documents", annotations: { readOnlyHint: true }, inputSchema: z.object({}) }, async () => result(sdk.workspace()));
  server.registerTool("learn_document", { description: "Read one registered Markdown document", annotations: { readOnlyHint: true }, inputSchema: z.object({ documentId: z.string().min(1) }) }, async ({ documentId }) => {
    try {
      return result(await sdk.document(documentId));
    } catch (error) {
      return failure(error);
    }
  });
  server.registerTool("learn_search", { description: "Search titles, metadata, and Markdown bodies", annotations: { readOnlyHint: true }, inputSchema: z.object({ query: z.string().min(1).max(200) }) }, async ({ query }) => {
    try {
      return result({ results: await sdk.search(query) });
    } catch (error) {
      return failure(error);
    }
  });
  server.registerTool("learn_ask", { description: "Run the configured read-only learning Runtime and return an answer plus optional pending proposal", annotations: { readOnlyHint: true }, inputSchema: z.object({ documentId: z.string().min(1), question: z.string().min(1).max(8e3), intent: z.enum(["answer", "revise"]).default("answer"), target: z.object({ from: z.number().int().min(0), to: z.number().int().min(0), baseHash: z.string().regex(/^sha256:[a-f0-9]{64}$/) }).optional().describe("Optional Markdown UTF-16 range from learn_document; only this range is proposed for replacement. Equal from/to inserts text.") }) }, async ({ documentId, question, intent, target }) => {
    try {
      return result(await sdk.ask({ documentId, question, intent, target }));
    } catch (error) {
      return failure(error);
    }
  });
  server.registerTool("learn_accept_document_proposal", { description: "Accept one already reviewed Markdown body proposal", annotations: { destructiveHint: true }, inputSchema: z.object({ proposalId: z.string().min(1) }) }, async ({ proposalId }) => {
    try {
      return result(await sdk.acceptProposal(proposalId));
    } catch (error) {
      return failure(error);
    }
  });
  server.registerTool("learn_accept_structure_proposal", { description: "Accept one already reviewed create, rename, or delete proposal", annotations: { destructiveHint: true }, inputSchema: z.object({ proposalId: z.string().min(1) }) }, async ({ proposalId }) => {
    try {
      return result(await sdk.acceptStructureProposal(proposalId));
    } catch (error) {
      return failure(error);
    }
  });
  server.registerTool("learn_blocks", { description: "Read stable block IDs, Markdown and hashes from the live collaborative document. Read before replacing or deleting a block.", annotations: { readOnlyHint: true }, inputSchema: z.object({ documentId: z.string().min(1) }) }, async ({ documentId }) => {
    try {
      const { state, vector, ...snapshot } = await sdk.blocks(documentId);
      return result(snapshot);
    } catch (error) {
      return failure(error);
    }
  });
  server.registerTool("learn_apply_operations", {
    description: "Apply an authorized edit directly to the shared document. Insert paragraphs incrementally, or replace/delete blocks with their last-read ifHash. Changes appear in open editors. A stale block is rejected; read again before retrying.",
    annotations: { destructiveHint: true },
    inputSchema: z.object({ documentId: z.string().min(1), operations: z.array(z.discriminatedUnion("type", [
      z.object({ type: z.literal("insert"), after: z.string().nullable(), markdown: z.string().max(1e6) }),
      z.object({ type: z.literal("replace"), blockId: z.string(), ifHash: z.string(), markdown: z.string().max(1e6) }),
      z.object({ type: z.literal("delete"), blockId: z.string(), ifHash: z.string() })
    ])).min(1).max(100) })
  }, async ({ documentId, operations }) => {
    try {
      const { state, vector, ...snapshot } = await sdk.applyOperations(documentId, operations);
      return result(snapshot);
    } catch (error) {
      return failure(error);
    }
  });
  return server;
}

// src/mcp/main.ts
var root = process.env.LEARN_WORKSPACE_ROOT ?? process.cwd();
var sdkPromise = createLearnWorkbench({ repositoryRoot: root });
var handle = serveStdio(async () => createLearnMcpServer(await sdkPromise), {
  onerror: (error) => console.error(`learn-workbench MCP error: ${error.message}`)
});
async function close() {
  await handle.close();
  (await sdkPromise).close();
}
process.once("SIGINT", () => {
  void close();
});
process.once("SIGTERM", () => {
  void close();
});
//# sourceMappingURL=main.js.map