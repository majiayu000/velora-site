#!/usr/bin/env node
type CliIo = {
    stdout: (value: string) => void;
    stderr: (value: string) => void;
};
declare function runCli(argv: string[], io?: CliIo): Promise<number>;

export { runCli };
