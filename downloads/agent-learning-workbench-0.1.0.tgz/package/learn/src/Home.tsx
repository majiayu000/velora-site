import { useEffect, useMemo, useState } from "react";
import { isDevelopmentWorkspace, useSpaceApi } from "./api";
import type { DocumentMetadata, DocumentSnapshot, SearchResult, Turn, Workspace } from "./types";

export function Home({ onOpenConversation,
  workspace,
  recentTurns,
  onOpen,
  onMap,
  onHistory,
}: {
  onOpenConversation: (turn: Turn) => void;
  workspace: Workspace;
  recentTurns: Turn[];
  onOpen: (id: string) => void;
  onMap: () => void;
  onHistory: () => void;
}) {
  const api = useSpaceApi();
  const [query, setQuery] = useState("");
  const [remoteResults, setRemoteResults] = useState<SearchResult[]>();
  const [searchError, setSearchError] = useState<string>();
  const localResults = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    if (!needle) return workspace.documents;
    return workspace.documents.filter((item) =>
      [item.title, item.summary, ...(item.tags ?? []), "body" in item ? item.body : ""].join(" ").toLocaleLowerCase().includes(needle),
    );
  }, [query, workspace.documents]);

  useEffect(() => {
    setRemoteResults(undefined);
    setSearchError(undefined);
    if (!isDevelopmentWorkspace || !query.trim()) return;
    let active = true;
    const timeout = window.setTimeout(() => {
      void api.search(query)
        .then(({ results }) => { if (active) setRemoteResults(results); })
        .catch((error) => { if (active) setSearchError(error instanceof Error ? error.message : String(error)); });
    }, 120);
    return () => { active = false; window.clearTimeout(timeout); };
  }, [api, query]);

  const documents: Array<DocumentMetadata | DocumentSnapshot> = remoteResults?.map((result) => ({ ...result.document, summary: result.snippet || result.document.summary })) ?? localResults;
  const recent = recentTurns.slice(0, 5);
  return (
    <div className="home-surface">
      <div className="space-overview">
        <section className="space-documents">
          <header className="home-intro">
            <h1>{workspace.site.title}</h1>
            {workspace.site.description && <p>{workspace.site.description}</p>}
          </header>
          <div className="index-tools">
            <label><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 4 4" /></svg><span className="sr-only">搜索标题和正文</span><input type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索标题和正文" /></label>
          </div>
          {searchError && <div className="map-warning" role="alert">{searchError}</div>}
          <section className="document-index" aria-label="文档列表">
            {documents.map((item, index) => (
              <button key={item.id} onClick={() => onOpen(item.id)}>
                <span className="index-number">{String(index + 1).padStart(2, "0")}</span>
                <span className="index-copy"><strong>{item.title}</strong><small>{item.summary}</small></span>
                <span className="index-stage">{item.stage ?? ""}</span>
              </button>
            ))}
            {!documents.length && <div className="empty-state"><strong>{query ? "没有找到相关文档" : "还没有学习文档"}</strong><p>{query ? "试试其他关键词，标题和正文都可以搜索。" : "在这个空间添加第一篇文档，开始学习。"}</p></div>}
          </section>
          <p className="index-count">{query ? `找到 ${documents.length} 篇文档` : `共 ${workspace.documents.length} 篇文档`}</p>
        </section>
        <aside className="space-sidebar">
          <nav className="space-links" aria-label="空间导航">
            <button onClick={onMap} aria-label="查看知识地图">知识地图 <span>↗</span></button>
            {isDevelopmentWorkspace && <button onClick={onHistory} aria-label="审核生长记录">生长记录 <span>↗</span></button>}
          </nav>
          <section className="recent-conversations">
            <h2>最近的对话</h2>
            {recent.length ? recent.map(turn => <button key={turn.id} onClick={() => onOpenConversation(turn)}>
              <span>{turn.question}</span>
              <small>{workspace.documents.find(document => document.id === turn.documentId)?.title ?? "学习文档"} · {new Date(turn.createdAt).toLocaleDateString("zh-CN", { month: "short", day: "numeric" })}</small>
            </button>) : <p>打开一篇文档，从第一个问题开始。</p>}
          </section>
        </aside>
      </div>
    </div>
  );
}
