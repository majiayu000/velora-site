import type { CollaborationSnapshot } from "../../src/ports/collaboration-port";
import { createContext, useContext } from "react";
import { subscribeEventStream } from "./sse";
import type { AuditReceipt, DocumentSnapshot, EvidenceReference, LearningSpaceSummary, LearnEvent, MutationReceipt, Proposal, RevertPreview, SearchResult, StructureProposal, TextAnchor, Turn, Workspace, WorkspaceInsights } from "./types";

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
    public readonly details?: Record<string, unknown>,
  ) {
    super(message);
  }
}

const bootstrap = window.__LEARN_BOOTSTRAP__;

export const isDevelopmentWorkspace = Boolean(bootstrap);

let refreshingSession: Promise<void> | undefined;
async function refreshSession(): Promise<void> {
  if (!refreshingSession) refreshingSession = (async () => {
    const response = await fetch("/__learn_bootstrap__.js", { cache: "no-store" });
    const match = (await response.text()).match(/window\.__LEARN_BOOTSTRAP__=(\{.*?\});/);
    if (!response.ok || !match || !bootstrap) throw new ApiError(401, "UNAUTHORIZED", "无法恢复本机会话，请刷新页面");
    const next = JSON.parse(match[1]!);
    if (next.apiBase !== bootstrap.apiBase || typeof next.token !== "string") throw new ApiError(401, "UNAUTHORIZED", "本机会话响应无效");
    bootstrap.token = next.token;
  })().finally(() => { refreshingSession = undefined; });
  return refreshingSession;
}

async function request<T>(path: string, init: RequestInit = {}, retrySession = true): Promise<T> {
  if (!bootstrap) throw new ApiError(405, "STATIC_BUILD", "生产构建是只读的");
  const response = await fetch(`${bootstrap.apiBase}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${bootstrap.token}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  if (response.status === 401 && retrySession) {
    await response.body?.cancel();
    await refreshSession();
    return request<T>(path, init, false);
  }
  const value = (await response.json()) as {
    error?: { code?: string; message?: string; details?: Record<string, unknown> };
  } & T;
  if (!response.ok) {
    throw new ApiError(
      response.status,
      value.error?.code ?? "REQUEST_FAILED",
      value.error?.message ?? `Request failed with ${response.status}`,
      value.error?.details,
    );
  }
  return value;
}

export const workbenchApi = {
  spaces: () => request<{ spaces: LearningSpaceSummary[] }>("/spaces"),
  chooseFolder: () => request<{ root: string | null }>("/folders/choose", { method: "POST" }),
  openSpace: (root: string, initialize = false) => request<{ space: LearningSpaceSummary }>("/spaces", {
    method: "POST",
    body: JSON.stringify({ root, initialize }),
  }),
};

export type SpaceApi = ReturnType<typeof createSpaceApi>;
export type RuntimeConfig = { adapter: string; command: string; args?: string[] };

export function createSpaceApi(spaceId: string) {
  const prefix = `/spaces/${encodeURIComponent(spaceId)}`;
  const scopedRequest = <T,>(path: string, init?: RequestInit) => request<T>(`${prefix}${path}`, init);
  return {
  spaceId,
  settings: () => scopedRequest<{ runtime: RuntimeConfig }>("/settings"),
  saveSettings: (runtime: RuntimeConfig) => scopedRequest<{ runtime: RuntimeConfig; health: Workspace["runtime"] }>("/settings", { method: "PUT", body: JSON.stringify({ runtime }) }),
  collaboration: (id: string) => scopedRequest<CollaborationSnapshot>(`/documents/${encodeURIComponent(id)}/collaboration`),
  syncDocument: (id: string, input: { update: string; vector: string; presence: { session: string; blockId?: string } }) => scopedRequest<CollaborationSnapshot & { peers: Array<{ session: string; blockId?: string }> }>(`/documents/${encodeURIComponent(id)}/collaboration`, { method: "POST", body: JSON.stringify(input) }),
  workspace: () => scopedRequest<Workspace>("/workspace"),
  document: (id: string) => scopedRequest<DocumentSnapshot>(`/documents/${encodeURIComponent(id)}`),
  search: (query: string) => scopedRequest<{ results: SearchResult[] }>(`/search?q=${encodeURIComponent(query)}`),
  insights: () => scopedRequest<WorkspaceInsights>("/insights"),
  saveDocument: (id: string, body: string, contentHash: string) =>
    scopedRequest<DocumentSnapshot>(`/documents/${encodeURIComponent(id)}`, {
      method: "PUT",
      headers: { "If-Match": contentHash },
      body: JSON.stringify({ body }),
    }),
  ask: (input: {
    documentId?: string;
    conversationId?: string;
    question: string;
    intent: "answer" | "revise" | "auto";
    anchor?: TextAnchor;
    target?: { from: number; to: number; baseHash: string };
  }) => scopedRequest<{ turn: Turn }>("/questions", { method: "POST", body: JSON.stringify(input) }),
  cancelTurn: (id: string) => scopedRequest<{ turn: Turn }>(`/turns/${encodeURIComponent(id)}/cancel`, { method: "POST", body: "{}" }),
  acceptProposal: (id: string) =>
    scopedRequest<{ proposal: Proposal; document: DocumentSnapshot }>(`/proposals/${encodeURIComponent(id)}/accept`, {
      method: "POST",
      body: "{}",
    }),
  rejectProposal: (id: string) =>
    scopedRequest<{ proposal: Proposal }>(`/proposals/${encodeURIComponent(id)}/reject`, { method: "POST", body: "{}" }),
  acceptStructureProposal: (id: string) =>
    scopedRequest<{ proposal: StructureProposal; workspace: { manifestHash: string; documents: Workspace["documents"]; warnings?: string[] } }>(`/structure-proposals/${encodeURIComponent(id)}/accept`, { method: "POST", body: "{}" }),
  rejectStructureProposal: (id: string) =>
    scopedRequest<{ proposal: StructureProposal }>(`/structure-proposals/${encodeURIComponent(id)}/reject`, { method: "POST", body: "{}" }),
  refreshEvidence: (turnId: string) =>
    scopedRequest<{ evidence: EvidenceReference[] }>(`/turns/${encodeURIComponent(turnId)}/evidence/refresh`, { method: "POST", body: "{}" }),
  history: () => scopedRequest<{ receipts: AuditReceipt[] }>("/history"),
  conversations: (query = "") => scopedRequest<{ conversations: import("./types").ConversationSummary[] }>(`/conversations?q=${encodeURIComponent(query)}`),
  updateConversation: (id: string, patch: Partial<Pick<import("./types").ConversationMetadata, "title" | "pinned" | "archived">>) => scopedRequest<{ conversation: import("./types").ConversationSummary }>(`/conversations/${encodeURIComponent(id)}`, { method: "PATCH", body: JSON.stringify(patch) }),
  previewRevert: (receiptId: string) => scopedRequest<RevertPreview>(`/history/${encodeURIComponent(receiptId)}/revert-preview`),
  revertReceipt: (receiptId: string) => scopedRequest<{ receipt: MutationReceipt; workspace: Workspace }>(`/history/${encodeURIComponent(receiptId)}/revert`, { method: "POST", body: "{}" }),
  };
}

export const SpaceApiContext = createContext<SpaceApi | null>(null);

export function useSpaceApi(): SpaceApi {
  const api = useContext(SpaceApiContext);
  if (!api) throw new Error("Space API is unavailable outside a learning space");
  return api;
}

export function subscribeToEvents(
  spaceId: string,
  after: number,
  onEvent: (event: LearnEvent) => void,
  onConnection: (connected: boolean) => void,
): () => void {
  if (!bootstrap) return () => undefined;
  let sequence = after;
  let stop: (() => void) | undefined;
  const updateVisibility = () => {
    if (document.visibilityState === "hidden") {
      stop?.();
      stop = undefined;
      onConnection(false);
    } else if (!stop) {
      stop = subscribeEventStream({
        apiBase: `${bootstrap.apiBase}/spaces/${encodeURIComponent(spaceId)}`,
        token: () => bootstrap.token,
        refreshSession,
        after: sequence,
        onEvent: (event) => { sequence = event.sequence; onEvent(event); },
        onConnection,
      });
    }
  };
  // Hidden tabs must not exhaust the browser's HTTP connection pool.
  document.addEventListener("visibilitychange", updateVisibility);
  updateVisibility();
  return () => {
    document.removeEventListener("visibilitychange", updateVisibility);
    stop?.();
  };
}
