export type DocumentMetadata = {
  id: string;
  path: string;
  title: string;
  summary: string;
  stage?: string;
  tags?: string[];
  prerequisites?: string[];
  related?: string[];
};

export type DocumentSnapshot = DocumentMetadata & {
  body: string;
  contentHash: string;
  modifiedAt: string;
};

export type Workspace = {
  site: { title: string; description?: string };
  documents: Array<DocumentMetadata | DocumentSnapshot>;
  manifestHash: string;
  runtime: { adapter: string; available: boolean; version?: string; message?: string };
};

export type LearningSpaceSummary = {
  id: string;
  root: string;
  title: string;
  description?: string;
};

export type EditTarget = { from: number; to: number; baseHash: string; blockId?: string; ifHash?: string };

export type TextAnchor = {
  exactQuote: string;
  prefix?: string;
  suffix?: string;
  headingPath?: string[];
  snapshotHash?: string;
};

export type Turn = {
  id: string;
  conversationId: string;
  documentId?: string;
  documentIds?: string[];
  question: string;
  intent: "answer" | "revise" | "auto";
  anchor?: TextAnchor;
  target?: EditTarget;
  status: "running" | "completed" | "failed" | "cancelled";
  answerMarkdown?: string;
  appliedEdits?: number;
  evidence?: EvidenceReference[];
  proposalId?: string;
  structureProposalId?: string;
  duplicateOfTurnId?: string;
  error?: string;
  createdAt: string;
};

export type EvidenceReference = {
  state: "verified" | "inferred" | "unknown";
  label: string;
  path?: string;
  line?: number;
  detail?: string;
  capturedHash?: string;
  stale?: boolean;
};

export type StructureOperation =
  | { type: "create"; document: DocumentMetadata; body: string }
  | { type: "update"; documentId: string; title: string; summary: string }
  | { type: "rename"; documentId: string; nextPath: string; title?: string }
  | { type: "delete"; documentId: string };

export type StructureProposal = {
  id: string;
  turnId: string;
  baseManifestHash: string;
  summary: string;
  operations: StructureOperation[];
  status: "pending" | "accepted" | "rejected" | "conflict";
  createdAt: string;
};

export type SearchResult = { document: DocumentMetadata; score: number; snippet: string };

export type WorkspaceInsights = {
  disconnectedDocumentIds: string[];
  duplicateQuestionGroups: Array<{ normalizedQuestion: string; turnIds: string[] }>;
};

export type Proposal = {
  id: string;
  turnId: string;
  documentId: string;
  baseHash: string;
  baseMarkdown: string;
  summary: string;
  replacementMarkdown: string;
  status: "pending" | "accepted" | "rejected" | "conflict";
  createdAt: string;
};

export type LearnEvent = {
  sequence: number;
  type: string;
  at: string;
  payload: Record<string, unknown>;
};

export type MutationReceipt = {
  id: string;
  kind: "mutation";
  at: string;
  source: "human" | "proposal" | "structure" | "revert";
  summary: string;
  files: string[];
  git: { status: "committed"; commit: string } | { status: "unavailable" | "failed"; message: string };
  revertedReceiptId?: string;
};

export type AuditReceipt =
  | { id: string; kind: "conversation"; at: string; conversation: ConversationMetadata }
  | { id: string; kind: "turn"; at: string; turn: Turn }
  | { id: string; kind: "decision"; at: string; proposalKind: "document" | "structure"; proposalId: string; turnId: string; decision: "accepted" | "rejected" }
  | MutationReceipt;

export type ConversationMetadata = { id: string; title: string; pinned: boolean; archived: boolean };
export type ConversationSummary = ConversationMetadata & {
  createdAt: string;
  updatedAt: string;
  documentId?: string;
  status: Turn["status"];
};

export type RevertPreview = {
  receiptId: string;
  commit: string;
  files: string[];
  patch: string;
  canApply: boolean;
  conflict?: string;
};

declare global {
  interface Window {
    __LEARN_BOOTSTRAP__?: { mode: "development"; apiBase: string; token: string };
  }
}
