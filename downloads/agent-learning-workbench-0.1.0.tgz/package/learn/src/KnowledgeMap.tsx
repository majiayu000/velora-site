import { useEffect, useMemo, useState } from "react";
import { isDevelopmentWorkspace, useSpaceApi } from "./api";
import type { DocumentMetadata, Workspace, WorkspaceInsights } from "./types";

export function KnowledgeMap({ workspace, currentDocumentId, onOpen }: { workspace: Workspace; currentDocumentId?: string; onOpen: (id: string) => void }) {
  const api = useSpaceApi();
  const documents = workspace.documents as DocumentMetadata[];
  const [insights, setInsights] = useState<WorkspaceInsights>();
  const [error, setError] = useState<string>();
  const byId = useMemo(() => new Map(documents.map((document) => [document.id, document])), [documents]);
  const stages = useMemo(() => {
    const groups = new Map<string, DocumentMetadata[]>();
    for (const document of documents) {
      const stage = document.stage?.match(/^\d+/)?.[0] ?? document.stage ?? "未分组";
      groups.set(stage, [...(groups.get(stage) ?? []), document]);
    }
    return [...groups.entries()].sort(([left], [right]) => left.localeCompare(right, undefined, { numeric: true }));
  }, [documents]);

  useEffect(() => {
    if (!isDevelopmentWorkspace) return;
    let active = true;
    setInsights(undefined);
    setError(undefined);
    void api.insights()
      .then((value) => { if (active) setInsights(value); })
      .catch((reason) => { if (active) setError(reason instanceof Error ? reason.message : String(reason)); });
    return () => { active = false; };
  }, [api, workspace.manifestHash]);

  const disconnected = insights?.disconnectedDocumentIds ?? documents.filter(document =>
    !(document.prerequisites?.length || document.related?.length) && !documents.some(other => other.prerequisites?.includes(document.id) || other.related?.includes(document.id)),
  ).map(document => document.id);

  return (
    <div className="knowledge-map" aria-label="知识地图">
      <header className="map-header"><div><p className="eyebrow">PREREQUISITE → RELATED</p><h1>知识地图</h1><p>从上往下学。每一步只需要前面那一步的基础。</p></div><div className="map-legend"><span><i className="current-key" />当前页</span><span><i className="disconnected-key" />未接入路径</span></div></header>
      {error && <div className="map-warning" role="alert">{error}</div>}
      {disconnected.length ? <div className="map-warning"><span className="warning-badge">{disconnected.length} 篇未接入</span><span>{disconnected.map((id) => byId.get(id)?.title ?? id).join("、")} 还没有先学或被引用关系。</span></div> : null}
      <div className="map-stages">
        {stages.map(([stage, items], index) => (
          <section key={stage} className={index > 0 && items.some(document => document.prerequisites?.some(id => stages[index - 1]![1].some(previous => previous.id === id))) ? "has-prerequisite" : ""}>
            <span className="stage-label">{stage}</span>
            {items.map((document) => (
              <article key={document.id} className={`${currentDocumentId === document.id ? "is-current" : ""} ${disconnected.includes(document.id) ? "is-disconnected" : ""}`}>
                <button onClick={() => onOpen(document.id)}>{document.stage !== stage && <span className="node-stage">{document.stage}</span>}<strong>{document.title}</strong><small>{document.summary}</small>{currentDocumentId === document.id && <em>当前页</em>}</button>
                <div>
                  {(document.prerequisites ?? []).map((id) => <button key={`pre-${id}`} onClick={() => onOpen(id)}>先学 {byId.get(id)?.title ?? id}</button>)}
                  {(document.related ?? []).map((id) => <button key={`rel-${id}`} onClick={() => onOpen(id)}>相关 {byId.get(id)?.title ?? id}</button>)}
                </div>
              </article>
            ))}
          </section>
        ))}
      </div>
      {!documents.length && <div className="empty-state"><strong>知识地图还在生长</strong><p>添加文档和先学关系后，就能在这里看到学习路径。</p></div>}
    </div>
  );
}
