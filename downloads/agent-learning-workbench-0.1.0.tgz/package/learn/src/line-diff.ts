export type DiffLine = {
  kind: "unchanged" | "added" | "removed";
  text: string;
  oldLine?: number;
  newLine?: number;
};

type DiffKind = DiffLine["kind"];
type RawDiffLine = { kind: DiffKind; text: string };

const MAX_LCS_CELLS = 500_000;

function splitLines(value: string): string[] {
  return value.split("\n");
}

function diffMiddle(before: string[], after: string[]): RawDiffLine[] {
  if (!before.length) return after.map((text) => ({ kind: "added", text }));
  if (!after.length) return before.map((text) => ({ kind: "removed", text }));

  if (before.length * after.length > MAX_LCS_CELLS) {
    return [
      ...before.map((text): RawDiffLine => ({ kind: "removed", text })),
      ...after.map((text): RawDiffLine => ({ kind: "added", text })),
    ];
  }

  const table = Array.from(
    { length: before.length + 1 },
    () => new Uint32Array(after.length + 1),
  );
  for (let oldIndex = before.length - 1; oldIndex >= 0; oldIndex -= 1) {
    for (let newIndex = after.length - 1; newIndex >= 0; newIndex -= 1) {
      table[oldIndex][newIndex] = before[oldIndex] === after[newIndex]
        ? table[oldIndex + 1][newIndex + 1] + 1
        : Math.max(table[oldIndex + 1][newIndex], table[oldIndex][newIndex + 1]);
    }
  }

  const result: RawDiffLine[] = [];
  let oldIndex = 0;
  let newIndex = 0;
  while (oldIndex < before.length && newIndex < after.length) {
    if (before[oldIndex] === after[newIndex]) {
      result.push({ kind: "unchanged", text: before[oldIndex] });
      oldIndex += 1;
      newIndex += 1;
    } else if (table[oldIndex + 1][newIndex] >= table[oldIndex][newIndex + 1]) {
      result.push({ kind: "removed", text: before[oldIndex] });
      oldIndex += 1;
    } else {
      result.push({ kind: "added", text: after[newIndex] });
      newIndex += 1;
    }
  }
  while (oldIndex < before.length) result.push({ kind: "removed", text: before[oldIndex++] });
  while (newIndex < after.length) result.push({ kind: "added", text: after[newIndex++] });
  return result;
}

export function buildLineDiff(beforeText: string, afterText: string): DiffLine[] {
  const before = splitLines(beforeText);
  const after = splitLines(afterText);
  let prefixLength = 0;
  while (
    prefixLength < before.length &&
    prefixLength < after.length &&
    before[prefixLength] === after[prefixLength]
  ) {
    prefixLength += 1;
  }

  let suffixLength = 0;
  while (
    suffixLength < before.length - prefixLength &&
    suffixLength < after.length - prefixLength &&
    before[before.length - suffixLength - 1] === after[after.length - suffixLength - 1]
  ) {
    suffixLength += 1;
  }

  const raw: RawDiffLine[] = [
    ...before.slice(0, prefixLength).map((text): RawDiffLine => ({ kind: "unchanged", text })),
    ...diffMiddle(
      before.slice(prefixLength, before.length - suffixLength),
      after.slice(prefixLength, after.length - suffixLength),
    ),
    ...before.slice(before.length - suffixLength).map((text): RawDiffLine => ({ kind: "unchanged", text })),
  ];

  let oldLine = 1;
  let newLine = 1;
  return raw.map((line) => {
    if (line.kind === "added") return { ...line, newLine: newLine++ };
    if (line.kind === "removed") return { ...line, oldLine: oldLine++ };
    return { ...line, oldLine: oldLine++, newLine: newLine++ };
  });
}

export function summarizeLineDiff(lines: DiffLine[]): { added: number; removed: number } {
  return lines.reduce(
    (summary, line) => {
      if (line.kind === "added") summary.added += 1;
      if (line.kind === "removed") summary.removed += 1;
      return summary;
    },
    { added: 0, removed: 0 },
  );
}
