import type { TextAnchor } from "./types";

export type PositionedTextAnchor = TextAnchor & { x: number; y: number };

export type AnchorResolution = {
  state: "exact" | "contextual" | "heading" | "detached";
  range?: Range;
  target?: HTMLElement;
};

type TextPoint = { node: Text; offset: number };

type NormalizedRootText = {
  text: string;
  starts: TextPoint[];
  ends: TextPoint[];
};

function compactWhitespace(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

function normalizedRootText(root: HTMLElement): NormalizedRootText {
  let text = "";
  const starts: TextPoint[] = [];
  const ends: TextPoint[] = [];
  const walker = root.ownerDocument.createTreeWalker(root, 4);
  let node = walker.nextNode() as Text | null;
  while (node) {
    if (node.parentElement?.closest("[data-anchor-ignore]")) { node = walker.nextNode() as Text | null; continue; }
    const value = node.data;
    for (let offset = 0; offset < value.length; offset += 1) {
      const character = value[offset];
      if (/\s/.test(character)) {
        if (!text || text.endsWith(" ")) continue;
        text += " ";
      } else {
        text += character;
      }
      starts.push({ node, offset });
      ends.push({ node, offset: offset + 1 });
    }
    node = walker.nextNode() as Text | null;
  }
  if (text.endsWith(" ")) {
    text = text.slice(0, -1);
    starts.pop();
    ends.pop();
  }
  return { text, starts, ends };
}

function rangeFromOffsets(rootText: NormalizedRootText, start: number, end: number): Range | undefined {
  if (start < 0 || end <= start || end > rootText.text.length) return undefined;
  const first = rootText.starts[start];
  const last = rootText.ends[end - 1];
  if (!first || !last) return undefined;
  const range = first.node.ownerDocument.createRange();
  range.setStart(first.node, first.offset);
  range.setEnd(last.node, last.offset);
  return range;
}

function occurrences(value: string, needle: string): number[] {
  const matches: number[] = [];
  let position = value.indexOf(needle);
  while (position >= 0 && matches.length < 50) {
    matches.push(position);
    position = value.indexOf(needle, position + 1);
  }
  return matches;
}

function commonPrefixLength(left: string, right: string): number {
  const limit = Math.min(left.length, right.length);
  let length = 0;
  while (length < limit && left[length] === right[length]) length += 1;
  return length;
}

function commonSuffixLength(left: string, right: string): number {
  const limit = Math.min(left.length, right.length);
  let length = 0;
  while (length < limit && left[left.length - 1 - length] === right[right.length - 1 - length]) length += 1;
  return length;
}

function strongestContext(value: string, side: "prefix" | "suffix", documentText: string) {
  const normalized = compactWhitespace(value).slice(side === "prefix" ? -120 : 0, side === "prefix" ? undefined : 120);
  for (let length = normalized.length; length >= 8; length -= Math.max(1, Math.floor(length / 5))) {
    const fragment = side === "prefix" ? normalized.slice(-length) : normalized.slice(0, length);
    const matches = occurrences(documentText, fragment);
    if (matches.length) return { fragment, matches };
  }
  return undefined;
}

function resolveExact(rootText: NormalizedRootText, anchor: TextAnchor): AnchorResolution | undefined {
  const quote = compactWhitespace(anchor.exactQuote);
  const matches = occurrences(rootText.text, quote);
  if (!matches.length) return undefined;
  const prefix = compactWhitespace(anchor.prefix ?? "");
  const suffix = compactWhitespace(anchor.suffix ?? "");
  const ranked = matches.map((start) => ({
    start,
    score:
      commonSuffixLength(rootText.text.slice(0, start).trimEnd(), prefix) +
      commonPrefixLength(rootText.text.slice(start + quote.length).trimStart(), suffix),
  })).sort((left, right) => right.score - left.score);
  if (ranked.length > 1 && ranked[0].score === ranked[1].score) return undefined;
  const range = rangeFromOffsets(rootText, ranked[0].start, ranked[0].start + quote.length);
  return range ? { state: "exact", range } : undefined;
}

function resolveContext(rootText: NormalizedRootText, anchor: TextAnchor): AnchorResolution | undefined {
  if (!anchor.prefix || !anchor.suffix) return undefined;
  const prefix = strongestContext(anchor.prefix, "prefix", rootText.text);
  const suffix = strongestContext(anchor.suffix, "suffix", rootText.text);
  if (!prefix || !suffix) return undefined;
  const expectedLength = compactWhitespace(anchor.exactQuote).length;
  const maximumGap = Math.min(2400, Math.max(160, expectedLength * 8 + 400));
  const candidates: Array<{ start: number; end: number; score: number }> = [];
  for (const prefixStart of prefix.matches) {
    const start = prefixStart + prefix.fragment.length;
    for (const end of suffix.matches) {
      if (end < start || end - start > maximumGap) continue;
      candidates.push({ start, end, score: Math.abs(end - start - expectedLength) });
    }
  }
  candidates.sort((left, right) => left.score - right.score);
  if (!candidates.length || (candidates.length > 1 && candidates[0].score === candidates[1].score)) return undefined;
  let { start, end } = candidates[0];
  while (rootText.text[start] === " ") start += 1;
  while (end > start && rootText.text[end - 1] === " ") end -= 1;
  const range = rangeFromOffsets(rootText, start, end);
  return range ? { state: "contextual", range } : undefined;
}

function resolveHeading(root: HTMLElement, anchor: TextAnchor): AnchorResolution | undefined {
  if (!anchor.headingPath?.length) return undefined;
  const headings = [...root.querySelectorAll<HTMLElement>("h1, h2, h3, h4, h5, h6")];
  for (let pathIndex = anchor.headingPath.length - 1; pathIndex >= 0; pathIndex -= 1) {
    const expected = compactWhitespace(anchor.headingPath[pathIndex]);
    const matches = headings.filter((heading) => compactWhitespace(heading.textContent ?? "") === expected);
    const ranked = matches.map((target) => {
      const candidatePath = headingPath(root, target) ?? [];
      let score = 0;
      while (
        score < candidatePath.length &&
        score < anchor.headingPath!.length &&
        candidatePath[candidatePath.length - 1 - score] === anchor.headingPath![anchor.headingPath!.length - 1 - score]
      ) score += 1;
      return { target, score };
    }).sort((left, right) => right.score - left.score);
    if (ranked.length && (ranked.length === 1 || ranked[0].score > ranked[1].score)) {
      return { state: "heading", target: ranked[0].target };
    }
  }
  return undefined;
}

function headingPath(root: HTMLElement, startNode: Node): string[] | undefined {
  const path: string[] = [];
  for (const heading of root.querySelectorAll<HTMLElement>("h1, h2, h3, h4, h5, h6")) {
    if (heading !== startNode && !heading.contains(startNode)) {
      const position = heading.compareDocumentPosition(startNode);
      if (!(position & Node.DOCUMENT_POSITION_FOLLOWING)) continue;
    }
    const level = Number(heading.tagName.slice(1));
    path.splice(level - 1);
    path[level - 1] = compactWhitespace(heading.textContent ?? "");
  }
  const normalized = path.filter(Boolean);
  return normalized.length ? normalized : undefined;
}

export function captureSelectionAnchor(
  root: HTMLElement | null,
  selection: Selection | null,
  viewportWidth: number,
  snapshotHash?: string,
): PositionedTextAnchor | undefined {
  if (!root || !selection?.rangeCount) return undefined;
  const range = selection.getRangeAt(0);
  if (range.collapsed || !root.contains(range.startContainer) || !root.contains(range.endContainer)) return undefined;
  const exactQuote = selection.toString().trim();
  if (!exactQuote || exactQuote.length > 1200) return undefined;

  const before = range.cloneRange();
  before.selectNodeContents(root);
  before.setEnd(range.startContainer, range.startOffset);
  const after = range.cloneRange();
  after.selectNodeContents(root);
  after.setStart(range.endContainer, range.endOffset);
  const contextText = (context: Range) => {
    const fragment = context.cloneContents();
    fragment.querySelectorAll("[data-anchor-ignore]").forEach(element => element.remove());
    return compactWhitespace(fragment.textContent ?? "");
  };
  const prefixText = contextText(before);
  const suffixText = contextText(after);
  const rect = range.getBoundingClientRect();

  return {
    exactQuote,
    prefix: prefixText.slice(-120) || undefined,
    suffix: suffixText.slice(0, 120) || undefined,
    headingPath: headingPath(root, range.startContainer),
    snapshotHash,
    x: Math.max(8, Math.min(rect.left, viewportWidth - 250)),
    y: rect.bottom + 8,
  };
}

export function questionAnchor(anchor: PositionedTextAnchor): TextAnchor {
  const { exactQuote, prefix, suffix, headingPath: headings, snapshotHash } = anchor;
  return { exactQuote, prefix, suffix, headingPath: headings, snapshotHash };
}

export function resolveTextAnchor(root: HTMLElement | null, anchor: TextAnchor): AnchorResolution {
  if (!root) return { state: "detached" };
  const rootText = normalizedRootText(root);
  return resolveExact(rootText, anchor)
    ?? resolveContext(rootText, anchor)
    ?? resolveHeading(root, anchor)
    ?? { state: "detached" };
}
