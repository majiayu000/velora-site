import { lazy, StrictMode, Suspense } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const Workbench = lazy(() => import("./App"));

createRoot(document.getElementById("app")!).render(
  <StrictMode>
    <Suspense fallback={<div className="shell-state" role="status">正在打开本地工作台…</div>}>
      <Workbench />
    </Suspense>
  </StrictMode>,
);
