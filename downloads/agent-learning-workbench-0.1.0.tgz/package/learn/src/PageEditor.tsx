import { Fragment, useEffect, useSyncExternalStore, useState, useRef } from "react";
import { EditorContent, useEditor } from "@tiptap/react";
import { Markdown } from "@tiptap/markdown";
import { Extension, type Editor } from "@tiptap/core";
import { TextSelection } from "@tiptap/pm/state";
import { canJoin } from "@tiptap/pm/transform";
import { ySyncPlugin, ySyncPluginKey, updateYFragment } from "@tiptap/y-tiptap";
import * as Y from "yjs";
import { MarkdownEditor } from "./MarkdownEditor";
import { MarkdownView } from "./MarkdownView";
import { AiEditPreview } from "./AiEditPreview";
import type { AiEdit, AiEdits } from "./ai-edit";
import { useSpaceApi } from "./api";
import { LiveDocument, humanOrigin } from "./collaboration";
import { blockId, blockList, blockMarkdown, createBlock, fragment, isSource, sourceText, richExtensions, type SharedBlock } from "../../src/adapters/collaboration/model";
import type { DocumentSnapshot } from "./types";

export const pageEditorExtensions = () => [...richExtensions(), Markdown];

function RichInput({ block, live, undo, focusOnMount, editors }: { block: SharedBlock; live: LiveDocument; undo: Y.UndoManager; focusOnMount: boolean; editors: Map<string, Editor> }) {
  const editor = useEditor({
    autofocus: focusOnMount ? "end" : false,
    extensions: [...pageEditorExtensions(), Extension.create({
      name: "sharedDocumentOperations",
      addProseMirrorPlugins: () => [ySyncPlugin(fragment(block))],
      addKeyboardShortcuts: () => ({ "Mod-z": () => { undo.undo(); return true; }, "Mod-Shift-z": () => { undo.redo(); return true; } }),
    })],
    editorProps: {
      attributes: { class: "markdown page-block-input", "aria-label": "段落编辑器", role: "textbox", "aria-multiline": "true" },
      handleKeyDown: (view, event) => {
        if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") { event.preventDefault(); void live.flush(); return true; }
        if (event.isComposing || view.composing || event.shiftKey || event.metaKey || event.ctrlKey || event.altKey || !view.state.selection.empty) return false;
        const backward = ["ArrowLeft", "ArrowUp", "Backspace"].includes(event.key);
        const forward = ["ArrowRight", "ArrowDown", "Delete"].includes(event.key);
        if (!backward && !forward) return false;
        const edge = backward ? TextSelection.atStart(view.state.doc).from : TextSelection.atEnd(view.state.doc).to;
        if (view.state.selection.from !== edge) return false;
        const list = blockList(live.doc); const index = list.toArray().indexOf(block);
        const neighbor = list.toArray()[index + (backward ? -1 : 1)];
        if (!neighbor || isSource(neighbor)) return false;
        const adjacent = editors.get(blockId(neighbor)); const current = editors.get(blockId(block));
        if (!adjacent || !current) return false;
        if (event.key !== "Backspace" && event.key !== "Delete") {
          adjacent.commands.focus(backward ? "end" : "start"); return true;
        }
        const left = backward ? adjacent : current; const right = backward ? current : adjacent;
        // Lists, tables and source blocks keep their own structural key handling.
        if (!left.state.doc.lastChild?.isTextblock || !right.state.doc.firstChild?.isTextblock) return false;
        const seam = left.state.doc.content.size;
        let caret = seam;
        const transaction = left.state.tr.insert(seam, left.schema.nodeFromJSON(right.getJSON()).content);
        if (canJoin(transaction.doc, seam)) { transaction.join(seam); caret = seam - 1; }
        undo.stopCapturing();
        live.doc.transact(() => {
          const binding = ySyncPluginKey.getState(left.state).binding;
          updateYFragment(live.doc, fragment(backward ? neighbor : block), transaction.doc, binding);
          list.delete(backward ? index : index + 1, 1);
        }, humanOrigin);
        undo.stopCapturing();
        left.commands.focus(caret); return true;
      },
    },
  });
  useEffect(() => {
    if (!editor) return;
    editors.set(blockId(block), editor);
    return () => { editors.delete(blockId(block)); };
  }, [editor, block, editors]);
  if (!editor) return null;
  return <>
    <div data-anchor-ignore className="page-format-toolbar" aria-label="段落格式">
      <button aria-label="加粗" onMouseDown={e => e.preventDefault()} onClick={() => editor.chain().focus().toggleBold().run()}><strong>B</strong></button>
      <button aria-label="斜体" onMouseDown={e => e.preventDefault()} onClick={() => editor.chain().focus().toggleItalic().run()}><em>I</em></button>
      <button onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}>标题</button>
      <button onClick={() => editor.chain().focus().toggleBulletList().run()}>列表</button>
      <button onClick={() => editor.chain().focus().toggleBlockquote().run()}>引用</button>
      <button onClick={() => editor.chain().focus().toggleCodeBlock().run()}>代码</button>
    </div><EditorContent editor={editor} />
  </>;
}

function SourceInput({ block, live, undo }: { block: SharedBlock; live: LiveDocument; undo: Y.UndoManager }) {
  const text = sourceText(block);
  return <div className="page-source-block"><p>此块使用源码编辑，保留图表与特殊格式。</p>
    <MarkdownEditor value={text.toString()} revision={blockId(block)} shared={{ text, undo }} onSave={() => void live.flush()} />
  </div>;
}

type PageEditorProps = {
  documentId: string;
  onSnapshot: (snapshot: DocumentSnapshot) => void;
  onRequestEdit: (from: number, to: number, block?: { blockId: string; ifHash: string }) => void;
  aiEdits?: AiEdits;
  onAiEditSynced?: (editId: string) => void;
};
export function PageEditor(props: PageEditorProps) {
  const api = useSpaceApi();
  const [session, setSession] = useState<{ live: LiveDocument; undo: Y.UndoManager }>();
  useEffect(() => {
    const live = new LiveDocument(api, props.documentId);
    const undo = new Y.UndoManager(blockList(live.doc), { trackedOrigins: new Set([humanOrigin, ySyncPluginKey]) });
    setSession({ live, undo }); void live.start();
    return () => { undo.destroy(); live.close(); };
  }, [api, props.documentId]);
  return session ? <LivePageEditor {...props} {...session} /> : <p>正在打开协作文档…</p>;
}
function LivePageEditor({ documentId, onSnapshot, onRequestEdit, aiEdits = {}, onAiEditSynced, live, undo }: PageEditorProps & { live: LiveDocument; undo: Y.UndoManager }) {
  useSyncExternalStore(live.subscribe, live.getVersion, live.getVersion);
  const [active, setActive] = useState<string>();
  const [sourceEditing, setSourceEditing] = useState<string>();
  const editors = useRef(new Map<string, Editor>()).current;
  useEffect(() => { if (live.snapshot && !live.pending) onSnapshot(live.snapshot.document); }, [live.snapshot, live.pending, onSnapshot]);
  const blocks = blockList(live.doc).toArray();
  // A later revision may legitimately delete an inserted block. The shared
  // revision is authoritative; historical previews must not resurrect it.
  const synced = (entry: AiEdit) => entry.revision !== undefined && (live.snapshot?.revision ?? -1) >= entry.revision;
  const edits = Object.values(aiEdits).filter(entry => entry.documentId === documentId && !synced(entry));
  useEffect(() => {
    for (const entry of Object.values(aiEdits)) if (entry.documentId === documentId && synced(entry)) onAiEditSynced?.(entry.editId);
  });
  const inserts = (after: string | null) => edits.filter(entry => entry.operation.type === "insert" && entry.operation.after === after).map(entry => (
    <section className="editable-block is-ai-editing ai-edit-insertion" data-ai-edit-id={entry.editId} key={entry.editId}>
      <AiEditPreview markdown={entry.markdown} saving={entry.revision !== undefined} />
    </section>
  ));
  const edit = (id?: string) => { if (live.activeBlock === id) return; setActive(id); live.activeBlock = id; void live.flush(); undo.stopCapturing(); };
  const insert = (after: number) => {
    const block = createBlock("新段落。\n\n");
    live.doc.transact(() => blockList(live.doc).insert(after + 1, [block]), humanOrigin);
    edit(blockId(block));
  };
  return <div className="page-editor">
    <div data-anchor-ignore className="live-document-toolbar">
      <span role="status" className="collaboration-status">{live.status}</span>
      <span>{live.peers.length + 1} 个编辑会话</span>
      <button onClick={() => { undo.undo(); }} disabled={!undo.canUndo()}>撤销我的修改</button>
      <button onClick={() => { undo.redo(); }} disabled={!undo.canRedo()}>重做我的修改</button>
      <button onClick={() => void live.flush()}>立即同步</button>
    </div>
    {live.error && <div role="alert" className="conflict-banner">{live.error}<button onClick={() => {
      const blob = new Blob([blocks.map(blockMarkdown).join("")], { type: "text/markdown" });
      const url = URL.createObjectURL(blob); const link = window.document.createElement("a"); link.href = url; link.download = `${documentId}.md`; link.click(); URL.revokeObjectURL(url);
    }}>下载本机副本</button></div>}
    {!live.ready ? <p>正在恢复文档与本机未同步修改…</p> : <>
      <p data-anchor-ignore className="page-editor-hint">点击正文即可编辑，修改自动保存。</p>
      {inserts(null)}
      {blocks.map((block, index) => {
        const id = blockId(block); const selected = live.snapshot?.blocks.find(b => b.id === id);
        const others = live.peers.filter(p => p.blockId === id);
        const aiEdit = edits.find(entry => entry.operation.type === "replace" && entry.operation.blockId === id);
        // Keep identified shared insertions covered until the preview hands over.
        const covered = edits.some(entry => entry.operation.type === "insert" && entry.blockIds?.includes(id));
        return <Fragment key={id}><section data-block-id={id} data-ai-edit-id={aiEdit?.editId} hidden={covered} className={`editable-block ${active === id ? "is-editing" : ""} ${aiEdit ? "is-ai-editing" : ""}`}
          onFocusCapture={() => edit(id)} onBlurCapture={event => { if (!event.currentTarget.contains(event.relatedTarget)) edit(undefined); }}>
          {others.length > 0 && <span data-anchor-ignore className="block-presence">{others.length} 个其他会话正在编辑此段</span>}
          <div hidden={!!aiEdit}>
          {isSource(block)
            ? sourceEditing === id ? <SourceInput block={block} live={live} undo={undo} /> : <MarkdownView body={blockMarkdown(block)} />
            : <RichInput block={block} live={live} undo={undo} focusOnMount={active === id} editors={editors} />}
          </div>
          {aiEdit && <AiEditPreview key={aiEdit.editId} markdown={aiEdit.markdown} original={blockMarkdown(block)} saving={aiEdit.revision !== undefined} />}
          <div data-anchor-ignore className="page-block-actions" hidden={!!aiEdit}>
            {isSource(block) && <button onClick={() => setSourceEditing(sourceEditing === id ? undefined : id)}>{sourceEditing === id ? "返回预览" : "编辑源码"}</button>}
            <button onClick={() => insert(index)}>插入段落</button>
            <button onClick={() => { live.doc.transact(() => blockList(live.doc).delete(index, 1), humanOrigin); if (active === id) edit(undefined); }}>删除此段</button>
            <button disabled={live.pending || !!live.error || !selected} onClick={() => selected && onRequestEdit(selected.from, selected.to, { blockId: id, ifHash: selected.hash })}>Agent 修改此段</button>
            <button disabled={live.pending || !!live.error || !selected} onClick={() => selected && onRequestEdit(selected.to, selected.to, { blockId: id, ifHash: selected.hash })}>在后面生成</button>
          </div>
        </section>{inserts(id)}</Fragment>;
      })}
      {!blocks.length && <button onClick={() => insert(-1)}>开始写作</button>}
    </>}
  </div>;
}
