declare module "virtual:project-learning-content" {
  import type { Workspace } from "./types";
  const workspace: Workspace;
  export default workspace;
}
