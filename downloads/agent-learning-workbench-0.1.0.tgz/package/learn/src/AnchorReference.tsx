import { useEffect, useState, type RefObject } from "react";
import { resolveTextAnchor, type AnchorResolution } from "./selection-anchor";
import type { TextAnchor } from "./types";

type VisibleState = AnchorResolution["state"] | "other-document";

const labels: Record<VisibleState, string> = {
  exact: "原文仍可精确定位",
  contextual: "原文已变化 · 按上下文恢复",
  heading: "原文已变化 · 定位到所属章节",
  detached: "原文已脱离 · 无法可靠定位",
  "other-document": "引用位于另一篇学习页",
};

function contentRoot(root: HTMLElement | null): HTMLElement | null {
  return root?.querySelector<HTMLElement>(".page-editor, .markdown") ?? null;
}

function focusResolution(resolution: AnchorResolution): void {
  const selection = window.getSelection();
  let target = resolution.target;
  if (resolution.range) {
    selection?.removeAllRanges();
    selection?.addRange(resolution.range);
    const container = resolution.range.commonAncestorContainer;
    target = (container.nodeType === Node.ELEMENT_NODE ? container : container.parentElement) as HTMLElement | null ?? undefined;
  }
  const focusTarget = target?.closest<HTMLElement>(".editable-block") ?? target?.closest<HTMLElement>("p, li, blockquote, pre, td, th, h1, h2, h3, h4, h5, h6") ?? target;
  focusTarget?.scrollIntoView({ behavior: "smooth", block: "center" });
  focusTarget?.setAttribute("data-anchor-flash", "true");
  if (focusTarget) window.setTimeout(() => focusTarget.removeAttribute("data-anchor-flash"), 1800);
}

export function AnchorReference({
  anchor,
  documentId,
  currentDocumentId,
  currentHash,
  articleRef,
  revisionKey,
}: {
  anchor: TextAnchor;
  documentId: string;
  currentDocumentId?: string;
  currentHash?: string;
  articleRef: RefObject<HTMLElement | null>;
  revisionKey: string;
}) {
  const [state, setState] = useState<VisibleState>("detached");

  useEffect(() => {
    if (documentId !== currentDocumentId) {
      setState("other-document");
      return;
    }
    setState(resolveTextAnchor(contentRoot(articleRef.current), anchor).state);
  }, [anchor, articleRef, currentDocumentId, documentId, revisionKey]);

  const label = state === "exact" && anchor.snapshotHash === currentHash ? "原始选区" : labels[state];
  const canLocate = state !== "detached" && state !== "other-document";

  return (
    <button
      type="button"
      className={`turn-anchor state-${state}`}
      data-anchor-state={state}
      disabled={!canLocate}
      onClick={() => {
        if (!canLocate) return;
        focusResolution(resolveTextAnchor(contentRoot(articleRef.current), anchor));
      }}
    >
      <span>“{anchor.exactQuote.slice(0, 62)}{anchor.exactQuote.length > 62 ? "…" : "”"}</span>
      <small>{label}{canLocate ? " ↗" : ""}</small>
    </button>
  );
}
