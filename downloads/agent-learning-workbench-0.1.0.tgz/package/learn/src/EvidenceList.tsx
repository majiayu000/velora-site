import type { EvidenceReference } from "./types";

const stateLabels: Record<EvidenceReference["state"], string> = {
  verified: "已验证",
  inferred: "推断",
  unknown: "未知",
};

export function EvidenceList({ evidence, onRefresh }: { evidence: EvidenceReference[]; onRefresh?: () => void }) {
  if (!evidence.length) return null;
  return (
    <section className="evidence-list" aria-label="回答证据">
      <div className="evidence-head"><strong>证据状态</strong>{onRefresh && <button onClick={onRefresh}>检查新鲜度</button>}</div>
      {evidence.map((item, index) => (
        <article className={`evidence-item state-${item.state} ${item.stale ? "is-stale" : ""}`} data-evidence-state={item.state} data-evidence-stale={item.stale ? "true" : "false"} key={`${item.state}-${item.path ?? item.label}-${index}`}>
          <span>{item.stale ? "已过期" : stateLabels[item.state]}</span>
          <div>
            <b>{item.label}</b>
            {item.path && <code>{item.path}{item.line ? `:${item.line}` : ""}</code>}
            {item.detail && <small>{item.detail}</small>}
          </div>
        </article>
      ))}
    </section>
  );
}
