import type { DocumentMetadata, DocumentSnapshot } from "./types";

export function Relations({
  document,
  documents,
  onOpen,
}: {
  document: DocumentSnapshot;
  documents: Map<string, DocumentMetadata>;
  onOpen: (id: string) => void;
}) {
  const ids = [...new Set([...(document.prerequisites ?? []), ...(document.related ?? [])])];
  if (!ids.length) return null;
  return (
    <section className="relations">
      <p>继续学习</p><h2>把这张地图连起来</h2>
      <div>{ids.map((id) => { const related = documents.get(id); return related ? <button key={id} onClick={() => onOpen(id)}><span>{related.stage ?? "—"}</span><strong>{related.title}</strong><em>→</em></button> : null; })}</div>
    </section>
  );
}
