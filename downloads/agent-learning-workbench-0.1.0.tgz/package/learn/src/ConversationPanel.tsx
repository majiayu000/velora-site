import { useEffect, useRef, useState, type RefObject } from "react";
import { AnchorReference } from "./AnchorReference";
import { EvidenceList } from "./EvidenceList";
import { MarkdownView } from "./MarkdownView";
import { ProposalCard } from "./ProposalCard";
import { StructureProposalCard } from "./StructureProposalCard";
import { isDevelopmentWorkspace } from "./api";
import type { PositionedTextAnchor } from "./selection-anchor";
import type { EditTarget, DocumentSnapshot, Proposal, StructureProposal, Turn, Workspace } from "./types";

function formatTime(value: string): string {
  return new Intl.DateTimeFormat("zh-CN", { hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

export function ConversationPanel({
  workspace,
  home,
  chooseDocument,
  openSpace,
  openSettings,
  focusedTurnId,
  title,
  panelCollapsed,
  openDocumentPanel,
  turns,
  proposals,
  structureProposals,
  progress,
  streamingAnswers,
  document,
  articleRef,
  visibleBody,
  activeTurn,
  questionError,
  clearQuestionError,
  question,
  target,
  clearTarget,
  setQuestion,
  anchor,
  setAnchor,
  questionRef,
  proposalPreview,
  setProposalPreview,
  submitQuestion,
  cancelTurn,
  acceptProposal,
  rejectProposal,
  acceptStructureProposal,
  rejectStructureProposal,
  refreshEvidence,
  navigateHistory,
  openDocument,
}: {
  workspace: Workspace;
  home: boolean;
  chooseDocument: () => void;
  openSpace?: () => void;
  openSettings: () => void;
  focusedTurnId?: string;
  title: string;
  panelCollapsed: boolean;
  openDocumentPanel: () => void;
  turns: Turn[];
  proposals: Record<string, Proposal>;
  structureProposals: Record<string, StructureProposal>;
  progress: Record<string, string>;
  streamingAnswers: Record<string, string>;
  document?: DocumentSnapshot;
  articleRef: RefObject<HTMLDivElement | null>;
  visibleBody: string;
  activeTurn?: Turn;
  questionError?: string;
  clearQuestionError: () => void;
  question: string;
  target?: EditTarget;
  clearTarget: () => void;
  setQuestion: (value: string) => void;
  anchor?: PositionedTextAnchor;
  setAnchor: (value: PositionedTextAnchor | undefined) => void;
  questionRef: RefObject<HTMLTextAreaElement | null>;
  proposalPreview?: string;
  setProposalPreview: (value: string | undefined) => void;
  submitQuestion: () => Promise<void>;
  cancelTurn: (turn: Turn) => Promise<void>;
  acceptProposal: (proposal: Proposal) => void;
  rejectProposal: (proposal: Proposal) => void;
  acceptStructureProposal: (proposal: StructureProposal) => void;
  rejectStructureProposal: (proposal: StructureProposal) => void;
  refreshEvidence: (turn: Turn) => void;
  navigateHistory: () => void;
  openDocument: (id: string) => void;
}) {
  const streamRef = useRef<HTMLDivElement>(null);
  const followOutput = useRef(true);
  const [addOpen, setAddOpen] = useState(false);
  const addRef = useRef<HTMLDivElement>(null);
  const addTrigger = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!addOpen) return;
    const dismiss = (event: PointerEvent) => {
      if (event.target instanceof Node && !addRef.current?.contains(event.target)) setAddOpen(false);
    };
    window.document.addEventListener("pointerdown", dismiss);
    return () => window.document.removeEventListener("pointerdown", dismiss);
  }, [addOpen]);
  useEffect(() => {
    const stream = streamRef.current;
    if (stream && followOutput.current) stream.scrollTop = stream.scrollHeight;
  }, [turns, streamingAnswers, progress]);

  useEffect(() => {
    const stream = streamRef.current;
    if (!stream) return;
    if (!focusedTurnId) { followOutput.current = true; return; }
    const turn = [...stream.querySelectorAll<HTMLElement>("[data-turn-id]")].find(item => item.dataset.turnId === focusedTurnId);
    if (turn) {
      stream.scrollTop += turn.getBoundingClientRect().top - stream.getBoundingClientRect().top - 16;
      followOutput.current = false;
    }
  }, [focusedTurnId, document?.id]);

  return (
    <aside className={`conversation-panel ${home ? "is-home" : ""}`} aria-label="对话">
      {home && <div className="question-home-intro">
        <p className="home-verse">循着问题，看见知识的全貌。</p>
        <h1>笔记会慢慢变旧，<br />问题让它重新活过来。</h1>
        <p>你来问，Agent 去查、去讲，再把讲明白的部分写进文档。每问一次，文档就比昨天完整一点。</p>
      </div>}
      <div className="conversation-head">
        <div className="conversation-heading"><strong title={title}>{title}</strong><span>{workspace.site.title}</span></div>
        {panelCollapsed && <button className="reopen-document-button" onClick={openDocumentPanel} aria-label="打开文档面板"><span aria-hidden="true">▤</span> 文档</button>}
      </div>

      <div className="conversation-stream" ref={streamRef} aria-live="polite" onScroll={() => {
        const stream = streamRef.current;
        if (stream) followOutput.current = stream.scrollHeight - stream.scrollTop - stream.clientHeight < 72;
      }}>
        {!turns.length && (
          <div className="empty-conversation">
            <span className="conversation-symbol" aria-hidden="true">↗</span>
            <h2>从一个真问题开始</h2>
            <p>提出你想弄懂的问题，Agent 会查找已有知识，补充相关文档或建立新主题。</p>
          </div>
        )}
        {[...turns].sort((a, b) => a.createdAt.localeCompare(b.createdAt)).map((turn) => {
          const proposal = turn.proposalId ? proposals[turn.proposalId] : undefined;
          const structureProposal = turn.structureProposalId ? structureProposals[turn.structureProposalId] : undefined;
          const streamingAnswer = streamingAnswers[turn.id];
          return (
            <section className="turn-card" key={turn.id} data-turn-id={turn.id}>
              <div className="turn-question">
                <span>{turn.proposalId || turn.intent === "revise" ? "修订" : "提问"}</span>
                {turn.anchor && turn.documentId && (
                  <AnchorReference
                    anchor={turn.anchor}
                    documentId={turn.documentId}
                    currentDocumentId={document?.id}
                    currentHash={document?.contentHash}
                    articleRef={articleRef}
                    revisionKey={visibleBody}
                  />
                )}
                <p>{turn.question}</p>
              </div>
              {turn.duplicateOfTurnId && <p className="duplicate-question">这个问题之前问过；本回合会优先补足已有答案。</p>}
              {turn.status === "running" && <div className="agent-progress"><i /><span>{progress[turn.id] ?? "Agent 正在建立证据链"}</span></div>}
              {streamingAnswer && !turn.answerMarkdown && <MarkdownView body={streamingAnswer} className="answer-markdown streaming-answer" />}
              {turn.answerMarkdown && <MarkdownView body={turn.answerMarkdown} className="answer-markdown" />}
              {turn.evidence && <EvidenceList evidence={turn.evidence} onRefresh={() => refreshEvidence(turn)} />}
              {turn.status === "failed" && <p className="inline-error">{turn.error}</p>}
              {turn.status === "cancelled" && <p className="muted-note">本回合已取消。</p>}
              {!!turn.documentIds?.length && <div className="turn-documents" aria-label="本回合的文档">{turn.documentIds.map(id => <button className="composer-document-context" key={id} onClick={() => openDocument(id)}>查看文档 · {workspace.documents.find(item => item.id === id)?.title ?? id}</button>)}</div>}
              {!!turn.appliedEdits && <div className="muted-note">已写入 {turn.appliedEdits} 次段落修改{turn.status === "cancelled" || turn.status === "failed" ? "，已完成的修改仍保留。" : "。"} <button onClick={navigateHistory}>查看历史与撤销</button></div>}
              {proposal && document && (
                <ProposalCard
                  proposal={proposal}
                  automatic={turn.intent === "auto"}
                  onHistory={navigateHistory}
                  previewing={proposalPreview === proposal.id}
                  onPreview={() => setProposalPreview(proposalPreview === proposal.id ? undefined : proposal.id)}
                  onAccept={() => acceptProposal(proposal)}
                  onReject={() => rejectProposal(proposal)}
                  />
                )}
              {structureProposal && <StructureProposalCard proposal={structureProposal} onAccept={() => acceptStructureProposal(structureProposal)} onReject={() => rejectStructureProposal(structureProposal)} />}
              <time>{formatTime(turn.createdAt)}</time>
            </section>
          );
        })}
      </div>

      <div className="composer-wrap">
        {!workspace.runtime.available && <div className="runtime-unavailable"><strong>Agent Runtime 不可用</strong><span>{workspace.runtime.message ?? "请在本地设置中选择 Agent 并重新检测。"}</span>{isDevelopmentWorkspace && <button onClick={openSettings}>配置 AI 助手</button>}</div>}
        {questionError && <div className="composer-error">{questionError}<button onClick={clearQuestionError}>×</button></div>}
        {target && <div className="anchor-chip"><span>{target.from === target.to ? "在选定位置生成新段落" : "只修改选定段落，其他内容保持不变"}</span><button aria-label="取消局部修订" onClick={clearTarget}>×</button></div>}
        {anchor && <div className="anchor-chip"><span>“{anchor.exactQuote.slice(0, 72)}{anchor.exactQuote.length > 72 ? "…" : "”"}</span><button onClick={() => setAnchor(undefined)}>×</button></div>}
        <div className="composer">
          <textarea
            ref={questionRef}
            value={question}
            onChange={(event) => setQuestion(event.target.value)}
            onKeyDown={(event) => {
              if (event.nativeEvent.isComposing || event.nativeEvent.keyCode === 229) return;
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                void submitQuestion();
              }
            }}
            aria-label={home ? "你想弄懂什么" : "回复 Agent"}
            placeholder={!workspace.runtime.available ? "Runtime 不可用，阅读和编辑仍可继续" : home ? "你想弄懂什么？比如：vLLM 是怎么做连续批处理的" : "回复 Agent…"}
            disabled={!isDevelopmentWorkspace || !workspace.runtime.available || Boolean(activeTurn)}
            rows={home ? 3 : 2}
          />
          <div className="composer-context">
            <div className="context-menu-anchor" ref={addRef} onKeyDown={event => {
              if (event.key === "Escape") { setAddOpen(false); addTrigger.current?.focus(); }
            }}>
              <button ref={addTrigger} className="context-add-button" onClick={() => setAddOpen(!addOpen)} aria-label="添加资料" aria-expanded={addOpen} aria-controls="add-context-menu" title="添加资料"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="M12 5v14M5 12h14" /></svg></button>
              {addOpen && <div id="add-context-menu" className="surface-menu add-context-menu">
                <button onClick={() => { setAddOpen(false); chooseDocument(); }}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="M6 3h9l4 4v14H6zM14 3v5h5" /></svg><span><strong>选择学习文档</strong><small>围绕空间里的一篇文档继续提问</small></span></button>
                {openSpace && <button onClick={() => { setAddOpen(false); openSpace(); }}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="M3 7h6l2 2h10v10H3z" /></svg><span><strong>打开本地文件夹</strong><small>选择一个已初始化的学习空间</small></span></button>}
              </div>}
            </div>
            {home && openSpace && <button className="composer-space-button" onClick={openSpace} aria-label="选择学习空间" title={workspace.site.title}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="M3 7h6l2 2h10v10H3z" /></svg><span>{workspace.site.title}</span><span aria-hidden="true">⌄</span></button>}
            <span className="composer-runtime">{isDevelopmentWorkspace ? workspace.runtime.adapter.startsWith("codex") ? "Codex" : workspace.runtime.adapter === "claude-code" ? "Claude" : workspace.runtime.adapter : "只读"}</span>
            {home && document && <button className="composer-document-context" onClick={chooseDocument} title={document.title}>{document.title}</button>}
          </div>
          {activeTurn ? (
            <button className="send-button stop" onClick={() => void cancelTurn(activeTurn)} aria-label="停止 Agent">■</button>
          ) : (
            <button className="send-button" onClick={() => void submitQuestion()} disabled={!question.trim() || !isDevelopmentWorkspace || !workspace.runtime.available} aria-label="发送问题"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="M12 19V5M6 11l6-6 6 6" /></svg></button>
          )}
        </div>
        {home && <p className="home-storage-note">当前学习空间的文档保存在本地，都是普通的 Markdown 文件。</p>}
        <small>{isDevelopmentWorkspace ? "Enter 发送 · Shift + Enter 换行" : "当前为只读文档，可自由阅读与浏览"}</small>
      </div>
    </aside>
  );
}
