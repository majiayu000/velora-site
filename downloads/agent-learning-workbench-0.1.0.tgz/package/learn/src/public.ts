import { enhanceDiagrams } from "./diagrams";
import "./public.css";

enhanceDiagrams(document.body);

const search = document.querySelector<HTMLInputElement>(".public-search input");
if (search) {
  const articles = [...document.querySelectorAll<HTMLElement>("[data-public-article]")];
  const count = document.querySelector<HTMLElement>("[data-result-count]")!;
  const empty = document.querySelector<HTMLElement>(".search-empty")!;
  const filter = () => {
    const query = search.value.trim().toLocaleLowerCase();
    let matches = 0;
    for (const article of articles) {
      article.hidden = !article.dataset.search!.includes(query);
      if (!article.hidden) matches++;
    }
    count.textContent = String(matches);
    empty.hidden = matches > 0;
  };
  search.addEventListener("input", filter);
  search.addEventListener("keydown", event => { if (event.key === "Escape") { search.value = ""; filter(); } });
}
