import { useEffect, useState } from "react";
import { useSpaceApi } from "./api";
import type { AuditReceipt, DocumentMetadata, RevertPreview, Workspace } from "./types";

function describe(receipt: AuditReceipt): string {
  if (receipt.kind === "turn") return `${receipt.turn.intent === "revise" ? "修订" : "提问"}：${receipt.turn.question}`;
  if (receipt.kind === "decision") return `${receipt.decision === "accepted" ? "接受" : "拒绝"}${receipt.proposalKind === "structure" ? "结构" : "正文"}提案`;
  if (receipt.kind === "conversation") return `整理对话：${receipt.conversation.title}${receipt.conversation.archived ? "（已归档）" : ""}`;
  return receipt.summary;
}

export function HistoryPanel({ documents, onOpen, onReverted }: { documents: Map<string, DocumentMetadata>; onOpen: (id: string) => void; onReverted: (workspace: Workspace) => void }) {
  const api = useSpaceApi();
  const [receipts, setReceipts] = useState<AuditReceipt[]>([]);
  const [preview, setPreview] = useState<RevertPreview>();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const refresh = () => api.history().then(({ receipts: next }) => setReceipts(next)).catch((reason) => setError(reason instanceof Error ? reason.message : String(reason)));
  useEffect(() => { void refresh(); }, []);

  const inspect = async (id: string) => {
    setError(undefined);
    try { setPreview(await api.previewRevert(id)); }
    catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)); }
  };
  const revert = async () => {
    if (!preview?.canApply || !window.confirm("这会创建一个新的 Git 提交来撤销该次修改。确定继续吗？")) return;
    setBusy(true);
    try {
      const result = await api.revertReceipt(preview.receiptId);
      onReverted(result.workspace);
      setPreview(undefined);
      await refresh();
    } catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)); }
    finally { setBusy(false); }
  };

  const days = new Map<string, AuditReceipt[]>();
  for (const receipt of [...receipts].sort((a, b) => b.at.localeCompare(a.at))) {
    const at = new Date(receipt.at);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    const date = at.toDateString() === today.toDateString() ? "今天" : at.toDateString() === yesterday.toDateString() ? "昨天" : at.toLocaleDateString("zh-CN", { year: "numeric", month: "long", day: "numeric" });
    days.set(date, [...(days.get(date) ?? []), receipt]);
  }

  return <div className="history-surface">
    <header><h1>生长记录</h1><p>这个空间里每一次提问和每一次改动。回看走过的路，也可以从这里撤销修改。</p></header>
    {error && <div className="map-warning" role="alert">{error}</div>}
    <div className={`history-layout ${preview ? "has-preview" : ""}`}>
      <section className="receipt-list" aria-label="学习记录">
        {receipts.length === 0 && <div className="empty-state"><strong>每次理解，都从这里留下痕迹。</strong><p>提一个问题，或修改一段文档，你的学习记录就会出现在这里。</p></div>}
        {[...days].map(([day, items]) => <section className="history-day" key={day}>
          <h2>{day}</h2>
          {items.map(receipt => <article key={receipt.id} className={`receipt-${receipt.kind}`}>
            <time dateTime={receipt.at}>{new Date(receipt.at).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })}</time>
            <span className="receipt-mark" aria-label={receipt.kind === "turn" ? "提问" : receipt.kind === "mutation" ? "修改" : receipt.kind === "conversation" ? "整理对话" : "审核"}>{receipt.kind === "turn" ? "?" : receipt.kind === "mutation" ? "✎" : receipt.kind === "conversation" ? "⋯" : "✓"}</span>
            <div className="receipt-content">
              {receipt.kind === "turn" ? <button className="receipt-title" disabled={!receipt.turn.documentId} onClick={() => { if (receipt.turn.documentId) onOpen(receipt.turn.documentId); }}>{receipt.turn.question}</button> : <strong>{describe(receipt)}</strong>}
              {receipt.kind === "turn" && <small>{receipt.turn.documentId ? documents.get(receipt.turn.documentId)?.title ?? "学习文档" : "尚未关联文档"}</small>}
              {receipt.kind === "mutation" && <><small>{receipt.files.join(" · ")}</small>{receipt.git.status === "committed" ? <><code className="receipt-commit">{receipt.git.commit.slice(0, 12)}</code><button className="text-button" onClick={() => void inspect(receipt.id)}>审核撤销</button></> : <small>{receipt.git.message}</small>}</>}
            </div>
          </article>)}
        </section>)}
      </section>
      {preview && <aside className="revert-preview">
        <header><h2>撤销预览</h2><button aria-label="关闭撤销预览" onClick={() => setPreview(undefined)}>×</button></header><small>{preview.files.join(" · ")}</small>
        {preview.conflict && <div className="map-warning">{preview.conflict}</div>}
        <pre>{preview.patch || "没有可展示的补丁"}</pre>
        <button className="danger-button" disabled={!preview.canApply || busy} onClick={() => void revert()}>{busy ? "撤销中…" : "确认并创建反向提交"}</button>
      </aside>}
    </div>
  </div>;
}
