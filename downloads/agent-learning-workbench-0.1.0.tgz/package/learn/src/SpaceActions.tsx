import { useEffect, useRef, useState } from "react";
import { isDevelopmentWorkspace, useSpaceApi } from "./api";
import type { Workspace } from "./types";

export function SpaceMenu({ workspace, root, connected, onOpen, onDocuments, onExport, onSettings }: {
  workspace: Workspace;
  root?: string;
  connected: boolean;
  onOpen?: () => void;
  onDocuments: () => void;
  onExport: () => void;
  onSettings: () => void;
}) {
  const [open, setOpen] = useState(false);
  const container = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!open) return;
    const dismiss = (event: PointerEvent) => {
      if (event.target instanceof Node && !container.current?.contains(event.target)) setOpen(false);
    };
    window.document.addEventListener("pointerdown", dismiss);
    return () => window.document.removeEventListener("pointerdown", dismiss);
  }, [open]);
  return <div className="space-menu" ref={container} onKeyDown={event => {
    if (event.key === "Escape") { setOpen(false); trigger.current?.focus(); }
  }}>
    <button ref={trigger} className="sidebar-connection" aria-label="学习空间菜单" title="更多学习空间操作" aria-expanded={open} aria-controls="local-space-menu" onClick={() => setOpen(!open)}>
      <span className="sidebar-avatar">澜</span>
      <span className="sidebar-profile"><strong>{isDevelopmentWorkspace ? "本地工作台" : "只读学习站点"}</strong><span className={`connection ${connected ? "is-online" : ""}`}><i />{isDevelopmentWorkspace ? connected ? "已连接" : "正在重连" : "静态只读"}</span></span>
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="19" cy="12" r="1.5" /></svg>
    </button>
    {open && <div id="local-space-menu" className="surface-menu local-space-menu">
      <header><strong>{workspace.site.title}</strong><small title={root}>{root || "只读文档"}</small></header>
      <button onClick={() => { setOpen(false); trigger.current?.focus(); onSettings(); }}>{isDevelopmentWorkspace ? "本地设置" : "空间信息"}</button>
      <div className="menu-divider" />
      {isDevelopmentWorkspace && <div className="space-runtime-info"><span>Agent</span><strong>{workspace.runtime.adapter}</strong><small>{workspace.runtime.available ? "可用" : "不可用"}</small></div>}
      <button onClick={() => { setOpen(false); onDocuments(); }}>浏览全部文档 <span>{workspace.documents.length} 篇</span></button>
      {onOpen && <button onClick={() => { setOpen(false); onOpen(); }}>打开其他学习空间 <span>↗</span></button>}
      <div className="menu-divider" />
      <button onClick={() => { setOpen(false); trigger.current?.focus(); onExport(); }}>导出全部为 Markdown <span>↗</span></button>
      <p>{isDevelopmentWorkspace ? "无需账号，文档保存在本地文件夹中" : "导出的学习站点仅供阅读"}</p>
    </div>}
  </div>;
}

export function ExportSpaceDialog({ workspace, onClose }: { workspace: Workspace; onClose: () => void }) {
  const api = useSpaceApi();
  const dialog = useRef<HTMLDialogElement>(null);
  const [exporting, setExporting] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  useEffect(() => { dialog.current?.showModal(); }, []);
  const copyLink = async () => {
    setError("");
    try { await navigator.clipboard.writeText(window.location.href); setMessage("本地链接已复制"); }
    catch (reason) { setError(`复制失败，请手动复制下方链接：${reason instanceof Error ? reason.message : String(reason)}`); }
  };
  const exportMarkdown = async () => {
    setExporting(true);
    setError("");
    setMessage("");
    try {
      const documents = await Promise.all(workspace.documents.map(item => "body" in item ? Promise.resolve(item) : api.document(item.id)));
      const markdown = [`# ${workspace.site.title}`, ...documents.map(item => `<!-- ${item.path} -->\n\n${item.body}`)].join("\n\n---\n\n");
      const url = URL.createObjectURL(new Blob([markdown], { type: "text/markdown;charset=utf-8" }));
      const link = window.document.createElement("a");
      link.href = url;
      link.download = `${workspace.site.title.replace(/[\\/:*?"<>|]/g, "-")}.md`;
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setMessage(`已导出 ${documents.length} 篇文档，不包含对话记录`);
    } catch (reason) { setError(`导出失败：${reason instanceof Error ? reason.message : String(reason)}`); }
    finally { setExporting(false); }
  };
  return <dialog ref={dialog} className="export-dialog" aria-labelledby="export-space-title" onClose={onClose} onClick={event => {
    if (event.target === event.currentTarget) {
      const bounds = event.currentTarget.getBoundingClientRect();
      if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) event.currentTarget.close();
    }
  }}>
    <header><h2 id="export-space-title">导出「{workspace.site.title}」</h2><button className="icon-button" aria-label="关闭导出" onClick={() => dialog.current?.close()}>×</button></header>
    <p>导出空间中已保存的文档，不包含未保存草稿、对话记录或知识地图的关系数据。</p>
    <section className="export-option"><span className="export-option-icon" aria-hidden="true">↓</span><div><h3>导出为 Markdown</h3><p>共 {workspace.documents.length} 篇文档，合并为一个文件，可发送给其他人。</p></div><button className="primary-button" disabled={exporting || !workspace.documents.length} onClick={() => void exportMarkdown()}>{exporting ? "导出中…" : "导出文档"}</button></section>
    <section className="export-link-section"><h3>本地链接</h3><p>仅适用于这台电脑。向其他人分享内容，请导出文档。</p><div><input aria-label="本地链接" readOnly value={window.location.href} onFocus={event => event.target.select()} /><button onClick={() => void copyLink()}>复制链接</button></div></section>
    {message && <p className="export-message" role="status">{message}</p>}
    {error && <p className="dialog-error" role="alert">{error}</p>}
  </dialog>;
}
