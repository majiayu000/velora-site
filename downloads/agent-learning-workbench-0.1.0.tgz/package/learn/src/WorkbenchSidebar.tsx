import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { createSpaceApi, isDevelopmentWorkspace } from "./api";
import type { ConversationMetadata, ConversationSummary, LearningSpaceSummary } from "./types";

const EXPANSION_KEY = "learn-workbench:sidebar-expanded";
function readExpansion(): Record<string, boolean> {
  try { return JSON.parse(localStorage.getItem(EXPANSION_KEY) ?? "{}") ?? {}; }
  catch { return {}; }
}
function dateLabel(value: string) {
  const date = new Date(value);
  return date.toDateString() === new Date().toDateString() ? "今天" : date.toLocaleDateString("zh-CN", { month: "numeric", day: "numeric" });
}
function Folder() {
  return <svg className="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10H3Z" /></svg>;
}
function ActionMenu({ label, children }: { label: string; children: (close: () => void) => ReactNode }) {
  const [open, setOpen] = useState(false);
  const container = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const close = () => { setOpen(false); trigger.current?.focus(); };
  useEffect(() => {
    if (!open) return;
    const dismiss = (event: PointerEvent) => { if (event.target instanceof Node && !container.current?.contains(event.target)) setOpen(false); };
    document.addEventListener("pointerdown", dismiss);
    return () => document.removeEventListener("pointerdown", dismiss);
  }, [open]);
  return <div className="sidebar-action-menu" ref={container} onKeyDown={event => { if (event.key === "Escape") { event.stopPropagation(); close(); } }}>
    <button className="icon-button sidebar-more" ref={trigger} aria-label={label} aria-expanded={open} onClick={() => setOpen(!open)}>⋯</button>
    {open && <div className="surface-menu sidebar-popover" aria-label={label}>{children(close)}</div>}
  </div>;
}

function ConversationList({ space, active, enabled, query, archived, selectedId, refreshKey, onOpen, onLoaded }: {
  space: LearningSpaceSummary; active: boolean; enabled: boolean; query: string; archived: boolean;
  selectedId?: string; refreshKey: string;
  onOpen: (spaceId: string, conversation: ConversationSummary) => void;
  onLoaded: (items: ConversationSummary[]) => void;
}) {
  const [items, setItems] = useState<ConversationSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>();
  const [limit, setLimit] = useState(8);
  const [renaming, setRenaming] = useState<string>();
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);
  const generation = useRef(0);
  const loaded = useRef(onLoaded);
  loaded.current = onLoaded;
  const load = useCallback(async () => {
    const request = ++generation.current;
    try {
      const { conversations } = await createSpaceApi(space.id).conversations(query);
      if (request !== generation.current) return;
      setItems(conversations); setError(undefined);
      if (active) loaded.current(conversations);
    } catch (reason) { if (request === generation.current) setError(reason instanceof Error ? reason.message : String(reason)); }
    finally { if (request === generation.current) setLoading(false); }
  }, [space.id, query, active]);
  useEffect(() => {
    if (!enabled || !isDevelopmentWorkspace) return;
    const timer = window.setTimeout(() => void load(), query ? 180 : 0);
    return () => { clearTimeout(timer); generation.current++; };
  }, [enabled, load, active ? refreshKey : ""]);
  useEffect(() => { setLimit(8); }, [query, archived]);
  useEffect(() => {
    if (!enabled || !isDevelopmentWorkspace) return;
    let timer: number;
    const refresh = () => { clearTimeout(timer); timer = window.setTimeout(() => void load(), 100); };
    window.addEventListener("focus", refresh);
    return () => { clearTimeout(timer); window.removeEventListener("focus", refresh); };
  }, [enabled, active, space.id, load]);
  useEffect(() => {
    // Keep one event stream for the open space; other groups only poll known running turns.
    if (!enabled || active || !items.some(item => item.status === "running")) return;
    const timer = window.setTimeout(() => void load(), 3000);
    return () => clearTimeout(timer);
  }, [enabled, active, items, load]);
  const update = async (id: string, patch: Partial<ConversationMetadata>) => {
    setBusy(true); setError(undefined);
    try {
      const { conversation } = await createSpaceApi(space.id).updateConversation(id, patch);
      if (active) loaded.current([conversation]);
      setRenaming(undefined);
      await load();
    } catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)); }
    finally { setBusy(false); }
  };
  const visible = items.filter(item => item.archived === archived);
  useEffect(() => {
    if (!active || !selectedId) return;
    const index = items.filter(item => item.archived === archived).findIndex(item => item.id === selectedId);
    if (index >= 0) setLimit(current => Math.max(current, Math.ceil((index + 1) / 8) * 8));
  }, [items, active, selectedId, archived]);
  if (!isDevelopmentWorkspace) return null;
  return <div className="conversation-list" aria-label={`${space.title} 的${archived ? "已归档" : ""}对话`}>
    {error && <div className="sidebar-error" role="alert">{error}<button onClick={() => void load()}>重试</button></div>}
    {loading ? <p className="sidebar-empty" role="status">正在读取对话…</p> : <>
      {visible.slice(0, query ? visible.length : limit).map(item => <div className={`sidebar-conversation ${active && selectedId === item.id ? "is-active" : ""}`} key={item.id}>
        {renaming === item.id ? <form className="conversation-rename" onSubmit={event => { event.preventDefault(); void update(item.id, { title }); }} onKeyDown={event => { if (event.key === "Escape") setRenaming(undefined); }}>
          <input aria-label="对话名称" autoFocus maxLength={200} value={title} onChange={event => setTitle(event.target.value)} />
          <button disabled={busy || !title.trim()} type="submit">保存</button><button disabled={busy} type="button" onClick={() => setRenaming(undefined)}>取消</button>
        </form> : <>
          <button className="conversation-link" title={item.title} aria-current={active && selectedId === item.id ? "page" : undefined} onClick={() => onOpen(space.id, item)}>
            <span className="conversation-status" title={item.status === "running" ? "正在生成" : item.status === "failed" ? "生成失败" : item.pinned ? "已置顶" : undefined} aria-label={item.status === "running" ? "正在生成" : item.status === "failed" ? "生成失败" : item.pinned ? "已置顶" : undefined}>{item.status === "running" ? "◌" : item.status === "failed" ? "!" : item.pinned ? "◆" : ""}</span>
            <span className="conversation-title">{item.title}</span><time dateTime={item.updatedAt}>{dateLabel(item.updatedAt)}</time>
          </button>
          <ActionMenu label={`对话菜单：${item.title}`}>{close => <>
            <button disabled={busy} onClick={() => { close(); setTitle(item.title); setRenaming(item.id); }}>重命名</button>
            <button disabled={busy} onClick={() => { close(); void update(item.id, { pinned: !item.pinned }); }}>{item.pinned ? "取消置顶" : "置顶对话"}</button>
            <button disabled={busy} onClick={() => { close(); void update(item.id, { archived: !item.archived }); }}>{item.archived ? "恢复对话" : "归档对话"}</button>
          </>}</ActionMenu>
        </>}
      </div>)}
      {!visible.length && !error && <p className="sidebar-empty">{query ? "没有匹配的对话" : archived ? "没有已归档对话" : "还没有对话"}</p>}
      {!query && visible.length > limit && <button className="sidebar-show-more" onClick={() => setLimit(value => value + 8)}>查看更多（{visible.length - limit}）</button>}
    </>}
  </div>;
}

export function WorkbenchSidebar({ spaces, activeSpaceId, selectedId, refreshKey, onHome, onNew, onAddSpace, onCloseSpace, onNavigate, onConversation, onLoaded, onSearchDocuments, footer }: {
  spaces: LearningSpaceSummary[]; activeSpaceId: string; selectedId?: string; refreshKey: string;
  onHome: () => void; onNew: () => void; onAddSpace?: () => void; onCloseSpace?: (id: string) => void;
  onNavigate: (id: string, destination: string) => void;
  onConversation: (id: string, conversation: ConversationSummary) => void;
  onLoaded: (items: ConversationSummary[]) => void; onSearchDocuments: () => void; footer: ReactNode;
}) {
  const [expanded, setExpanded] = useState(readExpansion);
  const [searching, setSearching] = useState(false);
  const [query, setQuery] = useState("");
  const [archived, setArchived] = useState(false);
  const [filterSpace, setFilterSpace] = useState<string>();
  const toggle = (id: string) => setExpanded(current => {
    const next = { ...current, [id]: !(current[id] ?? true) };
    localStorage.setItem(EXPANSION_KEY, JSON.stringify(next));
    return next;
  });
  const resetSearch = () => { setSearching(false); setQuery(""); setArchived(false); setFilterSpace(undefined); };
  return <aside className="workspace-sidebar" aria-label="学习空间与对话">
    <header>
      <button className="workbench-mark" role="tab" aria-selected="false" onClick={onHome}><span>澜</span><strong>观澜</strong></button>
      <button className="icon-button" aria-label={isDevelopmentWorkspace ? "搜索对话" : "搜索文档"} title={isDevelopmentWorkspace ? "搜索所有空间的对话" : "搜索文档"} onClick={() => isDevelopmentWorkspace ? setSearching(value => !value) : onSearchDocuments()}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg></button>
    </header>
    <button className="new-question-button" onClick={onNew}><span>＋</span>新问题<kbd>⌘N</kbd></button>
    {searching && <div className="sidebar-search">
      <input type="search" aria-label="搜索所有空间的对话" placeholder="搜索对话标题和正文" autoFocus value={query} onChange={event => setQuery(event.target.value)} onKeyDown={event => { if (event.key === "Escape") resetSearch(); }} />
      <div><label><input type="checkbox" checked={archived} onChange={event => setArchived(event.target.checked)} />已归档</label><button onClick={resetSearch}>返回列表</button></div>
      {filterSpace && <button onClick={() => setFilterSpace(undefined)}>搜索所有空间</button>}
    </div>}
    <div className="sidebar-section-title"><span>{searching ? archived ? "已归档对话" : "搜索对话" : "学习空间"}</span>{onAddSpace && <button className="icon-button" aria-label="打开学习空间" title="添加学习空间（打开文件夹）" onClick={onAddSpace}>＋</button>}</div>
    <nav className="sidebar-spaces" aria-label="学习空间">
      {spaces.filter(space => !searching || !filterSpace || space.id === filterSpace).map(space => {
        const open = searching || (expanded[space.id] ?? true);
        const active = space.id === activeSpaceId;
        return <section className="sidebar-space" key={space.id}>
          <div className={`sidebar-space-row ${active ? "is-current-space" : ""}`}>
            <button className="icon-button space-disclosure" aria-label={`${open ? "收起" : "展开"} ${space.title} 的对话`} aria-expanded={open} aria-controls={`sidebar-conversations-${space.id}`} disabled={searching} onClick={() => toggle(space.id)}><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="m9 5 7 7-7 7" /></svg></button>
            <button className="space-label" title={space.root} aria-current={active ? "true" : undefined} onClick={() => onNavigate(space.id, "documents")}><Folder /><span>{space.title}</span></button>
            {isDevelopmentWorkspace && <button className="icon-button space-new-question" aria-label={`在 ${space.title} 中新建对话`} title="新建对话" onClick={() => onNavigate(space.id, "new")}>＋</button>}
            {isDevelopmentWorkspace && <ActionMenu label={`空间菜单：${space.title}`}>{close => <>
              <button onClick={() => { close(); onNavigate(space.id, "documents"); }}>全部文档</button>
              <button onClick={() => { close(); setFilterSpace(space.id); setQuery(""); setArchived(true); setSearching(true); }}>已归档对话</button>
              {onCloseSpace && <button onClick={() => { close(); onCloseSpace(space.id); }}>关闭学习空间</button>}
            </>}</ActionMenu>}
          </div>
          <div id={`sidebar-conversations-${space.id}`} className="sidebar-conversations" hidden={!open}>
            {!searching && <button className="space-documents-link" onClick={() => onNavigate(space.id, "documents")}><span aria-hidden="true">▤</span>全部文档</button>}
            <ConversationList space={space} active={active} enabled={open} query={searching ? query : ""} archived={searching && archived} selectedId={selectedId} refreshKey={refreshKey} onOpen={onConversation} onLoaded={onLoaded} />
          </div>
        </section>;
      })}
    </nav>
    <footer>{footer}</footer>
  </aside>;
}
