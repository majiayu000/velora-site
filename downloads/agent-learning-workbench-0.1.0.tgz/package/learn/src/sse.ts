import type { LearnEvent } from "./types";

export class SseDecoder {
  private buffer = "";

  push(chunk: string): LearnEvent[] {
    this.buffer += chunk.replaceAll("\r\n", "\n");
    const events: LearnEvent[] = [];
    while (this.buffer.includes("\n\n")) {
      const boundary = this.buffer.indexOf("\n\n");
      const packet = this.buffer.slice(0, boundary);
      this.buffer = this.buffer.slice(boundary + 2);
      const data = packet
        .split("\n")
        .filter((line) => line.startsWith("data:"))
        .map((line) => line.slice(5).trimStart())
        .join("\n");
      if (data) events.push(JSON.parse(data) as LearnEvent);
    }
    return events;
  }
}

type SubscriptionOptions = {
  apiBase: string;
  token: () => string;
  refreshSession: () => Promise<void>;
  after: number;
  onEvent: (event: LearnEvent) => void;
  onConnection: (connected: boolean) => void;
  fetch?: typeof globalThis.fetch;
  retryMilliseconds?: number;
};

function isAbort(error: unknown): boolean {
  return error instanceof Error && error.name === "AbortError";
}

function wait(milliseconds: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve) => {
    if (signal.aborted) return resolve();
    const timeout = setTimeout(finish, milliseconds);
    function finish() {
      clearTimeout(timeout);
      signal.removeEventListener("abort", finish);
      resolve();
    }
    signal.addEventListener("abort", finish, { once: true });
  });
}

export function subscribeEventStream(options: SubscriptionOptions): () => void {
  const fetcher = options.fetch ?? globalThis.fetch;
  const controller = new AbortController();
  let stopped = false;
  let lastSequence = options.after;
  let sessionToken = options.token();

  const connect = async () => {
    while (!stopped) {
      try {
        const token = options.token();
        if (token !== sessionToken) { lastSequence = 0; sessionToken = token; }
        const response = await fetcher(`${options.apiBase}/events?after=${lastSequence}`, {
          headers: { Authorization: `Bearer ${token}` },
          signal: controller.signal,
        });
        if (response.status === 401) {
          await response.body?.cancel(); await options.refreshSession();
          throw new Error("Event session renewed");
        }
        if (!response.ok || !response.body) throw new Error(`Event stream failed: ${response.status}`);
        options.onConnection(true);
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        const parser = new SseDecoder();
        while (!stopped) {
          const { value, done } = await reader.read();
          if (done) break;
          for (const event of parser.push(decoder.decode(value, { stream: true }))) {
            if (event.sequence <= lastSequence) continue;
            lastSequence = event.sequence;
            options.onEvent(event);
          }
        }
        if (!stopped) {
          options.onConnection(false);
          await wait(options.retryMilliseconds ?? 1200, controller.signal);
        }
      } catch (error) {
        if (stopped || isAbort(error)) return;
        options.onConnection(false);
        await wait(options.retryMilliseconds ?? 1200, controller.signal);
      }
    }
  };
  void connect();
  return () => {
    stopped = true;
    controller.abort();
  };
}
