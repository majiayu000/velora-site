import { connectFlowChart } from "../../src/adapters/markdown/flowcharts";

/** Enhance figures; Markdown remains the only persisted source. */
export function enhanceDiagrams(root: HTMLElement): () => void {
  const cleanups = [...root.querySelectorAll<HTMLElement>(".learn-diagram")].map((figure) => {
    const viewport = figure.querySelector<HTMLElement>(".diagram-viewport")!;
    const svg = viewport.querySelector("svg")!;
    const canvas = viewport.querySelector<HTMLElement>(".flow-canvas");
    const flow = canvas ? connectFlowChart(figure) : undefined;
    const nodesRoot = canvas || svg;
    const output = figure.querySelector("output")!;
    const description = figure.querySelector<HTMLElement>(".diagram-description")!;
    const overview = description.textContent;
    const expandButton = figure.querySelector<HTMLButtonElement>('[data-diagram-action="expand"]')!;
    const nativeWidth = canvas ? 960 : svg.viewBox.baseVal.width;
    let fit = true;
    let width = viewport.clientWidth;
    let canvasWidth = width;
    let expanded = false;
    let beforeExpand = { fit, width, canvasWidth };
    let previousFocus: HTMLElement | null = null;
    const paint = () => {
      if (fit) { width = viewport.clientWidth; canvasWidth = width; }
      if (canvas) {
        canvas.style.width = `${canvasWidth}px`;
        canvas.style.setProperty("zoom", String(width / canvasWidth));
        flow!.redraw();
      } else svg.style.width = `${width}px`;
      output.textContent = `${Math.round(width / (canvas ? canvasWidth : nativeWidth) * 100)}%`;
    };
    const close = () => {
      if (!expanded) return;
      expanded = false;
      figure.classList.remove("is-expanded");
      figure.removeAttribute("role");
      figure.removeAttribute("aria-modal");
      figure.removeAttribute("aria-label");
      ({ fit, width, canvasWidth } = beforeExpand);
      expandButton.textContent = "展开阅读";
      expandButton.setAttribute("aria-expanded", "false");
      paint();
      if (previousFocus?.isConnected) previousFocus.focus();
    };
    const onClick = (event: MouseEvent) => {
      const target = event.target as Element;
      const action = target.closest<HTMLButtonElement>("[data-diagram-action]")?.dataset.diagramAction;
      if (action === "expand") {
        if (expanded) close();
        else {
          previousFocus = document.activeElement as HTMLElement;
          beforeExpand = { fit, width, canvasWidth };
          expanded = true;
          figure.classList.add("is-expanded");
          figure.setAttribute("role", "dialog");
          figure.setAttribute("aria-modal", "true");
          figure.setAttribute("aria-label", figure.querySelector("figcaption")?.textContent || "图表阅读");
          expandButton.textContent = "收起 · Esc";
          expandButton.setAttribute("aria-expanded", "true");
          fit = false;
          width = Math.max(nativeWidth, viewport.clientWidth);
          canvasWidth = width;
          paint();
          viewport.focus();
        }
      } else if (action) {
        fit = action === "fit";
        if (!fit) {
          // Fitted small SVGs can already exceed their native size. Resizing the
          // panel must also never make + shrink the image or - enlarge it.
          const maximum = Math.max(nativeWidth * 4, viewport.clientWidth * 4, width);
          width = action === "in" ? Math.min(maximum, width * 1.25) : Math.max(Math.min(120, width), width * .8);
        }
        paint();
        if (fit) { viewport.scrollLeft = 0; viewport.scrollTop = 0; }
      }
      const node = target.closest<HTMLElement | SVGElement>("[data-node]");
      if (node) {
        const selected = !node.classList.contains("is-selected");
        const id = node.dataset.node;
        for (const candidate of nodesRoot.querySelectorAll("[data-node]")) {
          candidate.classList.toggle("is-selected", selected && candidate === node);
          candidate.setAttribute("aria-pressed", String(selected && candidate === node));
        }
        for (const edge of svg.querySelectorAll<SVGElement>("path[data-from][data-to]")) {
          const connected = edge.dataset.from === id || edge.dataset.to === id;
          edge.classList.toggle("is-muted", selected && !connected);
          edge.classList.toggle("is-connected", selected && connected);
        }
        description.textContent = selected ? node.querySelector("desc, .flow-node-detail")?.textContent || node.querySelector("title")?.textContent || overview : overview;
      }
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape" && expanded) { event.preventDefault(); close(); }
      const target = event.target as Element;
      if ((event.key === "Enter" || event.key === " ") && target.matches("[data-node]") && target.tagName !== "BUTTON") {
        event.preventDefault();
        target.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      }
      if (event.key === "Tab" && expanded) {
        const focusable = [...figure.querySelectorAll<HTMLElement>("button, [tabindex='0']")];
        const first = focusable[0], last = focusable.at(-1)!;
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    for (const node of svg.querySelectorAll("[data-node]")) {
      node.setAttribute("tabindex", "0");
      node.setAttribute("role", "button");
      node.setAttribute("aria-pressed", "false");
      node.setAttribute("aria-label", node.querySelector("title")?.textContent || node.getAttribute("data-node")!);
    }
    figure.addEventListener("click", onClick);
    figure.addEventListener("keydown", onKey);
    const observer = new ResizeObserver(paint);
    observer.observe(viewport);
    paint();
    return () => {
      observer.disconnect();
      flow?.dispose();
      figure.removeEventListener("click", onClick);
      figure.removeEventListener("keydown", onKey);
      close();
    };
  });
  return () => cleanups.forEach((cleanup) => cleanup());
}
