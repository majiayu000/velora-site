import type { LearningSpaceSummary } from "./types";

export type TabsState = {
  tabs: string[];
  active: string | null;
};

export type StoredWorkbench = TabsState & {
  spaces: LearningSpaceSummary[];
};

function normalizeTabs(value: unknown, validIds?: ReadonlySet<string>): TabsState {
  if (!value || typeof value !== "object" || Array.isArray(value)) return { tabs: [], active: null };
  const record = value as Record<string, unknown>;
  const tabs = Array.isArray(record.tabs)
    ? [...new Set(record.tabs.filter((id): id is string => typeof id === "string" && (!validIds || validIds.has(id))))]
    : [];
  const requestedActive = typeof record.active === "string" ? record.active : null;
  return {
    tabs,
    active: requestedActive && tabs.includes(requestedActive) ? requestedActive : tabs[0] ?? null,
  };
}

function openTab(state: TabsState, id: string): TabsState {
  return {
    tabs: state.tabs.includes(id) ? state.tabs : [...state.tabs, id],
    active: id,
  };
}

function closeTab(state: TabsState, id: string): TabsState {
  const index = state.tabs.indexOf(id);
  if (index < 0) return state;
  const tabs = state.tabs.filter((candidate) => candidate !== id);
  if (state.active !== id) return { tabs, active: state.active };
  return { tabs, active: tabs[index] ?? tabs[index - 1] ?? null };
}

export function normalizeSpaceTabs(value: unknown, availableSpaceIds: readonly string[]): TabsState {
  return normalizeTabs(value, new Set(availableSpaceIds));
}

export function normalizeStoredWorkbench(value: unknown): StoredWorkbench {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return { spaces: [], tabs: [], active: null };
  }
  const record = value as Record<string, unknown>;
  const roots = new Set<string>();
  const ids = new Set<string>();
  const spaces = Array.isArray(record.spaces)
    ? record.spaces.flatMap((candidate): LearningSpaceSummary[] => {
      if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) return [];
      const space = candidate as Record<string, unknown>;
      if (typeof space.id !== "string" || typeof space.root !== "string" || typeof space.title !== "string") return [];
      if (roots.has(space.root) || ids.has(space.id)) return [];
      roots.add(space.root);
      ids.add(space.id);
      return [{
        id: space.id,
        root: space.root,
        title: space.title,
        ...(typeof space.description === "string" ? { description: space.description } : {}),
      }];
    })
    : [];
  return { spaces, ...normalizeTabs(record, ids) };
}

export function openSpaceTab(state: TabsState, spaceId: string): TabsState {
  return openTab(state, spaceId);
}

export function closeSpaceTab(state: TabsState, spaceId: string): TabsState {
  return closeTab(state, spaceId);
}

export function normalizeDocumentTabs(value: unknown, availableDocumentIds: readonly string[]): TabsState {
  return normalizeTabs(value, new Set(availableDocumentIds));
}

export function openDocumentTab(state: TabsState, documentId: string, availableDocumentIds: readonly string[]): TabsState {
  if (!availableDocumentIds.includes(documentId)) return state;
  return openTab(state, documentId);
}

export function closeDocumentTab(state: TabsState, documentId: string): TabsState {
  return closeTab(state, documentId);
}
