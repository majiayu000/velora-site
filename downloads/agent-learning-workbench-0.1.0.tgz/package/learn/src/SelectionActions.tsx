import type { RefObject } from "react";
import type { PositionedTextAnchor } from "./selection-anchor";

export function SelectionActions({ anchor, edit, questionRef, setQuestion }: {
  anchor: PositionedTextAnchor;
  edit: boolean;
  questionRef: RefObject<HTMLTextAreaElement | null>;
  setQuestion: (question: string) => void;
}) {
  if (edit) return null;
  const choose = (intent: "answer" | "revise", question?: string) => {
    setQuestion(question ?? (intent === "revise" ? "请修改选中的内容：" : "请解释选中的内容："));
    questionRef.current?.focus();
  };
  return (
    <div className="selection-menu" style={{ left: anchor.x, top: anchor.y }}>
      <button onClick={() => choose("answer")}>提问</button>
      <button onClick={() => choose("revise")}>修订这段</button>
      <button onClick={() => choose("answer", "请根据工作台提供的学习文档和用户材料核对这段内容的依据，区分已确认信息、推断与未知。")}>核对依据</button>
      <button onClick={() => choose("revise", "请扩展这段内容，补足原理、边界和一个具体例子。")}>展开</button>
      <button onClick={() => choose("revise", "请把这段内容改成一个可执行的单变量学习实验，并使用 experiment 学习块。")}>创建实验</button>
    </div>
  );
}
