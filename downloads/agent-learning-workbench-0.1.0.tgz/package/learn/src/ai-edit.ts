import type { DocumentEditEvent, DocumentEditOperation } from "../../src/ports/collaboration-port";
import type { LearnEvent, Turn } from "./types";

export type AiEdit = {
  editId: string;
  documentId: string;
  turnId: string;
  operation: DocumentEditOperation;
  markdown: string;
  revision?: number;
  blockIds?: string[];
};
export type AiEdits = Record<string, AiEdit>;

export function updateAiEdits(edits: AiEdits, event: LearnEvent): AiEdits {
  const payload = event.payload;
  if (event.type === "turn.started") {
    const turn = payload.turn as Turn;
    const target = turn.target;
    if (!turn.documentId || turn.status !== "running" || turn.intent !== "auto" || !target?.blockId || !target.ifHash || Object.values(edits).some(edit => edit.turnId === turn.id)) return edits;
    const editId = `waiting:${turn.id}`;
    return { ...edits, [editId]: {
      editId, documentId: turn.documentId, turnId: turn.id, markdown: "",
      operation: target.from === target.to ? { type: "insert", after: target.blockId } : { type: "replace", blockId: target.blockId, ifHash: target.ifHash },
    } };
  }
  if (["turn.completed", "turn.failed", "turn.cancelled"].includes(event.type)) {
    const turn = payload.turn as Turn;
    return Object.fromEntries(Object.entries(edits).filter(([, edit]) => edit.turnId !== turn.id || edit.revision !== undefined));
  }
  if (!event.type.startsWith("document.edit.")) return edits;
  const update = payload as unknown as DocumentEditEvent & { documentId: string; turnId: string };
  if (update.type === "started") {
    const { [`waiting:${update.turnId}`]: _waiting, ...remaining } = edits;
    return { ...remaining, [update.editId]: { editId: update.editId, documentId: update.documentId, turnId: update.turnId, operation: update.operation, markdown: "" } };
  }
  const edit = edits[update.editId];
  if (!edit || edit.documentId !== update.documentId || edit.turnId !== update.turnId) return edits;
  if (update.type === "delta" && update.offset < edit.markdown.length && edit.markdown.slice(update.offset, update.offset + update.delta.length) === update.delta) return edits;
  if (update.type === "aborted" || (update.type === "delta" && update.offset !== edit.markdown.length)) {
    const { [update.editId]: _discarded, ...remaining } = edits;
    return remaining;
  }
  if (update.type === "delta") return { ...edits, [edit.editId]: { ...edit, markdown: edit.markdown + update.delta } };
  if (update.type === "committed") return { ...edits, [edit.editId]: { ...edit, revision: update.revision, blockIds: update.blockIds } };
  return edits;
}
