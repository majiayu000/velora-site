import { useEffect, useRef } from "react";
import { EditorContent, useEditor } from "@tiptap/react";
import { Extension } from "@tiptap/core";
import { Markdown } from "@tiptap/markdown";
import { Plugin } from "@tiptap/pm/state";
import { Decoration, DecorationSet } from "@tiptap/pm/view";
import { richExtensions } from "../../src/adapters/collaboration/model";

// This editor has no Yjs binding: incomplete text never enters autosave or undo.
const aiCaret = Extension.create({
  name: "aiPreviewCaret",
  addProseMirrorPlugins: () => [new Plugin({
    props: { decorations: state => {
      let end = 0;
      state.doc.descendants((node, pos) => { if (node.isTextblock) end = pos + 1 + node.content.size; });
      return DecorationSet.create(state.doc, [Decoration.widget(end, () => {
        const caret = document.createElement("span");
        caret.className = "ai-edit-caret";
        caret.contentEditable = "false";
        caret.setAttribute("aria-hidden", "true");
        const label = document.createElement("span"); label.textContent = "AI";
        caret.append(label);
        return caret;
      }, { key: "ai-preview-caret", side: 1 })]);
    } },
  })],
});

export function AiEditPreview({ markdown, original = "", saving = false }: { markdown: string; original?: string; saving?: boolean }) {
  const received = useRef(markdown);
  received.current = markdown;
  const editor = useEditor({
    editable: false,
    extensions: [...richExtensions(), Markdown, aiCaret],
    content: original,
    contentType: "markdown",
    editorProps: { attributes: { class: "markdown ai-edit-preview", "aria-label": "AI 正在生成的段落", role: "region" } },
  });
  useEffect(() => {
    if (!editor) return;
    const segmenter = new Intl.Segmenter(undefined, { granularity: "grapheme" });
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let visible = "", last = 0, stride = 1, frame: number;
    const paint = (now: number) => {
      const text = received.current;
      if (text !== visible && now - last >= 50) {
        const rest = [...segmenter.segment(text.slice(visible.length))];
        // Catch up in at most four short paints; never invent future text.
        stride = Math.max(stride, Math.ceil(rest.length / 4));
        const count = reduced ? rest.length : stride;
        visible += rest.slice(0, count).map(part => part.segment).join("");
        editor.commands.setContent(visible || original, { contentType: "markdown", emitUpdate: false });
        last = now;
      }
      frame = requestAnimationFrame(paint);
    };
    frame = requestAnimationFrame(paint);
    return () => cancelAnimationFrame(frame);
  }, [editor, original]);
  return <div className="ai-edit-preview-wrap" aria-busy="true">
    <span className="sr-only" role="status">{saving ? "正在保存这一段" : markdown ? "AI 正在写入这一段" : "AI 正在准备修改这一段"}</span>
    <EditorContent editor={editor} />
  </div>;
}
