import { useEffect, useId, useMemo, useRef } from "react";
import { enhanceDiagrams } from "./diagrams";
import { renderMarkdown } from "../../src/adapters/markdown/markdown-renderer";

export function MarkdownView({ body, className = "markdown" }: { body: string; className?: string }) {
  const root = useRef<HTMLDivElement>(null);
  const namespace = useId().replace(/[^\w-]/g, "");
  const html = useMemo(() => renderMarkdown(body, namespace), [body, namespace]);
  // React reapplies innerHTML when this prop object changes, replacing the
  // enhanced figures and their listeners even when the Markdown is unchanged.
  const markup = useMemo(() => ({ __html: html }), [html]);
  useEffect(() => root.current ? enhanceDiagrams(root.current) : undefined, [html]);
  return <div ref={root} className={className} dangerouslySetInnerHTML={markup} />;
}
