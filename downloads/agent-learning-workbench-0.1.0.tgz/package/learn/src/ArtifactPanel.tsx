import { lazy, Suspense, type RefObject } from "react";
import { Home } from "./Home";
import { HistoryPanel } from "./HistoryPanel";
import { KnowledgeMap } from "./KnowledgeMap";
import { MarkdownView } from "./MarkdownView";
import { Relations } from "./Relations";
import type { DocumentMetadata, DocumentSnapshot, Proposal, Turn, Workspace } from "./types";
import type { AiEdits } from "./ai-edit";

const DevelopmentMarkdownEditor = (import.meta.env.DEV || import.meta.env.MODE === "app")
  ? lazy(() => import("./MarkdownEditor").then((module) => ({ default: module.MarkdownEditor })))
  : null;

const DevelopmentPageEditor = (import.meta.env.DEV || import.meta.env.MODE === "app")
  ? lazy(() => import("./PageEditor").then((module) => ({ default: module.PageEditor })))
  : null;

export type ArtifactRoute = { conversationId?: string; home?: boolean; index?: boolean; rich?: boolean; documentId?: string; edit: boolean; map: boolean; history: boolean; ask?: string; evidencePath?: string; evidenceLine?: number };

export function ArtifactPanel({
  sourcePreview, recentTurns, onOpenConversation, lastDocumentId, route, workspace, document, draft, dirty, loadingDocument,
  guardedProposal, currentProposal, conflict, externalChange, visibleBody, documentsById, articleRef,
  navigate, save, setDraft, setDirty, setProposalDecision, setProposalPreview, setToast,
  acceptProposal, loadDocument, overwriteAfterConflict,
  onCaptureSelection, onHistoryReverted, onRequestEdit, onSharedSnapshot, aiEdits, onAiEditSynced, navigateMap, navigateHistory,
}: {
  sourcePreview: boolean;
  recentTurns: Turn[];
  onOpenConversation: (turn: Turn) => void;
  lastDocumentId?: string;
  route: ArtifactRoute;
  workspace: Workspace;
  document?: DocumentSnapshot;
  draft: string;
  dirty: boolean;
  loadingDocument: boolean;
  guardedProposal?: Proposal;
  currentProposal?: Proposal;
  conflict?: string;
  externalChange: boolean;
  visibleBody: string;
  documentsById: Map<string, DocumentMetadata>;
  articleRef: RefObject<HTMLDivElement | null>;
  navigate: (id?: string, edit?: boolean, rich?: boolean) => void;
  save: () => Promise<boolean>;
  setDraft: (body: string) => void;
  setDirty: (dirty: boolean) => void;
  setProposalDecision: (id: string | undefined) => void;
  setProposalPreview: (id: string | undefined) => void;
  setToast: (message: string) => void;
  acceptProposal: (proposal: Proposal) => Promise<void>;
  loadDocument: (id: string) => Promise<void>;
  overwriteAfterConflict: () => Promise<void>;
  onCaptureSelection: () => void;
  onRequestEdit: (from: number, to: number, block?: { blockId: string; ifHash: string }) => void;
  onSharedSnapshot: (snapshot: DocumentSnapshot) => void;
  aiEdits: AiEdits;
  onAiEditSynced: (editId: string) => void;
  onHistoryReverted: (workspace: Workspace) => void;
  navigateMap: () => void;
  navigateHistory: () => void;
}) {
  return (
    <main className="artifact-panel">
      {guardedProposal && dirty && guardedProposal.documentId === document?.id && (
        <div className="proposal-draft-guard" role="alertdialog" aria-labelledby="proposal-draft-title">
          <div><strong id="proposal-draft-title">这篇文档还有未保存草稿</strong><span>提案基于磁盘版本生成。未明确选择前不会调用接受接口，也不会覆盖当前编辑内容。</span></div>
          <button onClick={() => setProposalDecision(undefined)}>继续编辑草稿</button>
          <button onClick={() => void save().then((saved) => { if (saved) setToast("草稿已保存；原提案基线已过期，请重新生成"); })}>先保存草稿</button>
          <button className="danger-button" onClick={() => void acceptProposal(guardedProposal)}>放弃草稿并应用提案</button>
        </div>
      )}

      {conflict && <div className="conflict-banner"><div><strong>磁盘已变化</strong><span>{conflict}</span></div><button onClick={() => document && void loadDocument(document.id)}>重新加载磁盘版</button><button className="danger-button" onClick={() => void overwriteAfterConflict()}>以草稿显式覆盖</button></div>}
      {externalChange && !conflict && !route.rich && <div className="conflict-banner subtle"><div><strong>另一位写者改了这页</strong><span>你的内存草稿保持不变，保存时会做冲突检查。</span></div><button onClick={() => document && void loadDocument(document.id)}>放弃草稿并加载</button></div>}

      {!route.documentId && route.history ? (
        <HistoryPanel documents={documentsById} onOpen={(id) => navigate(id)} onReverted={onHistoryReverted} />
      ) : !route.documentId && route.map ? (
        <KnowledgeMap currentDocumentId={lastDocumentId} workspace={workspace} onOpen={(id) => navigate(id)} />
      ) : !route.documentId ? (
        <Home onOpenConversation={onOpenConversation} recentTurns={recentTurns} workspace={workspace} onOpen={(id) => navigate(id)} onMap={navigateMap} onHistory={navigateHistory} />
      ) : loadingDocument || !document ? (
        <div className="loading-state"><i /><span>从磁盘读取最新 Markdown</span></div>
      ) : route.edit && !currentProposal && route.rich && DevelopmentPageEditor ? (
        <Suspense fallback={<div className="editor-loading">正在加载页面编辑器…</div>}>
          <div ref={articleRef} onMouseUp={onCaptureSelection}>
            <DevelopmentPageEditor key={document.id} documentId={document.id} onSnapshot={onSharedSnapshot} onRequestEdit={onRequestEdit} aiEdits={aiEdits} onAiEditSynced={onAiEditSynced} />
          </div>
        </Suspense>
      ) : route.edit && !currentProposal && DevelopmentMarkdownEditor ? (
        <div className={`editor-workspace ${sourcePreview ? "has-preview" : ""}`}>
          <div className="pane-label"><span>源文件</span><code>{document.path}</code></div>
          <div className="pane-label preview-label"><span>实时预览</span><small>与阅读页同一渲染器</small></div>
          <Suspense fallback={<div className="editor-loading">正在加载本地 Markdown 编辑器…</div>}>
            <DevelopmentMarkdownEditor value={draft} revision={`${document.id}:${document.contentHash}`} onChange={(value) => { setDraft(value); setDirty(value !== document.body); }} onSave={() => void save()} />
          </Suspense>
          <div className="editor-preview"><MarkdownView body={draft} /></div>
        </div>
      ) : (
        <article className="document-surface" ref={articleRef} onMouseUp={onCaptureSelection}>
          {currentProposal && <div className="proposal-preview-banner"><span>正在预览 Agent 提案，尚未写入文件</span><button onClick={() => setProposalPreview(undefined)}>退出预览</button></div>}
          <header className="document-header">
            <h1>{document.title}</h1><p>{document.summary}</p>
          </header>
          <MarkdownView body={visibleBody} />
          <Relations document={document} documents={documentsById} onOpen={(id) => navigate(id)} />
        </article>
      )}
    </main>
  );
}
