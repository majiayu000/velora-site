import * as Y from "yjs";
import { IndexeddbPersistence } from "y-indexeddb";
import { subscribeToEvents, type SpaceApi } from "./api";
import type { CollaborationSnapshot } from "../../src/ports/collaboration-port";

export const remoteOrigin = Symbol("remote");
export const humanOrigin = Symbol("human");
const encode = (value: Uint8Array) => { let result = ""; for (const byte of value) result += String.fromCharCode(byte); return btoa(result); };
const decode = (value: string) => Uint8Array.from(atob(value), c => c.charCodeAt(0));

export class LiveDocument {
  readonly doc = new Y.Doc();
  readonly session = crypto.randomUUID();
  readonly persistence: IndexeddbPersistence;
  snapshot?: CollaborationSnapshot;
  status = "正在连接…";
  error = "";
  pending = false;
  ready = false;
  activeBlock?: string;
  peers: Array<{ session: string; blockId?: string }> = [];
  private vector?: Uint8Array;
  private listeners = new Set<() => void>();
  private timer?: ReturnType<typeof setTimeout>;
  private poll?: ReturnType<typeof setInterval>;
  private unsubscribe?: () => void;
  private busy = false;
  private closed = false;
  private generation = 0;
  private version = 0;
  getVersion = () => this.version;
  constructor(readonly api: SpaceApi, readonly id: string) {
    this.persistence = new IndexeddbPersistence(`learn:${api.spaceId}:${id}`, this.doc);
  }
  subscribe = (listener: () => void) => { this.listeners.add(listener); return () => { this.listeners.delete(listener); }; };
  private emit() { this.version++; for (const listener of this.listeners) listener(); }
  private updated = (_update: Uint8Array, origin: unknown) => {
    if (origin !== remoteOrigin && origin !== this.persistence) {
      this.generation++; this.pending = true; this.status = "正在同步…"; this.schedule();
    }
    this.emit();
  };
  async start() {
    try {
      this.status = "正在恢复本机修改…"; this.emit();
      await this.persistence.whenSynced;
      if (this.closed) return;
      this.status = "正在读取共享版本…"; this.emit();
      const snapshot = await this.api.collaboration(this.id);
      if (this.closed) return;
      Y.applyUpdate(this.doc, decode(snapshot.state), remoteOrigin);
      this.vector = decode(snapshot.vector);
      this.snapshot = snapshot;
      this.ready = true;
      this.doc.on("update", this.updated);
      this.pending = true;
      this.status = "正在同步…"; this.emit();
      this.unsubscribe = subscribeToEvents(this.api.spaceId, 0, event => {
        if (event.type === "collaboration.changed" && event.payload.documentId === this.id) this.schedule();
      }, connected => { if (connected) this.schedule(); });
      this.poll = setInterval(() => this.schedule(), 3000);
      await this.flush();
    } catch (error) {
      if (this.closed) return;
      this.fail(error);
      this.timer = setTimeout(() => { this.timer = undefined; if (!this.closed) void this.start(); }, 2000);
    }
  }
  private schedule() {
    if (this.closed || this.timer) return;
    this.timer = setTimeout(() => { this.timer = undefined; void this.flush(); }, 120);
  }
  private fail(error: unknown) {
    this.error = error instanceof Error ? error.message : String(error);
    this.status = "连接中断或同步失败；本机保留修改"; this.emit();
  }
  async flush(): Promise<void> {
    if (this.closed || this.busy || !this.vector) return;
    this.busy = true;
    const generation = this.generation;
    try {
      const snapshot = await this.api.syncDocument(this.id, {
        update: encode(Y.encodeStateAsUpdate(this.doc, this.vector)),
        vector: encode(Y.encodeStateVector(this.doc)),
        presence: { session: this.session, blockId: this.activeBlock },
      });
      if (this.closed) return;
      Y.applyUpdate(this.doc, decode(snapshot.state), remoteOrigin);
      this.vector = decode(snapshot.vector);
      this.snapshot = snapshot;
      this.peers = snapshot.peers.filter(p => p.session !== this.session);
      this.pending = this.generation !== generation;
      this.error = ""; this.status = this.pending ? "正在同步…" : "已实时保存";
      this.emit();
    } catch (error) { this.fail(error); }
    finally { this.busy = false; if (this.pending && !this.error) this.schedule(); }
  }
  close() {
    this.closed = true; clearTimeout(this.timer); clearInterval(this.poll); this.unsubscribe?.();
    this.doc.off("update", this.updated);
    // IndexedDB writes queued by the provider complete independently of the editor.
    void this.persistence.destroy().then(() => this.doc.destroy());
  }
}
