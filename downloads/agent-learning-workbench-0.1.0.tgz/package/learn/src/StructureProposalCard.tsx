import type { StructureProposal } from "./types";

const labels = { create: "新建", update: "更新标题摘要", rename: "重命名", delete: "删除" } as const;

export function StructureProposalCard({ proposal, onAccept, onReject }: {
  proposal: StructureProposal;
  onAccept: () => void;
  onReject: () => void;
}) {
  const closed = proposal.status === "accepted" || proposal.status === "rejected";
  return (
    <div className={`structure-proposal-card status-${proposal.status}`}>
      <div className="proposal-title"><span>⌘</span><strong>站点结构提案</strong><em>{proposal.status}</em></div>
      <p>{proposal.summary}</p>
      <ol>
        {proposal.operations.map((operation, index) => (
          <li key={`${operation.type}-${index}`}>
            <span>{labels[operation.type]}</span>
            {operation.type === "create" && <div><strong>{operation.document.title}</strong><code>{operation.document.path}</code><small>{operation.document.summary}</small></div>}
            {operation.type === "rename" && <div><strong>{operation.title ?? operation.documentId}</strong><code>{operation.documentId} → {operation.nextPath}</code></div>}
            {operation.type === "update" && <div><strong>{operation.title}</strong><small>{operation.summary}</small></div>}
            {operation.type === "delete" && <div><strong>{operation.documentId}</strong><small>Markdown 文件和 manifest 登记会一起移除</small></div>}
          </li>
        ))}
      </ol>
      {!closed && <div className="proposal-actions"><button onClick={onReject}>拒绝</button><button className="accept" onClick={onAccept} disabled={proposal.status === "conflict"}>审核并应用结构</button></div>}
      {proposal.status === "conflict" && <small>manifest 或目标路径已变化，请重新生成结构提案。</small>}
    </div>
  );
}
