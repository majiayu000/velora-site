export { editableBlocks, preserveBlockEnding, replaceBlock, type EditableBlock } from "../../src/adapters/collaboration/markdown-blocks";
