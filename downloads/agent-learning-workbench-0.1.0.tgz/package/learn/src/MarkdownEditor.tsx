import { yCollab, yUndoManagerKeymap } from "y-codemirror.next";
import type { Text, UndoManager } from "yjs";
import { defaultKeymap, history, historyKeymap } from "@codemirror/commands";
import { markdown } from "@codemirror/lang-markdown";
import { EditorState } from "@codemirror/state";
import { EditorView, keymap, lineNumbers, highlightActiveLine, highlightActiveLineGutter } from "@codemirror/view";
import { useEffect, useRef } from "react";

type Props = {
  value: string;
  revision: string;
  onChange?: (value: string) => void;
  shared?: { text: Text; undo: UndoManager };
  onSave: () => void;
};

export function MarkdownEditor({ value, revision, onChange, onSave, shared }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const viewRef = useRef<EditorView | undefined>(undefined);
  const onChangeRef = useRef(onChange);
  const onSaveRef = useRef(onSave);
  onChangeRef.current = onChange;
  onSaveRef.current = onSave;

  useEffect(() => {
    if (!host.current) return;
    const view = new EditorView({
      parent: host.current,
      state: EditorState.create({
        doc: shared ? shared.text.toString() : value,
        extensions: [
          shared ? yCollab(shared.text, undefined, { undoManager: shared.undo }) : history(),
          markdown(),
          lineNumbers(),
          highlightActiveLine(),
          highlightActiveLineGutter(),
          EditorView.lineWrapping,
          keymap.of([
            {
              key: "Mod-s",
              preventDefault: true,
              run: () => {
                onSaveRef.current();
                return true;
              },
            },
            ...defaultKeymap,
            ...(shared ? yUndoManagerKeymap : historyKeymap),
          ]),
          EditorView.updateListener.of((update) => {
            if (update.docChanged && !shared) onChangeRef.current?.(update.state.doc.toString());
          }),
          EditorView.theme({
            "&": { height: "100%", background: "transparent" },
            ".cm-scroller": { fontFamily: '"SFMono-Regular", Consolas, monospace', lineHeight: "1.72" },
            ".cm-content": { padding: "24px 28px", caretColor: "#2B46E0" },
            ".cm-line": { padding: "0" },
            ".cm-gutters": { background: "#FFFFFF", border: "none", color: "#B4B9C2" },
            ".cm-activeLine": { background: "#F0F3FE" },
            ".cm-activeLineGutter": { background: "#F0F3FE" },
            ".cm-selectionBackground, &.cm-focused .cm-selectionBackground": { background: "#E3E8FC !important" },
            "&.cm-focused": { outline: "none" },
          }),
        ],
      }),
    });
    viewRef.current = view;
    return () => view.destroy();
  }, []);

  useEffect(() => {
    const view = viewRef.current;
    if (shared || !view || view.state.doc.toString() === value) return;
    view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: value } });
  }, [revision]);

  return <div className="editor-host" ref={host} aria-label="Markdown 编辑器" />;
}
