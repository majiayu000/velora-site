import { ProposalDiff } from "./ProposalDiff";
import type { Proposal } from "./types";

export function ProposalCard({
  proposal,
  automatic = false,
  onHistory,
  previewing,
  onPreview,
  onAccept,
  onReject,
}: {
  proposal: Proposal;
  automatic?: boolean;
  onHistory?: () => void;
  previewing: boolean;
  onPreview: () => void;
  onAccept: () => void;
  onReject: () => void;
}) {
  const closed = proposal.status === "accepted" || proposal.status === "rejected";
  return (
    <div className={`proposal-card status-${proposal.status}`}>
      <div className="proposal-title"><span>Δ</span><strong>{automatic ? "文档修改" : "文档修订提案"}</strong><em>{automatic ? ({ pending: "未应用", accepted: "已保存", conflict: "未应用", rejected: "未应用" })[proposal.status] : proposal.status}</em></div>
      <p>{proposal.summary}</p>
      <ProposalDiff before={proposal.baseMarkdown} after={proposal.replacementMarkdown} />
      {!automatic && !closed && <div className="proposal-actions"><button onClick={onPreview}>{previewing ? "退出预览" : "在右侧预览"}</button><button onClick={onReject}>拒绝</button><button className="accept" onClick={onAccept} disabled={proposal.status === "conflict"}>审核并写入</button></div>}
      {automatic && proposal.status === "accepted" && onHistory && <button onClick={onHistory}>查看历史与撤销</button>}
      {proposal.status === "conflict" && <small>磁盘版本已变化。请基于最新页面重新发起修订。</small>}
    </div>
  );
}
