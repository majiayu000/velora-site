import { useMemo } from "react";
import { buildLineDiff, summarizeLineDiff } from "./line-diff";

export function ProposalDiff({ before, after }: { before: string; after: string }) {
  const lines = useMemo(() => buildLineDiff(before, after), [before, after]);
  const stats = useMemo(() => summarizeLineDiff(lines), [lines]);

  return (
    <details className="proposal-diff">
      <summary>
        <span>查看逐行差异</span>
        <span className="diff-stat"><em>+{stats.added} 行</em><em>−{stats.removed} 行</em></span>
      </summary>
      <div className="diff-lines" role="table" aria-label="提案逐行差异">
        {lines.map((line, index) => (
          <div className={`diff-line is-${line.kind}`} role="row" data-diff-kind={line.kind} key={`${line.kind}-${index}`}>
            <span role="cell" aria-label={line.oldLine ? `旧文件第 ${line.oldLine} 行` : "旧文件无对应行"}>{line.oldLine ?? ""}</span>
            <span role="cell" aria-label={line.newLine ? `新文件第 ${line.newLine} 行` : "新文件无对应行"}>{line.newLine ?? ""}</span>
            <b role="cell" aria-hidden="true">{line.kind === "added" ? "+" : line.kind === "removed" ? "−" : " "}</b>
            <code role="cell">{line.text || " "}</code>
          </div>
        ))}
      </div>
    </details>
  );
}
