# Agent Learning Website Architecture

Status: P0-P5 accepted; live Docs collaboration implemented
Date: 2026-10-06
Product intent: [PRODUCT_INTENT.md](./PRODUCT_INTENT.md)
Scope: local-first editable learning website, Agent workflow, reusable engine, and runtime adapters

## Local service lifecycle

Agent boundary (2026-10-12): the product agent serves users through supplied learning documents, workbench guides, and guarded document operations. It has no source-code, shell, or general filesystem tools. Codex threads select `environments: []`; inherited MCP servers, host instructions, skills, plugins, hooks, and memories are disabled for this adapter. Claude runs with no built-in tools and with host customizations disabled. Evidence fingerprinting is limited to registered learning documents. This supersedes the original read-only repository-access design below.

`src/server/local-workbench.ts` owns workspace registration, engines, filesystem watchers, native folder selection, HTTP commands, and replayable event streams. `local-server.ts` hosts that service on loopback and serves compiled editable assets from `learn/app-dist`; `learn-workbench serve` runs it without Vite. In development, `standalone-vite.ts` starts the backend before the frontend and proxies same-origin API/bootstrap requests to it. Frontend restarts preserve the backend's token, open spaces, and active turns. The Vite plugin supplies only the UI shell/proxy or a read-only static content snapshot; it owns no interactive engines or file watchers. Static exports remain in `learn/dist`.

Edition boundary (2026-10-09): this repository provides the account-free local workbench and read-only static exports. Account, billing, repository authorization, and hosted sharing UI placeholders are removed. A future private cloud application will reuse the public engine and UI through a separate authenticated server composition. See [local and cloud edition plan](docs/local-and-cloud.md); the cloud service is not implemented here.


## Public reading export (2026-10-26)

Public builds generate an HTML homepage, selected article pages, a local-use guide, and a 404 page. `src/server/public-site.ts` reads only explicitly selected registered documents; it does not export receipts or initialize an interactive runtime. `learn/src/public.ts` adds title/summary search and diagram controls without React, editor bundles, or local APIs. Markdown and flow rendering live in `src/adapters/markdown/` and are shared by the workbench and build-time renderer; jsdom supplies the server DOM without enabling scripts or resource loading.

`build-site --documents ID,ID [--site-url URL]` stages the complete site before replacing its owned output directory. Unknown nonempty directories and output symlinks are refused. Failed builds retain the previous site; successful rebuilds remove withdrawn pages and old assets. A final URL enables canonical URLs and a sitemap, including subdirectory deployments. Without one, generated pages use noindex for preview. Static hosting must map missing paths to HTTP 404; the bundled Vite preview does this as well.

## Product website and packaged release (2026-10-26)

The fixed `website` build composes the public reader with a Velora product homepage, moves the example collection to `/learn/`, and supplies versioned package downloads. `scripts/build-release.mjs` packs the compiled application locally and writes its SHA-256. The website plugin reads that exact archive, computes download metadata from its bytes, and emits the archive and checksum into the site; no registry or remote publication is part of either build command.

`verify:release` installs the actual archive outside the checkout with production dependencies, invokes the installed CLI, serves its compiled assets, saves through HTTP, checks a deterministic JSON-stdio adapter, and exports a page. `verify:website` verifies browser downloads and navigation against the same checksum. The reading exporter remains separate from this fixed product composition. Node 22 CI includes independent installation; browser CI includes website verification. These configured gates do not by themselves claim a completed remote run.

## Live Docs update

The current collaboration contract is [docs/live-docs.md](docs/live-docs.md). It supersedes the original P0 exclusions for CRDT editing and direct Agent writes below. Tiptap binds to Yjs fragments with a document operations extension; guarded block operations are shared by HTTP, SDK and MCP. Per-document filesystem leases coordinate processes. Yjs state is durable in `.learn/collaboration/`; Markdown is its interoperable projection, and external Markdown edits are reconciled into the shared document. The browser caches updates in IndexedDB and owns a local-origin UndoManager. Source-mode whole-file writes retain the original If-Match contract. No cloud accounts or public remote access are introduced.

## Learning task update (2026-10-12)

Learning conversations have their own identity and may start without a document. The engine supplies page metadata and content roots; unscoped Codex tasks can open, create, and update page metadata through bounded tools, then use the existing collaborative block writer. Page creation and filling can finish in one turn. Saved artifacts update the index and open in the workbench; clarification does not require a new page. Conversation history is scoped by conversationId. The original proposal-only P0 workflow below is historical; path moves/deletes and explicit reviewed integrations still use proposals. See [current Live Docs contract](docs/live-docs.md).

## 1. Original P0 Decision Summary

The product is a standalone local-first Agent learning website. It is not a static-document generator, a hosted documentation platform, or a Skill that happens to emit HTML.

The website is the user's primary learning interface. Project Markdown plus `learn.manifest.json` is the durable content authority. One local `LearnEngine` instance owns active turns, proposals, document mutation, event ordering, and shutdown. The browser owns routes, presentation, text selection, and unsaved editor drafts only.

P0 must implement one complete vertical loop:

```text
open website
  -> ask a real project question
  -> stream Agent progress and answer
  -> inspect a proposed document change
  -> accept the proposal
  -> observe Markdown and the page update
  -> edit the same Markdown manually with live preview
  -> save with hash conflict protection
  -> select text and ask for a revision
  -> build a static read-only website from the same source
```

The chosen implementation is TypeScript end to end:

- React + Vite for the browser UI;
- CodeMirror 6 for Markdown editor state and native undo history;
- a loopback-only Node.js process for workspace, Agent, Git, and mutation effects;
- HTTP commands plus SSE events between browser and local process;
- a provider-neutral `RuntimePort`, with Codex app-server over `stdio` as the first real adapter;
- a modular monolith for P0, split into packages only after a second real consumer requires it.

The existing `learn/` site is retained as migration input, not treated as the finished product.

## 2. Objective

Turn questions asked while building or studying a real software project into verified, editable, interlinked learning pages that continue to grow with the project.

The system must let a person and an Agent work on the same source without giving either side an unsafe silent-overwrite path. Agent runtimes investigate and propose. Users review, accept, reject, edit, and save. The website immediately renders the accepted source without relying on a full HMR page reload.

### P0 user

A developer learning an unfamiliar or evolving codebase while actively working in it.

### P0 jobs

- Open a project and continue from its existing learning website.
- Ask about the repository, current page, file, symbol, or selected passage.
- See streamed progress, evidence, answer, unknowns, and next questions.
- Review an Agent proposal before it reaches canonical Markdown.
- Accept or reject the proposal.
- Edit Markdown manually with live preview and conflict protection.
- Select text and ask the Agent to explain or revise it.
- Build a read-only static website from exactly the same accepted source.

### P0 non-goals

- User accounts, billing, organizations, or a hosted control plane.
- Multi-user real-time collaboration or CRDT editing.
- A general-purpose Notion replacement or block database.
- A custom foundation-model inference runtime.
- Direct Agent writes to canonical documents.
- Arbitrary MDX, executable document JavaScript, or unsanitized HTML.
- Browser UI for creating, deleting, or renaming documents.
- Auto-commit by default.
- Treating model confidence, answer length, or search rank as evidence.

## 3. Current Evidence

The repository is no longer greenfield. It contains a useful read-only prototype and a product-intent baseline.

| Area | Current evidence | Architectural implication |
|---|---|---|
| Product contract | `PRODUCT_INTENT.md` locks editing, Agent interaction, proposal review, selection actions, and static production as the core loop | These capabilities belong in P0, not P1 |
| Content | `docs/learn/*.md` contains registered learning pages | Preserve Markdown and migrate in place |
| Navigation | `learn.manifest.json` owns IDs, paths, titles, tags, prerequisites, and relations | Keep it authoritative and versioned |
| Web entrypoint | `learn/index.html` and `learn/src/main.js` implement a Vite SPA | Evolve the existing site instead of creating another frontend |
| Rendering | `marked` + DOMPurify renders registered Markdown | Preserve sanitization; replace the ad hoc renderer behind a typed renderer port |
| Build | `learn/package.json` builds a static `dist/` | Production remains static and read-only |
| Development content loading | `learn/vite.config.mjs` reads files into a virtual module | Keep as a temporary compatibility path; development must fetch editable snapshots instead |
| Editing | No editor route, draft state, save endpoint, hash, or conflict UI exists | This is the first missing P0 boundary |
| Agent interaction | No question command, event stream, runtime adapter, proposal, or cancellation exists | This is the second missing P0 boundary |
| Tests | No unit, contract, security, or browser E2E suite exists | No product-readiness claim is permitted |
| Git | The current directory is not a Git repository | Git remains optional at runtime; document correctness cannot depend on Git being present |
| Skill | `$build-project-learning` can generate files and start the static site | Reposition it as installer/launcher after the real app exists |

### Existing forks and debt

| Path | Classification | Problem | Required convergence |
|---|---|---|---|
| Vite virtual content module | Intentional temporary bridge | Development and production both consume an inlined snapshot, so the page cannot safely edit live files | Development uses `DocumentSnapshot` API; production alone uses inlined content |
| Vanilla `learn/src/main.js` | Migration implementation | It owns routing and rendering but has no explicit application state | Replace incrementally with React app state; delete after feature parity |
| Skill-bundled site template | Accidental product fork | A separate template can drift from the real product | Skill installs or invokes the canonical app package; remove copied product code |
| Architecture v1 roadmap | Superseded plan | It placed the real web loop and runtime adapter in P1 | This specification replaces that priority split |

## 4. Reference Models Considered

| Reference | Borrow | Do not copy | Source |
|---|---|---|---|
| Existing `learn/` prototype | Markdown/manifest authority, static build, navigation, and sanitization | Its read-only development model and untyped global UI state | Current repository |
| Cuter learning contract | Development-only write surface, hash conflict, atomic save, production read-only | Cuter Rust/media authority or a Cuter-specific catalog as the permanent schema | User-provided compatible contract; not claimed as freshly inspected source |
| Vite | `configureServer` for development-only middleware and static production builds | Vite plugin hooks as domain logic or a production write server | [Plugin API](https://vite.dev/guide/api-plugin.html), [production build](https://vite.dev/guide/build) |
| CodeMirror 6 | Immutable editor state, transactions, selections, undo stack | Using rendered HTML as the Markdown authority | [System guide](https://codemirror.net/docs/guide/), [reference](https://codemirror.net/docs/ref/) |
| Codex app-server | Rich-client thread/turn lifecycle, streaming notifications, cancellation, authentication reuse | Provider event names in core, WebSocket transport for P0, or direct canonical writes | [Codex app-server documentation](https://learn.chatgpt.com/docs/app-server.md) |
| Codex SDK / `codex exec` | Contract-test reference and possible automation adapter | Treating a one-shot CLI subprocess as the product's state owner | [Codex SDK](https://learn.chatgpt.com/docs/codex-sdk.md), [non-interactive mode](https://learn.chatgpt.com/docs/non-interactive-mode.md) |
| MCP TypeScript SDK v2 | Future local tools/resources surface and stdio transport | MCP protocol types as core domain models or legacy HTTP+SSE as a new default | [MCP TypeScript SDK v2](https://ts.sdk.modelcontextprotocol.io/v2/) |
| Node filesystem APIs | Ordered write, flush, and rename primitives | Parallel writes to the same target or unchecked paths | [Node.js filesystem API](https://nodejs.org/api/fs.html) |
| Notion-style UX | Readable pages, selection affordances, clear insertion and comment patterns | Block database, workspace permissions, and general editor platform scope | Interaction reference only |
| OpenDesign/artifact UX | Left instruction surface and right visible artifact | One-shot generated HTML as durable content or unverified architectural internals | Visual interaction reference only |

## 5. Chosen Project Shape

The system combines three shapes behind one domain core:

1. a UI/app shell for reading, editing, selecting, and reviewing;
2. an Agent workflow runtime for turns, events, cancellation, and proposals;
3. a local developer service for filesystem, process, Git, and build effects.

State ownership model:

> One process-local `LearnEngine` owns all accepted runtime state and serializes canonical mutations; project Markdown and manifest own durable knowledge; the browser owns only view state and unsaved drafts.

```text
product/app
  - React learning workspace
  - local development composition root
  - future CLI and MCP entry surfaces

core/domain
  - document snapshots, questions, evidence, turns, proposals, anchors
  - invariants and typed errors
  - no filesystem, process, network, Git, DOM, or provider imports

runtime/application
  - workspace lifecycle
  - turn orchestration and cancellation
  - proposal review and apply
  - document mutation queues
  - event ordering and replay

adapters/backends
  - filesystem, watcher, Git, renderer, search
  - Codex app-server adapter
  - local HTTP/SSE and Vite development adapter

plugins/components
  - future Claude/other runtime adapters
  - rich Markdown directives
  - MCP, exporters, staleness strategies

testing/headless
  - fake runtime, in-memory filesystem, deterministic clock/IDs
  - provider fixtures, malicious-path fixtures, browser E2E
```

## 6. System Context and Boundary Map

```text
┌───────────────────────────────────────────────────────────────┐
│ Browser                                                       │
│ Questions │ Events │ Document read/edit/preview │ Diff review │
└───────────────────────────┬───────────────────────────────────┘
                            │ HTTP commands + SSE events
┌───────────────────────────▼───────────────────────────────────┐
│ Loopback development process                                  │
│ Session guard │ HTTP adapter │ Vite middleware │ composition  │
└───────────────────────────┬───────────────────────────────────┘
                            │ typed commands
┌───────────────────────────▼───────────────────────────────────┐
│ LearnEngine                                                    │
│ WorkspaceService │ TurnService │ ProposalService │ Documents  │
│ EventLog │ per-document queues │ cancellation │ watcher       │
└─────────────┬──────────────────────────────┬──────────────────┘
              │ pure decisions               │ explicit ports
┌─────────────▼──────────────┐   ┌───────────▼──────────────────┐
│ Domain                     │   │ Adapters                     │
│ models/invariants/errors   │   │ FS │ Git │ Codex │ Render    │
└────────────────────────────┘   └───────────┬──────────────────┘
                                            │ read-only runtime view
                                  ┌─────────▼──────────────────┐
                                  │ Project workspace           │
                                  │ code │ docs │ manifest │ Git│
                                  └─────────────────────────────┘
```

The browser never talks directly to Codex, Claude, Git, or the filesystem. Runtime adapters never receive the canonical `WorkspacePort` mutation capability.

## 7. Runtime Profiles

### 7.1 Interactive development

`learn dev` starts one loopback-only Node process. It creates `LearnEngine`, mounts the HTTP/SSE adapter, and runs Vite in development mode on the same origin. The process may spawn a selected Agent runtime as a child process.

The development server is the only profile with write and Agent capabilities.

`learn/vite.config.ts` composes a `createLearnDevPlugin(engineFactory)` adapter. Its `configureServer` hook mounts API/SSE middleware only when Vite's resolved command is `serve`; build mode receives only the read-only content bundling plugin. Domain behavior stays in application services, not in Vite hooks.

### 7.2 Static production

`learn build` validates the workspace and builds a static site. Markdown is compiled or inlined into browser assets. The output contains no write routes, session token, runtime process bridge, Git capability, or provider credential path.

### 7.3 Headless engine

P2 CLI, SDK, and MCP surfaces instantiate the same application services without the browser. They do not reimplement question, proposal, or mutation logic.

## 8. Language and Technology Decision

| Concern | Choice | Reason |
|---|---|---|
| Language | TypeScript, strict mode | Shared runtime schemas, fastest iteration across browser and Node, strong Agent/MCP ecosystem |
| Server runtime | maintained Node.js LTS compatible with selected dependencies | Filesystem, child process, stdio, watcher, and Git effects |
| Web UI | React + Vite | Explicit component/state boundary while preserving current Vite build |
| Editor | CodeMirror 6 | Transactional editor state, selection model, keymaps, undo, extension boundary |
| Transport | HTTP commands + SSE events | User actions are request/response; Agent output is primarily server-to-client streaming |
| Runtime schema | Zod with JSON Schema export | One validated shape for HTTP, events, runtime results, and fixtures |
| Markdown | unified/remark pipeline, GFM, controlled directives, sanitized HTML | AST-level safety and future rich learning blocks |
| Tests | Vitest + Playwright | Headless contracts plus full browser workflow |
| Persistence | Markdown + JSON manifest + optional Git | Portable, reviewable, no new database authority |

Do not introduce Rust, Go, Python, Electron, Tauri, a database, or a cloud service in P0. Revisit native packaging only after a real distribution or performance requirement is measured.

## 9. Repository Layout

P0 uses a modular monolith rather than premature npm package splitting:

```text
webs/
  package.json                    # one lockfile and root commands
  tsconfig.json
  learn.config.json
  learn.manifest.json
  docs/learn/*.md
  src/
    domain/                       # pure models, invariants, typed errors
    application/                  # LearnEngine and use cases
    ports/                        # capability interfaces
    adapters/
      filesystem/
      git/
      runtime-codex/
      runtime-fake/
      renderer-markdown/
      watcher/
    server/
      http/
      sse/
      session-guard/
    composition/
      create-learn-engine.ts
      create-dev-server.ts
  learn/
    index.html
    vite.config.ts
    src/
      app/
      questions/
      documents/
      editor/
      proposals/
      selection/
      shared/
  tests/
    unit/
    contracts/
    security/
    fixtures/
    e2e/
```

Extract `@learn/core`, `@learn/sdk`, or adapter packages only when P2 introduces a second separately built consumer. Folder boundaries and dependency tests exist before package boundaries.

## 10. Source-of-Truth Map

| Contract | Authoritative source | Consumers | Explicitly not authoritative |
|---|---|---|---|
| Product intent | `PRODUCT_INTENT.md` | architecture, roadmap, acceptance tests | Skill prompt, chat summary |
| Document prose | registered `docs/**/*.md` | editor, renderer, search, Agent context | generated HTML, browser cache, Agent answer |
| Site structure | `learn.manifest.json` | navigation, relationships, routes, context | generated sidebar arrays |
| Runtime/config schema | TypeScript/Zod schemas under `src/domain` | HTTP, events, adapters, tests | duplicated frontend interfaces |
| Accepted content state | filesystem after atomic apply | all readers | pending proposal, draft, chat transcript |
| Unsaved draft | browser editor session | current tab | Markdown, localStorage as content authority |
| Active turn/proposal | `LearnEngine`; optional `.learn/runs` replay record | UI projections, diagnostics | React component-local copies |
| Accepted history | Git when available + applied receipt | history/revert UI | Agent conversation text |
| Search index | `.learn/cache/` | search | canonical content |
| Runtime credentials | runtime-owned user config/environment | selected adapter | project files, static build, event log |

Everything under `.learn/cache/` must be deletable and reproducible. Deleting `.learn/runs/` may remove diagnostics but must not remove accepted documents.

## 11. File Contracts

### 11.1 `learn.config.json`

```json
{
  "version": 1,
  "contentRoots": ["docs"],
  "manifest": "learn.manifest.json",
  "maxDocumentBytes": 1048576,
  "server": {
    "host": "127.0.0.1",
    "port": 4178
  },
  "runtime": {
    "adapter": "codex"
  },
  "git": {
    "enabled": true,
    "autoCommit": false
  }
}
```

Environment variables may override runtime credentials and port selection. Core/application modules never read the environment directly.

### 11.2 `learn.manifest.json`

The existing v1 format remains authoritative:

```json
{
  "version": 1,
  "site": {
    "title": "Project Learning",
    "description": "Evidence-backed project learning"
  },
  "contentRoots": ["docs"],
  "documents": [
    {
      "id": "start-here",
      "path": "docs/learn/start-here.md",
      "title": "Start Here",
      "summary": "The first learning route",
      "stage": "00",
      "tags": ["overview"],
      "prerequisites": [],
      "related": []
    }
  ]
}
```

IDs are stable lowercase kebab-case. Paths must resolve through `realpath` under a configured content root and end in `.md`. P0 web commands can update registered document bodies but cannot create, delete, rename, or mutate manifest metadata.

## 12. Domain Model

```ts
type EvidenceState = "verified" | "inferred" | "unknown";
type TurnStatus =
  | "queued"
  | "collecting-context"
  | "running"
  | "awaiting-review"
  | "completed"
  | "cancelled"
  | "failed";

interface DocumentSnapshot {
  id: string;
  path: string;
  body: string;
  contentHash: string;
  modifiedAt: string;
}

interface TextQuoteAnchor {
  documentId: string;
  headingPath: string[];
  exactQuote: string;
  prefix: string;
  suffix: string;
  snapshotHash: string;
}

interface LearningQuestion {
  question: string;
  mode: "answer" | "revise";
  documentId?: string;
  selectedText?: TextQuoteAnchor;
}

interface EvidenceReference {
  state: EvidenceState;
  path?: string;
  symbol?: string;
  startLine?: number;
  endLine?: number;
  contentHash?: string;
  explanation: string;
  sourceUrl?: string;
}

interface DocumentChange {
  kind: "update";
  documentId: string;
  baseHash: string;
  proposedBody: string;
}

interface LearningProposal {
  id: string;
  turnId: string;
  summary: string;
  changes: DocumentChange[];
  evidence: EvidenceReference[];
  createdAt: string;
}
```

P0 proposal operations update existing documents only. Full proposed bodies are preferred over model-authored line-offset patches; the application computes the review diff and validates the final candidate.

P1 adds a separate `StructureProposal` for create, rename, and delete operations. It freezes the manifest hash at turn start, exposes every operation before acceptance, and never shares the ordinary body-proposal endpoint. The filesystem adapter preflights IDs, normalized Markdown paths, content-root containment, collisions, relationships, and size limits before staging any file. It writes staged files and the staged manifest, moves deleted files to transaction backups, commits the manifest last, and rolls back all pre-commit filesystem moves on failure. Post-commit durability or backup-cleanup failures are returned as explicit warnings rather than making a committed change appear pending.

## 13. State Ownership

### LearnEngine owns

- workspace readiness and configuration;
- active turn registry and cancellation controllers;
- ordered event sequence numbers;
- pending proposals and their status;
- per-document mutation queues;
- watcher reconciliation and document-change broadcasts;
- runtime adapter lifecycle;
- shutdown and drain decisions.

### Browser owns

- route and selected document;
- left-panel expansion and active turn projection;
- `EditorState`, selection, undo history, and dirty draft;
- preview of the current draft;
- diff-view selection before acceptance;
- temporary conflict-resolution choices.

The browser must not mutate a fetched snapshot in place and call it saved. Every accepted server result returns a new immutable `DocumentSnapshot`.

## 14. Lifecycles

### 14.1 Process lifecycle

```text
load config
  -> resolve and realpath workspace
  -> validate manifest and registered documents
  -> construct adapters
  -> create LearnEngine
  -> start watcher and event log
  -> start Vite/API loopback server
  -> ready
  -> accept commands
  -> stop accepting new turns
  -> cancel or drain active runtime turns
  -> finish queued atomic writes
  -> close child runtimes, watcher, SSE clients, and server
```

Startup fails when configuration or manifest is invalid, paths escape allowed roots, IDs collide, or required runtime capabilities are unavailable.

### 14.2 Question lifecycle

```text
question.received
  -> context.validated
  -> evidence.collection.started
  -> runtime.started
  -> answer.delta*
  -> evidence.added*
  -> runtime.completed
  -> result.validated
  -> proposal.created | answer.only
  -> awaiting.review | turn.completed
  -> proposal.accepted | proposal.rejected
  -> mutation.applied
  -> projections.updated
  -> turn.completed
```

Cancellation aborts the provider and leaves pending/unapplied changes unapplied.

### 14.3 Manual editor lifecycle

```text
open edit route
  -> GET latest DocumentSnapshot
  -> create EditorState(body, baseHash)
  -> edit transactions set dirty
  -> render preview from draft in memory
  -> Cmd+S sends body + If-Match(baseHash)
  -> mutation service validates and writes
  -> response replaces snapshot/baseHash
  -> dirty false; undo history remains editor-owned
```

Route changes and browser unload attempt are blocked or confirmed while dirty. Document saves never trigger a full-page HMR refresh.

### 14.4 External change lifecycle

```text
watcher observes registered file
  -> debounce and read stable snapshot
  -> compare known hash
  -> emit document.changed
  -> clean editor adopts snapshot
  -> dirty editor enters external-change state and keeps its draft
```

## 15. Port Contracts

```ts
interface ReadonlyWorkspacePort {
  loadDocument(id: string): Promise<DocumentSnapshot>;
  listDocuments(): Promise<DocumentSummary[]>;
  readEvidence(input: EvidenceReadRequest): Promise<EvidenceReadResult>;
}

interface WorkspacePort extends ReadonlyWorkspacePort {
  saveDocument(input: {
    id: string;
    baseHash: string;
    body: string;
  }): Promise<DocumentSnapshot>;
}

interface RuntimePort {
  readonly id: string;
  capabilities(): RuntimeCapabilities;
  startTurn(
    input: RuntimeTurnInput,
    sink: RuntimeEventSink,
    signal: AbortSignal,
  ): Promise<RuntimeTurnResult>;
  close(): Promise<void>;
}

interface GitPort {
  status(paths: string[]): Promise<GitPathStatus[]>;
  createCommit?(input: ExactFileCommit): Promise<GitCommitReceipt>;
}

interface EventLogPort {
  append(event: LearningEvent): Promise<void>;
  replay(afterSequence: number): AsyncIterable<LearningEvent>;
}
```

The implemented P0 uses a synchronous in-process `EventPort` with `publish`, ordered `subscribe(afterSequence)`, and `close`; the server adapter alone translates subscriptions into SSE headers, heartbeats, and response writes. `LearnEngine` depends on `WorkspacePort`, `EventPort`, and `RuntimePort`, never concrete filesystem, HTTP, or provider adapters.

An AST-based import-boundary gate enforces the modular-monolith direction:

```text
domain -> domain
ports -> domain | ports
application -> domain | ports | application
adapters -> domain | ports | adapters
server -> composition root; may assemble all backend layers
browser -> browser modules and browser dependencies only
```

Core layers cannot import React, Vite, HTTP transports, filesystem adapters, or provider adapters. Adapter code cannot import application orchestration or the server composition root.

The runtime receives a read-only evidence capability, not `saveDocument`. Only `DocumentService` may call canonical mutation methods.

## 16. Runtime Adapter Architecture

### 16.1 Provider-neutral rule

Provider events are normalized at the adapter boundary. Core understands `progress`, `answer-delta`, `evidence`, `proposal-candidate`, `completed`, `cancelled`, and `failed`; it does not understand Codex `thread/*`, Claude hook names, model slugs, or provider approval objects.

Missing capabilities return `E_UNSUPPORTED_CAPABILITY`. They are never converted into a successful empty answer.

### 16.2 First real adapter: Codex app-server

P0 uses `codex app-server` over `stdio` because the official contract is intended for rich clients and provides thread/turn lifecycle, streamed items, cancellation, and authentication reuse.

Adapter lifecycle:

```text
spawn codex app-server
  -> initialize / initialized handshake
  -> account/read capability check
  -> thread/start or thread/resume with project cwd
  -> turn/start in read-only sandbox
  -> map notifications to RuntimeEventSink
  -> turn/completed or turn/interrupt
  -> validate final structured learning result
```

Rules:

- Use `stdio` for P0; do not depend on experimental WebSocket transport.
- Keep the child process loopback/local and never expose it to the browser.
- Start threads without execution environments and disable inherited MCP servers. Expose workbench document tools and guides; canonical file access stays in the framework.
- Generate or inspect the app-server schema for the installed Codex version inside adapter tests; provider-specific generated types remain inside the adapter.
- If Codex is missing, unauthenticated, or protocol-incompatible, fail with a typed user-visible error and recovery instructions.
- Do not silently fall back to another model or `codex exec`.

### 16.3 Additional adapters

Claude, a direct model tool loop, or another runtime implements the same contract and passes the shared adapter suite. Adding a second adapter must require no changes to domain models or document mutation code.

## 17. Proposal and Mutation Contract

The Agent is an untrusted proposal generator.

1. Runtime output is parsed and schema-validated.
2. Every proposed document change references a registered document and `baseHash`.
3. The server computes a human-readable diff.
4. The UI shows affected documents, evidence, and the exact diff.
5. Accepting a proposal calls the same per-document mutation service as manual save.
6. If any base hash changed, the apply fails with `E_CONFLICT`; no subset is applied.
7. Successful application emits an immutable receipt and new snapshots.
8. Rejecting a proposal changes proposal state only.

Multi-document proposals use all-or-none preflight in P0: validate every base hash and candidate first, then apply. If reliable filesystem rollback cannot be guaranteed, P0 restricts accepted proposals to one document and returns `E_UNSUPPORTED_CAPABILITY` for multi-document apply rather than allowing partial success.

## 18. Local HTTP API

All endpoints bind to loopback and require a per-launch session token supplied to the development HTML through a non-persisted bootstrap mechanism. `transformIndexHtml` injects the token only during `serve`; the browser keeps it in memory and uses authenticated `fetch`, including for the SSE stream. The token is absent from source files and static builds. Validate `Host`, `Origin`, method, body type, size, and content type.

```text
GET    /api/v1/workspace
GET    /api/v1/documents
GET    /api/v1/documents/:id
PUT    /api/v1/documents/:id

POST   /api/v1/questions
POST   /api/v1/turns/:turnId/cancel
GET    /api/v1/turns/:turnId

GET    /api/v1/proposals/:proposalId
POST   /api/v1/proposals/:proposalId/accept
POST   /api/v1/proposals/:proposalId/reject

GET    /api/v1/events
GET    /api/v1/health
```

`PUT /documents/:id` requires both an `If-Match` hash and a body containing the same base hash. A mismatch between header and body is invalid input. Conflict responses include the current server snapshot metadata and a conflict ID, not an automatic merged body.

The browser resolves a conflict by showing both versions. Choosing “use mine” sends a new save against the now-visible current hash; there is no unconditional force-overwrite endpoint.

## 19. Event Contract

```ts
interface LearningEvent<TType extends string, TPayload> {
  version: 1;
  sequence: number;
  eventId: string;
  turnId?: string;
  type: TType;
  occurredAt: string;
  payload: TPayload;
}
```

P0 event types:

```text
workspace.ready
turn.queued
turn.context-progress
turn.runtime-started
turn.answer-delta
turn.evidence-added
turn.awaiting-review
turn.completed
turn.cancelled
turn.failed
proposal.created
proposal.accepted
proposal.rejected
proposal.conflict
document.changed
document.saved
```

Events are ordered per engine by `sequence`. SSE clients reconnect with `Last-Event-ID`; replay reads the bounded event log. Slow clients are disconnected with an explicit recoverable error and can replay. UI projections must be rebuildable from snapshots plus replayable events.

The browser reconnection acceptance test uses finite SSE responses to force disconnects, verifies reconnect URLs advance from the last accepted sequence, replays one duplicate plus one missed event, and finally returns the client to a real open stream. The resulting UI must contain one completed turn, not a duplicated projection.

## 20. Frontend Architecture

### 20.1 Primary layout

```text
┌──────────────────┬────────────────────────────────────────────┐
│ Questions/Agent   │ Document                                  │
│ active turn       │ read / Markdown editor / preview           │
│ progress/evidence │ selection toolbar                          │
│ answer/follow-ups │ proposal diff drawer                       │
│ history           │ conflict panel                             │
└──────────────────┴────────────────────────────────────────────┘
```

Navigation is collapsible and does not become a permanently competing third pane.

Routes:

```text
#/
#/doc/:id
#/doc/:id?edit=1
#/question/:turnId
#/map                         # P1
```

### 20.2 Frontend state slices

| Slice | Owner | Persistence | Rule |
|---|---|---|---|
| Workspace projection | React query/client store | refetch/replay | Server is authoritative |
| Active turn | event reducer | event replay | Never infer completion from lack of events |
| Editor session | CodeMirror `EditorState` + wrapper metadata | memory only in P0 | Preserve on Agent updates; prompt before unload |
| Preview | derived from current draft | none | Render draft, not stale server body |
| Proposal review | server proposal + UI selection | server proposal state | Cannot mark accepted before receipt |
| Selection anchor | document selection service | current question | Resolve or show detached state |

Use React context plus focused reducers/services for P0. Do not introduce a global state library until event projection complexity demonstrates the need.

## 21. Selection and Anchoring

Reading-mode selection creates:

```text
{ documentId, headingPath, exactQuote, prefix, suffix, snapshotHash }
```

Resolution order:

1. exact quote in the same snapshot;
2. exact quote in the current document;
3. quote with prefix/suffix scoring;
4. heading-path fallback marked as degraded;
5. detached anchor shown as unresolved.

The browser exposes four resolution states: `exact`, `contextual`, `heading`, and `detached`. `contextual` requires both a sufficiently long prefix suffix and suffix prefix around one bounded candidate range; a one-sided or ambiguous context is not accepted. `heading` scrolls to the deepest surviving heading and is visibly marked as degraded. `detached` never guesses. The submitted turn retains the validated anchor and source `snapshotHash`, so resolution can be recomputed whenever the canonical document or a proposal preview changes.

P0 selection actions are `Ask` and `Revise`. P1 adds `Trace code`, `Expand`, and `Create experiment`; they remain prompt presets mapped to the same answer/revise schema rather than new backend commands.

Never inject hidden block IDs into Markdown solely to support selection. Never reverse-convert edited rendered HTML into Markdown.

## 22. Markdown, Rich Content, and Rendering

Canonical prose remains portable Markdown. The renderer parses to an AST, applies GFM and a small directive registry, then sanitizes HTML through a strict allowlist.

P0 supports standard Markdown, tables, code fences, task lists, and blockquotes. P1 adds a deliberately small sanitized directive registry:

```text
note
warning
experiment
```

Other directive names remain ordinary portable Markdown until a concrete renderer and fixture are added. Raw scripts, event-handler attributes, `javascript:` URLs, remote executable embeds, and unsanitized HTML are forbidden.

## 23. Filesystem, Concurrency, and Conflict Safety

Every save or accepted proposal follows this algorithm:

1. Resolve document ID through the manifest.
2. Resolve `realpath`; verify it remains under an allowed content root and is a registered `.md` file.
3. Reject symlink escape, traversal, oversized body, invalid UTF-8, and forbidden content.
4. Acquire the per-document mutation queue.
5. Read the current file and compute its content hash.
6. Compare the supplied base hash; return `E_CONFLICT` when it differs.
7. Validate the candidate Markdown in memory.
8. Write a unique temporary file in the same directory.
9. Flush, close, and rename over the target.
10. Read back and verify the final hash.
11. Emit `document.saved` and rebuild affected projections.
12. Release the queue in `finally`.

There is no last-write-wins path. Errors cannot be converted to warnings plus stale content.

## 24. Security Contract

- Treat repository text, Markdown, Agent output, runtime events, and URLs as untrusted input.
- Bind development APIs to `127.0.0.1` only.
- Validate `Host` and exact allowed `Origin` to mitigate DNS rebinding.
- Require a high-entropy per-launch session token on mutation, question, proposal, and event endpoints.
- Keep provider credentials in runtime-owned user configuration or environment; never expose them to the browser or static build.
- Spawn executables with argument arrays and explicit cwd; never interpolate model output into a shell command.
- Give runtime adapters read-only project access for question turns.
- Limit document bytes, request bytes, event bytes, turn duration, concurrent turns, and event replay size.
- Redact likely secrets before persisting diagnostic events.
- Sanitize rendered HTML and test XSS fixtures.
- Production output contains no mutation handlers, session token, runtime bridge, or secrets.

P0 permits one active Agent turn per workspace. A second request receives `E_BUSY` with the active turn ID; it is not silently queued forever.

## 25. Error Policy

```text
E_CONFIG_INVALID
E_MANIFEST_INVALID
E_NOT_FOUND
E_OUT_OF_SCOPE
E_PATH_ESCAPE
E_TOO_LARGE
E_CONFLICT
E_INVALID_MARKDOWN
E_INVALID_PROPOSAL
E_BUSY
E_RUNTIME_UNAVAILABLE
E_RUNTIME_AUTH
E_RUNTIME_PROTOCOL
E_RUNTIME_CANCELLED
E_UNSUPPORTED_CAPABILITY
E_EVENT_BACKPRESSURE
E_WRITE_FAILED
E_GIT_FAILED
```

| Class | Examples | Behavior |
|---|---|---|
| Recoverable user action | conflict, busy, cancellation, detached anchor | Preserve draft/state and show recovery choices |
| Command-fatal | invalid proposal, path escape, failed write, runtime auth | Fail command visibly; no partial mutation |
| Process-fatal at startup | invalid config, invalid manifest, duplicate IDs, root escape | Do not start interactive service |
| Diagnostic only | cache miss, index rebuild reason, timing | Log without changing user-visible correctness |

Adapters preserve cause and provider details internally but map them to stable public errors with redacted diagnostics.

## 26. Configuration and Observability

Configuration precedence:

```text
CLI flags
  -> explicitly supported environment overrides
  -> learn.config.json
  -> safe defaults
```

The composition root reads configuration once and passes typed values inward. Runtime reload is not supported in P0.

Structured diagnostics include:

- workspace ID and process lifecycle;
- turn ID, provider adapter, status, and duration;
- queue depth and active document mutation;
- event sequence and SSE client replay position;
- proposal ID, affected document IDs, and outcome;
- save duration and conflict count;
- renderer and index rebuild reason.

Never log full credentials, environment dumps, raw private prompts by default, or entire document bodies.

## 27. Boundary Contract Matrix

| Contract | Owner | Allowed dependencies | Forbidden dependencies | Required tests |
|---|---|---|---|---|
| State ownership | `LearnEngine` + browser editor session | domain models, ports, reducer projections | hidden globals; Agent-owned canonical state | `state-owner.spec.ts`, editor external-change E2E |
| Lifecycle | application runtime | clock, event log, runtime port, abort signals | provider SDK in application services | `engine-lifecycle.spec.ts`, shutdown E2E |
| Events/actions | versioned domain schemas | Zod, event log | React component types; provider event types | `event-contract.spec.ts`, reconnect E2E |
| Filesystem effects | filesystem adapter | Node `fs/path`, hash service | unchecked user paths; IO in domain | `filesystem.contract.ts`, traversal/symlink suite |
| Document mutation | `DocumentService` | workspace port, per-doc queue, renderer validation | direct HTTP/Vite writes; last-write-wins | `document-mutation.spec.ts`, conflict E2E |
| Runtime execution | runtime adapters | child process/provider client, read-only evidence port | canonical save port; provider types in core | `runtime-adapter.contract.ts`, Codex fixture suite |
| Proposal review | `ProposalService` | domain diff, document service | direct Agent apply; partial multi-file apply | `proposal-service.spec.ts`, accept/reject E2E |
| HTTP/SSE | server adapter | application commands/events, session guard | business logic in handlers | `http.contract.ts`, origin/token/security tests |
| Editor | browser editor module | CodeMirror state, typed API client | file APIs; contenteditable Markdown recovery | `editor-session.spec.ts`, save/undo E2E |
| Rendering | renderer adapter | Markdown AST, directive registry, sanitizer | arbitrary script/eval | `renderer-security.spec.ts`, static fixture test |
| Config/resources | composition root | config parser, env adapter | env reads in domain/application | `config-contract.spec.ts` |
| Observability | redacted event/diagnostic sink | typed metadata | credentials, full env, canonical content bodies | `redaction.spec.ts` |
| Static output | Vite build adapter | registered Markdown, renderer | Node server/runtime imports | `static-readonly.spec.ts`, preview E2E |
| Git | Git adapter | executable + argument arrays | shell concatenation; implicit staged files | `git.contract.ts` |

## 28. Compatibility and Deletion Plan

| Path or bridge | Why it exists | Owner | Keep until | Delete or converge when |
|---|---|---|---|---|
| Build-only virtual Markdown module | Inlines registered Markdown into the static production artifact | Web adapter | Static build remains the supported publishing format | Replace only if a future renderer preserves the read-only boundary |
| React `learn/src/main.tsx` | Canonical reading, editing, question, and proposal surface | Web adapter | Current P0 UI | Split components when independent ownership or measured bundle pressure requires it |
| `marked` renderer | Existing safe-enough prototype with DOMPurify | Renderer adapter | unified/remark pipeline passes current content fixtures | Remove direct `marked` calls from UI |
| Skill-bundled site template | Bootstrap created the current prototype | Skill | Canonical app has install/init command | Skill references packaged app; delete copied template |
| Cuter catalog bridge | Compatibility with prior learning site | Integration adapter | Manifest reproduces catalog behavior | Cuter build/E2E passes from manifest alone |
| Codex app-server generated schema | Matches installed Codex protocol | Codex adapter | Adapter supports declared Codex version range | Regenerate on supported version changes; never promote to core schema |
| No-Git mode | Current directory is not a Git repo | Git adapter | User initializes Git or chooses to remain file-only | Keep as explicit supported mode; no fake history |

## 29. Validation Matrix

`npm run typecheck`, `npm test`, `npm run test:architecture`, `npm run test:contracts`, `npm run test:security`, `npm run test:static-readonly`, `npm run test:e2e`, and `npm run build` now exist and pass. The current E2E suite uses system Chrome on isolated loopback ports and never saves its draft fixture into canonical Markdown.

| Gate | Command | Evidence required |
|---|---|---|
| Type checking | `npm run typecheck` | strict TypeScript passes |
| Import boundaries | `npm run test:architecture` | core, adapter, server, and browser dependency directions pass |
| Unit tests | `npm test` | domain and application decisions pass with fake adapters |
| Adapter contracts | `npm run test:contracts` | filesystem, runtime, Git, renderer, HTTP contracts pass |
| Security | `npm run test:security` | traversal, symlink, token, origin, XSS, size, and command fixtures pass |
| Editor | `npm run test:e2e -- editor` | edit, preview, Cmd+S, undo, dirty navigation, reload pass |
| Agent turn | `npm run test:e2e -- question` | ask, stream, cancel, error, and reconnect pass |
| Proposal | `npm run test:e2e -- proposal` | diff, reject, accept, conflict, and no partial apply pass |
| Selection | `npm run test:e2e -- selection` | select, ask, revise, degraded/detached anchor pass |
| Static build | `npm run build` | registered content builds to static assets |
| Static write exclusion | `npm run test:static-readonly` | bundle/import graph and preview expose no write/runtime path |
| Full vertical slice | `npm run test:e2e -- learning-loop` | the ten-step acceptance scenario in `PRODUCT_INTENT.md` passes |

## 30. P0-P5 Delivery Roadmap

The priorities are delivery gates, not six increasingly speculative feature piles. A later stage cannot be called complete while an earlier gate is red. Cloud accounts, multi-user CRDT editing, billing, and a native shell remain outside these stages unless P5 product evidence explicitly changes the decision.

| Priority | Work | Files/modules | Done when | Verification |
|---|---|---|---|---|
| P0 | Root TypeScript scaffold and dependency boundaries | root config, `src/domain`, `src/ports`, import rules | current manifest loads through typed schema | `npm run typecheck && npm test -- schema` |
| P0 | Headless LearnEngine with fake runtime | `src/application`, fake adapters | one deterministic question creates a validated pending proposal | `npm test -- engine turn proposal` |
| P0 | Safe document mutation and watcher | filesystem adapter, `DocumentService` | manual and proposal saves share hash/atomic path | `npm run test:security && npm run test:contracts -- filesystem` |
| P0 | Loopback API, session guard, and SSE | `src/server` | typed commands and replayable events work on one origin | `npm run test:contracts -- http events` |
| P0 | React read/edit/preview migration | `learn/src` document/editor modules | existing pages read; edit/save/undo/dirty flow works | `npm run test:e2e -- editor` |
| P0 | Codex app-server adapter | runtime-codex adapter | real turn streams, cancels, validates result, and cannot write | `npm run test:contracts -- runtime-codex` |
| P0 | Question panel and proposal review | questions/proposals UI + services | ask → stream → diff → accept/reject is complete | `npm run test:e2e -- question proposal` |
| P0 | Selection Ask/Revise | selection module and anchors | selected passage seeds a turn and survives expected edits | `npm run test:e2e -- selection` |
| P0 | Static production boundary | Vite build adapter | same accepted Markdown renders; no mutation/runtime surface ships | `npm run build && npm run test:static-readonly` |
| P0 | Full acceptance and failure closure | E2E/security fixtures | complete learning loop, conflict, cancellation, restart all pass | `npm run test:e2e -- learning-loop && npm run test:security` |
| P0 | Streaming evidence, renderer, and runtime readiness | event projection, evidence types, renderer, runtime diagnostics | answer deltas are visible; evidence is typed; unsafe Markdown is rejected; incompatible Runtime fails before first question | `npm run test:p0` |
| P1 | Agent-reviewed create/rename/delete page proposals | manifest service + proposal extensions | structural change is reviewed and atomic | `npm run test:e2e -- structural-proposal` |
| P1 | Rich directives and evidence staleness | renderer/stale services | directives sanitize; changed evidence is flagged | `npm test -- renderer staleness` |
| P1 | More selection actions and knowledge map | web modules | trace/expand/experiment and useful relation map work | `npm run test:e2e -- selection map` |
| P1 | Full knowledge-growth acceptance | domain, filesystem, API, renderer and browser fixtures | structure proposals, search, map, directives and staleness pass together | `npm run test:p1` |
| P2 | Headless SDK, CLI, and MCP v2 server | composition adapters/packages | separately built consumers reuse the same engine and schemas | `npm run test:p2` |
| P2 | Second runtime adapter | provider adapter | one shared adapter suite passes without core changes | `npm run test:contracts -- runtime-all` |
| P3 | Exact-file Git history and reviewed revert | Git/history modules | accepted human/Agent mutations produce scoped receipts and can be reverted without touching unrelated files | `npm run test:p3` |
| P3 | Durable turn and decision receipts | receipt store | restart restores audit metadata without making receipts a content authority | `npm run test:contracts -- receipts restart` |
| P4 | Canonical installer and Skill convergence | init package, Skill integration contract | a fresh repository receives this workbench rather than the legacy static template | `npm run test:p4` |
| P4 | IDE/deep-link entry | URL/extension adapter | selected code can open a grounded website question without owning canonical state | `npm run test:e2e -- deep-link` |
| P5 | Release diagnostics, compatibility, and security closure | doctor, compatibility matrix, security fixtures | supported environments fail clearly; logs redact content/secrets; release artifact passes distribution validation | `npm run test:p5` |
| P5 | Native and hosted product decisions | benchmark and product-evidence reports | evidence produces an explicit build/defer decision; lack of evidence results in defer, not speculative infrastructure | `npm run validate:distribution && npm run validate:product-evidence` |

## 31. Issue and PR Map

The directory is now a local Git repository on `main`; the initial implementation baseline is commit `43dab41`. No remote repository, issues, or PRs exist. Keep Section 30 plus the registered retrospective page as the canonical implementation tracker rather than creating parallel task lists in the Skill.

## 32. Primary Risks

1. **The UI becomes a chat app with a Markdown preview.** Mitigation: acceptance tests require manual editing, proposal review, selection actions, and persisted website changes.
2. **The Agent silently becomes the document owner.** Mitigation: read-only runtime capability, base-hash proposal, explicit accept, shared mutation service.
3. **Provider details leak into core.** Mitigation: normalized runtime events and a second-adapter contract gate before P2 completion.
4. **Dirty drafts are lost during HMR or external changes.** Mitigation: editor-owned state, no full reload on save, route/unload guards, explicit external-change state.
5. **Development write capability leaks into production.** Mitigation: separate composition profiles and static import-graph/write-endpoint tests.
6. **The modular monolith becomes an unstructured monolith.** Mitigation: forbidden dependency tests and explicit ports before package extraction.
7. **Knowledge grows in volume but not usefulness.** Mitigation: evidence states, direct answer, experiment, prerequisites, next questions, and audit rubric.
8. **Selection anchors drift after Agent rewrites.** Mitigation: quote/context/heading resolution with a visible degraded or detached state.
9. **A runtime failure degrades into a plausible empty answer.** Mitigation: typed errors and no fallback without explicit user choice.
10. **Git absence is mistaken for data loss or fake history.** Mitigation: file-safe operation remains valid; history UI states Git is unavailable.

## 33. Open Questions and P0 Defaults

| Question | P0 default | Revisit trigger |
|---|---|---|
| Product name | internal name `learn` | Before packaging/public release |
| First runtime | Codex app-server over stdio | Contract spike proves required surface unavailable |
| Runtime write permission | read-only | A reviewed isolated-worktree proposal flow is separately designed |
| Concurrent turns | one per workspace | Real use shows parallel questions are necessary |
| Multi-document proposal | reject as unsupported unless atomicity is proven | Transaction/rollback design passes failure injection |
| Unsaved draft persistence | memory + navigation/unload guard | Users require crash recovery; add session draft cache without authority confusion |
| Auto-commit | off | Users explicitly opt into exact-file commits |
| Database | none | Search/event replay measurements show file-based state inadequate |
| Browser-only mode | unsupported for canonical writes/runtime | Cross-browser zero-install demand is demonstrated |
| Page creation in UI | Agent proposal plus explicit review | Users require a manual blank-page form; do not add before installation evidence |
| Port | config default, loopback only; choose another allowed free port on conflict | Existing matching server can be reused |

## 34. Readiness

The P0 vertical slice is now implemented: the React workbench reads fresh development snapshots, owns in-memory drafts, saves through hash-protected atomic replacement, streams real read-only Codex app-server turns, holds Markdown proposals for explicit review, supports selection-seeded Ask/Revise, and produces a static read-only build from the same sources.

Fresh implementation evidence on 2026-08-28 includes strict typecheck, AST-enforced import directions, filesystem/engine/event/HTTP tests, token and origin security gates, real Codex answer, revision, and immediate-cancellation turns over SSE, deterministic SSE decoder tests, four-state quote/context/heading anchor recovery, and Playwright coverage for dirty editor preview, persisted selection anchors with click-to-locate, forced SSE disconnect with sequence replay and duplicate suppression, cross-document anchor cleanup, 390 px layout, and static edit-route exclusion. The production preview write route returns 404 and its assets exclude the development-only CodeMirror implementation. The production JavaScript entry dropped from about 805 kB to about 310 kB after the editor boundary became development-only.

The precise status after the 2026-08-30 closure is **P0-P5 accepted as a local pre-alpha**, not “perfect” and not a public hosted-service claim. P5 adds a read-only `doctor`, an explicit compatibility matrix, diagnostic redaction, CSP, dependency audits, npm pack inspection, and machine-validated product decisions. The package is locally packable and installable; public registry publication remains unclaimed. Evidence for a native shell and hosted platform is currently absent, so both decisions are deliberately `defer`. The next work must come from real external-user evidence rather than another speculative platform layer.
