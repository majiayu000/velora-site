const SECRET_PATTERNS = [
  /\bBearer\s+[A-Za-z0-9._~+/=-]+/gi,
  /\b(?:sk|rk|pk)-[A-Za-z0-9_-]{12,}/g,
  /\b(?:api[_-]?key|access[_-]?token|authorization|password)\s*[:=]\s*[^\s,;]+/gi,
];

export function redactDiagnostic(value: string, limit = 800): string {
  let redacted = value.replace(/[\r\n\t]+/g, " ").trim();
  for (const pattern of SECRET_PATTERNS) redacted = redacted.replace(pattern, "[REDACTED]");
  redacted = redacted.replace(/\/(?:Users|home)\/[^/\s]+/g, "/[HOME]");
  return redacted.length > limit ? `${redacted.slice(0, limit)}…` : redacted;
}
