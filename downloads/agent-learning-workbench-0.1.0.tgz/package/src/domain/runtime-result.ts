import { validateEvidenceReferences } from "./evidence";
import { LearnError } from "./errors";
import { validateStructureOperations } from "./structure";
import type { RuntimeRequest, RuntimeResult } from "./types";

export function validateRuntimeResult(value: unknown, request?: RuntimeRequest): RuntimeResult {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new LearnError("RUNTIME_PROTOCOL_ERROR", "Runtime result must be an object", 502);
  }
  const result = value as Partial<RuntimeResult>;
  if (typeof result.answerMarkdown !== "string" || !result.answerMarkdown.trim()) {
    throw new LearnError("RUNTIME_PROTOCOL_ERROR", "Runtime result did not contain an answer", 502);
  }
  const evidence = validateEvidenceReferences(result.evidence);
  let proposal: RuntimeResult["proposal"];
  if (result.proposal === null) proposal = null;
  else if (result.proposal && typeof result.proposal.summary === "string" && typeof result.proposal.replacementMarkdown === "string") {
    proposal = { summary: result.proposal.summary.trim(), replacementMarkdown: result.proposal.replacementMarkdown };
    if (!proposal.summary) throw new LearnError("RUNTIME_PROTOCOL_ERROR", "Runtime proposal summary is required", 502);
    if (request?.intent === "revise" && request.document && proposal.replacementMarkdown === (request.target ? request.document.body.slice(request.target.from, request.target.to) : request.document.body)) {
      throw new LearnError("EMPTY_PROPOSAL", "Runtime did not change the requested document", 422);
    }
  } else throw new LearnError("RUNTIME_PROTOCOL_ERROR", "Runtime proposal was malformed", 502);

  let structureProposal: RuntimeResult["structureProposal"];
  if (result.structureProposal === null) structureProposal = null;
  else if (result.structureProposal && typeof result.structureProposal.summary === "string" && result.structureProposal.summary.trim()) {
    structureProposal = {
      summary: result.structureProposal.summary.trim(),
      operations: validateStructureOperations(result.structureProposal.operations),
    };
  } else throw new LearnError("RUNTIME_PROTOCOL_ERROR", "Runtime structure proposal was malformed", 502);
  if (proposal && structureProposal) throw new LearnError("RUNTIME_PROTOCOL_ERROR", "Runtime returned two incompatible proposal kinds", 502);
  return { answerMarkdown: result.answerMarkdown, evidence, proposal, structureProposal };
}
