export class LearnError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly status = 400,
    public readonly details?: Record<string, unknown>,
  ) {
    super(message);
    this.name = "LearnError";
  }
}

export function asLearnError(error: unknown): LearnError {
  if (error instanceof LearnError) return error;
  const message = error instanceof Error ? error.message : "Unknown error";
  return new LearnError("INTERNAL_ERROR", message, 500);
}
