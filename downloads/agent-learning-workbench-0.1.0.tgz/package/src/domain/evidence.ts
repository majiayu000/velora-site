import { LearnError } from "./errors";
import type { EvidenceReference } from "./types";

const SAFE_STATES = new Set<EvidenceReference["state"]>(["verified", "inferred", "unknown"]);

function invalid(message: string): never {
  throw new LearnError("INVALID_EVIDENCE", message, 422);
}

function validatePath(value: unknown): string | undefined {
  if (value === undefined || value === null) return undefined;
  if (typeof value !== "string" || !value || value.length > 500) invalid("Evidence path must contain 1 to 500 characters");
  if (
    value.startsWith("/") ||
    /^[A-Za-z]:\//.test(value) ||
    value.includes("\\") ||
    /^[a-z]+:\/\//i.test(value) ||
    /[\u0000-\u001f]/.test(value) ||
    value.split("/").some((segment) => segment === "." || segment === ".." || !segment)
  ) {
    invalid("Evidence path must be a normalized repository-relative path");
  }
  return value;
}

export function validateEvidenceReferences(value: unknown): EvidenceReference[] {
  if (!Array.isArray(value) || value.length > 100) invalid("Evidence must be an array with at most 100 entries");
  return value.map((candidate, index) => {
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) invalid(`Evidence ${index} must be an object`);
    const item = candidate as Record<string, unknown>;
    if (typeof item.state !== "string" || !SAFE_STATES.has(item.state as EvidenceReference["state"])) {
      invalid(`Evidence ${index} has an invalid state`);
    }
    if (typeof item.label !== "string" || !item.label.trim() || item.label.length > 500) {
      invalid(`Evidence ${index} label must contain 1 to 500 characters`);
    }
    const path = validatePath(item.path);
    if (item.state === "verified" && !path) invalid(`Verified evidence ${index} must name a learning document path`);
    if (item.line !== undefined && item.line !== null && (!Number.isInteger(item.line) || Number(item.line) < 1 || Number(item.line) > 10_000_000 || !path)) {
      invalid(`Evidence ${index} line must be a positive integer attached to a path`);
    }
    if (item.detail !== undefined && item.detail !== null && (typeof item.detail !== "string" || item.detail.length > 2_000)) {
      invalid(`Evidence ${index} detail must contain at most 2000 characters`);
    }
    return {
      state: item.state as EvidenceReference["state"],
      label: item.label.trim(),
      path,
      line: typeof item.line === "number" ? item.line : undefined,
      detail: typeof item.detail === "string" ? item.detail.trim() || undefined : undefined,
    };
  });
}
