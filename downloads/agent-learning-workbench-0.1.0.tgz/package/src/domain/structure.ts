import { LearnError } from "./errors";
import type { DocumentMetadata, StructureOperation } from "./types";

function invalidStructure(message: string): never {
  throw new LearnError("INVALID_STRUCTURE_PROPOSAL", message, 422);
}

function requiredText(value: unknown, field: string, maximum: number): string {
  if (typeof value !== "string" || !value.trim() || value.length > maximum) {
    invalidStructure(`${field} must contain 1 to ${maximum} characters`);
  }
  return value.trim();
}

function optionalText(value: unknown, field: string, maximum: number): string | undefined {
  if (value === undefined || value === null) return undefined;
  return requiredText(value, field, maximum);
}

function boundedText(value: unknown, field: string, maximum: number): string {
  if (typeof value !== "string" || value.length > maximum) invalidStructure(`${field} must be a string with at most ${maximum} characters`);
  return value.trim();
}

function stringList(value: unknown, field: string, maximumItems: number): string[] | undefined {
  if (value === undefined || value === null) return undefined;
  if (!Array.isArray(value) || value.length > maximumItems) invalidStructure(`${field} must be a short string array`);
  const normalized = value.map((item) => requiredText(item, field, 100));
  if (new Set(normalized).size !== normalized.length) invalidStructure(`${field} must not contain duplicates`);
  return normalized;
}

export function validateDocumentId(value: unknown): string {
  const id = requiredText(value, "document id", 80);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id)) invalidStructure("document id must be lowercase kebab-case");
  return id;
}

export function validateMarkdownPath(value: unknown): string {
  const candidate = requiredText(value, "document path", 500);
  if (
    candidate.startsWith("/") ||
    candidate.includes("\\") ||
    /^[a-z]+:\/\//i.test(candidate) ||
    /[\u0000-\u001f]/.test(candidate) ||
    candidate.split("/").some((segment) => !segment || segment === "." || segment === "..") ||
    !candidate.toLowerCase().endsWith(".md")
  ) {
    invalidStructure("document path must be a normalized repository-relative Markdown path");
  }
  return candidate;
}

export function validateDocumentMetadata(value: unknown): DocumentMetadata {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalidStructure("create.document must be an object");
  const candidate = value as Record<string, unknown>;
  return {
    id: validateDocumentId(candidate.id),
    path: validateMarkdownPath(candidate.path),
    title: requiredText(candidate.title, "document title", 200),
    summary: boundedText(candidate.summary, "document summary", 500),
    stage: optionalText(candidate.stage, "document stage", 40),
    tags: stringList(candidate.tags, "document tags", 30),
    prerequisites: stringList(candidate.prerequisites, "document prerequisites", 30)?.map(validateDocumentId),
    related: stringList(candidate.related, "document related", 30)?.map(validateDocumentId),
  };
}

export function validateStructureOperations(value: unknown, sizeLimitBytes = 1024 * 1024): StructureOperation[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > 20) {
    invalidStructure("structure proposal must contain 1 to 20 operations");
  }
  const touched = new Set<string>();
  return value.map((entry, index) => {
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) invalidStructure(`operation ${index} must be an object`);
    const operation = entry as Record<string, unknown>;
    if (operation.type === "create") {
      const document = validateDocumentMetadata(operation.document);
      if (touched.has(document.id)) invalidStructure(`document ${document.id} is changed more than once`);
      touched.add(document.id);
      if (typeof operation.body !== "string" || new TextEncoder().encode(operation.body).byteLength > sizeLimitBytes) {
        invalidStructure(`create body for ${document.id} exceeds the Markdown size limit`);
      }
      return { type: "create", document, body: operation.body };
    }
    const documentId = validateDocumentId(operation.documentId);
    if (touched.has(documentId)) invalidStructure(`document ${documentId} is changed more than once`);
    touched.add(documentId);
    if (operation.type === "update") return {
      type: "update", documentId,
      title: requiredText(operation.title, "document title", 200),
      summary: boundedText(operation.summary, "document summary", 500),
    };
    if (operation.type === "rename") {
      return {
        type: "rename",
        documentId,
        nextPath: validateMarkdownPath(operation.nextPath),
        title: optionalText(operation.title, "renamed document title", 200),
      };
    }
    if (operation.type === "delete") return { type: "delete", documentId };
    return invalidStructure(`operation ${index} has an unsupported type`);
  });
}
