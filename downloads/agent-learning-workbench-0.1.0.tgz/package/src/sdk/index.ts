import type { BlockOperation } from "../ports/collaboration-port";
import { createLearnEngine } from "../composition/create-learn-engine";
import { LearnError } from "../domain/errors";
import type { AuditReceipt, DocumentSnapshot, LearnEvent, Proposal, QuestionRequest, RevertPreview, SearchResult, StructureProposal, TurnRecord, WorkspaceInsights, WorkspaceSnapshot } from "../domain/types";
import type { RuntimePort } from "../ports/runtime-port";

export type QuestionOutcome = {
  turn: TurnRecord;
  proposal?: Proposal;
  structureProposal?: StructureProposal;
};

export class LearnWorkbenchSdk {
  constructor(private readonly engine: Awaited<ReturnType<typeof createLearnEngine>>) {}

  blocks(id: string) {
    if (!this.engine.collaboration) throw new LearnError("STATIC_BUILD", "Collaboration is unavailable", 405);
    return this.engine.collaboration.read(id);
  }
  applyOperations(id: string, operations: BlockOperation[]) {
    if (!this.engine.collaboration) throw new LearnError("STATIC_BUILD", "Collaboration is unavailable", 405);
    return this.engine.collaboration.operate(id, operations);
  }
  workspace(): WorkspaceSnapshot { return this.engine.getWorkspace(); }
  document(id: string): Promise<DocumentSnapshot> { return this.engine.store.getDocument(id); }
  search(query: string, limit?: number): Promise<SearchResult[]> { return this.engine.search(query, limit); }
  insights(): WorkspaceInsights { return this.engine.getInsights(); }
  saveDocument(id: string, body: string, expectedHash: string): Promise<DocumentSnapshot> { return this.engine.saveDocument(id, body, expectedHash); }
  acceptProposal(id: string) { return this.engine.acceptProposal(id); }
  rejectProposal(id: string) { return this.engine.rejectProposal(id); }
  acceptStructureProposal(id: string) { return this.engine.acceptStructureProposal(id); }
  rejectStructureProposal(id: string) { return this.engine.rejectStructureProposal(id); }
  refreshEvidence(turnId: string) { return this.engine.refreshEvidence(turnId); }
  receipts(): AuditReceipt[] { return this.engine.listReceipts(); }
  previewRevert(receiptId: string): Promise<RevertPreview> { return this.engine.previewRevert(receiptId); }
  revertReceipt(receiptId: string) { return this.engine.revertReceipt(receiptId); }
  subscribe(listener: (event: LearnEvent) => void, afterSequence = 0): () => void { return this.engine.events.subscribe(listener, afterSequence); }

  async ask(request: QuestionRequest, options: { signal?: AbortSignal; timeoutMs?: number } = {}): Promise<QuestionOutcome> {
    const timeoutMs = options.timeoutMs ?? 120_000;
    let turnId = "";
    let unsubscribe: () => void = () => undefined;
    let timeout: NodeJS.Timeout | undefined;
    let abortListener: (() => void) | undefined;
    try {
      const outcome = new Promise<QuestionOutcome>((resolve, reject) => {
        const finalizeTurn = (error?: unknown) => {
          if (!turnId) return;
          const turn = this.engine.getTurn(turnId);
          if (turn.status === "running") return;
          if (error) { reject(error); return; }
          if (turn.status === "failed") { reject(new LearnError("TURN_FAILED", turn.error ?? "Agent turn failed", 502)); return; }
          if (turn.status === "cancelled") { reject(new LearnError("TURN_CANCELLED", turn.error ?? "Agent turn cancelled", 409)); return; }
          resolve({
            turn,
            proposal: turn.proposalId ? this.engine.getProposal(turn.proposalId) : undefined,
            structureProposal: turn.structureProposalId ? this.engine.getStructureProposal(turn.structureProposalId) : undefined,
          });
        };
        unsubscribe = this.engine.events.subscribe((event) => {
          if (["turn.completed", "turn.failed", "turn.cancelled"].includes(event.type) && (event.payload.turn as TurnRecord | undefined)?.id === turnId) finalizeTurn();
        });
        const turn = this.engine.createQuestion(request);
        turnId = turn.id;
        timeout = setTimeout(() => {
          void this.engine.cancelTurn(turnId).finally(() => reject(new LearnError("TURN_TIMEOUT", "Agent turn timed out", 504)));
        }, timeoutMs);
        abortListener = () => { void this.engine.cancelTurn(turnId); };
        options.signal?.addEventListener("abort", abortListener, { once: true });
      });
      return await outcome;
    } finally {
      unsubscribe();
      if (timeout) clearTimeout(timeout);
      if (abortListener) options.signal?.removeEventListener("abort", abortListener);
    }
  }

  close(): void { this.engine.close(); }
}

export async function createLearnWorkbench(options: { repositoryRoot: string; runtime?: RuntimePort }): Promise<LearnWorkbenchSdk> {
  return new LearnWorkbenchSdk(await createLearnEngine({ repositoryRoot: options.repositoryRoot, runtime: options.runtime }));
}

export type { EditTarget, AuditReceipt, DocumentSnapshot, EvidenceReference, LearnEvent, MutationReceipt, Proposal, QuestionRequest, RevertPreview, SearchResult, StructureProposal, TurnRecord, WorkspaceInsights, WorkspaceSnapshot } from "../domain/types";
export type { RuntimeCallbacks, RuntimePort } from "../ports/runtime-port";

export type { BlockOperation, DocumentBlock, CollaborationSnapshot } from "../ports/collaboration-port";
