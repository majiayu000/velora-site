import type { LearnEvent } from "../domain/types";
import { redactDiagnostic } from "../domain/redact";
import type { EventPort, EventSink } from "../ports/event-port";

export class EventHub implements EventPort {
  private sequence = 0;
  private readonly history: LearnEvent[] = [];
  private readonly clients = new Set<EventSink>();

  publish(type: string, payload: Record<string, unknown>): LearnEvent {
    const event: LearnEvent = {
      sequence: ++this.sequence,
      type,
      at: new Date().toISOString(),
      payload,
    };
    this.history.push(event);
    if (this.history.length > 1000) this.history.shift();
    for (const sink of this.clients) {
      try {
        sink(event);
      } catch (error) {
        this.clients.delete(sink);
        console.error("Learn event subscriber failed", redactDiagnostic(error instanceof Error ? error.message : String(error)));
      }
    }
    return event;
  }

  subscribe(sink: EventSink, after = 0): () => void {
    for (const event of this.history) {
      if (event.sequence > after) sink(event);
    }
    this.clients.add(sink);
    return () => this.clients.delete(sink);
  }

  close(): void {
    this.clients.clear();
  }
}
