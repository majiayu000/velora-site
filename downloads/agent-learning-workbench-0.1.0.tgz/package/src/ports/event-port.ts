import type { LearnEvent } from "../domain/types";

export type EventSink = (event: LearnEvent) => void;

export interface EventPort {
  publish(type: string, payload: Record<string, unknown>): LearnEvent;
  subscribe(sink: EventSink, after?: number): () => void;
  close(): void;
}
