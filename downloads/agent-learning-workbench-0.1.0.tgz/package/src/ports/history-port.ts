import type { RevertPreview } from "../domain/types";

export type GitCommitResult =
  | { status: "committed"; commit: string }
  | { status: "unavailable" | "failed"; message: string };

export interface HistoryPort {
  initialize(): Promise<void>;
  commit(files: string[], message: string): Promise<GitCommitResult>;
  previewRevert(receiptId: string, commit: string, files: string[]): Promise<RevertPreview>;
  applyRevert(receiptId: string, commit: string, files: string[]): Promise<GitCommitResult>;
}
