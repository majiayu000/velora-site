import type { DocumentSnapshot } from "../domain/types";

export type DocumentBlock = { id: string; markdown: string; hash: string; sourceOnly: boolean; from: number; to: number };
export type BlockOperation =
  | { type: "insert"; after: string | null; markdown: string }
  | { type: "replace" | "delete"; blockId: string; ifHash: string; markdown?: string };
export type DocumentEditOperation =
  | { type: "insert"; after: string | null }
  | { type: "replace"; blockId: string; ifHash: string };
export type DocumentEditEvent = { editId: string } & (
  | { type: "started"; operation: DocumentEditOperation }
  | { type: "delta"; delta: string; offset: number }
  | { type: "committed"; revision: number; blockIds: string[] }
  | { type: "aborted"; reason: string }
);
export type CollaborationSnapshot = { state: string; vector: string; revision: number; blocks: DocumentBlock[]; document: DocumentSnapshot };
export interface CollaborationPort {
  read(id: string): Promise<CollaborationSnapshot>;
  sync(id: string, update: string, vector: string): Promise<CollaborationSnapshot>;
  operate(id: string, operations: BlockOperation[], signal?: AbortSignal): Promise<CollaborationSnapshot & { insertedBlockIds: string[] }>;
  replace(id: string, body: string, expectedHash: string): Promise<DocumentSnapshot>;
}
