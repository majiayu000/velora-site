import type { AuditReceipt } from "../domain/types";

export interface ReceiptPort {
  initialize(): Promise<void>;
  append(receipt: AuditReceipt): Promise<void>;
  list(): AuditReceipt[];
  get(id: string): AuditReceipt | undefined;
}
