import { promises as fs } from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { LearnError } from "../domain/errors";

export async function initializeWorkspace(rootInput: string, options: { title: string; description?: string }): Promise<string[]> {
  const root = await fs.realpath(rootInput);
  const title = options.title.trim();
  if (!title || title.length > 160) throw new LearnError("INVALID_TITLE", "title must contain 1 to 160 characters", 422);
  const targets = ["learn.config.json", "learn.manifest.json", "docs/learn/start-here.md"];
  for (const relative of targets) {
    try { await fs.lstat(path.join(root, relative)); throw new LearnError("INIT_TARGET_EXISTS", `文件夹中已有 ${relative}，已保留原文件。请检查是否为未完成的学习空间。`, 409); }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
  }
  const stage = path.join(root, `.learn-init-${randomUUID()}`);
  const created: string[] = [];
  const config = { version: 1, manifest: "learn.manifest.json", documentSizeLimitBytes: 1_048_576, runtime: { adapter: "codex-app-server", command: "codex" } };
  const manifest = { version: 1, site: { title, description: options.description?.trim() || "Evidence-backed notes about this project" }, contentRoots: ["docs"], documents: [{ id: "start-here", path: "docs/learn/start-here.md", title: "Start Here", summary: "What this project does and how to learn it", stage: "00", tags: ["overview"], prerequisites: [], related: [] }] };
  const starter = `# Start Here\n\n> 这里保存围绕 ${title} 逐步积累的学习内容。Agent 通过工作台提供的文档和指南服务，不读取本地源码。\n\n## 从一个问题开始\n\n- 我希望理解什么？\n- 已有哪些材料和前置知识？\n- 怎样用一个例子或练习检验理解？\n\n提出具体问题，结合提供的材料区分已确认信息、推断和未知，再把有价值的内容保存到学习文档中。\n`;
  try {
    await fs.mkdir(path.join(stage, "docs/learn"), { recursive: true, mode: 0o700 });
    await fs.writeFile(path.join(stage, "learn.config.json"), `${JSON.stringify(config, null, 2)}\n`, { encoding: "utf8", flag: "wx", mode: 0o600 });
    await fs.writeFile(path.join(stage, "learn.manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`, { encoding: "utf8", flag: "wx", mode: 0o600 });
    await fs.writeFile(path.join(stage, "docs/learn/start-here.md"), starter, { encoding: "utf8", flag: "wx", mode: 0o600 });
    await fs.mkdir(path.join(root, "docs/learn"), { recursive: true });
    for (const relative of targets) {
      await fs.link(path.join(stage, relative), path.join(root, relative));
      created.push(relative);
    }
    return targets;
  } catch (error) {
    for (const relative of created.reverse()) await fs.rm(path.join(root, relative), { force: true });
    throw new LearnError("INIT_FAILED", "无法在文件夹中创建学习空间，请检查写入权限和现有文件。", 500, {
      cause: error instanceof Error ? error.message : String(error),
    });
  } finally { await fs.rm(stage, { recursive: true, force: true }); }
}
