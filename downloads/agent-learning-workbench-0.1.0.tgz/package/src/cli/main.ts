#!/usr/bin/env node
import { realpathSync } from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { asLearnError, LearnError } from "../domain/errors";
import { createLearnWorkbench } from "../sdk/index";
import { initializeWorkspace } from "../installer/init-workspace";
import { createLearningLink } from "../integrations/deep-link";
import { runDoctor } from "../diagnostics/doctor";
import { startLocalServer } from "../server/local-server";

type CliIo = { stdout: (value: string) => void; stderr: (value: string) => void };

function takeOption(args: string[], name: string): string | undefined {
  const index = args.indexOf(name);
  if (index < 0) return undefined;
  const value = args[index + 1];
  if (!value || value.startsWith("--")) throw new Error(`${name} requires a value`);
  args.splice(index, 2);
  return value;
}

export async function runCli(argv: string[], io: CliIo = { stdout: console.log, stderr: console.error }): Promise<number> {
  const args = [...argv];
  let root: string;
  try { root = path.resolve(takeOption(args, "--root") ?? process.cwd()); }
  catch (error) { io.stderr(error instanceof Error ? error.message : String(error)); return 2; }
  const command = args.shift();
  if (!command || command === "help" || command === "--help") {
    io.stdout("learn-workbench [--root PATH] init --title TITLE | doctor | serve [--port 4178] | dev [--port 4178] | build-site --documents ID,ID [--site-url URL] [--out DIR] | link DOCUMENT [QUESTION] [--path FILE --line N] | workspace | document ID | search QUERY | insights | ask DOCUMENT QUESTION [--revise] [--accept]");
    return 0;
  }
  try {
    if (command === "init") {
      const title = takeOption(args, "--title"); const description = takeOption(args, "--description");
      if (!title || args.length) throw new Error("init requires --title and accepts optional --description");
      io.stdout(JSON.stringify({ created: await initializeWorkspace(root, { title, description }) }, null, 2)); return 0;
    }
    if (command === "link") {
      const pathValue = takeOption(args, "--path"); const lineRaw = takeOption(args, "--line"); const origin = takeOption(args, "--origin");
      const editIndex = args.indexOf("--edit"); const edit = editIndex >= 0; if (edit) args.splice(editIndex, 1);
      const documentId = args.shift(); if (!documentId) throw new Error("link requires a document ID");
      io.stdout(createLearningLink({ origin, documentId, question: args.join(" ") || undefined, path: pathValue, line: lineRaw ? Number(lineRaw) : undefined, edit })); return 0;
    }
    if (command === "doctor") {
      if (args.length) throw new Error("doctor takes no arguments");
      const report = await runDoctor(root); io.stdout(JSON.stringify(report, null, 2)); return report.ok ? 0 : 1;
    }
    if (command === "build-site") {
      const out = path.resolve(root, takeOption(args, "--out") ?? ".learn/site");
      const documents = takeOption(args, "--documents");
      const siteUrl = takeOption(args, "--site-url");
      if (!documents?.trim()) throw new LearnError("PUBLIC_DOCUMENTS_REQUIRED", "请用 --documents 选择公开文档 ID，多个 ID 用逗号分隔", 422);
      if (args.length) throw new Error("build-site accepts --documents, --site-url and --out");
      const { buildStandaloneSite } = await import("../server/standalone-vite");
      await buildStandaloneSite(root, out, { documentIds: documents.split(",").map(id => id.trim()).filter(Boolean), siteUrl }); io.stdout(JSON.stringify({ outDir: out }, null, 2)); return 0;
    }
    if (command === "dev" || command === "serve") {
      const portRaw = takeOption(args, "--port") ?? process.env.LEARN_PORT; if (args.length) throw new Error(`${command} accepts only --port`);
      const port = portRaw ? Number(portRaw) : 4178;
      if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("port must be between 1 and 65535");
      const server = command === "dev" ? await (await import("../server/standalone-vite")).startStandaloneDevServer(root, port) : await startLocalServer([root], { port });
      io.stdout(`${server.origin}/`);
      await new Promise<void>((resolve) => { const stop = () => { process.off("SIGINT", stop); process.off("SIGTERM", stop); void server.close().then(resolve); }; process.on("SIGINT", stop); process.on("SIGTERM", stop); });
      return 0;
    }
  } catch (error) {
    const known = asLearnError(error); io.stderr(JSON.stringify({ error: { code: known.code, message: known.message, details: known.details } })); return known.status >= 500 ? 1 : 2;
  }
  let sdk: Awaited<ReturnType<typeof createLearnWorkbench>> | undefined;
  try {
    sdk = await createLearnWorkbench({ repositoryRoot: root });
    let result: unknown;
    if (command === "workspace") result = sdk.workspace();
    else if (command === "document") {
      const id = args.shift(); if (!id || args.length) throw new Error("document requires exactly one ID");
      result = await sdk.document(id);
    } else if (command === "search") {
      if (!args.length) throw new Error("search requires a query");
      result = await sdk.search(args.join(" "));
    } else if (command === "insights") {
      if (args.length) throw new Error("insights takes no arguments");
      result = sdk.insights();
    } else if (command === "ask") {
      const revise = args.includes("--revise");
      const accept = args.includes("--accept");
      const positional = args.filter((arg) => arg !== "--revise" && arg !== "--accept");
      const documentId = positional.shift();
      if (!documentId || !positional.length) throw new Error("ask requires a document ID and question");
      const outcome = await sdk.ask({ documentId, question: positional.join(" "), intent: revise ? "revise" : "answer" });
      if (accept) {
        if (outcome.proposal) result = { ...outcome, accepted: await sdk.acceptProposal(outcome.proposal.id) };
        else if (outcome.structureProposal) result = { ...outcome, accepted: await sdk.acceptStructureProposal(outcome.structureProposal.id) };
        else throw new Error("Runtime did not return a proposal to accept");
      } else result = outcome;
    } else throw new Error(`Unknown command: ${command}`);
    io.stdout(JSON.stringify(result, null, 2));
    return 0;
  } catch (error) {
    const known = asLearnError(error);
    io.stderr(JSON.stringify({ error: { code: known.code, message: known.message, details: known.details } }));
    return known.status >= 500 ? 1 : 2;
  } finally {
    sdk?.close();
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  process.exitCode = await runCli(process.argv.slice(2));
}
