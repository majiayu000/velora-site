import { execFile } from "node:child_process";
import { randomUUID } from "node:crypto";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { promisify } from "node:util";
import { LearnError } from "../domain/errors";

const exec = promisify(execFile);
let pickerApp: Promise<string> | undefined;

// Launch Services needs an application bundle to reliably activate the panel.
const script = `use framework "Foundation"
use scripting additions
on run
  set args to current application's NSProcessInfo's processInfo()'s arguments()
  if (args's |count|()) < 2 then return
  set outputPath to (args's objectAtIndex:1) as text
  set reply to current application's NSMutableDictionary's dictionary()
  activate
  try
    set selectedPath to POSIX path of (choose folder with prompt "选择学习空间文件夹")
    reply's setObject:selectedPath forKey:"root"
  on error errorMessage number errorNumber
    if errorNumber is -128 then
      reply's setObject:"" forKey:"root"
    else
      reply's setObject:errorMessage forKey:"error"
    end if
  end try
  set outputData to current application's NSJSONSerialization's dataWithJSONObject:reply options:0 |error|:(missing value)
  outputData's writeToFile:outputPath atomically:true
end run`;

async function createPickerApp(): Promise<string> {
  const directory = await mkdtemp(path.join(tmpdir(), "headwater-folder-picker-"));
  const app = path.join(directory, "HeadwaterFolderPicker.app");
  await exec("/usr/bin/osacompile", ["-o", app, "-e", script], { timeout: 20_000 });
  const plist = path.join(app, "Contents", "Info.plist");
  await exec("/usr/bin/plutil", ["-insert", "CFBundleIdentifier", "-string", "local.headwater.folder-picker", plist]);
  await exec("/usr/bin/plutil", ["-insert", "CFBundleDisplayName", "-string", "观澜文件夹选择", plist]);
  await exec("/usr/bin/codesign", ["--force", "--sign", "-", app]);
  return app;
}

export async function chooseLocalFolder(): Promise<string | null> {
  if (process.platform !== "darwin") throw new LearnError("FOLDER_PICKER_UNAVAILABLE", "系统文件夹选择器当前支持 macOS，请手动输入路径。", 501);
  let output: string | undefined;
  try {
    pickerApp ??= createPickerApp().catch((error) => { pickerApp = undefined; throw error; });
    const app = await pickerApp;
    output = path.join(path.dirname(app), `${randomUUID()}.json`);
    await exec("/usr/bin/open", ["-W", "-n", app, "--args", output]);
    const result = JSON.parse(await readFile(output, "utf8")) as { root: string; error?: string };
    if (result.error) throw new Error(result.error);
    return result.root || null;
  } catch (error) {
    throw new LearnError("FOLDER_PICKER_FAILED", "无法打开系统文件夹选择器，请重试或手动输入路径。", 500, {
      cause: error instanceof Error ? error.message : String(error),
    });
  } finally {
    if (output) await rm(output, { force: true });
  }
}
