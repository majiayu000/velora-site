import { randomBytes } from "node:crypto";
import { promises as fs, watch, type FSWatcher } from "node:fs";
import type { IncomingMessage, ServerResponse } from "node:http";
import path from "node:path";
import { LearnEngine } from "../application/learn-engine";
import { createLearnEngine, createRuntimeAdapter } from "../composition/create-learn-engine";
import { readLearnConfig, type LearnConfig } from "../composition/config";
import { asLearnError, LearnError } from "../domain/errors";
import type { LearnEvent } from "../domain/types";
import type { EventPort } from "../ports/event-port";
import type { RuntimePort } from "../ports/runtime-port";
import { chooseLocalFolder } from "./native-folder-picker";
import { SpaceRegistry } from "./space-registry";

function sendJson(response: ServerResponse, status: number, value: unknown): void {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  response.end(JSON.stringify(value));
}

function writeSseEvent(response: ServerResponse, event: LearnEvent): void {
  response.write(`id: ${event.sequence}\n`);
  response.write(`event: ${event.type}\n`);
  response.write(`data: ${JSON.stringify(event)}\n\n`);
}

function streamEvents(response: ServerResponse, events: EventPort, after: number): void {
  response.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
  });
  response.write(": connected\n\n");
  const unsubscribe = events.subscribe((event) => writeSseEvent(response, event), after);
  const heartbeat = setInterval(() => response.write(": heartbeat\n\n"), 20_000);
  response.once("close", () => {
    clearInterval(heartbeat);
    unsubscribe();
  });
}

async function readJson(request: IncomingMessage, limit = 1024 * 1024 + 16_384): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of request) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    size += buffer.length;
    if (size > limit) throw new LearnError("REQUEST_TOO_LARGE", "Request body is too large", 413);
    chunks.push(buffer);
  }
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString("utf8")) as unknown;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Expected object");
    return parsed as Record<string, unknown>;
  } catch {
    throw new LearnError("INVALID_JSON", "Request body must be a JSON object", 400);
  }
}

function normalizedIfMatch(value: string | undefined): string {
  if (!value) return "";
  return value.replace(/^W\//, "").replace(/^"|"$/g, "");
}

function assertLocalRequest(request: IncomingMessage, token: string): void {
  const host = request.headers.host ?? "";
  if (!/^(127\.0\.0\.1|localhost):\d+$/.test(host)) {
    throw new LearnError("INVALID_HOST", "Velora only accepts loopback hosts", 403);
  }
  const origin = request.headers.origin;
  if (origin && origin !== `http://${host}`) {
    throw new LearnError("INVALID_ORIGIN", "Cross-origin write access is forbidden", 403);
  }
  if (request.headers.authorization !== `Bearer ${token}`) {
    throw new LearnError("UNAUTHORIZED", "Missing or invalid workspace token", 401);
  }
}

export function createLocalWorkbench(initialRoots: string[], options: { runtimeFactory?: (root: string) => RuntimePort } = {}) {
  const token = randomBytes(32).toString("base64url");
  const registry = new SpaceRegistry();
  const presence = new Map<string, Map<string, { session: string; blockId?: string; at: number }>>();
  const enginePromises = new Map<string, Promise<LearnEngine>>();
  const watchPathsBySpace = new Map<string, Set<string>>();
  let initialSpacesPromise: Promise<void> | undefined;
  const watchers = new Map<string, FSWatcher>();
  const streams = new Set<ServerResponse>();

  async function ensureInitialSpaces(): Promise<void> {
    if (!initialSpacesPromise) {
      initialSpacesPromise = (async () => {
        for (const root of initialRoots) await registry.register(root);
      })();
    }
    return initialSpacesPromise;
  }

  async function engine(spaceId: string): Promise<LearnEngine> {
    await ensureInitialSpaces();
    const space = registry.require(spaceId);
    let enginePromise = enginePromises.get(spaceId);
    if (!enginePromise) {
      enginePromise = (async () => {
        const instance = await createLearnEngine({
          repositoryRoot: space.root,
          profile: "interactive",
          runtime: options.runtimeFactory?.(space.root),
        });
        refreshWatchPaths(spaceId, instance);
        instance.events.subscribe(event => {
          if (event.type === "workspace.changed") refreshWatchPaths(spaceId, instance);
        });
        return instance;
      })();
      enginePromises.set(spaceId, enginePromise);
    }
    return enginePromise;
  }

  function refreshWatchPaths(spaceId: string, app: LearnEngine): void {
    const paths = new Set(app.store.getWatchPaths());
    watchPathsBySpace.set(spaceId, paths);
    for (const file of paths) {
      const directory = path.dirname(file);
      if (watchers.has(directory)) continue;
      const watcher = watch(directory, (_event, name) => {
        if (!name) return;
        const changed = path.join(directory, String(name));
        for (const [id, files] of watchPathsBySpace) {
          if (!files.has(changed)) continue;
          void enginePromises.get(id)?.then(async instance => {
            const document = instance.store.listDocuments().find(item => path.resolve(registry.require(id).root, item.path) === changed);
            if (document) await instance.documentChangedExternally(document.id);
          }).catch(error => console.error("Learn file watcher:", error));
        }
      });
      watcher.on("error", error => console.error("Learn file watcher:", error));
      watchers.set(directory, watcher);
    }
  }

  async function handleApi(request: IncomingMessage, response: ServerResponse): Promise<boolean> {
    const host = request.headers.host ?? "127.0.0.1";
    const url = new URL(request.url ?? "/", `http://${host}`);
    if (!url.pathname.startsWith("/api/v1/")) return false;
    assertLocalRequest(request, token);
    const method = request.method ?? "GET";

    if (url.pathname === "/api/v1/folders/choose" && method === "POST") {
      sendJson(response, 200, { root: await chooseLocalFolder() });
      return true;
    }
    if (url.pathname === "/api/v1/spaces" && method === "GET") {
      await ensureInitialSpaces();
      sendJson(response, 200, { spaces: registry.list() });
      return true;
    }
    if (url.pathname === "/api/v1/spaces" && method === "POST") {
      await ensureInitialSpaces();
      const body = await readJson(request);
      if (typeof body.root !== "string" || !body.root.trim()) {
        throw new LearnError("INVALID_SPACE_ROOT", "root must be a non-empty absolute path", 422);
      }
      const space = await registry.register(body.root, { initialize: body.initialize === true });
      sendJson(response, 201, { space });
      return true;
    }

    const spaceRoute = url.pathname.match(/^\/api\/v1\/spaces\/([^/]+)(\/.*)?$/);
    if (!spaceRoute) throw new LearnError("NOT_FOUND", `Unknown API endpoint: ${method} ${url.pathname}`, 404);
    const spaceId = decodeURIComponent(spaceRoute[1]!);
    registry.require(spaceId);
    const route = spaceRoute[2] ?? "/";
    const app = await engine(spaceId);

    if (route === "/settings" && method === "GET") {
      const { config } = await readLearnConfig(registry.require(spaceId).root);
      sendJson(response, 200, { runtime: config.runtime });
      return true;
    }
    if (route === "/settings" && method === "PUT") {
      const body = await readJson(request);
      const runtime = body.runtime as LearnConfig["runtime"] | undefined;
      if (!runtime || typeof runtime !== "object" || typeof runtime.adapter !== "string" ||
        typeof runtime.command !== "string" || !runtime.command.trim() ||
        (runtime.args !== undefined && (!Array.isArray(runtime.args) || runtime.args.some(arg => typeof arg !== "string")))) {
        throw new LearnError("INVALID_CONFIG", "请选择 Agent 并填写有效的程序路径。", 422);
      }
      const root = registry.require(spaceId).root;
      const selected = { adapter: runtime.adapter, command: runtime.command.trim(), ...(runtime.args ? { args: runtime.args } : {}) };
      const next = createRuntimeAdapter(root, "interactive", selected);
      const health = await app.changeRuntime(next, async () => {
        const { configPath } = await readLearnConfig(root);
        const config = JSON.parse(await fs.readFile(configPath, "utf8"));
        config.runtime = selected;
        const temporary = `${configPath}.${randomBytes(8).toString("hex")}.tmp`;
        try {
          await fs.writeFile(temporary, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
          await fs.rename(temporary, configPath);
        } finally { await fs.rm(temporary, { force: true }); }
      });
      sendJson(response, 200, { runtime: selected, health });
      return true;
    }

    if (method === "GET" && route === "/health") {
      sendJson(response, 200, { ok: true, runtime: app.getWorkspace().runtime });
      return true;
    }
    if (method === "GET" && route === "/workspace") {
      sendJson(response, 200, app.getWorkspace());
      return true;
    }
    if (method === "GET" && route === "/documents") {
      sendJson(response, 200, { documents: app.getWorkspace().documents });
      return true;
    }
    if (method === "GET" && route === "/search") {
      sendJson(response, 200, { results: await app.search(url.searchParams.get("q") ?? "", Number(url.searchParams.get("limit") ?? 20)) });
      return true;
    }
    if (method === "GET" && route === "/insights") {
      sendJson(response, 200, app.getInsights());
      return true;
    }
    const collaborationMatch = route.match(/^\/documents\/([^/]+)\/(collaboration|operations)$/);
    if (collaborationMatch && app.collaboration) {
      const id = decodeURIComponent(collaborationMatch[1]!);
      if (method === "GET" && collaborationMatch[2] === "collaboration") {
        sendJson(response, 200, await app.collaboration.read(id)); return true;
      }
      if (method === "POST") {
        const body = await readJson(request, 13 * 1024 * 1024);
        const result = collaborationMatch[2] === "operations"
          ? await app.collaboration.operate(id, body.operations as never)
          : await app.collaboration.sync(id, body.update as string, body.vector as string);
        const key = `${spaceId}:${id}`;
        const peers = presence.get(key) ?? new Map<string, { session: string; blockId?: string; at: number }>();
        presence.set(key, peers);
        const person = body.presence as { session?: unknown; blockId?: unknown } | undefined;
        if (person && typeof person.session === "string" && /^[a-f0-9-]{36}$/.test(person.session)) peers.set(person.session, { session: person.session, blockId: typeof person.blockId === "string" ? person.blockId.slice(0, 100) : undefined, at: Date.now() });
        for (const [session, peer] of peers) if (Date.now() - peer.at > 10000) peers.delete(session);
        sendJson(response, 200, { ...result, peers: [...peers.values()] }); return true;
      }
    }
    const documentMatch = route.match(/^\/documents\/([^/]+)$/);
    if (documentMatch && method === "GET") {
      sendJson(response, 200, await app.store.getDocument(decodeURIComponent(documentMatch[1])));
      return true;
    }
    if (documentMatch && method === "PUT") {
      const body = await readJson(request);
      if (typeof body.body !== "string") throw new LearnError("INVALID_DOCUMENT", "body must be a string", 400);
      const snapshot = await app.saveDocument(
        decodeURIComponent(documentMatch[1]),
        body.body,
        normalizedIfMatch(request.headers["if-match"]),
      );
      sendJson(response, 200, snapshot);
      return true;
    }
    if (method === "POST" && route === "/questions") {
      const body = await readJson(request);
      const turn = app.createQuestion({
        documentId: body.documentId as string | undefined,
        conversationId: body.conversationId as string | undefined,
        question: body.question as string,
        intent: body.intent as "answer" | "revise" | "auto",
        anchor: body.anchor as never,
        target: body.target as never,
      });
      sendJson(response, 202, { turn });
      return true;
    }
    const turnMatch = route.match(/^\/turns\/([^/]+)$/);
    if (turnMatch && method === "GET") {
      sendJson(response, 200, { turn: app.getTurn(decodeURIComponent(turnMatch[1])) });
      return true;
    }
    const cancelMatch = route.match(/^\/turns\/([^/]+)\/cancel$/);
    if (cancelMatch && method === "POST") {
      sendJson(response, 202, { turn: await app.cancelTurn(decodeURIComponent(cancelMatch[1])) });
      return true;
    }
    const proposalMatch = route.match(/^\/proposals\/([^/]+)$/);
    if (proposalMatch && method === "GET") {
      sendJson(response, 200, { proposal: app.getProposal(decodeURIComponent(proposalMatch[1])) });
      return true;
    }
    const acceptMatch = route.match(/^\/proposals\/([^/]+)\/accept$/);
    if (acceptMatch && method === "POST") {
      sendJson(response, 200, await app.acceptProposal(decodeURIComponent(acceptMatch[1])));
      return true;
    }
    const rejectMatch = route.match(/^\/proposals\/([^/]+)\/reject$/);
    if (rejectMatch && method === "POST") {
      sendJson(response, 200, { proposal: await app.rejectProposal(decodeURIComponent(rejectMatch[1])) });
      return true;
    }
    const structureProposalMatch = route.match(/^\/structure-proposals\/([^/]+)$/);
    if (structureProposalMatch && method === "GET") {
      sendJson(response, 200, { proposal: app.getStructureProposal(decodeURIComponent(structureProposalMatch[1])) });
      return true;
    }
    const structureAcceptMatch = route.match(/^\/structure-proposals\/([^/]+)\/accept$/);
    if (structureAcceptMatch && method === "POST") {
      const result = await app.acceptStructureProposal(decodeURIComponent(structureAcceptMatch[1]));
      sendJson(response, 200, result);
      return true;
    }
    const structureRejectMatch = route.match(/^\/structure-proposals\/([^/]+)\/reject$/);
    if (structureRejectMatch && method === "POST") {
      sendJson(response, 200, { proposal: await app.rejectStructureProposal(decodeURIComponent(structureRejectMatch[1])) });
      return true;
    }
    if (method === "GET" && route === "/conversations") {
      sendJson(response, 200, { conversations: app.listConversations(url.searchParams.get("q") ?? "") });
      return true;
    }
    const conversationMatch = route.match(/^\/conversations\/([^/]+)$/);
    if (conversationMatch && method === "PATCH") {
      sendJson(response, 200, { conversation: await app.updateConversation(decodeURIComponent(conversationMatch[1]!), await readJson(request)) });
      return true;
    }
    if (method === "GET" && route === "/history") {
      sendJson(response, 200, { receipts: app.listReceipts() });
      return true;
    }
    const revertPreviewMatch = route.match(/^\/history\/([^/]+)\/revert-preview$/);
    if (revertPreviewMatch && method === "GET") {
      sendJson(response, 200, await app.previewRevert(decodeURIComponent(revertPreviewMatch[1])));
      return true;
    }
    const revertMatch = route.match(/^\/history\/([^/]+)\/revert$/);
    if (revertMatch && method === "POST") {
      const result = await app.revertReceipt(decodeURIComponent(revertMatch[1]));
      sendJson(response, 200, result);
      return true;
    }
    const evidenceRefreshMatch = route.match(/^\/turns\/([^/]+)\/evidence\/refresh$/);
    if (evidenceRefreshMatch && method === "POST") {
      sendJson(response, 200, { evidence: await app.refreshEvidence(decodeURIComponent(evidenceRefreshMatch[1])) });
      return true;
    }
    if (method === "GET" && route === "/events") {
      const after = Number(url.searchParams.get("after") ?? request.headers["last-event-id"] ?? 0);
      streams.add(response);
      response.once("close", () => streams.delete(response));
      streamEvents(response, app.events, Number.isFinite(after) ? after : 0);
      return true;
    }
    throw new LearnError("NOT_FOUND", `Unknown API endpoint: ${method} ${url.pathname}`, 404);
  }

  return {
    bootstrapScript: () => `window.__LEARN_BOOTSTRAP__=${JSON.stringify({ mode: "development", apiBase: "/api/v1", token }).replaceAll("<", "\\u003c")};`,
    initialize: ensureInitialSpaces,
    async handle(request: IncomingMessage, response: ServerResponse): Promise<boolean> {
      try { return await handleApi(request, response); }
      catch (error) {
        if (response.headersSent) response.end();
        else {
          const known = asLearnError(error);
          sendJson(response, known.status, { error: { code: known.code, message: known.message, details: known.details } });
        }
        return true;
      }
    },
    async close(): Promise<void> {
      const apps = await Promise.all(enginePromises.values());
      for (const watcher of watchers.values()) watcher.close();
      watchers.clear();
      for (const stream of streams) stream.end();
      streams.clear();
      for (const app of apps) app.close();
      enginePromises.clear();
    },
  };
}
