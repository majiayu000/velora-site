import { promises as fs } from "node:fs";
import { createServer } from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { asLearnError, LearnError } from "../domain/errors";
import type { RuntimePort } from "../ports/runtime-port";
import { createLocalWorkbench } from "./local-workbench";

export async function bundledSiteRoot(): Promise<string> {
  const here = path.dirname(fileURLToPath(import.meta.url));
  for (const candidate of [path.resolve(here, "../learn"), path.resolve(here, "../../learn")]) {
    try { if ((await fs.stat(path.join(candidate, "index.html"))).isFile()) return candidate; }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
  }
  throw new LearnError("WEB_ASSETS_MISSING", "Canonical web assets are missing from this installation", 500);
}

const contentTypes: Record<string, string> = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon",
  ".woff2": "font/woff2", ".ttf": "font/ttf",
};

export async function startLocalServer(initialRoots: string[], options: {
  port: number;
  webRoot?: string;
  runtimeFactory?: (root: string) => RuntimePort;
}) {
  if (!Number.isInteger(options.port) || options.port < 0 || options.port > 65535) throw new LearnError("INVALID_PORT", "port must be between 0 and 65535", 422);
  const webRoot = await fs.realpath(options.webRoot ?? path.join(await bundledSiteRoot(), "app-dist")).catch((error: NodeJS.ErrnoException) => {
    if (error.code === "ENOENT") throw new LearnError("WEB_ASSETS_MISSING", "可编辑界面尚未构建，请先运行 npm run build:app", 500);
    throw error;
  });
  const indexHtml = await fs.readFile(path.join(webRoot, "index.html"), "utf8");
  const workbench = createLocalWorkbench(initialRoots, options);
  await workbench.initialize();
  const server = createServer((request, response) => {
    void (async () => {
      const host = request.headers.host ?? "";
      const url = new URL(request.url ?? "/", `http://${host}`);
      if (await workbench.handle(request, response)) return;
      if (!/^(127\.0\.0\.1|localhost):\d+$/.test(host)) throw new LearnError("INVALID_HOST", "Only loopback hosts are accepted", 403);
      if (request.headers.origin && request.headers.origin !== `http://${host}`) throw new LearnError("INVALID_ORIGIN", "Cross-origin access is forbidden", 403);
      if (request.method !== "GET" && request.method !== "HEAD") throw new LearnError("NOT_FOUND", "Not found", 404);
      response.setHeader("Cache-Control", "no-store");
      response.setHeader("X-Content-Type-Options", "nosniff");
      if (url.pathname === "/favicon.ico") { response.writeHead(204); response.end(); return; }
      if (url.pathname === "/__learn_bootstrap__.js") {
        const site = request.headers["sec-fetch-site"];
        if (site && site !== "same-origin" && site !== "none") throw new LearnError("INVALID_ORIGIN", "Cross-origin session access is forbidden", 403);
        response.setHeader("Cross-Origin-Resource-Policy", "same-origin");
        response.setHeader("Content-Type", "text/javascript; charset=utf-8");
        response.end(request.method === "HEAD" ? undefined : workbench.bootstrapScript());
        return;
      }
      if (url.pathname === "/" || url.pathname === "/index.html") {
        response.setHeader("Content-Type", contentTypes[".html"]!);
        // Development proxies serve their own HTML; standalone assets use this entry.
        const html = indexHtml.includes('src="/__learn_bootstrap__.js"') ? indexHtml
          : indexHtml.replace("<head>", '<head><script src="/__learn_bootstrap__.js"></script>');
        response.end(request.method === "HEAD" ? undefined : html);
        return;
      }
      const resourcePath = path.posix.normalize(decodeURIComponent(url.pathname));
      if (!resourcePath.startsWith("/assets/") && !resourcePath.startsWith("/fonts/")) throw new LearnError("NOT_FOUND", "Not found", 404);
      const file = await fs.realpath(path.resolve(webRoot, `.${resourcePath}`)).catch((error: NodeJS.ErrnoException) => {
        if (error.code === "ENOENT" || error.code === "ENOTDIR") throw new LearnError("NOT_FOUND", "Not found", 404);
        throw error;
      });
      const relative = path.relative(webRoot, file);
      if (relative.startsWith("..") || path.isAbsolute(relative) || !(await fs.stat(file)).isFile()) throw new LearnError("NOT_FOUND", "Not found", 404);
      response.setHeader("Content-Type", contentTypes[path.extname(file)] ?? "application/octet-stream");
      response.end(request.method === "HEAD" ? undefined : await fs.readFile(file));
    })().catch(error => {
      if (response.headersSent) { response.end(); return; }
      const known = asLearnError(error);
      response.writeHead(known.status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
      response.end(JSON.stringify({ error: { code: known.code, message: known.message } }));
    });
  });
  try {
    await new Promise<void>((resolve, reject) => {
      server.once("error", reject);
      server.listen(options.port, "127.0.0.1", () => { server.off("error", reject); resolve(); });
    });
  } catch (error) { await workbench.close(); throw error; }
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("Local server did not expose a TCP address");
  return {
    origin: `http://127.0.0.1:${address.port}`,
    async close() {
      const closed = new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
      server.closeAllConnections();
      await workbench.close();
      await closed;
    },
  };
}
