export type ProductRelease = { version: string; fileName: string; sha256: string; bytes: number };
type Example = { title: string; summary: string; url: string };
const escape = (value: string) => value.replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]!);

export function renderProductHome(release: ProductRelease, href: (path?: string) => string, examples: Example[]): string {
  const download = href(`downloads/${release.fileName}`);
  return `<main id="main" class="product-home" tabindex="-1">
    <section class="product-hero">
      <div class="product-introduction"><p class="eyebrow">观澜 VELORA · 本地学习工作台</p>
        <h1>把每次理解，<br>留成继续生长的文档。</h1>
        <p class="product-lead">带上你想学的材料，和 Agent 一边提问、一边整理。解释、例子和自己的笔记，回到同一份可以继续编辑的文档。</p>
        <div class="product-actions"><a class="download-button" href="${download}" download>下载本地工作台 <span aria-hidden="true">↓</span></a><a class="secondary-link" href="${href("learn/")}">先看学习示例 ↗</a></div>
        <p class="release-note">v${escape(release.version)} 预览版 · 需要 Node.js 22.12+ 或 24 · 无需观澜账号</p>
      </div>
      <figure class="learning-illustration" aria-label="学习过程示意"><figcaption>从问题，到自己的理解 <span>示意</span></figcaption>
        <div class="illustration-question"><span class="illustration-label">一个真问题</span><p>为什么 KV Cache 能让生成更快？</p></div>
        <div class="illustration-connection" aria-hidden="true">↓</div>
        <div class="illustration-document"><span class="illustration-label">一篇会生长的文档</span><h2>理解缓存，理解推理</h2><p>先拆开 Prefill 和 Decode，再用一个小例子观察计算如何被复用。</p><div class="illustration-chapters"><span>概念解释</span><span>可运行的例子</span><span>我的笔记</span></div><div class="illustration-note"><span aria-hidden="true">↳</span> 选中一段，继续问，继续改。</div></div>
      </figure>
    </section>
    <section class="product-workflow" aria-labelledby="workflow-title"><div class="section-intro"><p class="eyebrow">围绕同一份文档，持续学习</p><h2 id="workflow-title">问过的问题，留下下一次的起点。</h2></div><ol>
      <li><span>01</span><h3>提供材料</h3><p>把已有资料放进学习文档，说明想理解的问题和已知背景。</p></li>
      <li><span>02</span><h3>边问，边整理</h3><p>让 Agent 解释概念、补充例子，或选中一段请求修改。自己也能直接编辑。</p></li>
      <li><span>03</span><h3>带着理解回来</h3><p>继续追问，修订旧解释，把相关知识连起来。文档保存在自己的目录中。</p></li>
    </ol></section>
    <section class="product-example-section" aria-labelledby="examples-title"><div class="section-intro"><p class="eyebrow">先读一段，再决定</p><h2 id="examples-title">一条真实的学习路径</h2><p>从推理性能心智模型出发，逐步理解 CPU、GPU 与实验方法。</p></div><div class="product-examples">${examples.map(example => `<a href="${escape(example.url)}"><span class="eyebrow">公开学习文章</span><h3>${escape(example.title)}</h3><p>${escape(example.summary)}</p><span class="example-arrow" aria-hidden="true">↗</span></a>`).join("")}</div><a class="text-link" href="${href("learn/")}">浏览全部学习文章 ↗</a></section>
    <section id="download" class="product-download" aria-labelledby="download-title"><div><p class="eyebrow">在自己的电脑上开始</p><h2 id="download-title">让下一次学习，有地方继续。</h2><p>本地保存文档，使用自己配置的 Codex 或 Claude Code。阅读、手工编辑和导出也可以独立使用。</p></div><div class="download-details"><a class="download-button" href="${download}" download>下载 v${escape(release.version)} <span aria-hidden="true">↓</span></a><p>Node.js 命令行安装包 · ${(release.bytes / 1024 / 1024).toFixed(1)} MB</p><a href="${href("getting-started/")}">查看安装和首次使用指南 ↗</a><a class="checksum-link" href="${href(`downloads/${release.fileName}.sha256`)}" download>下载 SHA-256 校验值</a></div></section>
    <section class="product-faq" aria-labelledby="faq-title"><div class="section-intro"><p class="eyebrow">开始之前</p><h2 id="faq-title">你可能想先确认</h2></div>
      <details><summary>打开一个文件夹，Agent 就会读取里面的源码吗？</summary><p>不会。Agent 只使用工作台提供的学习文档、指南和受控文档工具。请先提供要学习的材料，再围绕这些材料提问。</p></details>
      <details><summary>需要登录观澜，或购买平台额度吗？</summary><p>本地工作台无需观澜账号。Agent 功能使用你在本机配置并登录的模型服务，推理由对应服务处理；本地保存文档不等于离线推理。</p></details>
      <details><summary>这个网站可以直接聊天和编辑吗？</summary><p>这里展示公开的只读学习文章。下载本地工作台后，可以提问、编辑、查看历史，并选择篇目导出自己的公开学习站。</p></details>
    </section>
  </main>`;
}

export function renderReleaseInstall(release: ProductRelease, href: (path?: string) => string): string {
  return `<h2 id="install">下载并安装</h2><p>准备 Node.js 22.12+ 或 24 与 npm。下载后，在安装包所在的目录打开终端，执行以下命令。安装依赖需要联网。</p><p><a class="download-button" href="${href(`downloads/${release.fileName}`)}" download>下载 v${escape(release.version)} 安装包 ↓</a></p><pre><code>mkdir velora-local
cd velora-local
npm init -y
npm install ../${escape(release.fileName)}
mkdir notes
npx --no-install learn-workbench --root ./notes init --title "我的学习空间"
npx --no-install learn-workbench --root ./notes serve</code></pre><p>打开 <a href="http://127.0.0.1:4178">http://127.0.0.1:4178</a> 即可使用。下次回到 <code>velora-local</code> 目录，重新执行最后一条命令就能继续。</p><p>第一次使用 Agent 前，请安装并登录本机的 Codex 或 Claude Code，然后在工作台的本地设置中选择。没有可用 Agent 时，仍能阅读、手工编辑和导出。</p><details class="release-checksum"><summary>核对安装包</summary><p>文件名：<code>${escape(release.fileName)}</code><br>版本：<code>${escape(release.version)}</code><br>SHA-256：</p><pre><code>${release.sha256}</code></pre><p><a href="${href(`downloads/${release.fileName}.sha256`)}" download>下载校验值文件</a>。这份安装包包含编译后的本地界面、CLI、SDK、MCP 与源码，按项目 MIT 许可分发。</p></details>`;
}
