import { createHash } from "node:crypto";
import path from "node:path";
import createDOMPurify from "dompurify";
import { JSDOM } from "jsdom";
import { renderMarkdown } from "../adapters/markdown/markdown-renderer";
import { WorkspaceStore } from "../adapters/filesystem/workspace-store";
import { readLearnConfig } from "../composition/config";
import { LearnError } from "../domain/errors";
import type { DocumentSnapshot } from "../domain/types";
import { renderProductHome, renderReleaseInstall, type ProductRelease } from "./product-pages";

export type PublicSiteOptions = { documentIds: string[]; siteUrl?: string; release?: { file: string; version: string } };

export function publicSiteAddress(input?: string): URL | undefined {
  if (!input) return undefined;
  let url: URL;
  try { url = new URL(input); }
  catch { throw new LearnError("INVALID_SITE_URL", "站点网址需要是完整的 http 或 https 地址", 422); }
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
    throw new LearnError("INVALID_SITE_URL", "站点网址不能包含凭据、查询参数或片段", 422);
  }
  url.pathname = url.pathname.replace(/\/?$/, "/");
  return url;
}

const escape = (value: string) => value.replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]!);
const json = (value: unknown) => JSON.stringify(value).replace(/</g, "\\u003c");
const articlePath = (id: string) => `learn/${encodeURIComponent(id)}/`;

/** The selected registered documents are the entire publication boundary. */
export async function renderPublicSite(root: string, options: PublicSiteOptions, address: URL | undefined, assets: string, release?: ProductRelease): Promise<Map<string, string>> {
  if (!options.documentIds?.length) throw new LearnError("PUBLIC_DOCUMENTS_REQUIRED", "请用 --documents 明确选择公开文档 ID，多个 ID 用逗号分隔", 422);
  const { config, manifestPath } = await readLearnConfig(root);
  const store = new WorkspaceStore(root, manifestPath, config.documentSizeLimitBytes);
  await store.initialize();
  const dom = new JSDOM();
  try {
    const { site } = store;
    const documents = await Promise.all([...new Set(options.documentIds)].map(id => store.getDocument(id)));
    const byId = new Map(documents.map(document => [document.id, document]));
    const base = address?.pathname ?? "/";
    const collectionPath = release ? "learn/" : "";
    const brand = release ? "观澜 Velora" : site.title;
    const href = (relative = "") => `${base}${relative}`;
    const absolute = (relative = "") => address ? new URL(relative, address).href : undefined;
    const files = new Map<string, string>();
    const environment = {
      purifier: createDOMPurify(dom.window as unknown as Parameters<typeof createDOMPurify>[0]),
      parseSvg: (source: string) => new dom.window.DOMParser().parseFromString(source, "image/svg+xml") as unknown as Document,
    };
    const links = documents.map(document => `<a href="${href(articlePath(document.id))}">${escape(document.title)}</a>`).join("");
    const shell = (title: string, description: string, relative: string, content: string, structuredData: unknown, noindex = false) => {
      const url = absolute(relative);
      const ld = json(structuredData);
      const hash = createHash("sha256").update(ld).digest("base64");
      const pageTitle = relative ? `${title} · ${brand}` : title;
      return `<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="color-scheme" content="light"><meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'sha256-${hash}'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'"><title>${escape(pageTitle)}</title><meta name="description" content="${escape(description)}">${!address || noindex ? '<meta name="robots" content="noindex,follow">' : ""}${url ? `<link rel="canonical" href="${escape(url)}"><meta property="og:url" content="${escape(url)}">` : ""}<meta property="og:title" content="${escape(pageTitle)}"><meta property="og:description" content="${escape(description)}"><meta property="og:type" content="${relative.startsWith("learn/") ? "article" : "website"}"><meta property="og:locale" content="zh_CN"><meta name="twitter:card" content="summary"><meta name="twitter:title" content="${escape(pageTitle)}"><meta name="twitter:description" content="${escape(description)}"><link rel="icon" href="${href("favicon.svg")}" type="image/svg+xml">${assets}<script type="application/ld+json">${ld}</script></head><body><a class="skip-link" href="#main">跳到正文</a><header class="public-header"><a class="public-brand" href="${href()}"><span aria-hidden="true">澜</span><strong>${escape(brand)}</strong></a><nav class="header-links" aria-label="主导航"><a href="${href(collectionPath)}#articles">全部文章</a><a href="${href("getting-started/")}">本地使用指南 <span aria-hidden="true">↗</span></a></nav></header>${content}<footer class="public-footer"><a href="${href()}">${escape(brand)}</a><span>使用观澜 Velora 整理与发布</span><a href="${href("getting-started/")}">继续构建自己的学习文档 ↗</a></footer></body></html>`;
    };
    const listItem = (document: DocumentSnapshot, index: number) => `<li data-public-article data-search="${escape([document.title, document.summary, ...(document.tags ?? [])].join(" ").toLocaleLowerCase())}"><a class="article-link" href="${href(articlePath(document.id))}"><span class="article-number">${String(index + 1).padStart(2, "0")}</span><div><h2>${escape(document.title)}</h2><p>${escape(document.summary)}</p><div class="article-tags">${(document.tags ?? []).map(tag => `<span>${escape(tag)}</span>`).join("")}</div></div><span class="article-arrow" aria-hidden="true">↗</span></a></li>`;
    files.set(`${collectionPath}index.html`, shell(site.title, site.description ?? site.title, collectionPath, `<main id="main" class="public-home" tabindex="-1"><section class="public-intro"><p class="eyebrow">观澜 · 公开学习笔记</p><h1>${escape(site.title)}</h1><p class="intro-description">${escape(site.description ?? "从一个问题开始，把理解留成可以继续阅读的知识。")}</p><a class="text-link" href="#articles">开始阅读 <span aria-hidden="true">↓</span></a></section><section id="articles" aria-labelledby="articles-title"><div class="collection-heading"><div><p class="eyebrow">沿着问题，逐步理解</p><h2 id="articles-title">学习文章 <span data-result-count>${documents.length}</span></h2></div><label class="public-search"><span class="sr-only">搜索文章标题和摘要</span><input type="search" placeholder="搜索标题、摘要和标签" aria-label="搜索文章标题和摘要"></label></div><ol class="article-list">${documents.map(listItem).join("")}</ol><p class="search-empty" hidden>没有找到相关文章，试试其他关键词。</p><noscript><p>可使用浏览器的“在页面中查找”寻找文章。</p></noscript></section></main>`, { "@context": "https://schema.org", "@type": "CollectionPage", name: site.title, description: site.description, ...(address ? { url: absolute(collectionPath) } : {}), inLanguage: "zh-CN" }));

    if (release) {
      const examples = documents.slice(0, 3).map(document => ({ title: document.title, summary: document.summary, url: href(articlePath(document.id)) }));
      files.set("index.html", shell("观澜 Velora · 把理解留成学习文档", "在自己的电脑上，和 Agent 一边提问、一边把提供的材料整理成可以持续编辑的学习文档。", "", renderProductHome(release, href, examples), { "@context": "https://schema.org", "@type": "SoftwareApplication", name: "观澜 Velora", applicationCategory: "EducationalApplication", operatingSystem: "Node.js", softwareVersion: release.version, inLanguage: "zh-CN", ...(address ? { url: absolute() } : {}) }));
    }

    for (let index = 0; index < documents.length; index++) {
      const document = documents[index]!;
      const body = dom.window.document.createElement("div");
      body.innerHTML = renderMarkdown(document.body, `article-${document.id}`, environment);
      const first = body.firstElementChild;
      if (first?.tagName === "H1" && first.textContent?.trim() === document.title.trim()) first.remove();
      for (const heading of body.querySelectorAll("h1")) {
        const replacement = dom.window.document.createElement("h2"); replacement.innerHTML = heading.innerHTML; heading.replaceWith(replacement);
      }
      const headings: string[] = [];
      const headingIds = new Set<string>();
      for (const [number, heading] of [...body.querySelectorAll("h2,h3")].filter(node => !node.closest(".learn-diagram")).entries()) {
        const slug = heading.id || (heading.textContent ?? "").toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-|-$/g, "") || `section-${number + 1}`;
        let id = slug;
        for (let suffix = 2; headingIds.has(id); suffix++) id = `${slug}-${suffix}`;
        heading.id = id; headingIds.add(id);
        headings.push(`<a class="toc-${heading.tagName.toLowerCase()}" href="#${escape(encodeURIComponent(id))}">${escape(heading.textContent ?? "")}</a>`);
      }
      // A Markdown link may only resolve to another published document.
      for (const link of body.querySelectorAll<HTMLAnchorElement>("a[href]")) {
        const target = link.getAttribute("href")!;
        const [file, fragment] = target.split("#");
        if (!file?.endsWith(".md") || /^[a-z][\w+.-]*:/i.test(target)) continue;
        const resolved = path.posix.normalize(path.posix.join(path.posix.dirname(document.path), file));
        const published = documents.find(candidate => candidate.path === resolved);
        if (published) link.setAttribute("href", href(articlePath(published.id)) + (fragment ? `#${fragment}` : ""));
        else link.replaceWith(...link.childNodes);
      }
      const related = [...new Set([...(document.prerequisites ?? []), ...(document.related ?? [])])].map(id => byId.get(id)).filter((item): item is DocumentSnapshot => !!item);
      const neighbors = [documents[index - 1], documents[index + 1]];
      const relative = articlePath(document.id);
      const structuredData = { "@context": "https://schema.org", "@graph": [{ "@type": "Article", headline: document.title, description: document.summary, dateModified: document.modifiedAt, inLanguage: "zh-CN", ...(address ? { url: absolute(relative) } : {}) }, { "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: site.title, ...(address ? { item: absolute(collectionPath) } : {}) }, { "@type": "ListItem", position: 2, name: document.title, ...(address ? { item: absolute(relative) } : {}) }] }] };
      const article = `<div class="reading-layout"><main id="main" class="public-article" tabindex="-1"><nav class="breadcrumbs" aria-label="面包屑"><a href="${href(collectionPath)}">全部文章</a><span aria-hidden="true">/</span><span>${escape(document.title)}</span></nav><header class="article-heading"><p class="eyebrow">${escape(document.stage ? `学习路径 ${document.stage}` : "学习笔记")}</p><h1>${escape(document.title)}</h1><p class="article-summary">${escape(document.summary)}</p><p class="article-meta">更新于 <time datetime="${escape(document.modifiedAt)}">${escape(document.modifiedAt.slice(0, 10))}</time><span>·</span>${Math.max(1, Math.ceil((body.textContent ?? "").length / 500))} 分钟阅读</p></header><details class="mobile-directory"><summary>学习目录</summary><nav aria-label="学习目录">${links}</nav></details><article class="markdown public-markdown">${body.innerHTML}</article>${related.length ? `<section class="related-reading"><h2>继续理解</h2>${related.map(item => `<a href="${href(articlePath(item.id))}"><strong>${escape(item.title)}</strong><span>${escape(item.summary)}</span></a>`).join("")}</section>` : ""}<nav class="article-pagination" aria-label="上下篇">${neighbors.map((item, number) => item ? `<a href="${href(articlePath(item.id))}"><small>${number === 0 ? "上一篇" : "下一篇"}</small><strong>${escape(item.title)}</strong></a>` : "<span></span>").join("")}</nav></main><aside class="reading-sidebar"><nav class="table-of-contents" aria-label="本页目录"><p>本页内容</p>${headings.join("")}</nav><nav class="reading-directory" aria-label="学习目录"><p>学习路径</p>${documents.map(item => `<a href="${href(articlePath(item.id))}"${item.id === document.id ? ' aria-current="page"' : ""}>${escape(item.title)}</a>`).join("")}</nav></aside></div>`;
      files.set(`${relative}index.html`, shell(document.title, document.summary, relative, article, structuredData));
    }
    const installation = release ? renderReleaseInstall(release, href) : `<h2>运行工作台</h2><p>准备 Git、Node.js 22.12+ 或 24，以及已安装并登录的 Codex 或 Claude Code。当前版本通过项目源码运行，需要先取得仓库访问权限。</p><pre><code>git clone https://github.com/majiayu000/agent-learning-workbench.git
cd agent-learning-workbench
npm install
npm run dev</code></pre><p>打开 <code>http://127.0.0.1:4178</code>，创建学习空间，提供要学习的材料，再提出第一个问题。没有可用 Agent 时，仍可手动阅读、编辑和导出。</p>`;
    const guide = `<main id="main" class="public-article standalone-page" tabindex="-1"><nav class="breadcrumbs" aria-label="面包屑"><a href="${href(collectionPath)}">全部文章</a><span aria-hidden="true">/</span><span>本地使用指南</span></nav><header class="article-heading"><p class="eyebrow">观澜 Velora</p><h1>让理解成为下一次学习的起点</h1><p class="article-summary">在自己的电脑上，和 Agent 一起把提供的材料整理成可以持续编辑的学习文档。</p></header><article class="markdown"><h2>阅读这里，创作在本地</h2><p>这个网站是公开学习文档的只读版本。本地工作台支持对话、直接编辑、段落修改、历史和导出。文档保存在自己的文件夹中，Agent 的回答使用你配置的本机模型服务。</p>${installation}<h2>开始第一篇学习文档</h2><ol><li>打开或新建一个学习空间，把已有材料整理到学习文档中。</li><li>提出具体问题，请 Agent 结合提供的资料解释并写入文档。</li><li>阅读保存结果，加入自己的例子，选中段落继续追问或修改。</li></ol><p>Agent 只访问工作台提供的学习文档和受控工具。打开文件夹不等于已经读取里面的源码。Codex 支持逐段实时编辑；Claude 生成修改后由工作台保存。</p><h2>导出与备份</h2><p>Markdown 导出适合分享已保存的正文。恢复整个工作台还需要保存 manifest、配置以及 <code>.learn/</code> 中的协作状态和历史。公开发布前，选择并审阅要公开的篇目。</p></article></main>`;
    files.set("getting-started/index.html", shell("本地使用指南", "在本地使用观澜 Velora，把提供的材料整理成可以持续编辑的学习文档。", "getting-started/", guide, { "@context": "https://schema.org", "@type": "WebPage", name: "本地使用指南", inLanguage: "zh-CN" }));
    files.set("404.html", shell("找不到这篇文章", "这篇文章不存在或已停止公开。", "404.html", `<main id="main" class="public-article standalone-page" tabindex="-1"><p class="eyebrow">404</p><h1>这篇文章暂时找不到了</h1><p>它可能已经移动，或不再公开。</p><a class="text-link" href="${href(collectionPath)}">返回全部文章 ↗</a></main>`, { "@context": "https://schema.org", "@type": "WebPage", name: "找不到这篇文章" }, true));
    files.set("favicon.svg", '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><rect width="40" height="40" rx="10" fill="#191b20"/><text x="20" y="27" text-anchor="middle" fill="white" font-size="24">澜</text></svg>');
    files.set("robots.txt", `User-agent: *\nAllow: /\n${address ? `Sitemap: ${absolute("sitemap.xml")}\n` : ""}`);
    if (address) files.set("sitemap.xml", `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${escape(absolute()!)}</loc></url><url><loc>${escape(absolute("getting-started/")!)}</loc></url>${release ? `<url><loc>${escape(absolute(collectionPath)!)}</loc></url>` : ""}${documents.map(document => `<url><loc>${escape(absolute(articlePath(document.id))!)}</loc><lastmod>${escape(document.modifiedAt)}</lastmod></url>`).join("")}</urlset>`);
    return files;
  } finally { dom.window.close(); }
}
