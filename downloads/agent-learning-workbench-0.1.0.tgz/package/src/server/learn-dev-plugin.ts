import path from "node:path";
import { promises as fs } from "node:fs";
import { createHash } from "node:crypto";
import type { Plugin } from "vite";
import { LearnError } from "../domain/errors";
import { publicSiteAddress, renderPublicSite, type PublicSiteOptions } from "./public-site";

export function learnWorkbenchPlugin(initialRoots: string[], backendOrigin?: string, publicSite?: PublicSiteOptions) {
  const virtualId = "virtual:project-learning-content";
  const resolvedVirtualId = `\0${virtualId}`;
  let command: "serve" | "build" = "serve";
  const address = publicSiteAddress(publicSite?.siteUrl);
  return {
    name: "agent-learning-workbench-ui",
    enforce: "pre" as const,
    config(config, environment) {
      return {
        ...(!backendOrigin ? { base: address?.pathname ?? "/" } : {}),
        resolve: { dedupe: ["yjs", "@tiptap/core", "@tiptap/y-tiptap", "prosemirror-model", "prosemirror-state", "prosemirror-view", "prosemirror-transform"] },
        ...(backendOrigin ? {
          // Different frontend proxies have different dependency hashes. Sharing
          // their cache can replace React chunks under another running server.
          cacheDir: path.resolve(config.root ?? ".", "node_modules", `.vite-workbench-${config.server?.port ?? "build"}`),
          server: { proxy: {
            "/api/v1": { target: backendOrigin, changeOrigin: false },
            "/__learn_bootstrap__.js": { target: backendOrigin, changeOrigin: false },
          } },
        } : {}),
      };
    },
    configResolved(config: { command: "serve" | "build" }) { command = config.command; },
    resolveId(id: string) { return id === virtualId ? resolvedVirtualId : null; },
    load: (id: string) => {
      if (id !== resolvedVirtualId) return null;
      return `export default ${JSON.stringify({
        site: { title: "观澜 Velora" }, documents: [], manifestHash: "", runtime: { adapter: "loading", available: false },
      })};`;
    },
    transformIndexHtml: { order: "pre", handler() {
      if (command === "build" && !backendOrigin) {
        return '<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><script type="module" src="/src/public.ts"></script></head><body></body></html>';
      }
      if (!backendOrigin) return [];
      return [{ tag: "script", attrs: { src: "/__learn_bootstrap__.js" }, injectTo: "head-prepend" as const }];
    } },
    configurePreviewServer(server) {
      if (backendOrigin) return;
      const directory = path.resolve(server.config.root, server.config.build.outDir);
      server.middlewares.use((request, response, next) => {
        void (async () => {
          const pathname = new URL(request.url ?? "/", "http://localhost").pathname;
          const base = server.config.base;
          const relative = pathname.startsWith(base) ? pathname.slice(base.length) : "../";
          const file = path.resolve(directory, !relative || relative.endsWith("/") ? `${relative}index.html` : relative);
          const within = !path.relative(directory, file).startsWith("..") && !path.isAbsolute(path.relative(directory, file));
          const exists = within && await fs.stat(file).then(stat => stat.isFile(), error => {
            if (["ENOENT", "ENOTDIR"].includes(error.code)) return false;
            throw error;
          });
          if (exists && ["GET", "HEAD"].includes(request.method ?? "GET")) { next(); return; }
          response.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
          response.end(request.method === "HEAD" ? undefined : await fs.readFile(path.join(directory, "404.html")));
        })().catch(next);
      });
    },
    generateBundle: { order: "post", async handler(_options, bundle) {
      if (backendOrigin) return;
      if (initialRoots.length !== 1) throw new LearnError("STATIC_MULTISPACE_UNSUPPORTED", "Static builds require exactly one learning space", 422);
      if (!publicSite) throw new LearnError("PUBLIC_DOCUMENTS_REQUIRED", "公开构建需要明确选择文档", 422);
      const index = bundle["index.html"];
      if (!index || index.type !== "asset") throw new Error("Public build did not emit its HTML entry");
      const assets = String(index.source).match(/<script\b[^>]*>[\s\S]*?<\/script>|<link\b[^>]*rel="stylesheet"[^>]*>/g)?.join("") ?? "";
      const binary = publicSite.release ? await fs.readFile(publicSite.release.file) : undefined;
      const release = binary && publicSite.release ? { version: publicSite.release.version, fileName: path.basename(publicSite.release.file), bytes: binary.length, sha256: createHash("sha256").update(binary).digest("hex") } : undefined;
      const pages = await renderPublicSite(initialRoots[0]!, publicSite, address, assets, release);
      if (release && binary) {
        this.emitFile({ type: "asset", fileName: `downloads/${release.fileName}`, source: binary });
        this.emitFile({ type: "asset", fileName: `downloads/${release.fileName}.sha256`, source: `${release.sha256}  ${release.fileName}\n` });
      }
      index.source = pages.get("index.html")!;
      for (const [fileName, source] of pages) if (fileName !== "index.html") this.emitFile({ type: "asset", fileName, source });
    } },
  } satisfies Plugin;
}
