import { createHash } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";
import { WorkspaceStore } from "../adapters/filesystem/workspace-store";
import { LearnError } from "../domain/errors";
import { readLearnConfig } from "../composition/config";
import { initializeWorkspace } from "../installer/init-workspace";

export type LearningSpaceSummary = {
  id: string;
  root: string;
  title: string;
  description?: string;
};

type LearningSpaceRecord = LearningSpaceSummary & {
  manifestPath: string;
};

function publicSummary(record: LearningSpaceRecord): LearningSpaceSummary {
  const { manifestPath: _manifestPath, ...summary } = record;
  return { ...summary };
}

export class SpaceRegistry {
  private readonly spaces = new Map<string, LearningSpaceRecord>();
  private readonly idsByRoot = new Map<string, string>();

  async register(candidateRoot: string, options: { initialize?: boolean } = {}): Promise<LearningSpaceSummary> {
    if (!path.isAbsolute(candidateRoot)) {
      throw new LearnError("INVALID_SPACE_ROOT", "请输入完整的文件夹路径，或点击“浏览文件夹”选择。", 422);
    }
    const root = await fs.realpath(candidateRoot).catch((error) => {
      throw new LearnError(
        "INVALID_SPACE_ROOT",
        "无法访问这个文件夹，请确认它仍然存在且有访问权限。",
        422,
        { cause: error instanceof Error ? error.message : String(error) },
      );
    });
    if (!(await fs.stat(root)).isDirectory()) throw new LearnError("INVALID_SPACE_ROOT", "请选择文件夹，而不是文件。", 422);
    const { config, manifestPath } = await readLearnConfig(root).catch(async (error) => {
      if (!options.initialize || !(error instanceof LearnError) || error.code !== "WORKSPACE_NOT_INITIALIZED") throw error;
      await initializeWorkspace(root, { title: path.basename(root).slice(0, 160) || "学习空间" });
      return readLearnConfig(root);
    });
    const existingId = this.idsByRoot.get(root);
    if (existingId) return publicSummary(this.spaces.get(existingId)!);

    const store = new WorkspaceStore(root, manifestPath, config.documentSizeLimitBytes);
    await store.initialize();
    const id = createHash("sha256").update(root).digest("hex").slice(0, 16);
    const record: LearningSpaceRecord = {
      id,
      root,
      title: store.site.title,
      ...(store.site.description ? { description: store.site.description } : {}),
      manifestPath,
    };
    this.spaces.set(id, record);
    this.idsByRoot.set(root, id);
    return publicSummary(record);
  }

  list(): LearningSpaceSummary[] {
    return [...this.spaces.values()].map(publicSummary);
  }

  require(id: string): LearningSpaceSummary {
    const record = this.spaces.get(id);
    if (!record) throw new LearnError("SPACE_NOT_FOUND", `Unknown learning space: ${id}`, 404);
    return publicSummary(record);
  }
}
