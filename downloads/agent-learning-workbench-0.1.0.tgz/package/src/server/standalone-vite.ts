import path from "node:path";
import { promises as fs } from "node:fs";
import react from "@vitejs/plugin-react";
import { build, createServer, type ViteDevServer } from "vite";
import { LearnError } from "../domain/errors";
import { learnWorkbenchPlugin } from "./learn-dev-plugin";
import { bundledSiteRoot, startLocalServer } from "./local-server";
import type { PublicSiteOptions } from "./public-site";

export async function startStandaloneDevServer(repositoryRoot: string, port: number) {
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new LearnError("INVALID_PORT", "port must be between 1 and 65535", 422);
  const siteRoot = await bundledSiteRoot();
  const backend = await startLocalServer([repositoryRoot], { port: 0, webRoot: siteRoot });
  let frontend: ViteDevServer | undefined;
  const startFrontend = async () => {
    frontend = await createServer({
      root: siteRoot, configFile: false,
      plugins: [react(), learnWorkbenchPlugin([], backend.origin)],
      server: { host: "127.0.0.1", port, strictPort: true },
    });
    await frontend.listen();
  };
  try { await startFrontend(); }
  catch (error) { await frontend?.close(); await backend.close(); throw error; }
  const address = frontend!.httpServer!.address();
  if (!address || typeof address === "string") throw new Error("Frontend did not expose a TCP address");
  return {
    origin: `http://127.0.0.1:${address.port}`,
    backendOrigin: backend.origin,
    async restartFrontend() { await frontend?.close(); await startFrontend(); },
    async close() { await frontend?.close(); await backend.close(); },
  };
}

export async function buildStandaloneSite(repositoryRoot: string, outDir: string, options: PublicSiteOptions): Promise<void> {
  const root = await fs.realpath(repositoryRoot);
  const requestedOutput = path.resolve(outDir);
  await fs.mkdir(path.dirname(requestedOutput), { recursive: true });
  const output = path.join(await fs.realpath(path.dirname(requestedOutput)), path.basename(requestedOutput));
  const rootFromOutput = path.relative(output, root);
  if (rootFromOutput === "" || (!rootFromOutput.startsWith("..") && !path.isAbsolute(rootFromOutput))) {
    throw new LearnError(
      "UNSAFE_OUTPUT_DIRECTORY",
      "Build output must not be the repository root or one of its parent directories",
      422,
    );
  }
  const marker = ".velora-static";
  let exists = false;
  try {
    const stat = await fs.lstat(output);
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw new LearnError("UNSAFE_OUTPUT_DIRECTORY", "输出路径必须是专用站点目录", 422);
    exists = true;
    if ((await fs.readdir(output)).length && await fs.readFile(path.join(output, marker), "utf8").catch(error => {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return "";
      throw error;
    }) !== "velora-public-site\n") throw new LearnError("UNSAFE_OUTPUT_DIRECTORY", "输出目录包含其他文件，请指定新的专用站点目录", 422);
  } catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
  const staging = await fs.mkdtemp(path.join(path.dirname(output), `.${path.basename(output)}-build-`));
  const previous = `${staging}-previous`;
  try {
    await build({
      root: await bundledSiteRoot(), configFile: false,
      plugins: [react(), learnWorkbenchPlugin([root], undefined, options)],
      build: { outDir: staging, emptyOutDir: false },
    });
    await fs.writeFile(path.join(staging, marker), "velora-public-site\n");
    if (exists) await fs.rename(output, previous);
    try { await fs.rename(staging, output); }
    catch (error) { if (exists) await fs.rename(previous, output); throw error; }
    if (exists) await fs.rm(previous, { recursive: true });
  } finally { await fs.rm(staging, { recursive: true, force: true }); }
}
