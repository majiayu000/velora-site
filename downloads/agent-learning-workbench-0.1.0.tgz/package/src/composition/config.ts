import { promises as fs } from "node:fs";
import path from "node:path";
import { LearnError } from "../domain/errors";

export type LearnConfig = {
  version: 1;
  manifest: string;
  documentSizeLimitBytes: number;
  runtime: { adapter: string; command: string; args?: string[] };
};

export async function readLearnConfig(repositoryRoot: string): Promise<{ config: LearnConfig; configPath: string; manifestPath: string }> {
  const root = await fs.realpath(repositoryRoot);
  const configPath = path.join(root, "learn.config.json");
  let value: unknown;
  try { value = JSON.parse(await fs.readFile(configPath, "utf8")); }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") {
      throw new LearnError("WORKSPACE_NOT_INITIALIZED", "这个文件夹尚未创建学习空间，请通过“打开学习空间”添加。", 409);
    }
    throw new LearnError("INVALID_CONFIG", "学习空间配置无法读取或格式损坏，请检查 learn.config.json。", 422, {
      cause: error instanceof Error ? error.message : String(error),
    });
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new LearnError("INVALID_CONFIG", "learn.config.json must be an object", 500);
  const config = value as Partial<LearnConfig>;
  if (
    config.version !== 1 || typeof config.manifest !== "string" || !Number.isInteger(config.documentSizeLimitBytes) || Number(config.documentSizeLimitBytes) < 1 || Number(config.documentSizeLimitBytes) > 10 * 1024 * 1024 ||
    !config.runtime || typeof config.runtime.adapter !== "string" || !config.runtime.adapter || typeof config.runtime.command !== "string" || !config.runtime.command ||
    (config.runtime.args !== undefined && (!Array.isArray(config.runtime.args) || config.runtime.args.some((arg) => typeof arg !== "string")))
  ) throw new LearnError("INVALID_CONFIG", "learn.config.json does not satisfy the v1 contract", 500);
  if (path.isAbsolute(config.manifest) || config.manifest.includes("\\") || config.manifest.split("/").some((part) => !part || part === "." || part === "..") || !config.manifest.endsWith(".json")) {
    throw new LearnError("INVALID_CONFIG", "manifest must be a normalized repository-relative JSON path", 500);
  }
  const manifestPath = path.resolve(root, config.manifest);
  const relative = path.relative(root, manifestPath);
  if (relative.startsWith("..") || path.isAbsolute(relative)) throw new LearnError("PATH_ESCAPE", "manifest escapes repository root", 500);
  return { config: config as LearnConfig, configPath, manifestPath };
}
