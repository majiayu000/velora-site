import { FileCollaboration } from "../adapters/collaboration/file-collaboration";
import { WorkspaceStore } from "../adapters/filesystem/workspace-store";
import { CodexRuntime } from "../adapters/runtime-codex/codex-runtime";
import { ClaudeRuntime } from "../adapters/runtime-claude/claude-runtime";
import { JsonStdioRuntime } from "../adapters/runtime-json-stdio/json-stdio-runtime";
import { FileReceiptStore } from "../adapters/receipts/file-receipt-store";
import { GitHistory } from "../adapters/git/git-history";
import { EventHub } from "../application/event-hub";
import { LearnEngine } from "../application/learn-engine";
import { LearnError } from "../domain/errors";
import type { RuntimePort } from "../ports/runtime-port";
import { readLearnConfig } from "./config";

export async function createLearnEngine(options: {
  repositoryRoot: string;
  profile?: "interactive" | "static";
  runtime?: RuntimePort;
}): Promise<LearnEngine> {
  const { config, manifestPath } = await readLearnConfig(options.repositoryRoot);
  const store = new WorkspaceStore(options.repositoryRoot, manifestPath, config.documentSizeLimitBytes);
  const runtime = options.runtime ?? createRuntimeAdapter(options.repositoryRoot, options.profile ?? "interactive", config.runtime);
  const events = new EventHub();
  const engine = options.profile === "static"
    ? new LearnEngine(store, new EventHub(), runtime)
    : new LearnEngine(store, events, runtime, new FileReceiptStore(options.repositoryRoot), new GitHistory(options.repositoryRoot), new FileCollaboration(options.repositoryRoot, store, events, config.documentSizeLimitBytes));
  await engine.initialize();
  return engine;
}

export function createRuntimeAdapter(repositoryRoot: string, profile: "interactive" | "static", config: Awaited<ReturnType<typeof readLearnConfig>>["config"]["runtime"]): RuntimePort {
  if (profile === "static") return {
    available: false,
    health: async () => ({ adapter: config.adapter, available: false, message: "静态构建不包含 Agent Runtime" }),
    run: async () => { throw new LearnError("STATIC_BUILD", "静态构建不包含 Agent Runtime", 405); },
    close: () => undefined,
  };
  if (config.adapter === "json-stdio") return new JsonStdioRuntime(repositoryRoot, config.command, config.args);
  if (config.adapter === "codex-app-server") return new CodexRuntime(repositoryRoot, config.command);
  if (config.adapter === "claude-code") return new ClaudeRuntime(repositoryRoot, config.command, config.args);
  throw new LearnError("UNSUPPORTED_RUNTIME", `Unsupported Runtime adapter: ${config.adapter}`, 500);
}
