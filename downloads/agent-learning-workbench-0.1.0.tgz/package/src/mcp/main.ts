#!/usr/bin/env node
import { serveStdio } from "@modelcontextprotocol/server/stdio";
import { createLearnMcpServer } from "./server";
import { createLearnWorkbench } from "../sdk/index";

const root = process.env.LEARN_WORKSPACE_ROOT ?? process.cwd();
const sdkPromise = createLearnWorkbench({ repositoryRoot: root });
const handle = serveStdio(async () => createLearnMcpServer(await sdkPromise), {
  onerror: (error) => console.error(`learn-workbench MCP error: ${error.message}`),
});

async function close(): Promise<void> {
  await handle.close();
  (await sdkPromise).close();
}

process.once("SIGINT", () => { void close(); });
process.once("SIGTERM", () => { void close(); });
