import { createHash, randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";
import { LearnError } from "../../domain/errors";
import { validateDocumentMetadata, validateStructureOperations } from "../../domain/structure";
import type { DocumentMetadata, DocumentSnapshot, LearnManifest, SearchResult, StructureMutationResult, StructureOperation } from "../../domain/types";

type RegisteredDocument = { metadata: DocumentMetadata; declaredPath: string; realPath: string };

function isWithin(candidate: string, parent: string): boolean {
  const relative = path.relative(parent, candidate);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function hash(body: string | Uint8Array): string {
  const digest = createHash("sha256");
  if (typeof body === "string") digest.update(body, "utf8");
  else digest.update(body);
  return `sha256:${digest.digest("hex")}`;
}

export class WorkspaceStore {
  private manifest!: LearnManifest;
  private documents = new Map<string, RegisteredDocument>();
  private queues = new Map<string, Promise<unknown>>();
  private resolvedRoot = "";
  private contentRoots: string[] = [];
  private manifestDigest = "";
  private structureQueue: Promise<void> = Promise.resolve();

  constructor(
    private readonly repositoryRoot: string,
    private readonly manifestPath: string,
    private readonly sizeLimitBytes = 1024 * 1024,
  ) {}

  async initialize(): Promise<void> {
    const root = await fs.realpath(this.repositoryRoot);
    const raw = await fs.readFile(this.manifestPath, "utf8");
    const manifest = JSON.parse(raw) as Partial<LearnManifest>;
    if (manifest.version !== 1 || !manifest.site || typeof manifest.site !== "object" || Array.isArray(manifest.site) || !Array.isArray(manifest.contentRoots) || !manifest.contentRoots.length || !Array.isArray(manifest.documents)) {
      throw new LearnError("INVALID_MANIFEST", "learn.manifest.json does not satisfy the v1 contract", 500);
    }
    const site = manifest.site as Record<string, unknown>;
    if (typeof site.title !== "string" || !site.title.trim() || site.title.length > 160 || (site.description !== undefined && typeof site.description !== "string")) {
      throw new LearnError("INVALID_MANIFEST", "site title and description do not satisfy the v1 contract", 500);
    }
    let documents: DocumentMetadata[];
    try {
      documents = manifest.documents.map((candidate) => validateDocumentMetadata(candidate));
    } catch (error) {
      throw new LearnError("INVALID_MANIFEST", error instanceof Error ? error.message : "Document metadata is malformed", 500);
    }
    const contentRoots = await Promise.all(
      manifest.contentRoots.map(async (entry) => {
        if (typeof entry !== "string") throw new LearnError("INVALID_MANIFEST", "contentRoots must contain strings", 500);
        const resolved = await fs.realpath(path.resolve(root, entry));
        if (!isWithin(resolved, root)) throw new LearnError("INVALID_MANIFEST", `Content root escapes repository: ${entry}`, 500);
        return resolved;
      }),
    );
    const registered = new Map<string, RegisteredDocument>();
    const registeredPaths = new Set<string>();
    for (const candidate of documents) {
      if (registered.has(candidate.id)) throw new LearnError("INVALID_MANIFEST", `Duplicate document id: ${candidate.id}`, 500);
      const declaredPath = path.resolve(root, candidate.path);
      const realPath = await fs.realpath(declaredPath);
      if (!contentRoots.some((contentRoot) => isWithin(realPath, contentRoot))) {
        throw new LearnError("PATH_ESCAPE", `Document escapes contentRoots: ${candidate.path}`, 500);
      }
      if (registeredPaths.has(realPath)) throw new LearnError("INVALID_MANIFEST", `Multiple document ids resolve to the same file: ${candidate.path}`, 500);
      registeredPaths.add(realPath);
      registered.set(candidate.id, { metadata: candidate, declaredPath, realPath });
    }
    this.manifest = {
      version: 1,
      site: { title: site.title.trim(), ...(typeof site.description === "string" ? { description: site.description } : {}) },
      contentRoots: [...manifest.contentRoots] as string[],
      documents,
    };
    this.documents = registered;
    this.resolvedRoot = root;
    this.contentRoots = contentRoots;
    this.manifestDigest = hash(raw);
  }

  get documentRoots(): string[] { return [...this.manifest.contentRoots]; }

  get site(): LearnManifest["site"] {
    return this.manifest.site;
  }

  get manifestHash(): string {
    return this.manifestDigest;
  }

  listDocuments(): DocumentMetadata[] {
    return this.manifest.documents.map((document) => ({ ...document }));
  }

  getWatchPaths(): string[] {
    return [...this.documents.values()].map((document) => document.realPath);
  }

  async getDocument(id: string): Promise<DocumentSnapshot> {
    await this.structureQueue;
    const registered = this.requireDocument(id);
    await this.assertStillSafe(registered);
    const stat = await fs.stat(registered.realPath);
    if (stat.size > this.sizeLimitBytes) {
      throw new LearnError("DOCUMENT_TOO_LARGE", `Document exceeds ${this.sizeLimitBytes} bytes`, 413);
    }
    const body = await fs.readFile(registered.realPath, "utf8");
    return {
      ...registered.metadata,
      body,
      contentHash: hash(body),
      modifiedAt: stat.mtime.toISOString(),
    };
  }

  async saveDocument(id: string, body: string, expectedHash: string): Promise<DocumentSnapshot> {
    if (typeof body !== "string" || Buffer.byteLength(body, "utf8") > this.sizeLimitBytes) {
      throw new LearnError("DOCUMENT_TOO_LARGE", `Document exceeds ${this.sizeLimitBytes} bytes`, 413);
    }
    if (!expectedHash) throw new LearnError("PRECONDITION_REQUIRED", "If-Match is required", 428);
    await this.structureQueue;
    const prior = this.queues.get(id) ?? Promise.resolve();
    const operation = prior.then(() => this.performSave(id, body, expectedHash));
    const queued = operation.catch(() => undefined);
    this.queues.set(id, queued);
    try {
      return await operation;
    } finally {
      if (this.queues.get(id) === queued) this.queues.delete(id);
    }
  }

  async applyStructure(operations: StructureOperation[], expectedManifestHash: string): Promise<StructureMutationResult> {
    if (!expectedManifestHash) throw new LearnError("PRECONDITION_REQUIRED", "Manifest If-Match is required", 428);
    const validated = validateStructureOperations(operations, this.sizeLimitBytes);
    const previous = this.structureQueue;
    let release!: () => void;
    this.structureQueue = new Promise<void>((resolve) => { release = resolve; });
    await previous;
    try {
      return await this.performStructure(validated, expectedManifestHash);
    } finally {
      release();
    }
  }

  async searchDocuments(query: string, limit = 20): Promise<SearchResult[]> {
    await this.structureQueue;
    const needle = query.trim().toLocaleLowerCase();
    if (!needle || needle.length > 200) {
      if (!needle) return [];
      throw new LearnError("INVALID_SEARCH", "Search query must contain at most 200 characters", 400);
    }
    const cappedLimit = Math.max(1, Math.min(50, Math.floor(limit)));
    const results = await Promise.all(this.listDocuments().map(async (document) => {
      const snapshot = await this.getDocument(document.id);
      const fields = [document.title, document.summary, ...(document.tags ?? [])].map((value) => value.toLocaleLowerCase());
      const body = snapshot.body.toLocaleLowerCase();
      let score = fields.reduce((total, value, index) => total + (value.includes(needle) ? (index === 0 ? 12 : index === 1 ? 6 : 8) : 0), 0);
      let offset = body.indexOf(needle);
      while (offset >= 0) {
        score += 1;
        offset = body.indexOf(needle, offset + needle.length);
      }
      if (!score) return undefined;
      const first = body.indexOf(needle);
      const start = first < 0 ? 0 : Math.max(0, first - 80);
      const snippet = snapshot.body.slice(start, start + 220).replace(/\s+/g, " ").trim();
      return { document, score, snippet } satisfies SearchResult;
    }));
    return results.filter((item): item is SearchResult => Boolean(item)).sort((left, right) => right.score - left.score || left.document.title.localeCompare(right.document.title)).slice(0, cappedLimit);
  }

  async fingerprintDocument(relativePath: string): Promise<string> {
    await this.structureQueue;
    const registered = [...this.documents.values()].find(document => document.metadata.path === relativePath);
    if (!registered) throw new LearnError("EVIDENCE_NOT_FOUND", "引用不是工作台已登记的学习文档，未核验。", 422);
    return (await this.getDocument(registered.metadata.id)).contentHash;
  }

  private async performStructure(operations: StructureOperation[], expectedManifestHash: string): Promise<StructureMutationResult> {
    const manifestRaw = await fs.readFile(this.manifestPath, "utf8");
    const actualHash = hash(manifestRaw);
    if (actualHash !== expectedManifestHash || actualHash !== this.manifestDigest) {
      throw new LearnError("MANIFEST_CONFLICT", "磁盘上的站点清单已被其他写者修改", 409, { expectedHash: expectedManifestHash, actualHash });
    }

    const nextDocuments = this.listDocuments();
    const byId = new Map(nextDocuments.map((document) => [document.id, document]));
    const creates: Array<{ operation: Extract<StructureOperation, { type: "create" }>; target: string; temporary: string }> = [];
    const renames: Array<{ source: string; target: string; documentId: string }> = [];
    const deletes: Array<{ source: string; backup: string; documentId: string }> = [];
    const transactionId = randomUUID();

    for (const operation of operations) {
      if (operation.type === "create") {
        if (byId.has(operation.document.id)) throw new LearnError("DOCUMENT_EXISTS", `Document id already exists: ${operation.document.id}`, 409);
        const target = await this.resolveNewDocumentPath(operation.document.path);
        if (nextDocuments.some((document) => path.resolve(this.resolvedRoot, document.path) === target)) {
          throw new LearnError("DOCUMENT_EXISTS", `Document path is already registered: ${operation.document.path}`, 409);
        }
        nextDocuments.push({ ...operation.document });
        byId.set(operation.document.id, nextDocuments[nextDocuments.length - 1]);
        creates.push({ operation, target, temporary: path.join(path.dirname(target), `.${path.basename(target)}.${transactionId}.tmp`) });
      } else if (operation.type === "update") {
        const document = byId.get(operation.documentId);
        if (!document) throw new LearnError("DOCUMENT_NOT_FOUND", `Unknown registered document: ${operation.documentId}`, 404);
        document.title = operation.title;
        document.summary = operation.summary;
      } else if (operation.type === "rename") {
        const document = byId.get(operation.documentId);
        if (!document) throw new LearnError("DOCUMENT_NOT_FOUND", `Unknown registered document: ${operation.documentId}`, 404);
        const registered = this.requireDocument(operation.documentId);
        await this.assertStillSafe(registered);
        const target = await this.resolveNewDocumentPath(operation.nextPath);
        if (target === registered.realPath) throw new LearnError("EMPTY_STRUCTURE_CHANGE", "Rename must change the document path", 422);
        if (nextDocuments.some((candidate) => candidate.id !== operation.documentId && path.resolve(this.resolvedRoot, candidate.path) === target)) {
          throw new LearnError("DOCUMENT_EXISTS", `Document path is already registered: ${operation.nextPath}`, 409);
        }
        document.path = operation.nextPath;
        if (operation.title) document.title = operation.title;
        renames.push({ source: registered.realPath, target, documentId: operation.documentId });
      } else {
        const document = byId.get(operation.documentId);
        if (!document) throw new LearnError("DOCUMENT_NOT_FOUND", `Unknown registered document: ${operation.documentId}`, 404);
        const registered = this.requireDocument(operation.documentId);
        await this.assertStillSafe(registered);
        const index = nextDocuments.findIndex((candidate) => candidate.id === operation.documentId);
        nextDocuments.splice(index, 1);
        byId.delete(operation.documentId);
        deletes.push({ source: registered.realPath, backup: path.join(path.dirname(registered.realPath), `.${path.basename(registered.realPath)}.${transactionId}.bak`), documentId: operation.documentId });
      }
    }

    const validIds = new Set(nextDocuments.map((document) => document.id));
    for (const document of nextDocuments) {
      document.prerequisites = document.prerequisites?.filter((id) => validIds.has(id));
      document.related = document.related?.filter((id) => validIds.has(id));
    }
    const nextManifest: LearnManifest = { ...this.manifest, documents: nextDocuments };
    const nextRaw = `${JSON.stringify(nextManifest, null, 2)}\n`;
    const manifestTemporary = path.join(path.dirname(this.manifestPath), `.${path.basename(this.manifestPath)}.${transactionId}.tmp`);
    const committedCreates: string[] = [];
    const committedRenames: Array<{ source: string; target: string }> = [];
    const committedDeletes: Array<{ source: string; backup: string }> = [];
    let manifestCommitted = false;
    try {
      for (const entry of creates) {
        const handle = await fs.open(entry.temporary, "wx", 0o600);
        try { await handle.writeFile(entry.operation.body, "utf8"); await handle.sync(); } finally { await handle.close(); }
      }
      const manifestHandle = await fs.open(manifestTemporary, "wx", 0o600);
      try { await manifestHandle.writeFile(nextRaw, "utf8"); await manifestHandle.sync(); } finally { await manifestHandle.close(); }
      for (const entry of creates) { await fs.rename(entry.temporary, entry.target); committedCreates.push(entry.target); }
      for (const entry of renames) { await fs.rename(entry.source, entry.target); committedRenames.push({ source: entry.source, target: entry.target }); }
      for (const entry of deletes) { await fs.rename(entry.source, entry.backup); committedDeletes.push({ source: entry.source, backup: entry.backup }); }
      await fs.rename(manifestTemporary, this.manifestPath);
      manifestCommitted = true;
    } catch (error) {
      if (!manifestCommitted) {
        const rollbackErrors: string[] = [];
        for (const entry of committedDeletes.reverse()) await fs.rename(entry.backup, entry.source).catch((rollback) => rollbackErrors.push(String(rollback)));
        for (const entry of committedRenames.reverse()) await fs.rename(entry.target, entry.source).catch((rollback) => rollbackErrors.push(String(rollback)));
        for (const target of committedCreates.reverse()) await fs.unlink(target).catch((rollback: NodeJS.ErrnoException) => { if (rollback.code !== "ENOENT") rollbackErrors.push(String(rollback)); });
        if (rollbackErrors.length) throw new LearnError("STRUCTURE_ROLLBACK_FAILED", "结构变更失败且回滚不完整", 500, { cause: String(error), rollbackErrors });
      }
      throw error;
    } finally {
      await Promise.all([...creates.map((entry) => entry.temporary), manifestTemporary].map((temporary) => fs.unlink(temporary).catch((error: NodeJS.ErrnoException) => { if (error.code !== "ENOENT") throw error; })));
    }

    const postCommit = await Promise.allSettled([
      this.syncDirectories(new Set([path.dirname(this.manifestPath), ...creates.map((entry) => path.dirname(entry.target)), ...renames.flatMap((entry) => [path.dirname(entry.source), path.dirname(entry.target)]), ...deletes.map((entry) => path.dirname(entry.source))])),
      ...committedDeletes.map((entry) => fs.unlink(entry.backup)),
    ]);
    const warnings = postCommit.filter((result) => result.status === "rejected").map((result) => `Post-commit durability cleanup failed: ${String((result as PromiseRejectedResult).reason)}`);
    const changedPaths = [...new Set([
      path.relative(this.resolvedRoot, this.manifestPath).split(path.sep).join("/"),
      ...operations.flatMap((operation) => {
        if (operation.type === "create") return [operation.document.path];
        if (operation.type === "update") return [];
        const previousPath = this.requireDocument(operation.documentId).metadata.path;
        if (operation.type === "rename") return [previousPath, operation.nextPath];
        return [previousPath];
      }),
    ])];
    await this.initialize();
    return { manifestHash: this.manifestDigest, documents: this.listDocuments(), changedPaths, warnings: warnings.length ? warnings : undefined };
  }

  private async resolveNewDocumentPath(relativePath: string): Promise<string> {
    const target = path.resolve(this.resolvedRoot, relativePath);
    const parent = await fs.realpath(path.dirname(target)).catch((error: NodeJS.ErrnoException) => {
      if (error.code === "ENOENT") throw new LearnError("DOCUMENT_DIRECTORY_NOT_FOUND", "New documents must use an existing content directory", 422);
      throw error;
    });
    if (!this.contentRoots.some((root) => isWithin(parent, root)) || !isWithin(target, parent)) {
      throw new LearnError("PATH_ESCAPE", `Document escapes contentRoots: ${relativePath}`, 422);
    }
    await fs.lstat(target).then(
      () => { throw new LearnError("DOCUMENT_EXISTS", `Target path already exists: ${relativePath}`, 409); },
      (error: NodeJS.ErrnoException) => { if (error.code !== "ENOENT") throw error; },
    );
    return target;
  }

  private async syncDirectories(directories: Set<string>): Promise<void> {
    for (const directory of directories) {
      const handle = await fs.open(directory, "r");
      try { await handle.sync(); } finally { await handle.close(); }
    }
  }

  private async performSave(id: string, body: string, expectedHash: string): Promise<DocumentSnapshot> {
    const registered = this.requireDocument(id);
    await this.assertStillSafe(registered);
    const current = await this.getDocument(id);
    if (current.contentHash !== expectedHash) {
      throw new LearnError("DOCUMENT_CONFLICT", "磁盘上的文档已被其他写者修改", 409, {
        expectedHash,
        actualHash: current.contentHash,
      });
    }
    const directory = path.dirname(registered.realPath);
    const temporaryPath = path.join(directory, `.${path.basename(registered.realPath)}.${randomUUID()}.tmp`);
    let handle: Awaited<ReturnType<typeof fs.open>> | undefined;
    try {
      handle = await fs.open(temporaryPath, "wx", 0o600);
      await handle.writeFile(body, "utf8");
      await handle.sync();
      await handle.close();
      handle = undefined;
      await fs.rename(temporaryPath, registered.realPath);
      const directoryHandle = await fs.open(directory, "r");
      try {
        await directoryHandle.sync();
      } finally {
        await directoryHandle.close();
      }
    } catch (error) {
      if (handle) await handle.close().catch(() => undefined);
      await fs.unlink(temporaryPath).catch((unlinkError: NodeJS.ErrnoException) => {
        if (unlinkError.code !== "ENOENT") throw unlinkError;
      });
      throw error;
    }
    const saved = await this.getDocument(id);
    if (saved.contentHash !== hash(body)) {
      throw new LearnError("WRITE_VERIFICATION_FAILED", "Saved document did not match requested content", 500);
    }
    return saved;
  }

  private requireDocument(id: string): RegisteredDocument {
    const registered = this.documents.get(id);
    if (!registered) throw new LearnError("DOCUMENT_NOT_FOUND", `Unknown registered document: ${id}`, 404);
    return registered;
  }

  private async assertStillSafe(registered: RegisteredDocument): Promise<void> {
    const currentRealPath = await fs.realpath(registered.declaredPath);
    if (currentRealPath !== registered.realPath) {
      throw new LearnError("PATH_CHANGED", "Document realpath changed after registration", 409);
    }
  }
}
