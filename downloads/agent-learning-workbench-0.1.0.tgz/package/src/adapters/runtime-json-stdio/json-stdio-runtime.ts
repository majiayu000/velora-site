import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { LearnError } from "../../domain/errors";
import { validateRuntimeResult } from "../../domain/runtime-result";
import type { RuntimeHealth, RuntimeRequest, RuntimeResult } from "../../domain/types";
import type { RuntimeCallbacks, RuntimePort } from "../../ports/runtime-port";
import { redactDiagnostic } from "../../domain/redact";

const OUTPUT_LIMIT = 2 * 1024 * 1024;

export class JsonStdioRuntime implements RuntimePort {
  private active?: ChildProcessWithoutNullStreams;
  private runtimeHealth: RuntimeHealth = { adapter: "json-stdio", available: true };

  constructor(
    private readonly repositoryRoot: string,
    private readonly command: string,
    private readonly args: string[] = [],
  ) {}

  get available(): boolean { return this.runtimeHealth.available; }

  async health(): Promise<RuntimeHealth> {
    try {
      const value = await this.exchange(["--learn-runtime-health"], undefined, undefined, 5_000);
      if (!value || typeof value !== "object" || (value as Record<string, unknown>).available !== true) {
        throw new LearnError("RUNTIME_PROTOCOL_ERROR", "JSON stdio health response must declare available: true", 502);
      }
      const response = value as Record<string, unknown>;
      this.runtimeHealth = {
        adapter: "json-stdio",
        available: true,
        version: typeof response.version === "string" ? response.version : undefined,
      };
    } catch (error) {
      const code = error instanceof LearnError ? error.code : "RUNTIME_UNAVAILABLE";
      this.runtimeHealth = { adapter: "json-stdio", available: false, message: `JSON stdio Runtime 初始化失败（${code}）` };
    }
    return { ...this.runtimeHealth };
  }

  async run(request: RuntimeRequest, callbacks: RuntimeCallbacks, signal: AbortSignal): Promise<RuntimeResult> {
    if (this.active) throw new LearnError("RUNTIME_BUSY", "JSON stdio Runtime already has an active turn", 409);
    callbacks.onProgress("正在调用 JSON stdio Runtime");
    const value = await this.exchange(["--learn-runtime-run"], request, signal, 120_000);
    callbacks.onProgress("正在校验 JSON stdio Runtime 结果");
    return validateRuntimeResult(value, request);
  }

  close(): void {
    this.active?.kill("SIGTERM");
    this.active = undefined;
  }

  private exchange(extraArgs: string[], input?: unknown, signal?: AbortSignal, timeoutMs = 120_000): Promise<unknown> {
    return new Promise((resolve, reject) => {
      if (signal?.aborted) { reject(new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409)); return; }
      const child = spawn(this.command, [...this.args, ...extraArgs], {
        cwd: this.repositoryRoot,
        env: process.env,
        stdio: ["pipe", "pipe", "pipe"],
      });
      this.active = child;
      let stdout = "";
      let stderr = "";
      let settled = false;
      const settleExchange = (error?: Error, value?: unknown) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        signal?.removeEventListener("abort", cancel);
        if (this.active === child) this.active = undefined;
        if (error) reject(error); else resolve(value);
      };
      const cancel = () => { child.kill("SIGTERM"); settleExchange(new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409)); };
      const timeout = setTimeout(() => { child.kill("SIGTERM"); settleExchange(new LearnError("RUNTIME_TIMEOUT", "JSON stdio Runtime timed out", 504)); }, timeoutMs);
      signal?.addEventListener("abort", cancel, { once: true });
      child.stdout.setEncoding("utf8");
      child.stderr.setEncoding("utf8");
      child.stdout.on("data", (chunk: string) => {
        stdout += chunk;
        if (Buffer.byteLength(stdout, "utf8") > OUTPUT_LIMIT) { child.kill("SIGTERM"); settleExchange(new LearnError("RUNTIME_OUTPUT_TOO_LARGE", "JSON stdio Runtime output exceeded 2 MiB", 502)); }
      });
      child.stderr.on("data", (chunk: string) => { stderr = `${stderr}${chunk}`.slice(-4_000); });
      child.once("error", (error) => settleExchange(new LearnError("RUNTIME_UNAVAILABLE", error.message, 503)));
      child.once("close", (code, exitSignal) => {
        if (settled) return;
        if (code !== 0) { settleExchange(new LearnError("RUNTIME_EXITED", `JSON stdio Runtime exited (${exitSignal ?? code ?? "unknown"})${stderr.trim() ? `: ${redactDiagnostic(stderr)}` : ""}`, 502)); return; }
        try { settleExchange(undefined, JSON.parse(stdout)); }
        catch { settleExchange(new LearnError("RUNTIME_PROTOCOL_ERROR", "JSON stdio Runtime returned invalid JSON", 502)); }
      });
      if (input === undefined) child.stdin.end();
      else child.stdin.end(JSON.stringify(input));
    });
  }
}
