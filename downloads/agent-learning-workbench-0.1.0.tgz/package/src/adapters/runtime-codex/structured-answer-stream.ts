export class StructuredAnswerStream {
  private buffer = "";
  private cursor = 0;
  private started = false;
  private completed = false;

  push(chunk: string): string {
    if (this.completed || !chunk) return "";
    this.buffer += chunk;
    if (!this.started) {
      const match = /"answerMarkdown"\s*:\s*"/.exec(this.buffer);
      if (!match) return "";
      this.started = true;
      this.cursor = match.index + match[0].length;
    }

    let output = "";
    while (this.cursor < this.buffer.length) {
      const character = this.buffer[this.cursor];
      if (character === '"') {
        this.completed = true;
        this.cursor += 1;
        break;
      }
      if (character !== "\\") {
        output += character;
        this.cursor += 1;
        continue;
      }
      if (this.cursor + 1 >= this.buffer.length) break;
      const escapeType = this.buffer[this.cursor + 1];
      const escapeLength = escapeType === "u" ? 6 : 2;
      if (this.cursor + escapeLength > this.buffer.length) break;
      const escape = this.buffer.slice(this.cursor, this.cursor + escapeLength);
      try {
        output += JSON.parse(`"${escape}"`) as string;
      } catch {
        this.completed = true;
        break;
      }
      this.cursor += escapeLength;
    }
    return output;
  }
}
