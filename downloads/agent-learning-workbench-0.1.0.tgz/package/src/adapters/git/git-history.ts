import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
import { LearnError } from "../../domain/errors";
import type { RevertPreview } from "../../domain/types";
import type { GitCommitResult, HistoryPort } from "../../ports/history-port";

const OUTPUT_LIMIT = 2 * 1024 * 1024;

type GitResult = { code: number; stdout: string; stderr: string };

function validateFiles(files: string[]): string[] {
  const unique = [...new Set(files)];
  if (!unique.length || unique.length > 100) throw new LearnError("INVALID_HISTORY_FILES", "History operation requires 1 to 100 exact files", 422);
  for (const file of unique) {
    if (!file || path.isAbsolute(file) || file.includes("\\") || file.split("/").some((part) => !part || part === "." || part === "..")) {
      throw new LearnError("INVALID_HISTORY_FILES", "History paths must be normalized and repository-relative", 422);
    }
  }
  return unique;
}

export class GitHistory implements HistoryPort {
  private available = false;
  private message = "Git 尚未检查";

  constructor(private readonly repositoryRoot: string) {}

  async initialize(): Promise<void> {
    try {
      const result = await this.git(["rev-parse", "--is-inside-work-tree"]);
      this.available = result.code === 0 && result.stdout.trim() === "true";
      this.message = this.available ? "Git 可用" : "当前工作区不是 Git 仓库，收据会保留但不会创建提交";
    } catch {
      this.available = false;
      this.message = "Git 命令不可用，收据会保留但不会创建提交";
    }
  }

  async commit(files: string[], message: string): Promise<GitCommitResult> {
    const exactFiles = validateFiles(files);
    if (!this.available) return { status: "unavailable", message: this.message };
    if (!message.trim() || message.length > 240) return { status: "failed", message: "Git commit message is invalid" };
    const temporary = await fs.mkdtemp(path.join(os.tmpdir(), "learn-git-index-"));
    const indexPath = path.join(temporary, "index");
    const environment = {
      ...process.env,
      GIT_INDEX_FILE: indexPath,
      GIT_AUTHOR_NAME: process.env.GIT_AUTHOR_NAME ?? "Velora",
      GIT_AUTHOR_EMAIL: process.env.GIT_AUTHOR_EMAIL ?? "learn-workbench@localhost",
      GIT_COMMITTER_NAME: process.env.GIT_COMMITTER_NAME ?? "Velora",
      GIT_COMMITTER_EMAIL: process.env.GIT_COMMITTER_EMAIL ?? "learn-workbench@localhost",
    };
    try {
      const head = await this.git(["rev-parse", "--verify", "HEAD"]);
      const seeded = head.code === 0 ? await this.git(["read-tree", "HEAD"], undefined, environment) : await this.git(["read-tree", "--empty"], undefined, environment);
      if (seeded.code !== 0) return { status: "failed", message: `Cannot seed temporary Git index: ${seeded.stderr.trim()}` };
      const stagedBefore = await this.git(["diff", "--cached", "--name-only", "--", ...exactFiles]);
      const added = await this.git(["add", "-A", "--", ...exactFiles], undefined, environment);
      if (added.code !== 0) return { status: "failed", message: `Cannot stage exact files: ${added.stderr.trim()}` };
      const changed = await this.git(["diff", "--cached", "--quiet", "--exit-code"], undefined, environment);
      if (changed.code === 0) return { status: "failed", message: "No Git changes were available for the mutation receipt" };
      if (changed.code !== 1) return { status: "failed", message: `Cannot inspect staged changes: ${changed.stderr.trim()}` };
      const committed = await this.git(["commit", "-m", message], undefined, environment);
      if (committed.code !== 0) return { status: "failed", message: `Exact-file Git commit failed: ${committed.stderr.trim()}` };
      const commit = await this.git(["rev-parse", "HEAD"]);
      if (commit.code !== 0) return { status: "failed", message: `Cannot resolve committed revision: ${commit.stderr.trim()}` };
      if (!stagedBefore.stdout.trim()) {
        const synced = await this.git(["reset", "--quiet", "HEAD", "--", ...exactFiles]);
        if (synced.code !== 0) return { status: "failed", message: `Commit ${commit.stdout.trim()} succeeded but the primary index could not be synchronized: ${synced.stderr.trim()}` };
      }
      return { status: "committed", commit: commit.stdout.trim() };
    } finally {
      await fs.rm(temporary, { recursive: true, force: true });
    }
  }

  async previewRevert(receiptId: string, commit: string, files: string[]): Promise<RevertPreview> {
    const exactFiles = validateFiles(files);
    if (!this.available) return { receiptId, commit, files: exactFiles, patch: "", canApply: false, conflict: this.message };
    if (!/^[a-f0-9]{7,64}$/.test(commit)) throw new LearnError("INVALID_GIT_COMMIT", "Receipt Git commit is malformed", 422);
    const patch = await this.git(["show", "--format=", "--binary", commit, "--", ...exactFiles]);
    if (patch.code !== 0) throw new LearnError("GIT_COMMIT_NOT_FOUND", "Receipt Git commit is unavailable", 409);
    const current = await this.git(["diff", "--quiet", commit, "--", ...exactFiles]);
    return {
      receiptId,
      commit,
      files: exactFiles,
      patch: patch.stdout,
      canApply: current.code === 0,
      conflict: current.code === 0 ? undefined : "受影响文件在该提交后又发生变化，禁止自动撤销",
    };
  }

  async applyRevert(receiptId: string, commit: string, files: string[]): Promise<GitCommitResult> {
    const preview = await this.previewRevert(receiptId, commit, files);
    if (!preview.canApply) throw new LearnError("HISTORY_CONFLICT", preview.conflict ?? "Receipt cannot be reverted", 409);
    if (!preview.patch.trim()) throw new LearnError("EMPTY_REVERT", "Receipt commit contains no reversible patch", 422);
    const checked = await this.git(["apply", "--reverse", "--check", "--whitespace=nowarn"], preview.patch);
    if (checked.code !== 0) throw new LearnError("HISTORY_CONFLICT", `Reverse patch no longer applies: ${checked.stderr.trim()}`, 409);
    const applied = await this.git(["apply", "--reverse", "--whitespace=nowarn"], preview.patch);
    if (applied.code !== 0) throw new LearnError("HISTORY_APPLY_FAILED", applied.stderr.trim() || "Git reverse patch failed", 500);
    const committed = await this.commit(preview.files, `learn: revert receipt ${receiptId}`);
    if (committed.status === "committed") return committed;
    const rollbackCheck = await this.git(["apply", "--check", "--whitespace=nowarn"], preview.patch);
    const rollback = rollbackCheck.code === 0 ? await this.git(["apply", "--whitespace=nowarn"], preview.patch) : rollbackCheck;
    if (rollback.code !== 0) throw new LearnError("HISTORY_ROLLBACK_FAILED", "Revert commit failed and working-tree rollback was incomplete", 500, { commitError: committed.message, rollbackError: rollback.stderr.trim() });
    return committed;
  }

  private git(args: string[], input?: string, env: NodeJS.ProcessEnv = process.env): Promise<GitResult> {
    return new Promise((resolve, reject) => {
      const child = spawn("git", ["-C", this.repositoryRoot, ...args], { env, stdio: ["pipe", "pipe", "pipe"] });
      let stdout = ""; let stderr = ""; let exceeded = false;
      child.stdout.setEncoding("utf8"); child.stderr.setEncoding("utf8");
      const append = (target: "stdout" | "stderr", chunk: string) => {
        if (target === "stdout") stdout += chunk; else stderr += chunk;
        if (Buffer.byteLength(stdout, "utf8") + Buffer.byteLength(stderr, "utf8") > OUTPUT_LIMIT) { exceeded = true; child.kill("SIGTERM"); }
      };
      child.stdout.on("data", (chunk: string) => append("stdout", chunk));
      child.stderr.on("data", (chunk: string) => append("stderr", chunk));
      child.once("error", reject);
      child.once("close", (code, signal) => resolve({ code: exceeded ? 75 : code ?? (signal ? 1 : 0), stdout, stderr: exceeded ? "Git output exceeded 2 MiB" : stderr }));
      child.stdin.end(input);
    });
  }
}
