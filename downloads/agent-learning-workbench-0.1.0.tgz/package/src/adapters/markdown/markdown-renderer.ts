import DOMPurify from "dompurify";
import { Marked } from "marked";
import { renderFlowChart } from "./flowcharts";

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]!);
}

function renderDirectives(markdown: string, parse: (body: string) => string): string {
  return markdown.replace(/^:::(note|warning|experiment)(?:\s+([^\n]+))?\n([\s\S]*?)\n:::\s*$/gm, (_match, kind: string, title: string | undefined, body: string) => {
    const renderedBody = parse(body);
    const label = title?.trim() || ({ note: "学习提示", warning: "注意", experiment: "可做实验" }[kind] ?? "学习块");
    return `<aside class="learn-directive directive-${kind}" data-directive="${kind}"><strong>${escapeHtml(label)}</strong>${renderedBody}</aside>`;
  });
}

type RenderEnvironment = {
  purifier: Pick<typeof DOMPurify, "sanitize">;
  parseSvg: (source: string) => Document;
};

function sanitizeDiagram(source: string, prefix: string, environment: RenderEnvironment): SVGSVGElement | undefined {
  const parsed = environment.parseSvg(source);
  const svg = parsed.documentElement;
  if (parsed.doctype || parsed.querySelector("parsererror") || svg.localName !== "svg" || svg.namespaceURI !== "http://www.w3.org/2000/svg") return;
  environment.purifier.sanitize(svg, {
    IN_PLACE: true,
    USE_PROFILES: { svg: true },
    FORBID_TAGS: ["style", "foreignObject", "image", "use", "a", "animate", "animateMotion", "animateTransform", "set"],
    FORBID_ATTR: ["style", "href", "xlink:href"],
    ALLOW_DATA_ATTR: false,
    ADD_ATTR: ["data-node", "data-from", "data-to"],
  });
  const bounds = (svg.getAttribute("viewBox") ?? "").trim().split(/[\s,]+/).map(Number);
  if (bounds.length !== 4 || bounds.some((value) => !Number.isFinite(value)) || bounds[2] <= 0 || bounds[3] <= 0) return;
  // Each figure owns its marker/gradient/clip IDs, including across multiple Markdown views.
  for (const element of [svg, ...svg.querySelectorAll("*")]) {
    for (const attribute of [...element.attributes]) {
      if (attribute.name === "id") element.setAttribute("id", `${prefix}-${attribute.value}`);
      else if (/url\s*\(/i.test(attribute.value)) {
        if (/^url\(#[\w.-]+\)$/.test(attribute.value)) element.setAttribute(attribute.name, attribute.value.replace("url(#", `url(#${prefix}-`));
        else element.removeAttribute(attribute.name);
      }
    }
  }
  svg.setAttribute("role", svg.querySelector("[data-node]") ? "group" : "img");
  svg.setAttribute("aria-label", svg.querySelector("title")?.textContent || "流程图");
  svg.removeAttribute("width");
  svg.removeAttribute("height");
  return svg as unknown as SVGSVGElement;
}

export function renderMarkdown(markdown: string, namespace = "learn", environment: RenderEnvironment = {
  purifier: DOMPurify,
  parseSvg: source => new DOMParser().parseFromString(source, "image/svg+xml"),
}): string {
  const diagrams: Array<{ slot: string; html: string }> = [];
  const parser = new Marked();
  const figure = (label: string, description: string, content: string, paths = "") => `<figure class="learn-diagram"><figcaption>${escapeHtml(label)}</figcaption>${paths}<div class="diagram-tools" role="group" aria-label="图表阅读工具"><button type="button" data-diagram-action="fit">适应宽度</button><button type="button" data-diagram-action="out" aria-label="缩小图表">−</button><output aria-live="polite">100%</output><button type="button" data-diagram-action="in" aria-label="放大图表">＋</button><button type="button" data-diagram-action="expand" aria-expanded="false">展开阅读</button></div><div class="diagram-viewport" tabindex="0" aria-label="${escapeHtml(label)}，放大后可滚动查看">${content}</div><p class="diagram-description" aria-live="polite">${escapeHtml(description)}</p></figure>`;
  parser.use({ renderer: { code(token) {
    if (token.lang?.trim() === "flow") {
      const slot = `${namespace}-diagram-${diagrams.length}`;
      try {
        const chart = renderFlowChart(token.text, slot);
        diagrams.push({ slot, html: figure(chart.title, chart.description, chart.content, chart.paths) });
        return `<div data-learn-svg="${slot}"></div>`;
      } catch (error) {
        return `<p class="diagram-error">流程图未显示：${escapeHtml(error instanceof Error ? error.message : String(error))}。原文保留在下方。</p><pre><code>${escapeHtml(token.text)}</code></pre>`;
      }
    }
    if (token.lang?.trim() !== "svg") return false;
    const slot = `${namespace}-diagram-${diagrams.length}`;
    const svg = sanitizeDiagram(token.text, slot, environment);
    if (!svg) return `<p class="diagram-error">SVG 未显示：需要有效的 SVG 和正尺寸 viewBox。原文保留在下方。</p><pre><code>${escapeHtml(token.text)}</code></pre>`;
    const label = svg.querySelector("title")?.textContent || "流程图";
    const description = svg.querySelector(":scope > desc")?.textContent || "点击节点查看说明与关联连线。";
    diagrams.push({ slot, html: figure(label, description, svg.outerHTML) });
    return `<div data-learn-svg="${slot}"></div>`;
  } } });
  const parse = (body: string) => parser.parse(body) as string;
  let html = environment.purifier.sanitize(parse(renderDirectives(markdown, parse)), { USE_PROFILES: { html: true } });
  for (const diagram of diagrams) html = html.replace(`<div data-learn-svg="${diagram.slot}"></div>`, diagram.html);
  return html;
}
