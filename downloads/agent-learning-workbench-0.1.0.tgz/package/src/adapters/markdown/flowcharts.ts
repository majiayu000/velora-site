type FlowNode = { id: string; title: string; summary?: string; detail?: string };
type FlowEdge = { from: string; to: string; dashed?: boolean; route?: "left" | "right"; label?: string };
type FlowChart = {
  title: string;
  description?: string;
  rows: Array<{ title: string; nodes: FlowNode[] }>;
  edges: FlowEdge[];
  paths?: Array<{ title: string; nodes: string[] }>;
};

const escape = (value: string) => value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]!);

/** This is the input boundary. Chart content is text, never executable HTML. */
export function renderFlowChart(source: string, prefix: string): { title: string; description: string; content: string; paths: string } {
  const chart = JSON.parse(source) as FlowChart;
  if (!chart || typeof chart.title !== "string" || !Array.isArray(chart.rows) || !chart.rows.length || !Array.isArray(chart.edges)) throw new Error("需要 title、rows 和 edges");
  const ids = new Set<string>();
  const text = (value: unknown) => value === undefined || typeof value === "string";
  if (!text(chart.description)) throw new Error("description 需要是文字");
  for (const row of chart.rows) {
    if (!row || typeof row.title !== "string" || !Array.isArray(row.nodes) || !row.nodes.length) throw new Error("每个分组需要 title 和非空 nodes");
    for (const node of row.nodes) {
      if (!node || typeof node.id !== "string" || !node.id || ids.has(node.id) || typeof node.title !== "string" || !text(node.summary) || !text(node.detail)) throw new Error("节点需要唯一 id、title 和文字说明");
      ids.add(node.id);
    }
  }
  for (const edge of chart.edges) {
    if (!edge || !ids.has(edge.from) || !ids.has(edge.to) || !text(edge.label) || (edge.dashed !== undefined && typeof edge.dashed !== "boolean") || (edge.route !== undefined && edge.route !== "left" && edge.route !== "right")) throw new Error("连接需要有效的 from / to；route 可为 left 或 right");
  }
  if (chart.paths !== undefined && (!Array.isArray(chart.paths) || chart.paths.some((path) => !path || typeof path.title !== "string" || !Array.isArray(path.nodes) || path.nodes.some((id) => !ids.has(id))))) throw new Error("流程需要 title 和有效节点列表");
  const paths = chart.paths?.length ? `<div class="flow-paths" role="group" aria-label="选择流程"><button type="button" data-flow-path="" aria-pressed="true">全部关系</button>${chart.paths.map((path) => `<button type="button" data-flow-path="${escape(JSON.stringify(path.nodes))}" aria-pressed="false">${escape(path.title)}</button>`).join("")}</div>` : "";
  const marker = `${prefix}-arrow`;
  const content = `<div class="flow-canvas"><svg class="flow-connections" aria-hidden="true"><defs><marker id="${marker}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#91a398"/></marker></defs><g>${chart.edges.map((edge) => `<path data-from="${escape(edge.from)}" data-to="${escape(edge.to)}"${edge.route ? ` data-route="${edge.route}"` : ""} fill="none" stroke="#91a398" stroke-width="1.6"${edge.dashed ? ' stroke-dasharray="5 4"' : ""} marker-end="url(#${marker})"/>`).join("")}</g>${chart.edges.map((edge) => edge.label ? `<text data-edge-label="" data-from="${escape(edge.from)}" data-to="${escape(edge.to)}" font-size="11" fill="#61716a" text-anchor="middle">${escape(edge.label)}</text>` : "").join("")}</svg>${chart.rows.map((row) => `<section class="flow-row"><h3>${escape(row.title)}</h3><div class="flow-nodes">${row.nodes.map((node) => `<button type="button" class="flow-node" data-node="${escape(node.id)}" aria-pressed="false" aria-label="${escape(node.title)}"><strong>${escape(node.title)}</strong><span class="flow-node-summary">${escape(node.summary || "")}</span><span class="flow-node-detail" hidden>${escape(node.detail || node.summary || node.title)}</span></button>`).join("")}</div></section>`).join("")}</div>`;
  return { title: chart.title, description: chart.description || "点击卡片查看说明；窗口变化时连线随节点位置更新。", content, paths };
}

/** Draw in canvas coordinates, even when the reading controls zoom the canvas. */
export function connectFlowChart(figure: HTMLElement): { redraw: () => void; dispose: () => void } {
  const canvas = figure.querySelector<HTMLElement>(".flow-canvas")!;
  const svg = canvas.querySelector("svg")!;
  const nodes = new Map([...canvas.querySelectorAll<HTMLElement>("[data-node]")].map((node) => [node.dataset.node!, node]));
  let frame = 0;
  let disposed = false;
  const draw = () => {
    frame = 0;
    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !canvas.offsetWidth) return;
    const scale = rect.width / canvas.offsetWidth;
    const width = canvas.offsetWidth, height = canvas.offsetHeight;
    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    const bounds = (node: HTMLElement) => {
      const box = node.getBoundingClientRect();
      return { left: (box.left - rect.left) / scale, right: (box.right - rect.left) / scale, top: (box.top - rect.top) / scale, bottom: (box.bottom - rect.top) / scale, x: (box.left + box.width / 2 - rect.left) / scale, y: (box.top + box.height / 2 - rect.top) / scale };
    };
    for (const edge of svg.querySelectorAll<SVGPathElement>("path[data-from]")) {
      const a = bounds(nodes.get(edge.dataset.from!)!), b = bounds(nodes.get(edge.dataset.to!)!);
      let d: string, labelX: number, labelY: number;
      if (edge.dataset.route) {
        const left = edge.dataset.route === "left";
        const gutter = left ? 12 : width - 12;
        const peers = [...nodes.values()].map(bounds).filter((box) => Math.abs(box.top - a.top) < 10);
        const exit = Math.max(...peers.map((box) => box.bottom)) + 14;
        const enter = b.top - 14;
        d = `M${a.x},${a.bottom} V${exit} H${gutter} V${enter} H${b.x} V${b.top}`;
        labelX = gutter; labelY = (exit + enter) / 2;
      } else if (Math.abs(a.top - b.top) < 10) {
        const forward = b.x > a.x;
        d = `M${forward ? a.right : a.left},${a.y} L${forward ? b.left : b.right},${b.y}`;
        labelX = (forward ? a.right + b.left : a.left + b.right) / 2; labelY = (a.y + b.y) / 2 - 8;
      } else {
        const down = b.y > a.y;
        const y1 = down ? a.bottom : a.top, y2 = down ? b.top : b.bottom;
        const mid = (y1 + y2) / 2;
        d = `M${a.x},${y1} C${a.x},${mid} ${b.x},${mid} ${b.x},${y2}`;
        labelX = (a.x + b.x) / 2; labelY = mid - 8;
      }
      edge.setAttribute("d", d);
      for (const label of svg.querySelectorAll<SVGTextElement>("text[data-edge-label]")) {
        if (label.dataset.from === edge.dataset.from && label.dataset.to === edge.dataset.to) {
          label.setAttribute("x", String(labelX)); label.setAttribute("y", String(labelY));
        }
      }
    }
  };
  const redraw = () => { if (!disposed && !frame) frame = requestAnimationFrame(draw); };
  const onPath = (event: MouseEvent) => {
    const button = (event.target as Element).closest<HTMLButtonElement>("[data-flow-path]");
    if (!button) return;
    const active = button.dataset.flowPath ? new Set(JSON.parse(button.dataset.flowPath) as string[]) : undefined;
    for (const candidate of figure.querySelectorAll("[data-flow-path]")) candidate.setAttribute("aria-pressed", String(candidate === button));
    for (const [id, node] of nodes) node.classList.toggle("is-outside-path", !!active && !active.has(id));
    for (const edge of svg.querySelectorAll<SVGElement>("[data-from][data-to]")) edge.classList.toggle("is-outside-path", !!active && (!active.has(edge.dataset.from!) || !active.has(edge.dataset.to!)));
  };
  figure.addEventListener("click", onPath);
  const observer = new ResizeObserver(redraw);
  observer.observe(canvas);
  for (const node of nodes.values()) observer.observe(node);
  void document.fonts?.ready.then(redraw);
  redraw();
  return { redraw, dispose: () => { disposed = true; cancelAnimationFrame(frame); observer.disconnect(); figure.removeEventListener("click", onPath); } };
}
