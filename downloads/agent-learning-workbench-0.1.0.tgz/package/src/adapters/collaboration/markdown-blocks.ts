import { marked } from "marked";

export type EditableBlock = { from: number; to: number; markdown: string; sourceOnly: boolean };

// Offsets always refer to the original Markdown, never the rendered HTML.
export function editableBlocks(body: string): EditableBlock[] {
  const blocks: EditableBlock[] = [];
  let offset = 0;
  const push = (from: number, to: number, sourceOnly: boolean) => {
    if (to > from) blocks.push({ from, to, markdown: body.slice(from, to), sourceOnly });
  };
  for (const token of marked.lexer(body)) {
    const from = body.indexOf(token.raw, offset);
    // Marked normalizes some source forms (e.g. CRLF). Keep those intact in source mode.
    if (from < 0) return [{ from: 0, to: body.length, markdown: body, sourceOnly: true }];
    const to = from + token.raw.length;
    if (from > offset) push(offset, from, true);
    const previous = blocks.at(-1);
    if (previous?.markdown.trimStart().startsWith(":::") && !/\n:::[ \t]*(?:\r?\n)*$/.test(previous.markdown)) {
      previous.to = to;
      previous.markdown = body.slice(previous.from, to);
    } else if (token.type === "space" && previous) {
      previous.to = to;
      previous.markdown = body.slice(previous.from, to);
    } else {
      const special = token.raw.includes(":::") || /<\/?[a-z!]|\]\[|^\s*\[[^\]]+\]:|^\s*[-*+] \[[ xX]\]/m.test(token.raw);
      const diagram = token.type === "code" && /^(svg|flow|mermaid)\b/.test(token.lang ?? "");
      push(from, to, special || diagram || !["heading", "paragraph", "list", "blockquote", "code", "table"].includes(token.type));
    }
    offset = to;
  }
  if (offset < body.length) push(offset, body.length, true);
  return blocks;
}

export function replaceBlock(body: string, block: Pick<EditableBlock, "from" | "to">, markdown: string): string {
  return body.slice(0, block.from) + markdown + body.slice(block.to);
}

export function preserveBlockEnding(original: string, markdown: string): string {
  return markdown.trimEnd() + (original.match(/(?:\r?\n)+$/)?.[0] ?? "");
}
