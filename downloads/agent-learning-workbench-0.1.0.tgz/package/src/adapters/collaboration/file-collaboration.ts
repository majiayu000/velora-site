import { createHash, randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";
import * as Y from "yjs";
import { LearnError } from "../../domain/errors";
import type { CollaborationPort, CollaborationSnapshot, BlockOperation } from "../../ports/collaboration-port";
import type { WorkspacePort } from "../../ports/workspace-port";
import type { EventPort } from "../../ports/event-port";
import { blockId, blockList, blockMarkdown, createBlock, documentMarkdown, isSource, reconcileMarkdown, setBlockMarkdown, validateSharedDocument } from "./model";

type RecordState = { state: string; revision: number; exportedHash: string; pending?: string };
const hash = (text: string) => `sha256:${createHash("sha256").update(text).digest("hex")}`;
const encode = (bytes: Uint8Array) => Buffer.from(bytes).toString("base64");
function decode(value: string): Uint8Array {
  if (typeof value !== "string" || value.length > 12 * 1024 * 1024 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) throw new LearnError("INVALID_UPDATE", "Invalid Yjs update encoding", 400);
  return Buffer.from(value, "base64");
}

export class FileCollaboration implements CollaborationPort {
  constructor(private readonly root: string, private readonly store: WorkspacePort, private readonly events: EventPort, private readonly sizeLimit = 1024 * 1024) {}

  private async locked<T>(id: string, action: (file: string) => Promise<T>): Promise<T> {
    // Validate document registration before creating any sidecar paths.
    await this.store.getDocument(id);
    const directory = path.join(this.root, ".learn", "collaboration");
    await fs.mkdir(directory, { recursive: true });
    const file = path.join(directory, createHash("sha256").update(id).digest("hex") + ".json");
    const lock = file + ".lock";
    const started = Date.now();
    while (true) {
      try {
        const handle = await fs.open(lock, "wx", 0o600);
        try { await handle.writeFile(String(process.pid)); } finally { await handle.close(); }
        break;
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
        try {
          const owner = Number(await fs.readFile(lock, "utf8"));
          if (owner > 0) {
            try { process.kill(owner, 0); } catch (error) { if ((error as NodeJS.ErrnoException).code === "ESRCH") { await fs.unlink(lock); continue; } }
          } else if (Date.now() - (await fs.stat(lock)).mtimeMs > 5000) { await fs.unlink(lock); continue; }
        } catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") continue; throw error; }
        if (Date.now() - started > 10000) throw new LearnError("DOCUMENT_BUSY", "Document is busy; retry the operation", 409);
        await new Promise(resolve => setTimeout(resolve, 25));
      }
    }
    try { return await action(file); } finally { await fs.unlink(lock); }
  }

  private async write(file: string, record: RecordState): Promise<void> {
    const temporary = `${file}.${randomUUID()}.tmp`;
    const handle = await fs.open(temporary, "wx", 0o600);
    try { await handle.writeFile(JSON.stringify(record)); await handle.sync(); } finally { await handle.close(); }
    await fs.rename(temporary, file);
  }

  private async transaction(id: string, mutate?: (doc: Y.Doc) => void, vector?: string): Promise<CollaborationSnapshot> {
    return this.locked(id, async file => {
      let snapshot = await this.store.getDocument(id);
      let record: RecordState | undefined;
      try { record = JSON.parse(await fs.readFile(file, "utf8")); } catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
      const doc = new Y.Doc();
      try {
        if (record) Y.applyUpdate(doc, decode(record.state));
        else doc.transact(() => reconcileMarkdown(doc, snapshot.body));
        // Finish an export interrupted after durable state was committed.
        if (record?.pending !== undefined) {
          if (snapshot.body !== record.pending) snapshot = await this.store.saveDocument(id, record.pending, record.exportedHash);
          record.exportedHash = snapshot.contentHash;
          delete record.pending;
          await this.write(file, record);
        }
        if (record && record.exportedHash !== snapshot.contentHash) doc.transact(() => reconcileMarkdown(doc, snapshot.body));
        const before = encode(Y.encodeStateAsUpdate(doc));
        if (mutate) doc.transact(() => mutate(doc), "agent");
        validateSharedDocument(doc);
        const body = documentMarkdown(doc);
        if (Buffer.byteLength(body) > this.sizeLimit) throw new LearnError("DOCUMENT_TOO_LARGE", "Collaborative document exceeds the workspace size limit", 413);
        const state = encode(Y.encodeStateAsUpdate(doc));
        if (state.length > 12 * 1024 * 1024) throw new LearnError("DOCUMENT_TOO_LARGE", "Collaborative history exceeds 9 MiB", 413);
        const changed = !record || record.state !== state;
        const revision = (record?.revision ?? 0) + (changed ? 1 : 0);
        if (changed) {
          const next: RecordState = { state, revision, exportedHash: snapshot.contentHash, ...(body !== snapshot.body ? { pending: body } : {}) };
          await this.write(file, next);
          if (next.pending !== undefined) {
            try {
              snapshot = await this.store.saveDocument(id, body, snapshot.contentHash);
              next.exportedHash = snapshot.contentHash;
              delete next.pending;
              await this.write(file, next);
            } catch (error) {
              throw new LearnError("COLLAB_EXPORT_FAILED", `协同状态已保存，Markdown 导出失败：${error instanceof Error ? error.message : String(error)}`, 409, { mutationApplied: true });
            }
          }
          this.events.publish("collaboration.changed", { documentId: id, revision });
          if (before !== state) this.events.publish("document.saved", { documentId: id, contentHash: snapshot.contentHash, source: "collaboration" });
        }
        let offset = 0;
        return {
          state: vector ? encode(Y.encodeStateAsUpdate(doc, decode(vector))) : state,
          vector: encode(Y.encodeStateVector(doc)), revision, document: snapshot,
          blocks: blockList(doc).toArray().map(block => {
            const markdown = blockMarkdown(block); const from = offset; offset += markdown.length;
            return { id: blockId(block), markdown, hash: hash(markdown), sourceOnly: isSource(block), from, to: offset };
          }),
        };
      } finally { doc.destroy(); }
    });
  }

  read(id: string) { return this.transaction(id); }
  sync(id: string, update: string, vector: string) {
    try { Y.decodeStateVector(decode(vector)); } catch { throw new LearnError("INVALID_UPDATE", "Invalid state vector", 400); }
    // Decode and validate on a disposable document; failed transactions never reach durable state.
    return this.transaction(id, doc => {
      try { Y.applyUpdate(doc, decode(update), "human"); validateSharedDocument(doc); }
      catch (error) { throw new LearnError("INVALID_UPDATE", error instanceof Error ? error.message : "Invalid Yjs update", 400); }
    }, vector);
  }
  async operate(id: string, operations: BlockOperation[], signal?: AbortSignal) {
    if (!Array.isArray(operations) || !operations.length || operations.length > 100) throw new LearnError("INVALID_OPERATION", "Provide 1–100 block operations", 400);
    const insertedBlockIds: string[] = [];
    const snapshot = await this.transaction(id, doc => {
      if (signal?.aborted) throw new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409);
      const list = blockList(doc);
      for (const operation of operations) {
        if (!operation || !["insert", "replace", "delete"].includes(operation.type)) throw new LearnError("INVALID_OPERATION", "Unknown block operation", 400);
        if (operation.type !== "delete" && (typeof operation.markdown !== "string" || Buffer.byteLength(operation.markdown) > this.sizeLimit)) throw new LearnError("INVALID_OPERATION", "markdown is required and must fit the document size limit", 400);
        if (operation.type === "insert") {
          const index = operation.after === null ? -1 : list.toArray().findIndex(b => blockId(b) === operation.after);
          if (index < 0 && operation.after !== null) throw new LearnError("BLOCK_NOT_FOUND", "Insertion anchor no longer exists", 404);
          const block = createBlock(operation.markdown);
          list.insert(index + 1, [block]);
          insertedBlockIds.push(blockId(block));
        } else {
          const index = list.toArray().findIndex(b => blockId(b) === operation.blockId);
          if (index < 0) throw new LearnError("BLOCK_NOT_FOUND", "Read the document again; this block no longer exists", 404);
          const block = list.get(index);
          if (!operation.ifHash) throw new LearnError("PRECONDITION_REQUIRED", "ifHash from the latest block read is required", 428);
          if (hash(blockMarkdown(block)) !== operation.ifHash) throw new LearnError("GUARD_MISMATCH", "This block changed; read it again before editing", 409);
          if (operation.type === "delete") list.delete(index, 1);
          else setBlockMarkdown(block, operation.markdown!);
        }
      }
    });
    return { ...snapshot, insertedBlockIds };
  }
  async replace(id: string, body: string, expectedHash: string) {
    return (await this.transaction(id, doc => {
      if (!expectedHash) throw new LearnError("PRECONDITION_REQUIRED", "If-Match is required", 428);
      if (hash(documentMarkdown(doc)) !== expectedHash) throw new LearnError("DOCUMENT_CONFLICT", "Document has changed", 409);
      reconcileMarkdown(doc, body);
    })).document;
  }
}
