import * as Y from "yjs";
import { getSchema, flattenExtensions } from "@tiptap/core";
import StarterKit from "@tiptap/starter-kit";
import { TableKit } from "@tiptap/extension-table";
import Image from "@tiptap/extension-image";
import { MarkdownManager } from "@tiptap/markdown";
import { prosemirrorJSONToYXmlFragment, yXmlFragmentToProsemirrorJSON } from "@tiptap/y-tiptap";
import { editableBlocks, preserveBlockEnding } from "./markdown-blocks";

export const richExtensions = () => [StarterKit.configure({ undoRedo: false, trailingNode: false, underline: false, link: { openOnClick: false } }), TableKit, Image];
const extensions = flattenExtensions(richExtensions());
const schema = getSchema(richExtensions());
const markdown = new MarkdownManager({ extensions });
export type SharedBlock = Y.Map<unknown>;
export const blockList = (doc: Y.Doc) => doc.getArray<SharedBlock>("blocks");
export const blockId = (block: SharedBlock) => block.get("id") as string;
export const isSource = (block: SharedBlock) => block.get("kind") === "source";
export const fragment = (block: SharedBlock) => block.get("content") as Y.XmlFragment;
export const sourceText = (block: SharedBlock) => block.get("source") as Y.Text;

export function createBlock(raw: string, sourceOnly = editableBlocks(raw).some(b => b.sourceOnly)): SharedBlock {
  const block = new Y.Map<unknown>();
  block.set("id", crypto.randomUUID());
  block.set("kind", sourceOnly ? "source" : "rich");
  block.set("original", raw);
  if (sourceOnly) block.set("source", new Y.Text(raw));
  else {
    const json = markdown.parse(raw.replace(/\n+$/, ""));
    const temporary = new Y.Doc();
    const content = temporary.getXmlFragment("content");
    prosemirrorJSONToYXmlFragment(schema, json, content);
    block.set("content", content.clone());
    temporary.destroy();
    // Compare the normalized ProseMirror representation, including schema defaults.
    block.set("initial", JSON.stringify(schema.nodeFromJSON(json).toJSON()));
  }
  return block;
}

export function blockMarkdown(block: SharedBlock): string {
  if (isSource(block)) return sourceText(block).toString();
  const json = schema.nodeFromJSON(yXmlFragmentToProsemirrorJSON(fragment(block))).toJSON();
  const original = block.get("original") as string;
  return JSON.stringify(json) === block.get("initial") ? original : preserveBlockEnding(original, markdown.serialize(json));
}
export const documentMarkdown = (doc: Y.Doc) => blockList(doc).toArray().map(blockMarkdown).join("");

export function setBlockMarkdown(block: SharedBlock, raw: string): void {
  const sourceOnly = editableBlocks(raw).some(b => b.sourceOnly);
  block.set("original", raw);
  if (sourceOnly) {
    if (!isSource(block)) block.set("source", new Y.Text());
    block.set("kind", "source");
    const text = sourceText(block);
    text.delete(0, text.length); text.insert(0, raw);
  } else {
    if (isSource(block)) block.set("content", new Y.XmlFragment());
    block.set("kind", "rich");
    const json = markdown.parse(raw.replace(/\n+$/, ""));
    prosemirrorJSONToYXmlFragment(schema, json, fragment(block));
    block.set("initial", JSON.stringify(schema.nodeFromJSON(json).toJSON()));
  }
}

// Whole-file edits retain exact matching blocks and reuse IDs for changed blocks in-place.
export function reconcileMarkdown(doc: Y.Doc, body: string): void {
  const list = blockList(doc);
  const next = editableBlocks(body);
  let i = 0;
  for (const item of next) {
    if (i < list.length && blockMarkdown(list.get(i)) === item.markdown) { i++; continue; }
    const later = list.toArray().findIndex((b, index) => index > i && blockMarkdown(b) === item.markdown);
    if (later >= 0) list.delete(i, later - i);
    else if (i < list.length && !next.slice(i + 1).some(b => b.markdown === blockMarkdown(list.get(i)))) setBlockMarkdown(list.get(i), item.markdown);
    else list.insert(i, [createBlock(item.markdown, item.sourceOnly)]);
    i++;
  }
  if (list.length > i) list.delete(i, list.length - i);
}

export function validateSharedDocument(doc: Y.Doc): void {
  const list = blockList(doc);
  if (list.length > 10000) throw new Error("Too many document blocks");
  const ids = new Set<string>();
  for (const block of list.toArray()) {
    if (!(block instanceof Y.Map) || typeof blockId(block) !== "string" || !/^[a-f0-9-]{36}$/.test(blockId(block)) || ids.has(blockId(block))) throw new Error("Invalid or duplicate block ID");
    ids.add(blockId(block));
    if (typeof block.get("original") !== "string") throw new Error("Missing original Markdown");
    if (isSource(block)) { if (!(sourceText(block) instanceof Y.Text)) throw new Error("Invalid source block"); }
    else {
      if (block.get("kind") !== "rich" || !(fragment(block) instanceof Y.XmlFragment)) throw new Error("Invalid rich block");
      schema.nodeFromJSON(yXmlFragmentToProsemirrorJSON(fragment(block))).check();
    }
  }
}
