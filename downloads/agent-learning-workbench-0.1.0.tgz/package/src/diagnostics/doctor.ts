import { spawn } from "node:child_process";
import { WorkspaceStore } from "../adapters/filesystem/workspace-store";
import { createRuntimeAdapter } from "../composition/create-learn-engine";
import { readLearnConfig } from "../composition/config";
import { redactDiagnostic } from "../domain/redact";

export type DoctorCheck = { name: "node" | "config" | "workspace" | "git" | "runtime"; status: "pass" | "warn" | "fail"; message: string };
export type DoctorReport = { ok: boolean; checks: DoctorCheck[] };

function command(command: string, args: string[], cwd: string, timeoutMs = 5_000): Promise<{ code: number; stdout: string; stderr: string }> {
  return new Promise((resolve) => {
    const child = spawn(command, args, { cwd, stdio: ["ignore", "pipe", "pipe"] });
    let stdout = ""; let stderr = ""; let settled = false;
    const settleCommand = (code: number) => { if (settled) return; settled = true; clearTimeout(timeout); resolve({ code, stdout, stderr }); };
    const timeout = setTimeout(() => { child.kill("SIGTERM"); settleCommand(124); }, timeoutMs);
    child.stdout.setEncoding("utf8"); child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk: string) => { stdout = `${stdout}${chunk}`.slice(-2_000); });
    child.stderr.on("data", (chunk: string) => { stderr = `${stderr}${chunk}`.slice(-2_000); });
    child.once("error", (error) => { stderr = error.message; settleCommand(127); });
    child.once("close", (code) => settleCommand(code ?? 1));
  });
}

export async function runDoctor(repositoryRoot: string): Promise<DoctorReport> {
  const checks: DoctorCheck[] = [];
  const [major, minor] = process.versions.node.split(".").map(Number);
  const nodeSupported = (major === 20 && minor >= 19) || (major >= 22 && major < 27 && (major !== 22 || minor >= 12));
  checks.push({ name: "node", status: nodeSupported ? "pass" : "fail", message: `Node ${process.versions.node}; supported range is ^20.19.0 or >=22.12.0 <27` });
  try {
    const { config, manifestPath } = await readLearnConfig(repositoryRoot);
    checks.push({ name: "config", status: "pass", message: "learn.config.json satisfies v1 and manifest containment rules" });
    const store = new WorkspaceStore(repositoryRoot, manifestPath, config.documentSizeLimitBytes);
    await store.initialize();
    checks.push({ name: "workspace", status: "pass", message: `${store.listDocuments().length} registered Markdown document(s) validated` });
    const git = await command("git", ["rev-parse", "--is-inside-work-tree"], repositoryRoot);
    const gitAvailable = git.code === 0 && git.stdout.trim() === "true";
    checks.push({ name: "git", status: gitAvailable ? "pass" : "warn", message: gitAvailable ? "Git worktree available for exact-file history" : "Git unavailable; receipts work but reviewed revert is disabled" });
    const runtime = createRuntimeAdapter(repositoryRoot, "interactive", config.runtime);
    try {
      const health = await runtime.health();
      checks.push({ name: "runtime", status: health.available ? "pass" : "fail", message: health.available ? `${health.adapter}${health.version ? ` ${health.version}` : ""} is ready` : redactDiagnostic(health.message ?? "Runtime unavailable") });
    } finally { runtime.close(); }
  } catch (error) {
    const message = redactDiagnostic(error instanceof Error ? error.message : String(error));
    const name = checks.some((check) => check.name === "config") ? "workspace" : "config";
    checks.push({ name, status: "fail", message });
  }
  return { ok: checks.every((check) => check.status !== "fail"), checks };
}
