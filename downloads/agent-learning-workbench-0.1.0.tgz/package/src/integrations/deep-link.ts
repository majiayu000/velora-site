import { LearnError } from "../domain/errors";

export function createLearningLink(input: { origin?: string; documentId: string; question?: string; path?: string; line?: number; edit?: boolean }): string {
  const origin = input.origin ?? "http://127.0.0.1:4178";
  const parsed = new URL(origin);
  if (!(["127.0.0.1", "localhost"].includes(parsed.hostname)) || parsed.protocol !== "http:") throw new LearnError("INVALID_LINK_ORIGIN", "Deep-link origin must be loopback HTTP", 422);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(input.documentId)) throw new LearnError("INVALID_DOCUMENT_ID", "documentId must use lowercase kebab-case", 422);
  const params = new URLSearchParams();
  if (input.edit) params.set("edit", "1");
  if (input.question?.trim()) params.set("ask", input.question.trim());
  if (input.path?.trim()) params.set("path", input.path.trim());
  if (input.line !== undefined) {
    if (!Number.isInteger(input.line) || input.line < 1) throw new LearnError("INVALID_LINE", "line must be a positive integer", 422);
    params.set("line", String(input.line));
  }
  return `${parsed.origin}/#/doc/${encodeURIComponent(input.documentId)}${params.size ? `?${params}` : ""}`;
}
