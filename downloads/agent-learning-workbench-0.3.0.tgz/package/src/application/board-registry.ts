import type { BoardMetadata } from "../ports/board-port";
import type { ComposeSpace } from "./board-composer";

/**
 * Keeps `boards` in the space manifest in step with the board store. A change is announced like any other
 * structure change and recorded in history together with the board's readable projection.
 */
export function boardRegistrar(space: Pick<ComposeSpace, "store" | "events" | "recordMutation">) {
  return async (board: BoardMetadata): Promise<void> => {
    const result = await space.store.registerBoard?.({ id: board.id, path: board.path, title: board.title });
    if (!result?.changed) return;
    space.events.publish("workspace.changed", { manifestHash: result.manifestHash, documents: space.store.listDocuments(), boards: space.store.listBoards?.() ?? [] });
    // The board and its registration are already on disk; a failed history commit must not report the create as failed.
    try { await space.recordMutation("structure", `Register board ${board.title}`, [...result.changedPaths, board.path]); }
    catch (error) { space.events.publish("history.warning", { message: `白板已保存，但历史记录失败：${error instanceof Error ? error.message : String(error)}` }); }
  };
}
