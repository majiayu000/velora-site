import { buildBoardTask, normalizeAssistRequest, validateBoardAssistResult, type BoardAssistResult } from "../domain/board-agent";
import { LearnError } from "../domain/errors";
import type { RuntimeHealth } from "../domain/types";
import type { BoardPort } from "../ports/board-port";
import type { RuntimePort } from "../ports/runtime-port";

/**
 * Runs one board AI action against the space's configured runtime. It reads the durable board,
 * asks for structured JSON with no tools, and returns validated suggestions. It never writes the
 * board: the browser applies results under an AI-turn origin so the person can undo the turn.
 */
export class BoardAssistant {
  constructor(private readonly boards: BoardPort, private readonly runtime: () => { port: RuntimePort; health: RuntimeHealth }) {}

  async assist(boardId: string, input: Record<string, unknown>, signal: AbortSignal): Promise<BoardAssistResult & { adapter: string }> {
    const request = normalizeAssistRequest(input);
    const { port, health } = this.runtime();
    if (!health.available) throw new LearnError("RUNTIME_UNAVAILABLE", health.message ?? "Agent Runtime 当前不可用", 503);
    if (!port.structured) throw new LearnError("ASSIST_UNSUPPORTED", `${health.adapter} 不支持白板 AI，请在设置里切换到 Codex 或 Claude Code`, 501);
    const board = await this.boards.projection(boardId);
    const { task, focusIds } = buildBoardTask(request, board);
    const raw = await port.structured(task, signal);
    return { ...validateBoardAssistResult(request.action, raw, focusIds), adapter: health.adapter };
  }
}
