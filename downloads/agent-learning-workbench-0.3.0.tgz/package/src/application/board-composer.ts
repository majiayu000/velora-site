import { randomUUID } from "node:crypto";
import { cardContentHash, type BoardCard, type CardKind } from "../domain/board";
import {
  buildComposeTask, composeBrief, composedDocumentId, linksFromEdits, normalizeComposeRequest, validateComposeResult,
  type ComposeOutcome, type ComposeRequest, type SourceLink,
} from "../domain/board-compose";
import { LearnError, asLearnError } from "../domain/errors";
import type { QuestionRequest, RuntimeHealth, StructureMutationResult } from "../domain/types";
import type { BoardPort, BoardProjection } from "../ports/board-port";
import type { CollaborationPort } from "../ports/collaboration-port";
import type { EventPort } from "../ports/event-port";
import type { RuntimePort } from "../ports/runtime-port";
import type { WorkspacePort } from "../ports/workspace-port";

/** The parts of a learning space the composer writes through; satisfied by LearnEngine. */
export type ComposeSpace = {
  store: WorkspacePort;
  events: EventPort;
  collaboration?: CollaborationPort;
  runtime: RuntimePort;
  getWorkspace(): { runtime: RuntimeHealth };
  recordMutation(source: "structure" | "proposal" | "human", summary: string, files: string[]): Promise<unknown>;
  /** Starts an ordinary document turn; used to write a compose block by block with live streaming. */
  createQuestion?(request: QuestionRequest): { id: string; conversationId: string };
  updateConversation?(id: string, input: Record<string, unknown>): Promise<unknown>;
};

/** Runtimes that call workbench tools themselves and can therefore write a compose block by block. */
const STREAMING_ADAPTERS = new Set(["codex-app-server", "direct-api"]);
const cardHashes = (board: BoardProjection) => Object.fromEntries(board.cards.map(c => [c.id, cardContentHash(c.kind as CardKind, c.text)]));
const newLinkId = () => `l_${randomUUID().slice(0, 12)}`;
type BoardInput = Parameters<typeof buildComposeTask>[1];

/**
 * Board → document. With a tool-running runtime the compose is an ordinary document turn: the document is
 * created, the model writes it block by block (streaming into the open document), and each begin_document_edit
 * names its source cards. Other runtimes return all sections in one structured call. Either way every block ends
 * with one source link on the board, and only live cards in the selection reach the model.
 */
export class BoardComposer {
  constructor(private readonly boards: BoardPort, private readonly space: ComposeSpace) {}

  async compose(boardId: string, input: Record<string, unknown>, signal: AbortSignal): Promise<ComposeOutcome> {
    const request = normalizeComposeRequest(input);
    const health = this.space.getWorkspace().runtime;
    if (!this.space.collaboration) throw new LearnError("COLLABORATION_UNAVAILABLE", "转稿需要块级协作", 409);
    if (!health.available) throw new LearnError("RUNTIME_UNAVAILABLE", health.message ?? "Agent Runtime 当前不可用", 503);
    const board = await this.boards.projection(boardId);
    const input_ = { ...board, cards: board.cards as Array<BoardCard & { color: string }> };
    if (STREAMING_ADAPTERS.has(health.adapter) && this.space.createQuestion) return this.composeAsTurn(boardId, request, board, input_, health.adapter);
    if (!this.space.runtime.structured) throw new LearnError("ASSIST_UNSUPPORTED", `${health.adapter} 不支持白板转稿，请在设置里切换到 Codex、Claude Code 或直连模型`, 501);
    const { task, focusIds } = buildComposeTask(request, input_);
    const result = validateComposeResult(await this.space.runtime.structured(task, signal), focusIds, request.title || board.title);
    if (signal.aborted) throw new LearnError("TURN_CANCELLED", "转稿已取消", 409);

    const turnId = randomUUID();
    const { documentId, path, created } = await this.createDocument(boardId, turnId, result.title, result.summary);
    // Insert section by section so every block knows which section, and therefore which cards, it came from.
    // Blocks carry their own trailing separator, so each section ends with a blank line.
    const collaboration = this.space.collaboration;
    let after = (await collaboration.read(documentId)).blocks.at(-1)?.id ?? null;
    const hashes = cardHashes(board);
    const at = new Date().toISOString();
    const links: SourceLink[] = [];
    for (const section of result.sections) {
      const next = await collaboration.operate(documentId, [{ type: "insert", after, markdown: `${section.markdown}\n\n` }]);
      const blocks = new Map(next.blocks.map(b => [b.id, b]));
      for (const blockId of next.insertedBlockIds) {
        links.push({
          id: newLinkId(), documentId, blockId, blockHash: blocks.get(blockId)!.hash, turnId, at,
          cards: Object.fromEntries(section.sources.map(id => [id, hashes[id]!])),
          ...(section.inferred ? { inferred: true } : {}),
        });
      }
      after = next.insertedBlockIds.at(-1) ?? after;
    }
    await this.boards.addLinks(boardId, links);
    await this.space.recordMutation("structure", `Board compose ${result.title}`, [path, ...created.changedPaths]);
    return { documentId, title: result.title, summary: result.summary, turnId, adapter: health.adapter, sections: result.sections.length, inferred: result.sections.filter(s => s.inferred).length, links };
  }

  private async createDocument(boardId: string, seed: string, title: string, summary: string): Promise<{ documentId: string; path: string; created: StructureMutationResult }> {
    const root = this.space.store.documentRoots[0];
    if (!root) throw new LearnError("NO_CONTENT_ROOT", "学习空间没有可写的内容目录", 409);
    const documentId = composedDocumentId(boardId, seed);
    const path = `${root}/${documentId}.md`;
    const created = await this.space.store.applyStructure([{ type: "create", document: { id: documentId, path, title, summary }, body: `# ${title}\n\n` }], this.space.store.manifestHash);
    this.space.events.publish("workspace.changed", { manifestHash: created.manifestHash, documents: created.documents });
    return { documentId, path, created };
  }

  /** Returns as soon as the turn starts; links are written when the turn ends, from the edits it committed. */
  private async composeAsTurn(boardId: string, request: ComposeRequest, board: BoardProjection, input: BoardInput, adapter: string): Promise<ComposeOutcome> {
    const { question, focusIds } = composeBrief(request, input);
    const title = request.title || `${board.title}：转写稿`;
    const summary = `由白板「${board.title}」的 ${focusIds.length} 张卡片转写`;
    const hashes = cardHashes(board);
    const { documentId, path, created } = await this.createDocument(boardId, randomUUID(), title, summary);
    await this.space.recordMutation("structure", `Board compose ${title}`, [path, ...created.changedPaths]).catch(() => undefined);

    const sources = new Map<string, string[] | undefined>();
    const committed: Array<{ blockIds: string[]; sources?: string[] }> = [];
    let turnId: string | undefined;
    const buffered: Array<{ type: string; payload: Record<string, unknown> }> = [];
    const finish = async () => {
      unsubscribe();
      try {
        const blocks = new Map((await this.space.collaboration!.read(documentId)).blocks.map(b => [b.id, b.hash]));
        const links = linksFromEdits(committed, focusIds, hashes, blocks, { documentId, turnId: turnId!, at: new Date().toISOString(), newId: newLinkId });
        if (links.length) await this.boards.addLinks(boardId, links);
        this.space.events.publish("board.compose.finished", { boardId, documentId, turnId, links: links.length, inferred: links.filter(l => l.inferred).length });
      } catch (error) {
        this.space.events.publish("history.warning", { message: `转写已完成，但来源记录失败：${asLearnError(error).message}` });
      }
    };
    const handle = (type: string, payload: Record<string, unknown>) => {
      if (type.startsWith("document.edit.") && (payload.turnId !== turnId || payload.documentId !== documentId)) return;
      if (type === "document.edit.started") sources.set(String(payload.editId), Array.isArray(payload.sources) ? payload.sources as string[] : undefined);
      if (type === "document.edit.committed") committed.push({ blockIds: (payload.blockIds as string[] | undefined) ?? [], sources: sources.get(String(payload.editId)) });
      if (["turn.completed", "turn.failed", "turn.cancelled"].includes(type) && (payload.turn as { id?: string } | undefined)?.id === turnId) void finish();
    };
    // Subscribe before the turn starts; events that arrive before its id is known are replayed once it is.
    const unsubscribe = this.space.events.subscribe(event => {
      const payload = (event.payload ?? {}) as Record<string, unknown>;
      if (turnId) handle(event.type, payload); else buffered.push({ type: event.type, payload });
    });
    try {
      const turn = this.space.createQuestion!({ documentId, question, intent: "auto" });
      turnId = turn.id;
      for (const event of buffered.splice(0)) handle(event.type, event.payload);
      // The question is a long brief; name the conversation after the board instead.
      await this.space.updateConversation?.(turn.conversationId, { title: `转写：${board.title}` }).catch(() => undefined);
      return { documentId, title, summary, turnId: turn.id, adapter, sections: 0, inferred: 0, links: [], streaming: { conversationId: turn.conversationId } };
    } catch (error) {
      unsubscribe();
      // Nothing was written into the new document; remove it so a refused turn leaves no empty page behind.
      await this.space.store.applyStructure([{ type: "delete", documentId }], this.space.store.manifestHash).then(next => this.space.events.publish("workspace.changed", { manifestHash: next.manifestHash, documents: next.documents }), () => undefined);
      throw error;
    }
  }
}
