import { randomUUID } from "node:crypto";
import { DOCUMENT_TOOLS, GUIDE_TOOL, WORKSPACE_TOOLS, editSources, type AgentToolSpec } from "../../domain/agent-tools";
import type { StructuredTask } from "../../domain/board-agent";
import { documentInstructions, readDocumentGuides } from "../../domain/document-guides";
import { LearnError, asLearnError } from "../../domain/errors";
import { RESULT_SCHEMA, buildRuntimePrompt } from "../../domain/runtime-prompt";
import { validateRuntimeResult } from "../../domain/runtime-result";
import type { DocumentMetadata, RuntimeHealth, RuntimeRequest, RuntimeResult } from "../../domain/types";
import type { DocumentEditOperation } from "../../ports/collaboration-port";
import type { RuntimeCallbacks, RuntimePort } from "../../ports/runtime-port";
import { readKey, keyEnvName, KEYCHAIN_SERVICE } from "./keychain";
import { createModelClient, type ChatMessage, type ModelClient, type ToolCall } from "./protocols";

export type DirectRuntimeOptions = { protocol: "openai-compatible" | "anthropic"; baseUrl: string; model: string; keyRef: string };
type Dependencies = { fetch?: typeof fetch; readKey?: (keyRef: string) => Promise<string | undefined> };

const MAX_TOOL_CALLS = 40;
const FINISH_TOOL: AgentToolSpec = { name: "finish_turn", description: "Finish the turn with the structured learning result. Call exactly once, last, after every document edit is committed.", inputSchema: RESULT_SCHEMA };
const ADAPTER = "direct-api";

/**
 * A model API called directly (OpenAI-compatible Chat Completions or Anthropic Messages). Velora runs the
 * tool loop itself: every tool call goes through the same guarded document and workspace callbacks as Codex,
 * text after begin_document_edit streams into the document as the edit body, and finish_turn carries the result.
 */
export class DirectRuntime implements RuntimePort {
  private activeTurn = false;
  private runtimeHealth: RuntimeHealth;

  constructor(private readonly options: DirectRuntimeOptions, private readonly dependencies: Dependencies = {}) {
    this.runtimeHealth = { adapter: ADAPTER, available: false, message: "尚未检查" };
  }

  get available(): boolean { return this.runtimeHealth.available; }
  private get host(): string { return new URL(this.options.baseUrl).host; }

  private async client(): Promise<ModelClient> {
    const key = await (this.dependencies.readKey ?? readKey)(this.options.keyRef);
    if (!key) throw new LearnError("RUNTIME_KEY_MISSING", `没有找到名为 ${this.options.keyRef} 的 Key。请在终端运行 security add-generic-password -s ${KEYCHAIN_SERVICE} -a ${this.options.keyRef} -w ，或设置环境变量 ${keyEnvName(this.options.keyRef)}。`, 503);
    return createModelClient({ ...this.options, key, fetch: this.dependencies.fetch });
  }

  /** Cheap check with no network call: configuration is valid and a key is present. */
  async health(): Promise<RuntimeHealth> {
    try {
      await this.client();
      this.runtimeHealth = { adapter: ADAPTER, available: true, version: `${this.options.protocol} · ${this.options.model} @ ${this.host}` };
    } catch (error) {
      this.runtimeHealth = { adapter: ADAPTER, available: false, message: asLearnError(error).message };
    }
    return { ...this.runtimeHealth };
  }

  /** "测试连接": one minimal request that must come back as a tool call, so a model without tool support fails clearly. */
  async probe(signal: AbortSignal): Promise<RuntimeHealth> {
    const client = await this.client();
    const tool: AgentToolSpec = { name: "report", description: "Report that the connection works.", inputSchema: { type: "object", additionalProperties: false, required: ["ok"], properties: { ok: { type: "boolean" } } } };
    const result = await client.step({ system: "Call the report tool with ok=true.", messages: [{ role: "user", text: "ping" }], tools: [tool], toolChoice: { name: "report" } }, () => undefined, signal);
    if (!result.toolCalls.some(call => call.name === "report")) throw new LearnError("RUNTIME_TOOLS_UNSUPPORTED", `模型 ${this.options.model} 没有返回工具调用；观澜需要支持工具调用的模型。`, 422);
    return this.health();
  }

  async structured(task: StructuredTask, signal: AbortSignal): Promise<unknown> {
    this.begin();
    try {
      const client = await this.client();
      const submit: AgentToolSpec = { name: "submit", description: "Submit the result.", inputSchema: task.schema };
      const result = await client.step({ system: task.instructions, messages: [{ role: "user", text: task.prompt }], tools: [submit], toolChoice: { name: "submit" } }, () => undefined, signal);
      const call = result.toolCalls.find(item => item.name === "submit");
      if (call) return call.args;
      try { return JSON.parse(result.text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "")) as unknown; }
      catch { throw new LearnError("RUNTIME_PROTOCOL_ERROR", "模型没有返回结构化结果", 502); }
    } finally { this.activeTurn = false; }
  }

  async run(request: RuntimeRequest, callbacks: RuntimeCallbacks, signal: AbortSignal): Promise<RuntimeResult> {
    this.begin();
    let edit: { id: string; operation: DocumentEditOperation; text: string } | undefined;
    const abortEdit = (reason: string) => { if (edit) callbacks.onEdit?.({ type: "aborted", editId: edit.id, reason }); edit = undefined; };
    try {
      const client = await this.client();
      const tools = [GUIDE_TOOL, ...(callbacks.document ? DOCUMENT_TOOLS : []), ...(callbacks.workspace ? WORKSPACE_TOOLS : []), FINISH_TOOL];
      const messages: ChatMessage[] = [{ role: "user", text: buildRuntimePrompt(request, Boolean(callbacks.document), randomUUID(), Boolean(callbacks.workspace)) }];
      const system = this.instructions(Boolean(callbacks.document));
      let calls = 0, nudged = false;
      callbacks.onProgress(`正在请求 ${this.options.model}`);
      for (;;) {
        if (signal.aborted) throw new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409);
        // Text that follows a successful begin_document_edit is the edit body; other text is a preview of the answer.
        const bodyEdit = edit;
        const step = await client.step({ system, messages, tools }, delta => {
          if (bodyEdit && edit === bodyEdit) { const offset = bodyEdit.text.length; bodyEdit.text += delta; callbacks.onEdit?.({ type: "delta", editId: bodyEdit.id, offset, delta }); }
          else callbacks.onDelta(delta);
        }, signal);
        messages.push({ role: "assistant", text: step.text, toolCalls: step.toolCalls });
        if (!step.toolCalls.length) {
          if (nudged) throw new LearnError("RUNTIME_PROTOCOL_ERROR", "模型没有调用 finish_turn 结束回合", 502);
          nudged = true;
          messages.push({ role: "user", text: "Call finish_turn now with the structured result." });
          continue;
        }
        const results: Array<{ id: string; content: string }> = [];
        for (const call of step.toolCalls) {
          if (++calls > MAX_TOOL_CALLS) throw new LearnError("RUNTIME_TOOL_LIMIT", `单个回合最多 ${MAX_TOOL_CALLS} 次工具调用`, 502);
          if (call.name === "finish_turn") {
            if (edit) throw new LearnError("RUNTIME_PROTOCOL_ERROR", "正文生成结束但段落尚未提交", 502);
            callbacks.onProgress("正在校验结构化答案");
            const result = validateRuntimeResult(call.args, request);
            if (callbacks.document && result.proposal) throw new LearnError("RUNTIME_PROTOCOL_ERROR", "逐段编辑回合只能通过文档工具写入，不能再返回整篇替换提案", 502);
            return result;
          }
          let content: unknown;
          try { content = await this.tool(call, callbacks, () => edit, next => { edit = next; }, signal); }
          catch (error) {
            const known = asLearnError(error);
            if (known.code === "TURN_CANCELLED") throw known;
            abortEdit(known.message);
            content = { code: known.code, message: known.message, ...known.details };
          }
          results.push({ id: call.id, content: JSON.stringify(content) });
        }
        messages.push({ role: "tool", results });
      }
    } finally {
      abortEdit("生成已结束，未提交内容已撤下");
      this.activeTurn = false;
    }
  }

  close(): void { this.activeTurn = false; }

  private begin(): void {
    if (this.activeTurn) throw new LearnError("RUNTIME_BUSY", "同一工作区当前只能运行一个 Agent 回合", 409);
    this.activeTurn = true;
  }

  private instructions(progressive: boolean): string {
    return [
      "You are Velora's learning assistant inside a documentation workbench, not a coding agent.",
      "You have no shell, filesystem, or source-code access. Use only the provided tools; learn workbench capabilities from guide.",
      "Answer in Chinese unless the user's question clearly asks for another language.",
      "Use supplied learning documents as evidence when relevant. General explanations may return evidence=[]. Never invent source-code evidence.",
      documentInstructions("runtime"),
      "Learning tasks may create and update pages with the provided tools. Path renames and deletions require an explicit request and a reviewed structureProposal.",
      ...(progressive ? ["For document body edits: read_document, then begin_document_edit with insert/replace metadata only. In your NEXT response, write ONLY the Markdown body as plain text (no explanation, no outer code fence) and call commit_document_edit with the editId in that same response. One block per edit; finish one before starting the next. edit_document only deletes. If a tool says mutationApplied=true, do not retry."] : ["When revising, return the complete replacement Markdown for the selected registered document only."]),
      "End every turn by calling finish_turn exactly once with the structured result (proposal=null when you edited through the tools).",
    ].join("\n");
  }

  private async tool(call: ToolCall, callbacks: RuntimeCallbacks, current: () => { id: string; operation: DocumentEditOperation; text: string } | undefined, setEdit: (edit?: { id: string; operation: DocumentEditOperation; text: string }) => void, signal: AbortSignal): Promise<unknown> {
    if (signal.aborted) throw new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409);
    const args = call.args;
    if (call.name === "guide") {
      const items = args.items;
      if (!Array.isArray(items) || !items.length || items.length > 20 || items.some(item => typeof item !== "string" || !item.length)) throw new LearnError("INVALID_TOOL_CALL", "guide requires 1–20 nonempty topic strings", 400);
      return readDocumentGuides(items as string[], "runtime");
    }
    if (["open_document", "create_document", "update_document_metadata"].includes(call.name)) {
      if (!callbacks.workspace) throw new LearnError("INVALID_TOOL_CALL", "Workspace tools are not available for this turn", 403);
      if (current()) throw new LearnError("INVALID_TOOL_CALL", "先提交当前段落，再切换或创建文档", 409);
      if (call.name === "open_document") return callbacks.workspace.open(args.documentId as string);
      if (call.name === "create_document") return callbacks.workspace.create(args.document as DocumentMetadata, args.body as string);
      return callbacks.workspace.update(args.title as string, args.summary as string);
    }
    if (!callbacks.document) throw new LearnError("INVALID_TOOL_CALL", "Document tool is not available for this turn", 403);
    if (call.name === "read_document") return callbacks.document.read();
    if (call.name === "begin_document_edit") {
      if (current()) throw new LearnError("INVALID_TOOL_CALL", "先提交当前段落，再开始下一段", 400);
      const operation = args.operation as DocumentEditOperation | undefined;
      if (!operation || (operation.type === "insert" ? operation.after !== null && typeof operation.after !== "string" : operation.type !== "replace" || typeof operation.blockId !== "string" || typeof operation.ifHash !== "string") || "markdown" in operation) throw new LearnError("INVALID_TOOL_CALL", "begin 仅接受 insert/replace 定位元数据，不包含正文", 400);
      const edit = { id: randomUUID(), operation, text: "" };
      setEdit(edit);
      const sources = editSources(args);
      callbacks.onEdit?.({ type: "started", editId: edit.id, operation, ...(sources ? { sources } : {}) });
      return { editId: edit.id, instruction: "In your next response write ONLY the Markdown body as plain text, then call commit_document_edit with this editId." };
    }
    if (call.name === "commit_document_edit") {
      const edit = current();
      if (!edit || edit.id !== args.editId) throw new LearnError("INVALID_TOOL_CALL", "editId 不对应当前待提交段落", 400);
      if (!edit.text.trim()) throw new LearnError("INVALID_TOOL_CALL", "begin 之后需要先写出正文，再提交", 400);
      const saved = await callbacks.document.apply({ ...edit.operation, markdown: edit.text });
      setEdit(undefined);
      callbacks.onEdit?.({ type: "committed", editId: edit.id, revision: saved.revision, blockIds: edit.operation.type === "replace" ? [edit.operation.blockId] : saved.insertedBlockIds });
      return saved;
    }
    if (call.name === "edit_document") {
      if (current()) throw new LearnError("INVALID_TOOL_CALL", "先提交当前待生成段落", 400);
      const operation = args.operation as { type?: string; blockId: string; ifHash: string } | undefined;
      if (operation?.type !== "delete") throw new LearnError("INVALID_TOOL_CALL", "插入和替换请使用 begin_document_edit 与 commit_document_edit", 400);
      return callbacks.document.apply({ type: "delete", blockId: operation.blockId, ifHash: operation.ifHash });
    }
    throw new LearnError("INVALID_TOOL_CALL", `Unknown tool ${call.name}`, 400);
  }
}
