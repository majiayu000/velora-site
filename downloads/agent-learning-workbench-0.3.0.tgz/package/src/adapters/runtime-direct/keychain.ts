import { execFile } from "node:child_process";

export const KEYCHAIN_SERVICE = "velora";
export const keyEnvName = (keyRef: string) => `VELORA_KEY_${keyRef.toUpperCase().replace(/[^A-Z0-9]/g, "_")}`;

/**
 * Reads the API key named by `keyRef`: the environment variable first (CI, other systems), then the macOS
 * keychain item `velora / keyRef`. The key is only ever held in memory; it is never written or logged here.
 */
export async function readKey(keyRef: string, env: NodeJS.ProcessEnv = process.env, platform = process.platform): Promise<string | undefined> {
  const fromEnv = env[keyEnvName(keyRef)]?.trim();
  if (fromEnv) return fromEnv;
  if (platform !== "darwin") return undefined;
  return new Promise(resolve => {
    execFile("security", ["find-generic-password", "-s", KEYCHAIN_SERVICE, "-a", keyRef, "-w"], { timeout: 5000 }, (error, stdout) => {
      resolve(error ? undefined : stdout.trim() || undefined);
    });
  });
}
