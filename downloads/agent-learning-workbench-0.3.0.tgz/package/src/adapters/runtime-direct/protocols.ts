// Minimal streaming clients for the two protocols the direct runtime supports. Each request goes only to
// the configured base URL; the key travels in a header and never appears in errors.
import { LearnError } from "../../domain/errors";
import { redactDiagnostic } from "../../domain/redact";
import type { AgentToolSpec } from "../../domain/agent-tools";

export type ToolCall = { id: string; name: string; args: Record<string, unknown> };
export type ChatMessage =
  | { role: "user"; text: string }
  | { role: "assistant"; text: string; toolCalls: ToolCall[] }
  | { role: "tool"; results: Array<{ id: string; content: string }> };
export type StepInput = { system: string; messages: ChatMessage[]; tools: AgentToolSpec[]; toolChoice?: "auto" | "required" | { name: string } };
export type StepResult = { text: string; toolCalls: ToolCall[]; stop: string };
export interface ModelClient {
  step(input: StepInput, onText: (delta: string) => void, signal: AbortSignal): Promise<StepResult>;
}
export type ClientOptions = { protocol: "openai-compatible" | "anthropic"; baseUrl: string; model: string; key: string; fetch?: typeof fetch; maxTokens?: number };

/** Splits an SSE byte stream into `{ event, data }` records. */
async function* sse(body: ReadableStream<Uint8Array>): AsyncGenerator<{ event?: string; data: string }> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true }).replace(/\r\n?/g, "\n");
    for (let end = buffer.indexOf("\n\n"); end >= 0; end = buffer.indexOf("\n\n")) {
      const record = buffer.slice(0, end); buffer = buffer.slice(end + 2);
      let event: string | undefined; const data: string[] = [];
      for (const line of record.split("\n")) {
        if (line.startsWith("event:")) event = line.slice(6).trim();
        else if (line.startsWith("data:")) data.push(line.slice(5).replace(/^ /, ""));
      }
      if (data.length) yield { event, data: data.join("\n") };
    }
  }
}

function parseArgs(raw: string, name: string): Record<string, unknown> {
  if (!raw.trim()) return {};
  try {
    const value = JSON.parse(raw) as unknown;
    if (value && typeof value === "object" && !Array.isArray(value)) return value as Record<string, unknown>;
  } catch { /* reported below */ }
  throw new LearnError("RUNTIME_PROTOCOL_ERROR", `模型给 ${name} 的参数不是 JSON 对象`, 502);
}

export function createModelClient(options: ClientOptions): ModelClient {
  const request = options.fetch ?? fetch;
  const secretFree = (text: string) => redactDiagnostic(text.split(options.key).join("[redacted]"));
  async function post(path: string, headers: Record<string, string>, body: unknown, signal: AbortSignal): Promise<ReadableStream<Uint8Array>> {
    let response: Response;
    try {
      response = await request(`${options.baseUrl}${path}`, { method: "POST", headers: { "content-type": "application/json", accept: "text/event-stream", ...headers }, body: JSON.stringify(body), signal });
    } catch (error) {
      if (signal.aborted) throw new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409);
      throw new LearnError("RUNTIME_UNAVAILABLE", `无法连接模型服务：${secretFree(error instanceof Error ? error.message : String(error))}`, 503);
    }
    if (!response.ok || !response.body) {
      const detail = secretFree((await response.text().catch(() => "")).slice(0, 600));
      const code = response.status === 401 || response.status === 403 ? "RUNTIME_AUTH_FAILED" : "RUNTIME_REQUEST_FAILED";
      throw new LearnError(code, `模型服务返回 ${response.status}${detail ? `：${detail}` : ""}`, 502);
    }
    return response.body;
  }
  const guard = async <T>(signal: AbortSignal, work: () => Promise<T>): Promise<T> => {
    try { return await work(); }
    catch (error) {
      if (signal.aborted) throw new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409);
      throw error;
    }
  };
  return options.protocol === "anthropic" ? anthropic() : openai();

  function openai(): ModelClient {
    return {
      step: (input, onText, signal) => guard(signal, async () => {
        const messages: unknown[] = [{ role: "system", content: input.system }];
        for (const message of input.messages) {
          if (message.role === "user") messages.push({ role: "user", content: message.text });
          else if (message.role === "assistant") messages.push({ role: "assistant", content: message.text || null, ...(message.toolCalls.length ? { tool_calls: message.toolCalls.map(call => ({ id: call.id, type: "function", function: { name: call.name, arguments: JSON.stringify(call.args) } })) } : {}) });
          else for (const result of message.results) messages.push({ role: "tool", tool_call_id: result.id, content: result.content });
        }
        const choice = input.toolChoice === undefined || input.toolChoice === "auto" ? "auto" : input.toolChoice === "required" ? "required" : { type: "function", function: { name: input.toolChoice.name } };
        const body = await post("/chat/completions", { authorization: `Bearer ${options.key}` }, {
          model: options.model, stream: true, messages,
          ...(input.tools.length ? { tools: input.tools.map(tool => ({ type: "function", function: { name: tool.name, description: tool.description, parameters: tool.inputSchema } })), tool_choice: choice } : {}),
        }, signal);
        let text = "", stop = "";
        const calls: Array<{ id: string; name: string; args: string }> = [];
        for await (const { data } of sse(body)) {
          if (data === "[DONE]") break;
          const chunk = JSON.parse(data) as { choices?: Array<{ delta?: { content?: string | null; tool_calls?: Array<{ index: number; id?: string; function?: { name?: string; arguments?: string } }> }; finish_reason?: string | null }>; error?: { message?: string } };
          if (chunk.error) throw new LearnError("RUNTIME_REQUEST_FAILED", secretFree(chunk.error.message ?? "模型服务出错"), 502);
          const choice = chunk.choices?.[0];
          if (!choice) continue;
          if (choice.delta?.content) { text += choice.delta.content; onText(choice.delta.content); }
          for (const part of choice.delta?.tool_calls ?? []) {
            const call = calls[part.index] ??= { id: "", name: "", args: "" };
            if (part.id) call.id = part.id;
            if (part.function?.name) call.name += part.function.name;
            if (part.function?.arguments) call.args += part.function.arguments;
          }
          if (choice.finish_reason) stop = choice.finish_reason;
        }
        return { text, stop, toolCalls: calls.filter(Boolean).map((call, i) => ({ id: call.id || `call_${i}`, name: call.name, args: parseArgs(call.args, call.name) })) };
      }),
    };
  }

  function anthropic(): ModelClient {
    return {
      step: (input, onText, signal) => guard(signal, async () => {
        const messages: unknown[] = [];
        for (const message of input.messages) {
          if (message.role === "user") messages.push({ role: "user", content: message.text });
          else if (message.role === "assistant") messages.push({ role: "assistant", content: [...(message.text ? [{ type: "text", text: message.text }] : []), ...message.toolCalls.map(call => ({ type: "tool_use", id: call.id, name: call.name, input: call.args }))] });
          else messages.push({ role: "user", content: message.results.map(result => ({ type: "tool_result", tool_use_id: result.id, content: result.content })) });
        }
        const choice = input.toolChoice === undefined || input.toolChoice === "auto" ? { type: "auto" } : input.toolChoice === "required" ? { type: "any" } : { type: "tool", name: input.toolChoice.name };
        const base = options.baseUrl.endsWith("/v1") ? "" : "/v1";
        const body = await post(`${base}/messages`, { "x-api-key": options.key, "anthropic-version": "2023-06-01" }, {
          model: options.model, max_tokens: options.maxTokens ?? 8192, stream: true, system: input.system, messages,
          ...(input.tools.length ? { tools: input.tools.map(tool => ({ name: tool.name, description: tool.description, input_schema: tool.inputSchema })), tool_choice: choice } : {}),
        }, signal);
        let text = "", stop = "";
        const blocks: Array<{ type: string; id?: string; name?: string; json: string }> = [];
        for await (const { data } of sse(body)) {
          const event = JSON.parse(data) as { type: string; index?: number; content_block?: { type: string; id?: string; name?: string }; delta?: { type?: string; text?: string; partial_json?: string; stop_reason?: string }; error?: { message?: string } };
          if (event.type === "error") throw new LearnError("RUNTIME_REQUEST_FAILED", secretFree(event.error?.message ?? "模型服务出错"), 502);
          if (event.type === "content_block_start" && event.content_block) blocks[event.index ?? blocks.length] = { type: event.content_block.type, id: event.content_block.id, name: event.content_block.name, json: "" };
          if (event.type === "content_block_delta" && event.delta) {
            if (event.delta.type === "text_delta" && event.delta.text) { text += event.delta.text; onText(event.delta.text); }
            if (event.delta.type === "input_json_delta" && event.delta.partial_json) blocks[event.index ?? 0]!.json += event.delta.partial_json;
          }
          if (event.type === "message_delta" && event.delta?.stop_reason) stop = event.delta.stop_reason;
          if (event.type === "message_stop") break;
        }
        return { text, stop, toolCalls: blocks.filter(block => block?.type === "tool_use").map((block, i) => ({ id: block.id ?? `toolu_${i}`, name: block.name ?? "", args: parseArgs(block.json, block.name ?? "") })) };
      }),
    };
  }
}
