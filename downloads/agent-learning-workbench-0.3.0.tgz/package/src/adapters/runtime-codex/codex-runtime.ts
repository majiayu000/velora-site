import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { randomUUID } from "node:crypto";
import { LearnError, asLearnError } from "../../domain/errors";
import type { DocumentEditOperation } from "../../ports/collaboration-port";
import { validateRuntimeResult } from "../../domain/runtime-result";
import type { DocumentMetadata, RuntimeHealth, RuntimeRequest, RuntimeResult } from "../../domain/types";
import type { RuntimeCallbacks, RuntimePort } from "../../ports/runtime-port";
import { RESULT_SCHEMA, buildRuntimePrompt } from "../../domain/runtime-prompt";
import type { StructuredTask } from "../../domain/board-agent";
import { StructuredAnswerStream } from "./structured-answer-stream";
import { redactDiagnostic } from "../../domain/redact";
import { documentInstructions, readDocumentGuides } from "../../domain/document-guides";
import { DOCUMENT_TOOLS as SHARED_DOCUMENT_TOOLS, GUIDE_TOOL as SHARED_GUIDE_TOOL, WORKSPACE_TOOLS as SHARED_WORKSPACE_TOOLS, type AgentToolSpec, editSources } from "../../domain/agent-tools";

type JsonObject = Record<string, unknown>;
type PendingRequest = { resolve: (value: JsonObject) => void; reject: (error: Error) => void };

const asDynamic = (tool: AgentToolSpec) => ({ type: "function", ...tool });
const GUIDE_TOOL = asDynamic(SHARED_GUIDE_TOOL);
const WORKSPACE_TOOLS = SHARED_WORKSPACE_TOOLS.map(asDynamic);
const DOCUMENT_TOOLS = SHARED_DOCUMENT_TOOLS.map(asDynamic);

export class CodexRuntime implements RuntimePort {
  private process?: ChildProcessWithoutNullStreams;
  private requestId = 0;
  private stdoutBuffer = "";
  private stderrTail = "";
  private pending = new Map<number, PendingRequest>();
  private initialized?: Promise<void>;
  private disabledMcpConfig: JsonObject = {};
  // Per app-server process: what Codex told us before a request stalled.
  private serverVersion?: string;
  private accountReady = false;
  private recentNotifications: string[] = [];
  private runtimeHealth: RuntimeHealth = { adapter: "codex-app-server", available: true };
  private active?: {
    threadId: string;
    turnId?: string;
    completedText: string;
    resolve: (value: string) => void;
    reject: (error: Error) => void;
    callbacks: RuntimeCallbacks;
    answerStream: StructuredAnswerStream;
    answerItemId?: string;
    edit?: { id: string; operation: DocumentEditOperation; itemId?: string; text: string; completed: boolean; invalid?: boolean };
    cancelRequested: boolean;
    interruptSent: boolean;
    toolCalls: Promise<void>;
    finished: boolean;
  };

  constructor(
    private readonly repositoryRoot: string,
    private readonly command = "codex",
    private readonly requestTimeoutMs = 30_000,
  ) {}

  get available(): boolean {
    return this.runtimeHealth.available;
  }

  async health(): Promise<RuntimeHealth> {
    try {
      await this.ensureInitialized();
      this.runtimeHealth = { ...this.runtimeHealth, available: true, message: undefined };
    } catch (error) {
      const code = error instanceof LearnError ? error.code : "RUNTIME_UNAVAILABLE";
      this.runtimeHealth = {
        adapter: "codex-app-server",
        available: false,
        message: `Codex Runtime 初始化失败（${code}）。请检查命令、登录状态和协议版本后重新检测。`,
      };
    }
    return { ...this.runtimeHealth };
  }

  async run(request: RuntimeRequest, callbacks: RuntimeCallbacks, signal: AbortSignal): Promise<RuntimeResult> {
    if (this.active) throw new LearnError("RUNTIME_BUSY", "同一工作区当前只能运行一个 Agent 回合", 409);
    this.throwIfCancelled(signal);
    await this.ensureInitialized();
    this.throwIfCancelled(signal);
    callbacks.onProgress("正在读取工作台提供的文档上下文");
    const threadId = await this.startThread({
      cwd: this.repositoryRoot,
      environments: [],
      config: this.disabledMcpConfig,
      approvalPolicy: "never",
      sandbox: "read-only",
      ephemeral: true,
      serviceName: "Velora",
      baseInstructions: "You are Velora's learning assistant. Provide services through the workbench's supplied context, guides, and document tools.",
      dynamicTools: [GUIDE_TOOL, ...(callbacks.document ? DOCUMENT_TOOLS : []), ...(callbacks.workspace ? WORKSPACE_TOOLS : [])],
      developerInstructions: [
        "You are a learning assistant inside a documentation workbench, not a coding agent.",
        "You have no shell, filesystem, or source-code access. Use only the provided workbench tools. Learn workbench capabilities from guide, never from implementation files.",
        "Answer in Chinese unless the user's question clearly asks for another language.",
        "Use supplied learning documents as evidence when relevant. General explanations may return evidence=[]. Never invent source-code evidence.",
        documentInstructions("runtime"),
        ...(!callbacks.document ? ["When revising, return the complete replacement Markdown for the selected registered document only."] : []),
        "Learning tasks may create and update pages with the provided tools. Path renames and deletions require an explicit request and a reviewed structureProposal.",
        ...(callbacks.document ? ["For learning document body edits, use read_document, then begin_document_edit with insert/replace metadata (no body), emit exactly one commentary message containing ONLY the actual Markdown body, then commit_document_edit with the returned editId. The host streams that message into the document preview and commits it without repeating the body. Do not wrap the body in an outer code fence or put explanations in that message. Finish and check one block before starting the next; never generate an entire document in one block. edit_document only deletes blocks. These tools are the only permitted write path. Final JSON is a separate summary with proposal=null. If a tool says mutationApplied=true, do not retry; stop and explain the partial result."] : []),
      ].join("\n"),
    }, callbacks.onProgress);
    this.throwIfCancelled(signal);

    let activeTurn!: NonNullable<CodexRuntime["active"]>;
    const completedText = new Promise<string>((resolve, reject) => {
      activeTurn = {
        threadId,
        completedText: "",
        resolve,
        reject,
        callbacks,
        answerStream: new StructuredAnswerStream(),
        cancelRequested: signal.aborted,
        interruptSent: false,
        toolCalls: Promise.resolve(),
        finished: false,
      };
      this.active = activeTurn;
    });
    const onAbort = () => void this.interrupt(activeTurn);
    signal.addEventListener("abort", onAbort, { once: true });
    callbacks.onProgress("Codex 正在阅读问题与当前页面");
    try {
      const turnResponse = await this.request("turn/start", {
        threadId,
        input: [{ type: "text", text: buildRuntimePrompt(request, Boolean(callbacks.document), randomUUID(), Boolean(callbacks.workspace)), text_elements: [] }],
        outputSchema: RESULT_SCHEMA,
        approvalPolicy: "never",
        sandboxPolicy: { type: "readOnly", networkAccess: false },
      });
      const turn = turnResponse.turn as JsonObject | undefined;
      if (typeof turn?.id === "string") activeTurn.turnId = turn.id;
      if (signal.aborted || activeTurn.cancelRequested) await this.interrupt(activeTurn);
      const raw = await completedText;
      if (activeTurn.edit) throw new LearnError("RUNTIME_PROTOCOL_ERROR", "正文生成结束但段落尚未提交", 502);
      callbacks.onProgress("正在校验结构化答案");
      const result = this.parseResult(raw, request);
      if (callbacks.document && result.proposal) throw new LearnError("RUNTIME_PROTOCOL_ERROR", "逐段编辑回合只能通过文档工具写入，不能再返回整篇替换提案", 502);
      return result;
    } catch (error) {
      this.active = undefined;
      throw error;
    } finally {
      signal.removeEventListener("abort", onAbort);
      await activeTurn.toolCalls;
      this.abortEdit(activeTurn, "生成已结束，未提交内容已撤下");
      if (this.active === activeTurn) this.active = undefined;
    }
  }

  /** One-shot structured task: a fresh thread with no tools; the final message must match `task.schema`. */
  async structured(task: StructuredTask, signal: AbortSignal): Promise<unknown> {
    if (this.active) throw new LearnError("RUNTIME_BUSY", "同一工作区当前只能运行一个 Agent 回合", 409);
    this.throwIfCancelled(signal);
    await this.ensureInitialized();
    this.throwIfCancelled(signal);
    const threadId = await this.startThread({
      cwd: this.repositoryRoot,
      environments: [],
      config: this.disabledMcpConfig,
      approvalPolicy: "never",
      sandbox: "read-only",
      ephemeral: true,
      serviceName: "Velora",
      baseInstructions: task.instructions,
      dynamicTools: [],
      developerInstructions: task.instructions,
    });
    this.throwIfCancelled(signal);
    const callbacks: RuntimeCallbacks = { onProgress: () => undefined, onDelta: () => undefined };
    let activeTurn!: NonNullable<CodexRuntime["active"]>;
    const completedText = new Promise<string>((resolve, reject) => {
      activeTurn = { threadId, completedText: "", resolve, reject, callbacks, answerStream: new StructuredAnswerStream(), cancelRequested: signal.aborted, interruptSent: false, toolCalls: Promise.resolve(), finished: false };
      this.active = activeTurn;
    });
    const onAbort = () => void this.interrupt(activeTurn);
    signal.addEventListener("abort", onAbort, { once: true });
    try {
      const turnResponse = await this.request("turn/start", {
        threadId,
        input: [{ type: "text", text: task.prompt, text_elements: [] }],
        outputSchema: task.schema,
        approvalPolicy: "never",
        sandboxPolicy: { type: "readOnly", networkAccess: false },
      });
      const turn = turnResponse.turn as JsonObject | undefined;
      if (typeof turn?.id === "string") activeTurn.turnId = turn.id;
      if (signal.aborted || activeTurn.cancelRequested) await this.interrupt(activeTurn);
      const raw = await completedText;
      try { return JSON.parse(raw) as unknown; }
      catch { throw new LearnError("RUNTIME_PROTOCOL_ERROR", "Codex 未返回有效的结构化 JSON", 502); }
    } catch (error) {
      this.active = undefined;
      throw error;
    } finally {
      signal.removeEventListener("abort", onAbort);
      await activeTurn.toolCalls;
      if (this.active === activeTurn) this.active = undefined;
    }
  }

  /**
   * thread/start is where Codex first needs its account, workspace routing and model list.
   * When it stalls, the app-server stays alive and answers nothing, so a bare request timeout
   * says nothing useful. Report what Codex did say, and restart the process so a retry starts clean.
   */
  private async startThread(params: JsonObject, onProgress?: (message: string) => void): Promise<string> {
    const startedAt = Date.now();
    const slowNotice = onProgress
      ? setTimeout(() => onProgress("Codex 仍在创建会话，可能在等待网络或登录刷新"), Math.min(8_000, Math.floor(this.requestTimeoutMs / 2)))
      : undefined;
    try {
      const response = await this.request("thread/start", params);
      const thread = response.thread as JsonObject | undefined;
      if (typeof thread?.id !== "string") throw new LearnError("RUNTIME_PROTOCOL_ERROR", "Codex did not return a thread id", 502);
      return thread.id;
    } catch (error) {
      if (error instanceof LearnError && error.code === "RUNTIME_TIMEOUT") throw this.threadStartTimeout(Date.now() - startedAt);
      throw error;
    } finally {
      clearTimeout(slowNotice);
    }
  }

  private threadStartTimeout(waitedMs: number): LearnError {
    const stderr = this.stderrTail.trim();
    const details = {
      method: "thread/start",
      waitedMs,
      codexVersion: this.serverVersion ?? null,
      accountReady: this.accountReady,
      notifications: [...this.recentNotifications],
      stderr: stderr ? redactDiagnostic(stderr.slice(-4_000), 600) : "",
    };
    this.restartProcess();
    const version = this.serverVersion ? ` ${this.serverVersion}` : "";
    const hint = this.accountReady
      ? "登录与工作区路由已就绪，卡在会话创建本身"
      : "期间也没收到 account/updated，登录或工作区路由未完成，优先检查到 chatgpt.com 的网络与代理";
    return new LearnError(
      "RUNTIME_THREAD_START_TIMEOUT",
      `Codex${version} 已启动，但 ${Math.round(waitedMs / 1000)} 秒内没有创建会话（thread/start 无响应）；${hint}。`
        + `已重启 Codex 进程，可直接重试。仍失败时在终端运行 codex exec "hi" 确认 Codex 本身能否对话，并检查代理（HTTPS_PROXY）和 codex login status。`
        + (details.stderr ? ` Codex 输出：${details.stderr}` : " Codex 没有输出任何错误。"),
      504,
      details,
    );
  }

  private restartProcess(): void {
    const child = this.process;
    this.process = undefined;
    this.initialized = undefined;
    child?.kill("SIGTERM");
  }

  close(): void {
    if (this.active) this.abortEdit(this.active, "生成已关闭");
    this.active?.reject(new LearnError("RUNTIME_CLOSED", "Codex runtime closed", 503));
    this.active = undefined;
    this.process?.kill("SIGTERM");
    this.process = undefined;
    this.initialized = undefined;
  }

  private async ensureInitialized(): Promise<void> {
    if (this.initialized) return this.initialized;
    this.initialized = (async () => {
      const child = spawn(this.command, ["app-server", ...[
        "features.shell_tool=false", "features.hooks=false", "features.memories=false",
        "features.chronicle=false", "features.apps=false", "features.plugins=false",
        "features.remote_plugin=false", "features.tool_suggest=false",
        "features.multi_agent=false", "features.multi_agent_v2.enabled=false",
        "skills.include_instructions=false", "skills.bundled.enabled=false", "project_doc_max_bytes=0",
      ].flatMap(setting => ["-c", setting])], {
        cwd: this.repositoryRoot,
        env: process.env,
        stdio: ["pipe", "pipe", "pipe"],
      });
      this.process = child;
      this.stdoutBuffer = "";
      this.stderrTail = "";
      this.serverVersion = undefined;
      this.accountReady = false;
      this.recentNotifications = [];
      // A replaced (restarted) child must not feed or tear down its successor.
      const isStale = () => this.process !== undefined && this.process !== child;
      child.stdout.setEncoding("utf8");
      child.stderr.setEncoding("utf8");
      child.stdout.on("data", (chunk: string) => { if (!isStale()) this.consumeStdout(chunk); });
      child.stderr.on("data", (chunk: string) => {
        if (!isStale()) this.stderrTail = `${this.stderrTail}${chunk}`.slice(-12_000);
      });
      child.once("error", (error) => { if (!isStale()) this.failAll(new LearnError("RUNTIME_UNAVAILABLE", error.message, 503)); });
      child.once("exit", (code, signal) => {
        if (isStale()) return;
        const detail = this.stderrTail.trim();
        this.failAll(
          new LearnError(
            "RUNTIME_EXITED",
            `Codex app-server exited (${signal ?? code ?? "unknown"})${detail ? `: ${redactDiagnostic(detail)}` : ""}`,
            502,
          ),
        );
      });
      const response = await this.request("initialize", {
        clientInfo: { name: "learn-workbench", title: "Velora", version: "0.1.0" },
        capabilities: {
          experimentalApi: true,
          requestAttestation: false,
          optOutNotificationMethods: ["thread/tokenUsage/updated", "account/rateLimits/updated"],
        },
      });
      const serverInfo = response.serverInfo as JsonObject | undefined;
      // 0.17x reports its version only inside userAgent ("<client>/0.172.0 (...)").
      const userAgentVersion = typeof response.userAgent === "string" ? /\/(\d+\.\d+\.\d+[^\s]*)/.exec(response.userAgent)?.[1] : undefined;
      this.serverVersion = typeof serverInfo?.version === "string" ? serverInfo.version : userAgentVersion;
      this.runtimeHealth = {
        adapter: "codex-app-server",
        available: true,
        version: this.serverVersion,
      };
      this.notify("initialized");
      // Empty MCP maps merge with user configuration; disable every inherited server explicitly.
      const effective = await this.request("config/read", { cwd: this.repositoryRoot, includeLayers: false });
      const config = effective.config as JsonObject;
      this.disabledMcpConfig = Object.fromEntries(Object.keys(config.mcp_servers ?? {}).map(name => [`mcp_servers.${name}.enabled`, false]));
    })().catch((error) => {
      this.initialized = undefined;
      const child = this.process;
      this.process = undefined;
      child?.kill("SIGTERM");
      throw error;
    });
    return this.initialized;
  }

  private request(method: string, params: JsonObject): Promise<JsonObject> {
    const id = ++this.requestId;
    return new Promise((resolve, reject) => {
      const process = this.process;
      if (!process?.stdin.writable) {
        reject(new LearnError("RUNTIME_UNAVAILABLE", "Codex app-server is not writable", 503));
        return;
      }
      const timeout = setTimeout(() => {
        const pending = this.pending.get(id);
        if (!pending) return;
        this.pending.delete(id);
        pending.reject(new LearnError("RUNTIME_TIMEOUT", `Codex request timed out: ${method}`, 504));
      }, this.requestTimeoutMs);
      this.pending.set(id, {
        resolve: (value) => { clearTimeout(timeout); resolve(value); },
        reject: (error) => { clearTimeout(timeout); reject(error); },
      });
      process.stdin.write(`${JSON.stringify({ method, id, params })}\n`, (error) => {
        if (!error) return;
        const pending = this.pending.get(id);
        this.pending.delete(id);
        pending?.reject(error);
      });
    });
  }

  private notify(method: string): void {
    this.process?.stdin.write(`${JSON.stringify({ method })}\n`);
  }

  private consumeStdout(chunk: string): void {
    this.stdoutBuffer += chunk;
    while (true) {
      const newline = this.stdoutBuffer.indexOf("\n");
      if (newline < 0) break;
      const line = this.stdoutBuffer.slice(0, newline).trim();
      this.stdoutBuffer = this.stdoutBuffer.slice(newline + 1);
      if (!line) continue;
      try {
        this.handleMessage(JSON.parse(line) as JsonObject);
      } catch (error) {
        this.failAll(new LearnError("RUNTIME_PROTOCOL_ERROR", `Invalid app-server JSON: ${String(error)}`, 502));
      }
    }
  }

  private handleMessage(message: JsonObject): void {
    if (typeof message.id === "number" && ("result" in message || "error" in message)) {
      const pending = this.pending.get(message.id);
      if (!pending) return;
      this.pending.delete(message.id);
      if (message.error) {
        const error = message.error as JsonObject;
        pending.reject(new LearnError("RUNTIME_REQUEST_FAILED", String(error.message ?? "Codex request failed"), 502));
      } else {
        pending.resolve((message.result ?? {}) as JsonObject);
      }
      return;
    }
    if ((typeof message.id === "number" || typeof message.id === "string") && typeof message.method === "string") {
      const active = this.active;
      if (message.method === "item/tool/call" && active) {
        active.toolCalls = active.toolCalls.then(() => this.handleToolCall(message, active));
        return;
      }
      this.process?.stdin.write(
        `${JSON.stringify({ id: message.id, error: { code: -32601, message: "Velora does not allow runtime-side mutations or approvals" } })}\n`,
      );
      return;
    }
    if (typeof message.method === "string") {
      if (message.method === "account/updated") this.accountReady = true;
      this.recentNotifications = [...this.recentNotifications, message.method].slice(-6);
    }
    const active = this.active;
    if (!active || typeof message.method !== "string") return;
    const params = (message.params ?? {}) as JsonObject;
    if (message.method === "turn/started" && params.threadId === active.threadId) {
      const turn = params.turn as JsonObject | undefined;
      if (typeof turn?.id === "string") active.turnId = turn.id;
      if (active.cancelRequested) void this.interrupt(active);
      return;
    }
    if (params.threadId && params.threadId !== active.threadId) return;
    if (message.method === "item/started" && params.turnId === active.turnId) {
      const item = params.item as JsonObject | undefined;
      if (item?.type === "agentMessage" && active.edit && !active.cancelRequested) {
        if (active.edit.itemId || item.phase !== "commentary" || typeof item.id !== "string") active.edit.invalid = true;
        else active.edit.itemId = item.id;
      }
      return;
    }
    if (message.method === "item/agentMessage/delta" && params.turnId === active.turnId) {
      if (active.cancelRequested) return;
      const delta = typeof params.delta === "string" ? params.delta : "";
      if (active.edit) {
        const edit = active.edit;
        if (edit.invalid || edit.completed || params.itemId !== edit.itemId) return;
        const offset = edit.text.length;
        edit.text += delta;
        if (delta) active.callbacks.onEdit?.({ type: "delta", editId: edit.id, offset, delta });
        return;
      }
      if (params.itemId !== active.answerItemId) {
        active.answerItemId = params.itemId as string | undefined;
        active.answerStream = new StructuredAnswerStream();
      }
      const answerDelta = active.answerStream.push(delta);
      if (answerDelta) active.callbacks.onDelta(answerDelta);
      return;
    }
    if (message.method === "item/completed" && params.turnId === active.turnId) {
      const item = params.item as JsonObject | undefined;
      if (item?.type === "agentMessage" && typeof item.text === "string") {
        if (active.edit) {
          const edit = active.edit;
          if (item.id !== edit.itemId || edit.completed || edit.text !== item.text) edit.invalid = true;
          else edit.completed = true;
        } else active.completedText = item.text;
      }
      return;
    }
    if (message.method === "turn/completed") {
      const turn = params.turn as JsonObject | undefined;
      if (!turn || turn.id !== active.turnId) return;
      const status = turn.status;
      const items = Array.isArray(turn.items) ? turn.items as JsonObject[] : [];
      const completedMessage = [...items].reverse().find((item) => item.type === "agentMessage" && typeof item.text === "string");
      const text = active.completedText || (typeof completedMessage?.text === "string" ? completedMessage.text : "");
      active.finished = true;
      void active.toolCalls.then(() => {
        if (status === "completed") active.resolve(text);
        else if (status === "interrupted") active.reject(new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409));
        else {
          const turnError = turn.error as JsonObject | undefined;
          active.reject(new LearnError("RUNTIME_TURN_FAILED", String(turnError?.message ?? "Codex turn failed"), 502));
        }
      });
    }
  }

  private async handleToolCall(message: JsonObject, active: NonNullable<CodexRuntime["active"]>): Promise<void> {
    let success = false;
    let result: unknown;
    const params = (message.params ?? {}) as JsonObject;
    try {
      if (this.active !== active || active.cancelRequested || active.finished) throw new LearnError("TURN_CANCELLED", "This turn is no longer accepting document operations", 409);
      if (params.threadId !== active.threadId || params.turnId !== active.turnId || params.namespace != null) throw new LearnError("INVALID_TOOL_CALL", "Document tool is not available for this turn", 403);
      if (params.tool === "guide") {
        const items = (params.arguments as JsonObject | undefined)?.items;
        if (!Array.isArray(items) || !items.length || items.length > 20 || items.some(item => typeof item !== "string" || !item.length)) throw new LearnError("INVALID_TOOL_CALL", "guide requires 1–20 nonempty topic strings", 400);
        result = readDocumentGuides(items, "runtime");
      } else if (["open_document", "create_document", "update_document_metadata"].includes(String(params.tool))) {
        if (!active.callbacks.workspace) throw new LearnError("INVALID_TOOL_CALL", "Workspace tools are not available for this turn", 403);
        if (active.edit) throw new LearnError("INVALID_TOOL_CALL", "先提交当前段落，再切换或创建文档", 409);
        const args = (params.arguments ?? {}) as JsonObject;
        if (params.tool === "open_document") result = await active.callbacks.workspace.open(args.documentId as string);
        else if (params.tool === "create_document") result = await active.callbacks.workspace.create(args.document as DocumentMetadata, args.body as string);
        else result = await active.callbacks.workspace.update(args.title as string, args.summary as string);
      } else {
        if (!active.callbacks.document) throw new LearnError("INVALID_TOOL_CALL", "Document tool is not available for this turn", 403);
        if (params.tool === "read_document") result = await active.callbacks.document.read();
        else if (params.tool === "begin_document_edit") {
          if (active.edit) throw new LearnError("INVALID_TOOL_CALL", "先提交当前段落，再开始下一段", 400);
          const operation = (params.arguments as JsonObject | undefined)?.operation as DocumentEditOperation | undefined;
          if (!operation || (operation.type === "insert" ? operation.after !== null && typeof operation.after !== "string" : operation.type !== "replace" || typeof operation.blockId !== "string" || typeof operation.ifHash !== "string") || "markdown" in operation) throw new LearnError("INVALID_TOOL_CALL", "begin 仅接受 insert/replace 定位元数据，不包含正文", 400);
          const edit = { id: randomUUID(), operation, text: "", completed: false };
          active.edit = edit;
          const sources = editSources(params.arguments as JsonObject | undefined);
          active.callbacks.onEdit?.({ type: "started", editId: edit.id, operation, ...(sources ? { sources } : {}) });
          result = { editId: edit.id, instruction: "Now emit exactly ONE commentary message containing ONLY the actual replacement Markdown. Then call commit_document_edit with this editId. No outer wrapper, explanation, or duplicated body in tool arguments." };
        } else if (params.tool === "commit_document_edit") {
          const edit = active.edit;
          if (!edit || edit.id !== (params.arguments as JsonObject | undefined)?.editId) throw new LearnError("INVALID_TOOL_CALL", "editId 不对应当前待提交段落", 400);
          if (!edit.completed || edit.invalid || !edit.text.trim()) throw new LearnError("INVALID_TOOL_CALL", "需要一条完整且与增量一致的正文 commentary 消息", 400);
          result = await active.callbacks.document.apply({ ...edit.operation, markdown: edit.text });
          const saved = result as Awaited<ReturnType<NonNullable<RuntimeCallbacks["document"]>["apply"]>>;
          active.edit = undefined;
          active.callbacks.onEdit?.({ type: "committed", editId: edit.id, revision: saved.revision, blockIds: edit.operation.type === "replace" ? [edit.operation.blockId] : saved.insertedBlockIds });
        } else if (params.tool === "edit_document") {
          if (active.edit) throw new LearnError("INVALID_TOOL_CALL", "先提交当前待生成段落", 400);
          const operation = (params.arguments as JsonObject | undefined)?.operation as { type?: string; blockId: string; ifHash: string } | undefined;
          if (operation?.type !== "delete") throw new LearnError("INVALID_TOOL_CALL", "插入和替换请使用 begin_document_edit 与 commit_document_edit", 400);
          result = await active.callbacks.document.apply({ type: "delete", blockId: operation.blockId, ifHash: operation.ifHash });
        }
        else throw new LearnError("INVALID_TOOL_CALL", "Unknown document tool", 400);
      }
      success = true;
    } catch (error) {
      const known = asLearnError(error);
      if (params.threadId === active.threadId && params.turnId === active.turnId && params.namespace == null) this.abortEdit(active, known.message);
      result = { code: known.code, message: known.message, ...known.details };
    }
    this.process?.stdin.write(`${JSON.stringify({ id: message.id, result: { success, contentItems: [{ type: "inputText", text: JSON.stringify(result) }] } })}\n`);
  }

  private abortEdit(active: NonNullable<CodexRuntime["active"]>, reason: string): void {
    const edit = active.edit;
    active.edit = undefined;
    if (edit) active.callbacks.onEdit?.({ type: "aborted", editId: edit.id, reason });
  }

  private failAll(error: Error): void {
    for (const pending of this.pending.values()) pending.reject(error);
    this.pending.clear();
    if (this.active) this.abortEdit(this.active, error.message);
    this.active?.reject(error);
    this.active = undefined;
    this.process = undefined;
    this.initialized = undefined;
  }

  private throwIfCancelled(signal: AbortSignal): void {
    if (signal.aborted) throw new LearnError("TURN_CANCELLED", "Agent 回合已取消", 409);
  }

  private async interrupt(active: NonNullable<CodexRuntime["active"]>): Promise<void> {
    active.cancelRequested = true;
    this.abortEdit(active, "已停止，未提交内容已撤下");
    if (!active.turnId || active.interruptSent || this.active !== active) return;
    active.interruptSent = true;
    try {
      await this.request("turn/interrupt", { threadId: active.threadId, turnId: active.turnId });
    } catch (error) {
      if (this.active === active) this.active = undefined;
      active.reject(error instanceof Error ? error : new Error(String(error)));
    }
  }


  private parseResult(raw: string, request: RuntimeRequest): RuntimeResult {
    const normalized = raw.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
    let value: unknown;
    try {
      value = JSON.parse(normalized);
    } catch {
      throw new LearnError("RUNTIME_PROTOCOL_ERROR", "Codex returned an invalid structured learning result", 502, {
        preview: raw.slice(0, 240),
      });
    }
    return validateRuntimeResult(value, request);
  }
}
