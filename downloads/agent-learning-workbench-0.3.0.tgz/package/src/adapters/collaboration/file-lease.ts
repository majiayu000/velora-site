import { randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";

/**
 * Cross-process lease: an exclusive lock file holding the owner's pid. Stale locks from dead
 * processes are reclaimed; a live owner makes callers wait up to `timeoutMs`, then `busy()` is thrown.
 */
export async function withFileLease<T>(file: string, action: () => Promise<T>, busy: () => Error, timeoutMs = 10000): Promise<T> {
  const lock = `${file}.lock`;
  const started = Date.now();
  while (true) {
    try {
      const handle = await fs.open(lock, "wx", 0o600);
      try { await handle.writeFile(String(process.pid)); } finally { await handle.close(); }
      break;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      try {
        const owner = Number(await fs.readFile(lock, "utf8"));
        if (owner > 0) {
          try { process.kill(owner, 0); } catch (error) { if ((error as NodeJS.ErrnoException).code === "ESRCH") { await fs.unlink(lock); continue; } }
        } else if (Date.now() - (await fs.stat(lock)).mtimeMs > 5000) { await fs.unlink(lock); continue; }
      } catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") continue; throw error; }
      if (Date.now() - started > timeoutMs) throw busy();
      await new Promise(resolve => setTimeout(resolve, 25));
    }
  }
  try { return await action(); } finally { await fs.unlink(lock); }
}

/** Write via a synced temporary file and rename, so readers never see a partial file. */
export async function writeFileAtomic(file: string, text: string): Promise<void> {
  const temporary = `${file}.${randomUUID()}.tmp`;
  const handle = await fs.open(temporary, "wx", 0o600);
  try { await handle.writeFile(text); await handle.sync(); } finally { await handle.close(); }
  await fs.rename(temporary, file);
}
