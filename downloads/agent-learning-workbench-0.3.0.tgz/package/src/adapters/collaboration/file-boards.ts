import { randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";
import * as Y from "yjs";
import { LearnError } from "../../domain/errors";
import type { EventPort } from "../../ports/event-port";
import type { BoardMetadata, BoardPort, BoardProjection, BoardSyncSnapshot } from "../../ports/board-port";
import { addSourceLinks, boardTitle, removeSourceLinks, setBoardTitle, snapshot, sourceLinks, validateBoardDoc } from "./board-model";
import type { SourceLink } from "../../domain/board-compose";
import { withFileLease, writeFileAtomic } from "./file-lease";

type BoardRecord = { state: string; revision: number; title: string };
const ID = /^board-[a-f0-9]{8}$/;
const STATE_LIMIT = 12 * 1024 * 1024;
const SERVER_ORIGIN = { kind: "server" } as const;
const encode = (bytes: Uint8Array) => Buffer.from(bytes).toString("base64");
function decode(value: unknown): Uint8Array {
  if (typeof value !== "string" || value.length > STATE_LIMIT || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) throw new LearnError("INVALID_UPDATE", "Invalid Yjs update encoding", 400);
  return Buffer.from(value, "base64");
}

/**
 * Whiteboards persisted as Yjs state under `.learn/collaboration/boards/`, with a readable
 * projection at `boards/<id>.board.json`. Same lease and validate-before-commit rules as documents.
 */
export class FileBoards implements BoardPort {
  private readonly stateDirectory: string;
  private readonly projectionDirectory: string;

  /** `register` records a board in the space manifest; called on create, on rename, and for boards found only on disk. */
  constructor(private readonly root: string, private readonly events: EventPort, private readonly register?: (board: BoardMetadata) => Promise<void>) {
    this.stateDirectory = path.join(root, ".learn", "collaboration", "boards");
    this.projectionDirectory = path.join(root, "boards");
  }

  private stateFile(id: string): string {
    if (!ID.test(id)) throw new LearnError("BOARD_NOT_FOUND", "Unknown board", 404);
    return path.join(this.stateDirectory, `${id}.json`);
  }

  private async readRecord(file: string): Promise<BoardRecord | undefined> {
    try { return JSON.parse(await fs.readFile(file, "utf8")) as BoardRecord; }
    catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return undefined; throw error; }
  }

  private metadata(id: string, record: BoardRecord): BoardMetadata {
    return { id, title: record.title, path: `boards/${id}.board.json`, revision: record.revision };
  }

  private toProjection(id: string, doc: Y.Doc): BoardProjection {
    const board = snapshot(doc);
    return {
      version: 1, id, title: boardTitle(doc),
      cards: board.cards.map(({ id, text, kind, status, color, author, x, y, w, h, frameId }) => ({ id, text, kind, status, color, author, x, y, w, h, ...(frameId ? { frameId } : {}) })),
      frames: board.frames, edges: board.edges, links: sourceLinks(doc),
    };
  }

  private async project(id: string, doc: Y.Doc): Promise<void> {
    const projection = this.toProjection(id, doc);
    await fs.mkdir(this.projectionDirectory, { recursive: true });
    await writeFileAtomic(path.join(this.projectionDirectory, `${id}.board.json`), `${JSON.stringify(projection, null, 2)}\n`);
  }

  private async transaction(id: string, mutate?: (doc: Y.Doc) => void, vector?: Uint8Array): Promise<BoardSyncSnapshot> {
    const file = this.stateFile(id);
    await fs.mkdir(this.stateDirectory, { recursive: true });
    let renamed: BoardMetadata | undefined;
    const result = await withFileLease(file, async () => {
      const record = await this.readRecord(file);
      if (!record) throw new LearnError("BOARD_NOT_FOUND", "Unknown board", 404);
      const doc = new Y.Doc();
      try {
        Y.applyUpdate(doc, decode(record.state));
        if (mutate) {
          // Merge and validate on this disposable document; nothing is written unless it passes.
          try { mutate(doc); validateBoardDoc(doc); }
          catch (error) { throw error instanceof LearnError ? error : new LearnError("INVALID_UPDATE", error instanceof Error ? error.message : "Invalid board update", 400); }
        }
        const state = encode(Y.encodeStateAsUpdate(doc));
        if (state.length > STATE_LIMIT) throw new LearnError("BOARD_TOO_LARGE", "Board history exceeds the size limit", 413);
        let current = record;
        if (state !== record.state) {
          current = { state, revision: record.revision + 1, title: boardTitle(doc) };
          await writeFileAtomic(file, JSON.stringify(current));
          await this.project(id, doc);
          this.events.publish("board.changed", { boardId: id, revision: current.revision });
          if (current.title !== record.title) renamed = this.metadata(id, current);
        }
        return {
          state: vector ? encode(Y.encodeStateAsUpdate(doc, vector)) : state,
          vector: encode(Y.encodeStateVector(doc)),
          revision: current.revision,
          board: this.metadata(id, current),
        };
      } finally { doc.destroy(); }
    }, () => new LearnError("BOARD_BUSY", "Board is busy; retry the operation", 409));
    // Outside the lease: registration takes the manifest queue and may record history.
    if (renamed) await this.register?.(renamed);
    return result;
  }

  async list(): Promise<BoardMetadata[]> {
    let names: string[] = [];
    try { names = await fs.readdir(this.stateDirectory); }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
    const boards: BoardMetadata[] = [];
    for (const name of names.filter(n => /^board-[a-f0-9]{8}\.json$/.test(n)).sort()) {
      const id = name.slice(0, -5);
      const record = await this.readRecord(path.join(this.stateDirectory, name));
      if (record) boards.push(this.metadata(id, record));
    }
    for (const board of boards) await this.register?.(board);
    return boards;
  }

  async create(title: string): Promise<BoardMetadata> {
    if (typeof title !== "string") throw new LearnError("INVALID_BOARD", "title must be a string", 422);
    const id = `board-${randomUUID().replaceAll("-", "").slice(0, 8)}`;
    const doc = new Y.Doc();
    try {
      setBoardTitle(doc, title, SERVER_ORIGIN);
      const record: BoardRecord = { state: encode(Y.encodeStateAsUpdate(doc)), revision: 1, title: boardTitle(doc) };
      await fs.mkdir(this.stateDirectory, { recursive: true });
      const file = this.stateFile(id);
      await withFileLease(file, async () => {
        if (await this.readRecord(file)) throw new LearnError("BOARD_EXISTS", "Board id collision; retry", 409);
        await writeFileAtomic(file, JSON.stringify(record));
        await this.project(id, doc);
      }, () => new LearnError("BOARD_BUSY", "Board is busy; retry the operation", 409));
      this.events.publish("board.changed", { boardId: id, revision: record.revision });
      await this.register?.(this.metadata(id, record));
      return this.metadata(id, record);
    } finally { doc.destroy(); }
  }

  read(id: string): Promise<BoardSyncSnapshot> { return this.transaction(id); }

  async projection(id: string): Promise<BoardProjection> {
    const { state } = await this.transaction(id);
    const doc = new Y.Doc();
    try { Y.applyUpdate(doc, decode(state)); return this.toProjection(id, doc); } finally { doc.destroy(); }
  }

  addLinks(id: string, links: SourceLink[]): Promise<BoardSyncSnapshot> {
    return this.transaction(id, doc => addSourceLinks(doc, links, SERVER_ORIGIN));
  }

  removeLinks(id: string, linkIds: string[]): Promise<BoardSyncSnapshot> {
    return this.transaction(id, doc => removeSourceLinks(doc, linkIds, SERVER_ORIGIN));
  }

  async sync(id: string, update: string, vector: string): Promise<BoardSyncSnapshot> {
    let clientVector: Uint8Array;
    try { clientVector = decode(vector); Y.decodeStateVector(clientVector); }
    catch { throw new LearnError("INVALID_UPDATE", "Invalid state vector", 400); }
    const bytes = decode(update);
    return this.transaction(id, doc => Y.applyUpdate(doc, bytes, "remote-client"), clientVector);
  }
}
