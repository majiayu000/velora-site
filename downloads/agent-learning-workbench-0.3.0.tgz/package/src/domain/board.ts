// Pure whiteboard rules shared by the browser prototype and future server code.
// No Yjs, DOM, filesystem or provider imports.

export type Point = { x: number; y: number };
export type Rect = Point & { w: number; h: number };
export type CardKind = "note" | "image" | "docRef";
export type CardStatus = "live" | "draft";
export type BoardCard = Rect & { id: string; text: string; kind: CardKind; frameId?: string; status: CardStatus };
export type BoardFrame = Rect & { id: string; title: string };
export type BoardEdge = { id: string; from: string; to: string; label?: string };
export type Side = "top" | "right" | "bottom" | "left";
export type Align = "start" | "center" | "end";
export type Place = { ref: Rect | null; side: Side; align: Align };
export type ArrangeStrategy = "by-group" | "timeline" | "grid";

export const CARD_WIDTH = 180;
export const CARD_MIN_HEIGHT = 64;
export const GAP = 24;
const FRAME_PADDING = 28;

export function normalizeCardText(text: string): string {
  return text.replace(/\r\n?/g, "\n").split("\n").map(line => line.trimEnd()).join("\n").trim();
}

/** Content identity only: moving or recolouring a card must not mark its derived paragraphs stale. */
export function cardContentHash(kind: CardKind, text: string): string {
  const input = `${kind}\u0000${normalizeCardText(text)}`;
  let a = 0x811c9dc5, b = 0x01000193;
  for (let i = 0; i < input.length; i += 1) {
    const code = input.charCodeAt(i);
    a = Math.imul(a ^ code, 0x01000193) >>> 0;
    b = Math.imul(b ^ code, 0x5bd1e995) >>> 0;
  }
  return `${a.toString(16).padStart(8, "0")}${b.toString(16).padStart(8, "0")}`;
}

/** Rough rendered height of a card before it is measured: about 12 CJK characters per line at the default width. */
export function estimateCardHeight(text: string, withActions = false): number {
  const lines = text.split("\n").reduce((sum, line) => sum + Math.max(1, Math.ceil([...line].length / 12)), 0);
  return Math.max(CARD_MIN_HEIGHT, 18 + lines * 20 + (withActions ? 30 : 0));
}

export function overlaps(a: Rect, b: Rect, gap = 0): boolean {
  return a.x < b.x + b.w + gap && b.x < a.x + a.w + gap && a.y < b.y + b.h + gap && b.y < a.y + a.h + gap;
}

export function contains(outer: Rect, inner: Rect): boolean {
  return inner.x >= outer.x && inner.y >= outer.y && inner.x + inner.w <= outer.x + outer.w && inner.y + inner.h <= outer.y + outer.h;
}

export function boundsOf(rects: Rect[]): Rect | null {
  if (!rects.length) return null;
  const x = Math.min(...rects.map(r => r.x)), y = Math.min(...rects.map(r => r.y));
  return { x, y, w: Math.max(...rects.map(r => r.x + r.w)) - x, h: Math.max(...rects.map(r => r.y + r.h)) - y };
}

function byPosition(a: Rect, b: Rect): number {
  // Two items share a row when they overlap vertically by at least half of the shorter one;
  // a card beside a tall frame therefore reads left to right, not after the whole frame.
  const overlap = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
  const sameRow = overlap >= Math.min(a.h, b.h) / 2;
  return sameRow ? (a.x - b.x || a.y - b.y) : a.y - b.y;
}

/** Cards inside one group follow edge order; cycles and unconnected cards fall back to position. */
function topologicalOrder(cards: BoardCard[], edges: BoardEdge[]): BoardCard[] {
  const ids = new Set(cards.map(c => c.id));
  const inner = edges.filter(e => ids.has(e.from) && ids.has(e.to) && e.from !== e.to);
  const indegree = new Map(cards.map(c => [c.id, 0]));
  for (const edge of inner) indegree.set(edge.to, (indegree.get(edge.to) ?? 0) + 1);
  const byId = new Map(cards.map(c => [c.id, c]));
  const ready = cards.filter(c => indegree.get(c.id) === 0).sort(byPosition);
  const result: BoardCard[] = [];
  while (ready.length) {
    const next = ready.shift()!;
    result.push(next);
    for (const edge of inner.filter(e => e.from === next.id)) {
      const left = (indegree.get(edge.to) ?? 0) - 1;
      indegree.set(edge.to, left);
      if (left === 0) { ready.push(byId.get(edge.to)!); ready.sort(byPosition); }
    }
  }
  if (result.length !== cards.length) return [...cards].sort(byPosition);
  return result;
}

/** Writing order for compose: groups by frame position, then edge order inside each group. */
export function readingOrder(cards: BoardCard[], frames: BoardFrame[], edges: BoardEdge[]): string[] {
  const live = cards.filter(c => c.status === "live");
  const frameById = new Map(frames.map(f => [f.id, f]));
  const groups = new Map<string, BoardCard[]>();
  for (const card of live) {
    const key = card.frameId && frameById.has(card.frameId) ? card.frameId : `card:${card.id}`;
    groups.set(key, [...(groups.get(key) ?? []), card]);
  }
  const anchor = (key: string, members: BoardCard[]): Rect => frameById.get(key) ?? members[0];
  return [...groups.entries()]
    .sort(([ka, a], [kb, b]) => byPosition(anchor(ka, a), anchor(kb, b)))
    .flatMap(([, members]) => topologicalOrder(members, edges).map(c => c.id));
}

/** Deterministic placement relative to a reference rectangle; never moves existing obstacles. */
export function placeCards(place: Place, sizes: { w: number; h: number }[], obstacles: Rect[], viewportOrigin: Point = { x: 0, y: 0 }): Point[] {
  const ref = place.ref ?? { ...viewportOrigin, w: 0, h: 0 };
  const vertical = place.side === "top" || place.side === "bottom";
  const total = sizes.reduce((sum, s) => sum + (vertical ? s.w : s.h), 0) + GAP * Math.max(0, sizes.length - 1);
  const span = vertical ? ref.w : ref.h;
  const offset = place.align === "start" ? 0 : place.align === "center" ? (span - total) / 2 : span - total;
  let placed: Rect[] = [];
  let cursor = (vertical ? ref.x : ref.y) + offset;
  for (const size of sizes) {
    placed.push(vertical
      ? { x: cursor, y: place.side === "bottom" ? ref.y + ref.h + GAP : ref.y - GAP - size.h, ...size }
      : { x: place.side === "right" ? ref.x + ref.w + GAP : ref.x - GAP - size.w, y: cursor, ...size });
    cursor += (vertical ? size.w : size.h) + GAP;
  }
  // Move the batch as one block away from the reference until it clears every obstacle,
  // so related suggestions stay side by side instead of scattering around obstacles.
  const step: Point = { x: place.side === "right" ? GAP : place.side === "left" ? -GAP : 0, y: place.side === "bottom" ? GAP : place.side === "top" ? -GAP : 0 };
  for (let guard = 0; guard < 400 && placed.some(p => obstacles.some(o => overlaps(p, o, GAP / 2))); guard += 1) {
    placed = placed.map(p => ({ ...p, x: p.x + step.x, y: p.y + step.y }));
  }
  return placed.map(({ x, y }) => ({ x: Math.round(x), y: Math.round(y) }));
}

export type ArrangePlan = { positions: Record<string, Point>; frames: { title: string; rect: Rect; cardIds: string[] }[] };

/** Layout for an AI arrange request. The model only supplies grouping and order; coordinates come from here. */
export function arrangeLayout(cards: BoardCard[], strategy: ArrangeStrategy, origin: Point, groups?: { title: string; cardIds: string[] }[], order?: string[]): ArrangePlan {
  const byId = new Map(cards.map(c => [c.id, c]));
  const ordered = (order?.filter(id => byId.has(id)) ?? []).concat(cards.map(c => c.id).filter(id => !order?.includes(id)));
  const positions: Record<string, Point> = {};
  const frames: ArrangePlan["frames"] = [];
  if (strategy === "timeline") {
    let x = origin.x;
    for (const id of ordered) { positions[id] = { x, y: origin.y }; x += byId.get(id)!.w + GAP; }
    return { positions, frames };
  }
  if (strategy === "grid") {
    const columns = Math.max(1, Math.ceil(Math.sqrt(ordered.length)));
    const rowHeights: number[] = [];
    ordered.forEach((id, i) => { const row = Math.floor(i / columns); rowHeights[row] = Math.max(rowHeights[row] ?? 0, byId.get(id)!.h); });
    ordered.forEach((id, i) => {
      const row = Math.floor(i / columns), column = i % columns;
      positions[id] = { x: origin.x + column * (CARD_WIDTH + GAP), y: origin.y + rowHeights.slice(0, row).reduce((s, h) => s + h + GAP, 0) };
    });
    return { positions, frames };
  }
  const assigned = new Set<string>();
  const groupList = (groups ?? []).map(g => ({ title: g.title, cardIds: g.cardIds.filter(id => byId.has(id) && !assigned.has(id) && (assigned.add(id), true)) }))
    .filter(g => g.cardIds.length);
  const rest = ordered.filter(id => !assigned.has(id));
  if (rest.length) groupList.push({ title: "其他", cardIds: rest });
  let x = origin.x;
  for (const group of groupList) {
    let y = origin.y + FRAME_PADDING + 8;
    const width = Math.max(...group.cardIds.map(id => byId.get(id)!.w));
    for (const id of group.cardIds) { positions[id] = { x: x + FRAME_PADDING, y }; y += byId.get(id)!.h + GAP; }
    frames.push({ title: group.title, cardIds: group.cardIds, rect: { x, y: origin.y, w: width + FRAME_PADDING * 2, h: y - origin.y - GAP + FRAME_PADDING } });
    x += width + FRAME_PADDING * 2 + GAP * 2;
  }
  return { positions, frames };
}

/** On accept, cards the person moved after the preview started keep the person's position. */
export function mergeArrange(plan: ArrangePlan, baseline: Record<string, Point>, current: Record<string, Point>): Record<string, Point> {
  const result: Record<string, Point> = {};
  for (const [id, target] of Object.entries(plan.positions)) {
    const before = baseline[id], now = current[id];
    if (!now) continue;
    const movedByPerson = before && (before.x !== now.x || before.y !== now.y);
    if (!movedByPerson) result[id] = target;
  }
  return result;
}

/** Frame membership is explicit, but a dropped card joins the smallest frame that fully contains it. */
export function frameForCard(card: Rect, frames: BoardFrame[]): string | undefined {
  return frames.filter(f => contains(f, card)).sort((a, b) => a.w * a.h - b.w * b.h)[0]?.id;
}
