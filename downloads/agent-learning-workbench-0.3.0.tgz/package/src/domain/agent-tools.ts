// Workbench tools offered to an Agent runtime. One definition shared by every adapter that runs tools
// itself (Codex dynamic tools, the direct model API); each adapter maps these to its wire format.
/** Card ids a block is based on, as passed to begin_document_edit; anything malformed is ignored. */
export function editSources(args: Record<string, unknown> | undefined): string[] | undefined {
  const value = args?.sources;
  if (!Array.isArray(value)) return undefined;
  const ids = [...new Set(value.filter((id): id is string => typeof id === "string" && id.length > 0 && id.length <= 80))].slice(0, 50);
  return ids.length ? ids : undefined;
}

export type AgentToolSpec = { name: string; description: string; inputSchema: Record<string, unknown> };

export const GUIDE_TOOL: AgentToolSpec = {
  name: "guide", description: "Read workbench guides on demand: topic.index, topic.instructions, topic.creating, topic.editing, topic.diagram, topic.charts, topic.skill, or refusal.<actual error code>. Read the relevant workflow before creating or editing; fetch only needed topics.",
  inputSchema: { type: "object", properties: { items: { type: "array", items: { type: "string", minLength: 1 }, minItems: 1, maxItems: 20 } }, required: ["items"], additionalProperties: false },
};

export const WORKSPACE_TOOLS: AgentToolSpec[] = [
  { name: "open_document", description: "Select a registered learning page by id and read its live blocks. Subsequent document tools edit this page. Use for a related existing topic.", inputSchema: { type: "object", properties: { documentId: { type: "string" } }, required: ["documentId"], additionalProperties: false } },
  { name: "create_document", description: "Create and save a new learning page with a meaningful title, summary and initial Markdown outline, then select it. Continue filling sections with document tools in the SAME turn. Use a .md path in an allowed existing content directory. Do not create a duplicate topic.", inputSchema: {
    type: "object", required: ["document", "body"], additionalProperties: false, properties: {
      document: { type: "object", required: ["id", "path", "title", "summary"], additionalProperties: false, properties: { id: { type: "string" }, path: { type: "string" }, title: { type: "string" }, summary: { type: "string" } } },
      body: { type: "string" },
    },
  } },
  { name: "update_document_metadata", description: "Save the selected page's title and summary in the document index. Keep them consistent with the Markdown heading and content. Does not move or delete files.", inputSchema: { type: "object", properties: { title: { type: "string" }, summary: { type: "string" } }, required: ["title", "summary"], additionalProperties: false } },
];

export const DOCUMENT_TOOLS: AgentToolSpec[] = [
  { name: "read_document", description: "Read the current document's live blocks and hashes. Read before editing; reread after guard conflicts.", inputSchema: { type: "object", properties: {}, required: [], additionalProperties: false } },
  { name: "begin_document_edit", description: "Begin ONE authorized block insert or replacement, without its body. After success emit exactly one commentary message containing ONLY the actual replacement Markdown (no explanation or wrapping fence), then call commit_document_edit. One pending edit at a time. Nothing is saved until commit succeeds.", inputSchema: {
    type: "object", required: ["operation"], additionalProperties: false,
    properties: { sources: { type: "array", items: { type: "string" }, maxItems: 50, description: "Only when composing from whiteboard cards: the ids of the cards this block is based on." }, operation: { anyOf: [
      { type: "object", required: ["type", "after"], additionalProperties: false, properties: { type: { type: "string", const: "insert" }, after: { type: ["string", "null"] } } },
      { type: "object", required: ["type", "blockId", "ifHash"], additionalProperties: false, properties: { type: { type: "string", const: "replace" }, blockId: { type: "string" }, ifHash: { type: "string" } } },
    ] } },
  } },
  { name: "commit_document_edit", description: "Save the completed commentary Markdown message for editId through the guarded document writer. Do not repeat the body in tool arguments. Read the returned live block IDs/hashes before the next edit. Success is durable; stopping keeps saved edits.", inputSchema: { type: "object", properties: { editId: { type: "string" } }, required: ["editId"], additionalProperties: false } },
  { name: "edit_document", description: "Immediately DELETE one block. Inserts and replacements MUST use begin_document_edit, a single commentary Markdown message, then commit_document_edit. Requires ifHash from read_document; success is durable.", inputSchema: { type: "object", properties: { operation: { type: "object", properties: { type: { type: "string", const: "delete" }, blockId: { type: "string" }, ifHash: { type: "string" } }, required: ["type", "blockId", "ifHash"], additionalProperties: false } }, required: ["operation"], additionalProperties: false } },
];
