import type { BoardEdge, BoardFrame } from "../domain/board";
import type { SourceLink } from "../domain/board-compose";
export type { RefreshOutcome } from "../domain/board-refresh";
export type { ComposeGenre, ComposeOutcome, ComposeRequest, SourceState, SourceStatus } from "../domain/board-compose";
export type { BoardAssistAction, BoardAssistRequest, BoardAssistResult } from "../domain/board-agent";

export type BoardMetadata = { id: string; title: string; path: string; revision: number };
/** Readable projection stored beside the space's documents; Yjs state stays authoritative. */
export type BoardProjection = {
  version: 1;
  id: string;
  title: string;
  cards: Array<{ id: string; text: string; kind: string; status: string; color: string; author: string; x: number; y: number; w: number; h: number; frameId?: string }>;
  frames: BoardFrame[];
  edges: BoardEdge[];
  links: SourceLink[];
};
export type BoardSyncSnapshot = { state: string; vector: string; revision: number; board: BoardMetadata };

export interface BoardPort {
  list(): Promise<BoardMetadata[]>;
  create(title: string): Promise<BoardMetadata>;
  read(id: string): Promise<BoardSyncSnapshot>;
  sync(id: string, update: string, vector: string): Promise<BoardSyncSnapshot>;
  /** Plain view of the durable board, for server-side readers such as the assistant. */
  projection(id: string): Promise<BoardProjection>;
  /** Server-side write of source links after a compose; links never enter the person's undo history. */
  addLinks(id: string, links: SourceLink[]): Promise<BoardSyncSnapshot>;
  removeLinks(id: string, linkIds: string[]): Promise<BoardSyncSnapshot>;
}
