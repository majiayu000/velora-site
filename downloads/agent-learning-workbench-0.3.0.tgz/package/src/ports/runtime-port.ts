import type { DocumentMetadata, DocumentSnapshot, RuntimeHealth, RuntimeRequest, RuntimeResult } from "../domain/types";
import type { BlockOperation, CollaborationSnapshot, DocumentEditEvent } from "./collaboration-port";
import type { StructuredTask } from "../domain/board-agent";

export type RuntimeDocument = Pick<CollaborationSnapshot, "revision" | "blocks"> & { document?: DocumentSnapshot };

export type RuntimeCallbacks = {
  onProgress: (message: string) => void;
  onDelta: (delta: string) => void;
  onEdit?: (event: DocumentEditEvent) => void;
  document?: {
    read(): Promise<RuntimeDocument>;
    apply(operation: BlockOperation): Promise<RuntimeDocument & { insertedBlockIds: string[] }>;
  };
  workspace?: {
    open(documentId: string): Promise<RuntimeDocument>;
    create(document: DocumentMetadata, body: string): Promise<RuntimeDocument>;
    update(title: string, summary: string): Promise<RuntimeDocument>;
  };
};

export interface RuntimePort {
  readonly available: boolean;
  health(): Promise<RuntimeHealth>;
  run(request: RuntimeRequest, callbacks: RuntimeCallbacks, signal: AbortSignal): Promise<RuntimeResult>;
  /** One-shot task with no tools that must return JSON matching `task.schema` (used by the board assistant). */
  structured?(task: StructuredTask, signal: AbortSignal): Promise<unknown>;
  close(): void;
}
