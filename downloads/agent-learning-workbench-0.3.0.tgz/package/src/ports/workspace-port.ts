import type { BoardRegistration, DocumentMetadata, DocumentSnapshot, LearnManifest, SearchResult, StructureMutationResult, StructureOperation } from "../domain/types";

export interface WorkspacePort {
  readonly site: LearnManifest["site"];
  readonly manifestHash: string;
  readonly documentRoots: string[];
  initialize(): Promise<void>;
  listDocuments(): DocumentMetadata[];
  getWatchPaths(): string[];
  getDocument(id: string): Promise<DocumentSnapshot>;
  saveDocument(id: string, body: string, expectedHash: string): Promise<DocumentSnapshot>;
  applyStructure(operations: StructureOperation[], expectedManifestHash: string): Promise<StructureMutationResult>;
  searchDocuments(query: string, limit?: number): Promise<SearchResult[]>;
  fingerprintDocument(relativePath: string): Promise<string>;
  listBoards?(): BoardRegistration[];
  /** Adds or retitles a board in the manifest; returns whether the manifest changed. */
  registerBoard?(board: BoardRegistration): Promise<{ manifestHash: string; changed: boolean; changedPaths: string[] }>;
}
