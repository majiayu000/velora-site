import { promises as fs } from "node:fs";
import path from "node:path";
import { LearnError } from "../domain/errors";

export type CommandRuntimeSettings = { adapter: string; command: string; args?: string[] };
/** A model API called directly. Only the key's name is stored; the key lives in the keychain or an environment variable. */
export type DirectRuntimeSettings = { adapter: "direct-api"; protocol: "openai-compatible" | "anthropic"; baseUrl: string; model: string; keyRef: string };
export type RuntimeSettings = CommandRuntimeSettings | DirectRuntimeSettings;
export type LearnConfig = {
  version: 1;
  manifest: string;
  documentSizeLimitBytes: number;
  runtime: RuntimeSettings;
};

export const isDirectRuntime = (runtime: RuntimeSettings): runtime is DirectRuntimeSettings => runtime.adapter === "direct-api";

/** Normalises runtime settings from the config file or the settings form; throws INVALID_CONFIG with a readable reason. */
export function validateRuntimeSettings(value: unknown): RuntimeSettings {
  const invalid = (message: string) => new LearnError("INVALID_CONFIG", message, 422);
  if (!value || typeof value !== "object" || Array.isArray(value)) throw invalid("请选择 Agent。");
  const runtime = value as Record<string, unknown>;
  if (typeof runtime.adapter !== "string" || !runtime.adapter) throw invalid("请选择 Agent。");
  if (runtime.adapter === "direct-api") {
    if (["key", "apiKey", "api_key", "token", "secret"].some(name => name in runtime)) throw invalid("不要把 Key 写进配置；只填写 Key 的名称（keyRef），Key 本身存在钥匙串或环境变量里。");
    if (runtime.protocol !== "openai-compatible" && runtime.protocol !== "anthropic") throw invalid("协议只能是 OpenAI 兼容或 Anthropic。");
    let url: URL;
    try { url = new URL(String(runtime.baseUrl ?? "")); } catch { throw invalid("Base URL 不是有效地址。"); }
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw invalid("Base URL 必须是不含账号、查询参数的 http(s) 地址。");
    if (typeof runtime.model !== "string" || !runtime.model.trim() || runtime.model.length > 200) throw invalid("请填写模型名称。");
    if (typeof runtime.keyRef !== "string" || !/^[A-Za-z0-9_-]{1,64}$/.test(runtime.keyRef)) throw invalid("Key 名称只能包含字母、数字、下划线和连字符。");
    return { adapter: "direct-api", protocol: runtime.protocol, baseUrl: url.href.replace(/\/+$/, ""), model: runtime.model.trim(), keyRef: runtime.keyRef };
  }
  if (typeof runtime.command !== "string" || !runtime.command.trim()) throw invalid("请选择 Agent 并填写有效的程序路径。");
  if (runtime.args !== undefined && (!Array.isArray(runtime.args) || runtime.args.some(arg => typeof arg !== "string"))) throw invalid("args 必须是字符串数组。");
  return { adapter: runtime.adapter, command: runtime.command.trim(), ...(runtime.args ? { args: runtime.args as string[] } : {}) };
}

export async function readLearnConfig(repositoryRoot: string): Promise<{ config: LearnConfig; configPath: string; manifestPath: string }> {
  const root = await fs.realpath(repositoryRoot);
  const configPath = path.join(root, "learn.config.json");
  let value: unknown;
  try { value = JSON.parse(await fs.readFile(configPath, "utf8")); }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") {
      throw new LearnError("WORKSPACE_NOT_INITIALIZED", "这个文件夹尚未创建学习空间，请通过“打开学习空间”添加。", 409);
    }
    throw new LearnError("INVALID_CONFIG", "学习空间配置无法读取或格式损坏，请检查 learn.config.json。", 422, {
      cause: error instanceof Error ? error.message : String(error),
    });
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new LearnError("INVALID_CONFIG", "learn.config.json must be an object", 500);
  const config = value as Partial<LearnConfig>;
  if (
    config.version !== 1 || typeof config.manifest !== "string" || !Number.isInteger(config.documentSizeLimitBytes) || Number(config.documentSizeLimitBytes) < 1 || Number(config.documentSizeLimitBytes) > 10 * 1024 * 1024 ||
    !config.runtime
  ) throw new LearnError("INVALID_CONFIG", "learn.config.json does not satisfy the v1 contract", 500);
  try { config.runtime = validateRuntimeSettings(config.runtime); }
  catch (error) { throw new LearnError("INVALID_CONFIG", `learn.config.json does not satisfy the v1 contract: ${error instanceof Error ? error.message : String(error)}`, 500); }
  if (path.isAbsolute(config.manifest) || config.manifest.includes("\\") || config.manifest.split("/").some((part) => !part || part === "." || part === "..") || !config.manifest.endsWith(".json")) {
    throw new LearnError("INVALID_CONFIG", "manifest must be a normalized repository-relative JSON path", 500);
  }
  const manifestPath = path.resolve(root, config.manifest);
  const relative = path.relative(root, manifestPath);
  if (relative.startsWith("..") || path.isAbsolute(relative)) throw new LearnError("PATH_ESCAPE", "manifest escapes repository root", 500);
  return { config: config as LearnConfig, configPath, manifestPath };
}
