import type { IncomingMessage, ServerResponse } from "node:http";
import type { BoardAssistant } from "../application/board-assistant";
import type { BoardComposer } from "../application/board-composer";
import type { BoardSources } from "../application/board-sources";
import type { BoardPort } from "../ports/board-port";
import { readJson, sendJson } from "./http-json";

/**
 * Space-scoped whiteboard routes. Returns false when the route is not a board route.
 *   GET  /boards                       list boards
 *   POST /boards {title}               create a board
 *   GET  /boards/:id/collaboration     full state
 *   POST /boards/:id/collaboration     {update, vector} → merged diff for the caller
 *   POST /boards/:id/assist            {action, cardIds, instruction?, strategy?} → AI suggestions
 *   POST /boards/:id/compose           {cardIds, order?, genre, instruction?, title?} → new document with source links
 *   GET  /boards/:id/sources           status of every source link (fresh / card-changed / ...)
 *   POST /boards/:id/links/:link/refresh          rewrite the paragraph from its updated cards (or propose, if hand-edited)
 *   POST /boards/:id/links/:link/apply            {markdown, baseHash} accept a reviewed proposal
 *   POST /boards/:id/links/:link/keep             keep the paragraph; current cards become the baseline
 *   POST /boards/:id/links/:link/relink           {blockId} point a broken link at another paragraph
 *   POST /boards/:id/links/:link/remove-paragraph {baseHash} delete a paragraph whose cards were deleted
 *   GET  /boards/:id/links/:link/paragraphs       paragraphs of the linked document
 *   DELETE /boards/:id/links/:link                unlink
 */
export async function handleBoardRoute(route: string, method: string, request: IncomingMessage, response: ServerResponse, boards: BoardPort, assistant?: BoardAssistant, composer?: BoardComposer, sources?: BoardSources): Promise<boolean> {
  if (route === "/boards" && method === "GET") {
    sendJson(response, 200, { boards: await boards.list() });
    return true;
  }
  if (route === "/boards" && method === "POST") {
    const body = await readJson(request);
    sendJson(response, 201, { board: await boards.create(typeof body.title === "string" ? body.title : "") });
    return true;
  }
  const assist = route.match(/^\/boards\/([^/]+)\/assist$/);
  if (assist && method === "POST" && assistant) {
    const body = await readJson(request);
    // A closed connection (the person cancelled or left) stops the model call.
    const controller = new AbortController();
    response.once("close", () => { if (!response.writableEnded) controller.abort(); });
    sendJson(response, 200, await assistant.assist(decodeURIComponent(assist[1]!), body, controller.signal));
    return true;
  }
  const compose = route.match(/^\/boards\/([^/]+)\/compose$/);
  if (compose && method === "POST" && composer) {
    const body = await readJson(request);
    const controller = new AbortController();
    response.once("close", () => { if (!response.writableEnded) controller.abort(); });
    sendJson(response, 201, await composer.compose(decodeURIComponent(compose[1]!), body, controller.signal));
    return true;
  }
  const list = route.match(/^\/boards\/([^/]+)\/sources$/);
  if (list && method === "GET" && sources) {
    sendJson(response, 200, { sources: await sources.list(decodeURIComponent(list[1]!)) });
    return true;
  }
  const link = route.match(/^\/boards\/([^/]+)\/links\/(l_[a-f0-9-]{1,40})(?:\/([a-z-]+))?$/);
  if (link && sources) {
    const [boardId, linkId, action] = [decodeURIComponent(link[1]!), link[2]!, link[3]];
    if (method === "DELETE" && !action) { await sources.unlink(boardId, linkId); sendJson(response, 200, { ok: true }); return true; }
    if (method === "GET" && action === "paragraphs") { sendJson(response, 200, await sources.paragraphs(boardId, linkId)); return true; }
    if (method === "POST" && action) {
      const body = await readJson(request);
      if (action === "refresh") {
        const controller = new AbortController();
        response.once("close", () => { if (!response.writableEnded) controller.abort(); });
        sendJson(response, 200, await sources.refresh(boardId, linkId, body, controller.signal)); return true;
      }
      if (action === "apply") { sendJson(response, 200, await sources.apply(boardId, linkId, body)); return true; }
      if (action === "keep") { sendJson(response, 200, await sources.keep(boardId, linkId)); return true; }
      if (action === "relink") { sendJson(response, 200, await sources.relink(boardId, linkId, body)); return true; }
      if (action === "remove-paragraph") { await sources.removeParagraph(boardId, linkId, body); sendJson(response, 200, { ok: true }); return true; }
    }
  }
  const match = route.match(/^\/boards\/([^/]+)\/collaboration$/);
  if (!match) return false;
  const id = decodeURIComponent(match[1]!);
  if (method === "GET") {
    sendJson(response, 200, await boards.read(id));
    return true;
  }
  if (method === "POST") {
    const body = await readJson(request, 13 * 1024 * 1024);
    sendJson(response, 200, await boards.sync(id, body.update as string, body.vector as string));
    return true;
  }
  return false;
}
