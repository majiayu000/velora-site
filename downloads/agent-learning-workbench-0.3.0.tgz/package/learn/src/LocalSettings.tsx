import { useEffect, useRef, useState } from "react";
import { isDevelopmentWorkspace, useSpaceApi, type RuntimeConfig } from "./api";
import type { Workspace } from "./types";

export function LocalSettings({ workspace, root, busy = false, onRuntimeChange, onClose }: {
  workspace: Workspace;
  root?: string;
  busy?: boolean;
  onRuntimeChange: (runtime: Workspace["runtime"]) => void;
  onClose: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const api = useSpaceApi();
  const [runtime, setRuntime] = useState<RuntimeConfig>();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  useEffect(() => { dialog.current?.showModal(); }, []);
  useEffect(() => {
    if (!isDevelopmentWorkspace) return;
    let cancelled = false;
    api.settings().then(value => { if (!cancelled) setRuntime(value.runtime); })
      .catch(reason => { if (!cancelled) setError(reason instanceof Error ? reason.message : String(reason)); });
    return () => { cancelled = true; };
  }, [api]);
  const direct = runtime?.adapter === "direct-api";
  const host = (() => { try { return runtime?.baseUrl ? new URL(runtime.baseUrl).host : ""; } catch { return ""; } })();
  async function test() {
    if (!runtime || saving || busy) return;
    setSaving(true); setError(""); setMessage("");
    try {
      const { health } = await api.testSettings(runtime);
      if (health.available) setMessage(`连接成功：${health.version ?? health.adapter}`); else setError(health.message ?? "连接失败");
    } catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)); }
    finally { setSaving(false); }
  }
  async function save() {
    if (!runtime || saving || busy) return;
    setSaving(true); setError(""); setMessage("");
    try {
      const result = await api.saveSettings(runtime);
      setRuntime(result.runtime);
      onRuntimeChange(result.health);
      setMessage("设置已保存，新的 Agent 已生效。");
    } catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)); }
    finally { setSaving(false); }
  }
  const spaceDetails = <dl className="settings-details">
      <div><dt>运行方式</dt><dd>{isDevelopmentWorkspace ? "本地工作台" : "静态只读"}</dd></div>
      <div><dt>学习空间</dt><dd>{workspace.site.title}</dd></div>
      {root && <div><dt>文档位置</dt><dd><code>{root}</code></dd></div>}
      <div><dt>文档数量</dt><dd>{workspace.documents.length} 篇</dd></div>
      {isDevelopmentWorkspace && <div><dt>Agent</dt><dd>{workspace.runtime.adapter} · {workspace.runtime.available ? "可用" : "暂不可用"}</dd></div>}
    </dl>;
  return <dialog ref={dialog} className="local-settings" aria-labelledby="local-settings-title" onClose={onClose}>
    <header><h2 id="local-settings-title">{isDevelopmentWorkspace ? "本地设置" : "空间信息"}</h2><button className="icon-button" aria-label="关闭设置" onClick={() => dialog.current?.close()}>×</button></header>
    <p className="settings-description">{isDevelopmentWorkspace ? "工作台在这台电脑上运行，无需注册或登录观澜。" : "这是导出的只读学习站点，无需登录即可阅读。"}</p>

    {isDevelopmentWorkspace && <section className="settings-agent" aria-labelledby="settings-agent-title">
      <h3 id="settings-agent-title">AI 助手</h3>
      <p className="settings-runtime-status">当前 Agent：{workspace.runtime.adapter} · {workspace.runtime.available ? "可用" : "暂不可用"}</p>
      {!runtime && !error && <p role="status">正在读取设置…</p>}
      {runtime && <form onSubmit={event => { event.preventDefault(); void save(); }}>
        <fieldset disabled={saving || busy}>
          <label htmlFor="settings-runtime">Agent Runtime</label>
          <select id="settings-runtime" value={runtime.adapter} onChange={event => {
            const adapter = event.target.value;
            setRuntime(adapter === "direct-api" ? { adapter, protocol: "openai-compatible", baseUrl: "http://127.0.0.1:11434/v1", model: "", keyRef: "default" } : { adapter, command: adapter === "claude-code" ? "claude" : "codex" });
            setError(""); setMessage("");
          }}>
            <option value="codex-app-server">Codex</option>
            <option value="claude-code">Claude Code</option>
            <option value="direct-api">直连模型 API</option>
            {!["codex-app-server", "claude-code", "direct-api"].includes(runtime.adapter) && <option value={runtime.adapter}>自定义 Runtime（{runtime.adapter}）</option>}
          </select>
          {direct ? <>
            <label htmlFor="settings-protocol">协议</label>
            <select id="settings-protocol" value={runtime.protocol} onChange={event => { setRuntime({ ...runtime, protocol: event.target.value as RuntimeConfig["protocol"] }); setMessage(""); }}>
              <option value="openai-compatible">OpenAI 兼容（Chat Completions）</option>
              <option value="anthropic">Anthropic Messages</option>
            </select>
            <label htmlFor="settings-base-url">Base URL</label>
            <input id="settings-base-url" value={runtime.baseUrl ?? ""} required spellCheck={false} onChange={event => { setRuntime({ ...runtime, baseUrl: event.target.value }); setMessage(""); }} />
            <label htmlFor="settings-model">模型</label>
            <input id="settings-model" value={runtime.model ?? ""} required spellCheck={false} onChange={event => { setRuntime({ ...runtime, model: event.target.value }); setMessage(""); }} />
            <label htmlFor="settings-key-ref">Key 名称</label>
            <input id="settings-key-ref" value={runtime.keyRef ?? ""} required spellCheck={false} pattern="[A-Za-z0-9_-]{1,64}" onChange={event => { setRuntime({ ...runtime, keyRef: event.target.value }); setMessage(""); }} />
            <p className="settings-hint">Key 本身不进配置。在终端运行 <code>security add-generic-password -s velora -a {runtime.keyRef || "名称"} -w</code> 存入钥匙串，或设置环境变量 <code>VELORA_KEY_{(runtime.keyRef || "名称").toUpperCase().replace(/[^A-Z0-9]/g, "_")}</code>。</p>
            {host && <p className="settings-hint" role="note">你的文档和白板内容会发送到 {host}。</p>}
            <button type="button" onClick={() => void test()} disabled={!runtime.baseUrl || !runtime.model || !runtime.keyRef}>测试连接</button>
          </> : <>
            <label htmlFor="settings-command">程序路径</label>
            <input id="settings-command" value={runtime.command ?? ""} required spellCheck={false} onChange={event => { setRuntime({ ...runtime, command: event.target.value }); setMessage(""); }} />
            <p className="settings-hint">填写命令名称或可执行文件的完整路径。</p>
          </>}
          <button className="primary-button" type="submit" disabled={direct ? !runtime.baseUrl || !runtime.model || !runtime.keyRef : !runtime.command?.trim()}>{saving ? "正在检测并保存…" : "保存并检测"}</button>
        </fieldset>
      </form>}
      {busy && <p role="status">Agent 正在运行，结束或停止当前回合后可切换。</p>}
      {error && <p className="settings-error" role="alert">{error}</p>}
      {message && <p className="settings-success" role="status">{message}</p>}
      <div className="settings-agent-note">
        <p>设置保存在当前学习空间的 learn.config.json，立即生效。使用所选程序已有的模型和登录配置，相关上下文会发送给它配置的模型服务。检测确认程序和登录信息，模型服务权限以实际调用为准。</p>
        {runtime?.adapter === "claude-code" && <p>Claude 支持问答和文档修改提案；修改内容生成完成后由工作台保存。请先在终端安装 Claude Code 并运行 claude auth login。</p>}
        {runtime?.adapter === "codex-app-server" && <p>Codex 支持问答和逐段实时编辑。请先在终端安装 Codex 并运行 codex login。</p>}
        {direct && <p>直连模式由观澜自己调用模型并运行工具，支持问答、逐段实时编辑和白板 AI。模型必须支持工具调用和流式输出。</p>}
        {!workspace.runtime.available && <p role="status">{workspace.runtime.message || "当前 Agent 不可用，请选择程序后重新检测。"} 阅读、手工编辑和导出仍可使用。</p>}
      </div>
    </section>}
    {isDevelopmentWorkspace ? <details className="settings-space-info"><summary>学习空间信息</summary>{spaceDetails}</details> : spaceDetails}
  </dialog>;
}
