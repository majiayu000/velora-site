// Hash routes of the workbench: #/space/:spaceId/(doc/:id | board/:id | map | history | documents | new).
import { isDevelopmentWorkspace } from "./api";
import type { ArtifactRoute as Route } from "./ArtifactPanel";

export function spaceIdFromHash(): string | undefined {
  const match = window.location.hash.match(/^#\/space\/([^/?]+)/);
  return match ? decodeURIComponent(match[1]!) : undefined;
}

export function routeFromHash(spaceId?: string): Route {
  const escapedSpaceId = spaceId?.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const scoped = escapedSpaceId ? window.location.hash.match(new RegExp(`^#/space/${escapedSpaceId}/doc/([^?]+)`)) : null;
  const legacy = window.location.hash.match(/^#\/doc\/([^?]+)/);
  const match = scoped ?? legacy;
  const params = new URLSearchParams(window.location.hash.split("?")[1] ?? "");
  const base = spaceId ? `#/space/${encodeURIComponent(spaceId)}` : "#";
  const routePath = window.location.hash.split("?")[0];
  const board = escapedSpaceId && isDevelopmentWorkspace ? routePath.match(new RegExp(`^#/space/${escapedSpaceId}/board/(board-[a-f0-9]{8})$`)) : null;
  const line = Number(params.get("line"));
  return {
    documentId: match ? decodeURIComponent(match[1]) : undefined,
    conversationId: params.get("conversation") || undefined,
    edit: isDevelopmentWorkspace && !!match,
    rich: isDevelopmentWorkspace && !!match && (params.get("edit") !== "1" || params.get("mode") === "page"),
    boardId: board ? board[1] : undefined,
    home: isDevelopmentWorkspace && !match && !board && !/\/(map|history|documents)$/.test(routePath),
    index: /\/documents$/.test(routePath) || (!isDevelopmentWorkspace && !match && !/\/(map|history)$/.test(routePath)),
    map: routePath === `${base}/map` || (!spaceId && routePath === "#/map"),
    history: routePath === `${base}/history` || (!spaceId && routePath === "#/history"),
    ask: params.get("ask") || undefined,
    evidencePath: params.get("path") || undefined,
    evidenceLine: Number.isInteger(line) && line > 0 ? line : undefined,
  };
}
