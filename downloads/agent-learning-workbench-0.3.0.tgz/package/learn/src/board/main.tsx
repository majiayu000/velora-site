import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "@xyflow/react/dist/style.css";
import "./board.css";
import "./board-page.css";
import { BoardApp } from "./BoardApp";

createRoot(document.getElementById("board")!).render(<StrictMode><BoardApp /></StrictMode>);
