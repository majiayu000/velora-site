import { createContext, memo, useContext, useEffect, useRef, useState } from "react";
import { Handle, Position, type Node, type NodeProps } from "@xyflow/react";
import type * as Y from "yjs";
import { acceptDrafts, discardDrafts, setCardText, type CardColor } from "../../../src/adapters/collaboration/board-model";

export const BoardDocContext = createContext<Y.Doc | null>(null);

export type CardData = { text: string; color: CardColor; status: "live" | "draft"; author: "human" | "ai"; order?: number; frameTitle?: string };
export type FrameData = { title: string };
export type GhostData = { text?: string; title?: string };
export type CardNodeType = Node<CardData, "card">;
export type FrameNodeType = Node<FrameData, "frame">;
export type GhostNodeType = Node<GhostData, "ghost">;
export type BoardNode = CardNodeType | FrameNodeType | GhostNodeType;

export const CardNode = memo(function CardNode({ id, data, selected }: NodeProps<CardNodeType>) {
  const doc = useContext(BoardDocContext)!;
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(data.text);
  const area = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { if (!editing) setDraft(data.text); }, [data.text, editing]);
  useEffect(() => { if (editing) area.current?.focus(); }, [editing]);
  const commit = () => { setEditing(false); setCardText(doc, id, draft); };
  return <div className={`board-card c-${data.color}${data.status === "draft" ? " is-draft" : ""}${selected ? " is-selected" : ""}`}
    onDoubleClick={event => { event.stopPropagation(); if (data.status === "live") setEditing(true); }}>
    <Handle type="target" position={Position.Left} />
    {data.order !== undefined && <span className="board-order">{data.order}</span>}
    {editing
      ? <textarea ref={area} className="nodrag nowheel" value={draft} onChange={e => setDraft(e.target.value)} onBlur={commit}
          onKeyDown={e => { if (e.key === "Escape") { setDraft(data.text); setEditing(false); } if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) commit(); e.stopPropagation(); }} />
      : <p>{data.text || <span className="board-muted">双击编辑</span>}</p>}
    {data.status === "draft" && <div className="board-draft-actions nodrag">
      <span>AI 建议</span>
      <button onClick={() => acceptDrafts(doc, [id])}>✓ 接受</button>
      <button onClick={() => discardDrafts(doc, [id])}>✕</button>
    </div>}
    <Handle type="source" position={Position.Right} />
  </div>;
});

export const FrameNode = memo(function FrameNode({ data, selected }: NodeProps<FrameNodeType>) {
  return <div className={`board-frame${selected ? " is-selected" : ""}`}><b>{data.title}</b></div>;
});

export const GhostNode = memo(function GhostNode({ data }: NodeProps<GhostNodeType>) {
  return data.title !== undefined
    ? <div className="board-ghost-frame"><b>{data.title}</b></div>
    : <div className="board-ghost-card"><p>{data.text}</p></div>;
});

export const nodeTypes = { card: CardNode, frame: FrameNode, ghost: GhostNode };
