import * as Y from "yjs";
import { REMOTE_ORIGIN } from "../../../src/adapters/collaboration/board-model";

/**
 * Two in-page replicas joined by a simulated network. Offline edits queue on each side and
 * reconcile through state vectors on reconnect, the same exchange the loopback server uses.
 */
export class SimulatedLink {
  private online = true;
  private readonly listeners = new Set<(online: boolean) => void>();

  private readonly toB = (update: Uint8Array, origin: unknown) => this.forward(update, origin, this.b);
  private readonly toA = (update: Uint8Array, origin: unknown) => this.forward(update, origin, this.a);

  constructor(readonly a: Y.Doc, readonly b: Y.Doc) {
    a.on("update", this.toB);
    b.on("update", this.toA);
    this.reconcile();
  }

  /** Detach from both documents; a leaked link would keep forwarding while "offline". */
  destroy(): void {
    this.a.off("update", this.toB);
    this.b.off("update", this.toA);
    this.listeners.clear();
  }

  private forward(update: Uint8Array, origin: unknown, target: Y.Doc): void {
    if (!this.online || origin === REMOTE_ORIGIN) return;
    Y.applyUpdate(target, update, REMOTE_ORIGIN);
  }

  private reconcile(): void {
    Y.applyUpdate(this.b, Y.encodeStateAsUpdate(this.a, Y.encodeStateVector(this.b)), REMOTE_ORIGIN);
    Y.applyUpdate(this.a, Y.encodeStateAsUpdate(this.b, Y.encodeStateVector(this.a)), REMOTE_ORIGIN);
  }

  get isOnline(): boolean { return this.online; }

  setOnline(online: boolean): void {
    if (online === this.online) return;
    this.online = online;
    if (online) this.reconcile();
    for (const listener of this.listeners) listener(online);
  }

  subscribe(listener: (online: boolean) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
}
