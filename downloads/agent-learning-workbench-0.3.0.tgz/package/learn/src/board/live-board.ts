import * as Y from "yjs";
import { IndexeddbPersistence } from "y-indexeddb";
import { REMOTE_ORIGIN } from "../../../src/adapters/collaboration/board-model";
import type { BoardMetadata } from "../../../src/ports/board-port";
import { subscribeToEvents, type SpaceApi } from "../api";

const encode = (value: Uint8Array) => { let result = ""; for (const byte of value) result += String.fromCharCode(byte); return btoa(result); };
const decode = (value: string) => Uint8Array.from(atob(value), c => c.charCodeAt(0));

export type LiveBoardStatus = "connecting" | "syncing" | "saved" | "offline";

/**
 * A board replica bound to the loopback server. Local edits are kept in IndexedDB first, then
 * pushed as a state-vector diff; `board.changed` events and a slow poll pull other clients' edits.
 */
export class LiveBoard {
  readonly persistence: IndexeddbPersistence;
  status: LiveBoardStatus = "connecting";
  error = "";
  meta?: BoardMetadata;
  private vector?: Uint8Array;
  private listeners = new Set<() => void>();
  private timer?: ReturnType<typeof setTimeout>;
  private poll?: ReturnType<typeof setInterval>;
  private unsubscribe?: () => void;
  private busy = false;
  private closed = false;
  private generation = 0;
  private flushed = 0;

  constructor(readonly api: SpaceApi, readonly id: string, readonly doc = new Y.Doc()) {
    this.persistence = new IndexeddbPersistence(`learn:${api.spaceId}:board:${id}`, doc);
  }

  subscribe(listener: () => void): () => void { this.listeners.add(listener); return () => { this.listeners.delete(listener); }; }
  private emit(): void { for (const listener of this.listeners) listener(); }

  private updated = (_update: Uint8Array, origin: unknown) => {
    if (origin === REMOTE_ORIGIN || origin === this.persistence) return;
    this.generation += 1;
    this.status = "syncing"; this.emit();
    this.schedule(60);
  };

  /** Resolves once the server copy has been merged; local IndexedDB edits are pushed in the same round. */
  async start(): Promise<void> {
    await this.persistence.whenSynced;
    if (this.closed) return;
    const snapshot = await this.api.boardCollaboration(this.id);
    if (this.closed) return;
    Y.applyUpdate(this.doc, decode(snapshot.state), REMOTE_ORIGIN);
    this.vector = decode(snapshot.vector);
    this.meta = snapshot.board;
    this.doc.on("update", this.updated);
    this.unsubscribe = subscribeToEvents(this.api.spaceId, 0, event => {
      if (event.type === "board.changed" && event.payload.boardId === this.id) this.schedule(0);
    }, connected => { if (connected) this.schedule(0); });
    this.poll = setInterval(() => this.schedule(0), 3000);
    this.generation += 1; // push anything IndexedDB held that the server lacks
    await this.flush();
  }

  private schedule(delay: number): void {
    if (this.closed || this.timer) return;
    this.timer = setTimeout(() => { this.timer = undefined; void this.flush(); }, delay);
  }

  async flush(): Promise<void> {
    if (this.closed || this.busy || !this.vector) return;
    this.busy = true;
    const generation = this.generation;
    try {
      const snapshot = await this.api.syncBoard(this.id, {
        update: encode(Y.encodeStateAsUpdate(this.doc, this.vector)),
        vector: encode(Y.encodeStateVector(this.doc)),
      });
      if (this.closed) return;
      Y.applyUpdate(this.doc, decode(snapshot.state), REMOTE_ORIGIN);
      this.vector = decode(snapshot.vector);
      this.meta = snapshot.board;
      this.flushed = Math.max(this.flushed, generation);
      this.error = "";
      this.status = this.generation === this.flushed ? "saved" : "syncing";
    } catch (error) {
      this.error = error instanceof Error ? error.message : String(error);
      this.status = "offline";
      this.schedule(2000);
    } finally {
      this.busy = false;
      this.emit();
      if (this.generation !== this.flushed && this.status !== "offline") this.schedule(60);
    }
  }

  close(): void {
    this.closed = true;
    clearTimeout(this.timer); clearInterval(this.poll); this.unsubscribe?.();
    this.doc.off("update", this.updated);
    void this.persistence.destroy();
  }
}
