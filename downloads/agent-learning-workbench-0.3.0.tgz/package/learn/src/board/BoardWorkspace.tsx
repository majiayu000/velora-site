import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import type * as Y from "yjs";
import {
  acceptDrafts, addCard, addDraftCards, addDraftGroups, addEdge, addFrame, applyArrange, arrangeLayout, boundsOf, mergeArrange, readingOrder,
  snapshot, turnOrigin, turnUndoManager, type ArrangePlan, type ArrangeStrategy, type Point, type TurnOrigin,
} from "../../../src/adapters/collaboration/board-model";
import type { BoardAssistRequest, BoardAssistResult, ComposeGenre, ComposeOutcome, ComposeRequest, SourceStatus } from "../../../src/ports/board-port";
import { BoardCanvas, useBoardSnapshot, type DragStats } from "./BoardCanvas";
import { SourcePanel, type SourceActions } from "./SourcePanel";
import { MarkdownView } from "../MarkdownView";

export function seedDemoBoard(doc: Y.Doc): void {
  const open = addFrame(doc, "开头", { x: 0, y: 0, w: 240, h: 170 });
  const proof = addFrame(doc, "证据", { x: 300, y: 0, w: 240, h: 330 });
  const q = addCard(doc, { text: "为什么越堵越要变道？", x: 28, y: 44, frameId: open });
  const sim = addCard(doc, { text: "模拟：随机变道 vs 不变道，通行时间对比", x: 328, y: 44, color: "b", frameId: proof });
  const clip = addCard(doc, { text: "真实行车记录仪片段 3 段", x: 328, y: 200, color: "b", frameId: proof });
  addCard(doc, { text: "结尾：下期讲匝道", x: 600, y: 40, color: "g" });
  addCard(doc, { text: "观众常见误解：变道一定更快", x: 600, y: 200, color: "p" });
  addEdge(doc, q, sim); addEdge(doc, sim, clip);
}

type Turn = { origin: TurnOrigin; label: string; undo: Y.UndoManager; undone: boolean; draftIds?: string[] };
type Preview = { plan: ArrangePlan; baseline: Record<string, Point>; label: string };
export type BoardAssist = (request: BoardAssistRequest, signal: AbortSignal) => Promise<BoardAssistResult & { adapter: string }>;
/** Board → document through the server; only available when the page is connected to a learning space. */
export type ComposeProgress = { body: string; pending: string; finished: boolean };
export type BoardComposer = SourceActions & {
  compose(request: ComposeRequest, signal: AbortSignal): Promise<ComposeOutcome>;
  sources(): Promise<SourceStatus[]>;
  watch?(documentId: string, onUpdate: (progress: ComposeProgress) => void): () => void;
};
const GENRE_LABEL: Record<ComposeGenre, string> = { plan: "策划稿", outline: "大纲", compare: "对比", free: "自由" };
const positions = (doc: Y.Doc) => Object.fromEntries(snapshot(doc).cards.map(c => [c.id, { x: c.x, y: c.y }]));
const colourTitle: Record<string, string> = { y: "问题", b: "证据", g: "结尾", p: "误解" };

type Props = {
  doc: Y.Doc;
  undo: Y.UndoManager;
  paneTitle: string;
  /** Mode-specific controls: sync status, board picker, simulated network switch. */
  controls: ReactNode;
  /** Optional second replica rendered beside the main canvas (simulated mode). */
  secondary?: ReactNode;
  /** Real model behind the AI buttons; without it the buttons use deterministic stand-ins. */
  assistant?: BoardAssist;
  composer?: BoardComposer;
  heading?: string;
  /** Drag frame timings from the prototype; only shown on the standalone board page. */
  showDragStats?: boolean;
  /** Open a composed document in the same window instead of a new tab (workbench tab). */
  openDocument?: (documentId: string) => void;
};

export function BoardWorkspace({ doc, undo, paneTitle, controls, secondary, assistant, composer, heading = "白板原型", openDocument, showDragStats = true }: Props) {
  const board = useBoardSnapshot(doc);
  const [selection, setSelection] = useState<string[]>([]);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [preview, setPreview] = useState<Preview>();
  const [strategy, setStrategy] = useState<ArrangeStrategy>("by-group");
  const [order, setOrder] = useState<string[]>();
  const [stats, setStats] = useState<DragStats>();
  const [instruction, setInstruction] = useState("");
  const [running, setRunning] = useState<{ label: string; controller: AbortController }>();
  const [aiError, setAiError] = useState("");
  const [fitKey, setFitKey] = useState(0);
  const [material, setMaterial] = useState("");
  const [genre, setGenre] = useState<ComposeGenre>("plan");
  const [composed, setComposed] = useState<Record<string, string>>({});
  const [composeNote, setComposeNote] = useState("");
  const [writing, setWriting] = useState<{ documentId: string; title: string } & ComposeProgress>();

  // While a compose turn writes, follow it beside the canvas; when its links are recorded, refresh the source panel.
  useEffect(() => {
    if (!writing?.documentId || !composer?.watch) return;
    const { documentId } = writing;
    return composer.watch(documentId, progress => {
      setWriting(current => current?.documentId === documentId ? { ...current, ...progress } : current);
      if (progress.finished) {
        setComposeNote(`已写完「${writing.title}」，每段都已记下来源卡片`);
        void composer.sources().then(setSources, () => undefined);
      }
    });
  }, [writing?.documentId, composer]);
  const [sources, setSources] = useState<SourceStatus[]>([]);

  // Source states are computed by the server on read; refresh shortly after the board settles.
  useEffect(() => {
    if (!composer) return;
    const timer = setTimeout(() => { composer.sources().then(setSources, () => undefined); }, 600);
    return () => clearTimeout(timer);
  }, [composer, board]);
  // Paragraphs can change in the document while the board sits still; re-read link states every few seconds.
  useEffect(() => {
    if (!composer) return;
    const timer = setInterval(() => { if (document.visibilityState === "visible") composer.sources().then(setSources, () => undefined); }, 5000);
    return () => clearInterval(timer);
  }, [composer]);

  const startTurn = useCallback((label: string) => {
    const origin = turnOrigin(crypto.randomUUID().slice(0, 6));
    const turn: Turn = { origin, label, undo: turnUndoManager(doc, origin), undone: false };
    setTurns(prev => [turn, ...prev]);
    return turn;
  }, [doc]);

  const selectedCards = board.cards.filter(c => selection.includes(c.id));
  const liveScope = () => (selectedCards.length ? selectedCards : board.cards).filter(c => c.status === "live");

  const simulateGapFill = () => {
    const turn = startTurn(`补缺口（${selectedCards.length || "无"} 张选中）`);
    addDraftCards(doc, turn.origin, { ref: boundsOf(selectedCards), side: "bottom", align: "start" }, ["补：一个反例镜头", "补：数据来源说明", "补：结尾的悬念"]);
    setFitKey(key => key + 1);
  };

  const arrangeOrigin = () => {
    const all = boundsOf([...board.cards, ...board.frames]);
    return { x: all?.x ?? 0, y: (all?.y ?? 0) + (all?.h ?? 0) + 80 };
  };

  const simulateArrange = () => {
    const targets = liveScope();
    // Stand-in for the model's grouping: group by colour, ordered by the reading order.
    const byColour = new Map<string, string[]>();
    for (const card of targets) byColour.set(card.color, [...(byColour.get(card.color) ?? []), card.id]);
    const groups = [...byColour.entries()].map(([color, cardIds]) => ({ title: colourTitle[color] ?? color, cardIds }));
    setPreview({ plan: arrangeLayout(targets, strategy, arrangeOrigin(), groups, readingOrder(targets, board.frames, board.edges)), baseline: positions(doc), label: `整理排版（${strategy}，模拟）` });
  };

  /** Ask the real model; the result is applied here, under an AI-turn origin, so it can be undone as a turn. */
  const runAssistant = async (action: "gap-fill" | "arrange") => {
    if (!assistant) return;
    const targets = liveScope();
    const ref = boundsOf(selectedCards.length ? selectedCards : targets);
    const controller = new AbortController();
    setAiError("");
    setRunning({ label: action === "gap-fill" ? "AI 正在找缺口…" : "AI 正在想怎么排…", controller });
    try {
      const result = await assistant({ action, cardIds: targets.map(c => c.id), ...(instruction.trim() ? { instruction: instruction.trim() } : {}), strategy }, controller.signal);
      if (result.action === "gap-fill") {
        const turn = startTurn(`补缺口：${result.summary || `${result.cards.length} 张建议`}（${result.adapter}）`);
        turn.draftIds = addDraftCards(doc, turn.origin, { ref, side: result.side, align: "start" }, result.cards);
        setFitKey(key => key + 1);
      } else if (result.action === "arrange") {
        const latest = snapshot(doc);
        const live = latest.cards.filter(c => targets.some(t => t.id === c.id));
        setPreview({ plan: arrangeLayout(live, result.strategy, arrangeOrigin(), result.groups, result.order), baseline: positions(doc), label: `整理排版：${result.summary || result.strategy}（${result.adapter}）` });
      }
    } catch (error) {
      if (!controller.signal.aborted) setAiError(error instanceof Error ? error.message : String(error));
    } finally {
      setRunning(undefined);
    }
  };

  /** 倒素材: pasted ideas become grouped draft cards under one AI turn; the person accepts them one by one or all at once. */
  const runSplit = async () => {
    if (!assistant || !material.trim()) return;
    const controller = new AbortController();
    setAiError("");
    setRunning({ label: "AI 正在把素材拆成卡片…", controller });
    try {
      const result = await assistant({ action: "split", cardIds: [], material: material.trim(), ...(instruction.trim() ? { instruction: instruction.trim() } : {}) }, controller.signal);
      if (result.action !== "split") return;
      const count = result.groups.reduce((sum, g) => sum + g.cards.length, 0);
      const turn = startTurn(`倒素材：${count} 张建议，${result.groups.length} 组（${result.adapter}）`);
      turn.draftIds = addDraftGroups(doc, turn.origin, result.groups);
      setMaterial("");
      setFitKey(key => key + 1);
    } catch (error) {
      if (!controller.signal.aborted) setAiError(error instanceof Error ? error.message : String(error));
    } finally {
      setRunning(undefined);
    }
  };

  /** Compose uses the outline order when it is open, otherwise the server's reading order. */
  const runCompose = async () => {
    if (!composer) return;
    const targets = liveScope();
    const controller = new AbortController();
    setAiError("");
    setRunning({ label: `AI 正在写${GENRE_LABEL[genre]}…`, controller });
    try {
      const result = await composer.compose({ cardIds: targets.map(c => c.id), genre, ...(order ? { order } : {}), ...(instruction.trim() ? { instruction: instruction.trim() } : {}) }, controller.signal);
      setComposed(prev => ({ ...prev, [result.documentId]: result.title }));
      if (result.streaming) {
        setWriting({ documentId: result.documentId, title: result.title, body: "", pending: "", finished: false });
        setComposeNote(`正在逐段写入「${result.title}」（${result.adapter}），右侧实时显示`);
        return;
      }
      setSources(await composer.sources());
      setComposeNote(`已写成「${result.title}」：${result.sections} 段${result.inferred ? `，其中 ${result.inferred} 段来源为推断` : ""}（${result.adapter}）`);
    } catch (error) {
      if (!controller.signal.aborted) setAiError(error instanceof Error ? error.message : String(error));
    } finally {
      setRunning(undefined);
    }
  };

  const cardText = (id: string) => board.cards.find(c => c.id === id)?.text.split("\n")[0] ?? "已删除的卡片";

  const acceptArrange = () => {
    if (!preview) return;
    const turn = startTurn(preview.label);
    applyArrange(doc, turn.origin, preview.plan, mergeArrange(preview.plan, preview.baseline, positions(doc)));
    setPreview(undefined);
  };

  const orderMap = useMemo(() => order ? Object.fromEntries(order.map((id, i) => [id, i + 1])) : undefined, [order]);
  const outline = order?.map(id => board.cards.find(c => c.id === id)).filter(Boolean) ?? [];
  const moveInOutline = (index: number, delta: number) => setOrder(prev => {
    if (!prev) return prev;
    const next = [...prev]; const target = index + delta;
    if (target < 0 || target >= next.length) return prev;
    [next[index], next[target]] = [next[target], next[index]];
    return next;
  });

  return <div className="board-app">
    <header className="board-bar">
      <strong>{heading}</strong>
      <span className="board-sep" />
      <button onClick={() => undo.undo()}>撤销（人）</button>
      <button onClick={() => undo.redo()}>重做</button>
      <span className="board-sep" />
      <input className="board-instruction" value={instruction} onChange={e => setInstruction(e.target.value)} placeholder={assistant ? "给 AI 的要求（可选）" : "模拟模式：AI 为固定结果"} disabled={!assistant || !!running} aria-label="给 AI 的要求" />
      <button onClick={() => assistant ? void runAssistant("gap-fill") : simulateGapFill()} disabled={!!running}>AI 补缺口</button>
      <select value={strategy} onChange={e => setStrategy(e.target.value as ArrangeStrategy)} aria-label="排版方式">
        <option value="by-group">按组</option><option value="timeline">时间线</option><option value="grid">网格</option>
      </select>
      <button onClick={() => assistant ? void runAssistant("arrange") : simulateArrange()} disabled={!!preview || !!running}>AI 整理排版</button>
      {running && <><span className="board-warn">{running.label}</span><button onClick={() => running.controller.abort()}>取消</button></>}
      {preview && <><button className="primary" onClick={acceptArrange}>接受排版</button><button onClick={() => setPreview(undefined)}>放弃</button></>}
      <span className="board-sep" />
      <button onClick={() => setOrder(readingOrder(liveScope(), board.frames, board.edges))}>转稿顺序</button>
      {order && <button onClick={() => setOrder(undefined)}>关闭顺序</button>}
      {composer && <>
        <select value={genre} onChange={e => setGenre(e.target.value as ComposeGenre)} aria-label="体裁">
          {Object.entries(GENRE_LABEL).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
        </select>
        <button className="primary" onClick={() => void runCompose()} disabled={!!running}>转成文档</button>
      </>}
      <span className="board-sep" />
      {controls}
    </header>
    <div className="board-main">
      <aside className="board-side">
        {assistant && <section className="board-material" aria-label="倒素材">
          <h3>倒素材</h3>
          <textarea value={material} onChange={e => setMaterial(e.target.value)} rows={board.cards.length ? 3 : 6} placeholder="把想法、笔记或聊天记录贴在这里，一次可以贴很多条" aria-label="素材" disabled={!!running} />
          <button className="primary" onClick={() => void runSplit()} disabled={!material.trim() || !!running}>拆成卡片</button>
        </section>}
        <h3>AI 回合</h3>
        {aiError && <p className="board-error" role="alert">{aiError}</p>}
        {!turns.length && <p className="board-muted">还没有 AI 回合。</p>}
        {turns.map(turn => <div key={turn.origin.turnId} className="board-turn">
          <span>{turn.label}</span>
          {!turn.undone && turn.draftIds && board.cards.some(c => turn.draftIds!.includes(c.id) && c.status === "draft") && <button onClick={() => acceptDrafts(doc, turn.draftIds!.filter(id => board.cards.some(c => c.id === id && c.status === "draft")))}>全部接受</button>}
          <button disabled={turn.undone} onClick={() => { while (turn.undo.undoStack.length) turn.undo.undo(); turn.undone = true; setTurns(prev => [...prev]); }}>{turn.undone ? "已撤销" : "撤销这一轮"}</button>
        </div>)}
        {outline.length > 0 && <>
          <h3>转稿顺序（卡片链接大纲）</h3>
          <ol className="board-outline">{outline.map((card, i) => <li key={card!.id}>
            <span>{card!.text.split("\n")[0] || "（空白卡片）"}</span>
            <button onClick={() => moveInOutline(i, -1)} aria-label="上移">↑</button>
            <button onClick={() => moveInOutline(i, 1)} aria-label="下移">↓</button>
          </li>)}</ol>
        </>}
        {composer && <>
          <h3>转稿与来源</h3>
          {composeNote && <p className="board-ok" role="status">{composeNote}</p>}
          {!sources.length && <p className="board-muted">选中卡片后点「转成文档」。文档每段会记住来源卡片，改了卡片这里会标黄。</p>}
          <SourcePanel sources={sources} titles={composed} cardText={cardText} actions={composer} openDocument={openDocument} instruction={instruction.trim()} reload={async () => setSources(await composer.sources())} />
        </>}
        {showDragStats && <>
        <h3>拖动帧间隔</h3>
        {stats ? <p className="board-stats">{stats.frames} 帧 · 平均 {stats.avgMs.toFixed(1)} ms · 最长 {stats.maxMs.toFixed(1)} ms · 写入 Yjs {stats.writes} 次</p> : <p className="board-muted">拖一张卡片后显示。</p>}
        </>}
        <p className="board-muted">双击空白处加卡片；拖住卡片右侧圆点连线；拖空白处框选；Cmd+Z 只撤销你自己的操作。</p>
      </aside>
      <section className="board-pane">
        <div className="board-pane-title">{paneTitle}</div>
        <BoardCanvas doc={doc} undo={undo} preview={preview?.plan} order={orderMap} fitKey={fitKey} onSelection={setSelection} onDragStats={setStats} />
      </section>
      {secondary}
      {writing && <section className="board-pane board-writing" aria-label="正在写入的文档">
        <div className="board-pane-title">
          <span>{writing.finished ? "已写完" : "正在写入"}：{writing.title}</span>
          {composer && <a href={composer.documentHref(writing.documentId)} {...(openDocument ? { onClick: event => { event.preventDefault(); openDocument(writing.documentId); } } : { target: "_blank", rel: "noreferrer" })}>打开文档</a>}
          <button onClick={() => setWriting(undefined)} aria-label="关闭写入预览">×</button>
        </div>
        <div className="board-writing-body">
          <MarkdownView body={writing.body} />
          {writing.pending && <div className="board-writing-pending" aria-live="polite"><MarkdownView body={writing.pending} /><span className="board-caret" aria-hidden="true" /></div>}
        </div>
      </section>}
    </div>
  </div>;
}
