import { subscribeToEvents, type SpaceApi } from "../api";
import type { BoardAssist, BoardComposer } from "./BoardWorkspace";
import type { LiveBoard } from "./live-board";

/**
 * Server-backed AI and source actions for one live board, shared by board.html and the workbench tab.
 * The server reads the durable board, so local edits are pushed before every call that depends on cards.
 */
export function serverBoardActions(api: SpaceApi, live: LiveBoard, documentHref: (documentId: string) => string): { assistant: BoardAssist; composer: BoardComposer } {
  const id = live.id;
  return {
    assistant: async (request, signal) => { await live.flush(); return api.boardAssist(id, request, signal); },
    composer: {
      compose: async (request, signal) => { await live.flush(); return api.boardCompose(id, request, signal); },
      sources: async () => { await live.flush(); return (await api.boardSources(id)).sources; },
      documentHref,
      refresh: async (linkId, instruction, signal) => { await live.flush(); return api.boardLink(id, linkId, "refresh", instruction ? { instruction } : {}, signal); },
      apply: async (linkId, markdown, baseHash) => { await api.boardLink(id, linkId, "apply", { markdown, baseHash }); },
      keep: async linkId => { await live.flush(); await api.boardLink(id, linkId, "keep"); },
      unlink: async linkId => { await api.boardUnlink(id, linkId); },
      relink: async (linkId, blockId) => { await api.boardLink(id, linkId, "relink", { blockId }); },
      removeParagraph: async (linkId, baseHash) => { await api.boardLink(id, linkId, "remove-paragraph", { baseHash }); },
      paragraphs: linkId => api.boardLinkParagraphs(id, linkId),
      // Follows a compose turn writing into a document: saved body, the block being streamed, and when links are recorded.
      watch: (documentId, onUpdate) => {
        let body = "", pending = "", finished = false, closed = false;
        const emit = () => { if (!closed) onUpdate({ body, pending, finished }); };
        const refresh = async () => { try { body = (await api.document(documentId)).body; emit(); } catch { /* the next event retries */ } };
        void refresh();
        const stop = subscribeToEvents(api.spaceId, 0, event => {
          const payload = event.payload as Record<string, unknown>;
          if (payload.documentId !== documentId) return;
          if (event.type === "document.edit.started") { pending = ""; emit(); }
          if (event.type === "document.edit.delta") { pending += String(payload.delta ?? ""); emit(); }
          if (event.type === "document.edit.committed" || event.type === "document.edit.aborted") { pending = ""; void refresh(); }
          if (event.type === "board.compose.finished") { finished = true; void refresh(); }
        }, () => undefined);
        return () => { closed = true; stop(); };
      },
    },
  };
}
