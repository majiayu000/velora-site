import { useEffect, useState, useSyncExternalStore } from "react";
import * as Y from "yjs";
import { IndexeddbPersistence } from "y-indexeddb";
import { humanUndoManager, snapshot } from "../../../src/adapters/collaboration/board-model";
import type { BoardMetadata } from "../../../src/ports/board-port";
import { createSpaceApi, isDevelopmentWorkspace, workbenchApi } from "../api";
import { BoardCanvas, useBoardSnapshot } from "./BoardCanvas";
import { BoardWorkspace, seedDemoBoard } from "./BoardWorkspace";
import { serverBoardActions } from "./server-board";
import { LiveBoard, type LiveBoardStatus } from "./live-board";
import { SimulatedLink } from "./sync-sim";

// Sessions are created once per page, outside React: they subscribe to Yjs on construction, and
// StrictMode runs useState initialisers twice, which would leak a second subscriber.

type ServerSession = { live: LiveBoard; undo: Y.UndoManager; boards: BoardMetadata[]; spaceId: string };

async function connectServerBoard(): Promise<ServerSession> {
  const params = new URLSearchParams(location.search);
  const { spaces } = await workbenchApi.spaces();
  const space = spaces.find(s => s.id === params.get("space")) ?? spaces[0];
  if (!space) throw new Error("没有可用的学习空间");
  const api = createSpaceApi(space.id);
  let { boards } = await api.boards();
  let board = boards.find(b => b.id === params.get("board")) ?? boards[0];
  const created = !board;
  if (!board) { board = (await api.createBoard("第 12 期策划")).board; boards = [board]; }
  const doc = new Y.Doc();
  const undo = humanUndoManager(doc);
  const live = new LiveBoard(api, board.id, doc);
  await live.start();
  if (created && !snapshot(doc).cards.length) seedDemoBoard(doc);
  undo.clear();
  history.replaceState(null, "", `?space=${encodeURIComponent(space.id)}&board=${encodeURIComponent(board.id)}`);
  return { live, undo, boards, spaceId: space.id };
}

const STORE = "velora-board-prototype";
function createSimulatedSession() {
  const a = new Y.Doc(), b = new Y.Doc();
  return { a, b, link: new SimulatedLink(a, b), undoA: humanUndoManager(a), undoB: humanUndoManager(b) };
}

const serverSession = isDevelopmentWorkspace ? connectServerBoard() : undefined;
const simulatedSession = isDevelopmentWorkspace ? undefined : createSimulatedSession();

const statusText: Record<LiveBoardStatus, string> = { connecting: "正在连接…", syncing: "同步中…", saved: "已保存到本机服务", offline: "服务不可达，修改保留在本机" };

function ServerBoardApp({ session }: { session: ServerSession }) {
  const { live, undo } = session;
  const status = useSyncExternalStore(cb => live.subscribe(cb), () => live.status);
  useEffect(() => {
    if (import.meta.env.DEV) Object.assign(window, { __board: { a: live.doc, live, snapshot } });
  }, [live]);
  const openBoard = (id: string) => { location.search = `?space=${encodeURIComponent(session.spaceId)}&board=${encodeURIComponent(id)}`; };
  const newBoard = async () => {
    const { board } = await createSpaceApi(session.spaceId).createBoard(`白板 ${session.boards.length + 1}`);
    openBoard(board.id);
  };
  const { assistant, composer } = serverBoardActions(createSpaceApi(session.spaceId), live, id => `/#/space/${encodeURIComponent(session.spaceId)}/doc/${encodeURIComponent(id)}`);
  return <BoardWorkspace doc={live.doc} undo={undo} assistant={assistant} composer={composer} paneTitle={`${live.meta?.title ?? "白板"} · ${live.meta?.path ?? ""}`} controls={<>
    <select value={live.id} onChange={e => openBoard(e.target.value)} aria-label="白板">
      {session.boards.map(b => <option key={b.id} value={b.id}>{b.title}</option>)}
    </select>
    <button onClick={() => void newBoard()}>新白板</button>
    <span className={status === "saved" ? "board-ok" : "board-warn"} title={live.error}>{statusText[status]}</span>
    <button onClick={() => window.open(location.href, "_blank")}>在新标签页再开一个</button>
  </>} />;
}

function SimulatedBoardApp() {
  const { a, b, link, undoA, undoB } = simulatedSession!;
  const [ready, setReady] = useState(false);
  const online = useSyncExternalStore(cb => link.subscribe(cb), () => link.isOnline);
  const [showB, setShowB] = useState(true);
  const boardA = useBoardSnapshot(a), boardB = useBoardSnapshot(b);
  useEffect(() => {
    const persistence = new IndexeddbPersistence(STORE, a);
    persistence.once("synced", () => { if (!snapshot(a).cards.length) seedDemoBoard(a); undoA.clear(); setReady(true); });
    if (import.meta.env.DEV) Object.assign(window, { __board: { a, b, link, snapshot } });
    return () => { void persistence.destroy(); };
  }, [a, b, link, undoA]);
  if (!ready) return <p className="board-loading">正在读取本地白板…</p>;
  const converged = JSON.stringify(boardA) === JSON.stringify(boardB);
  return <BoardWorkspace doc={a} undo={undoA} paneTitle="客户端 A（本机，存 IndexedDB）" controls={<>
    <label><input type="checkbox" checked={online} onChange={e => link.setOnline(e.target.checked)} /> 在线</label>
    <label><input type="checkbox" checked={showB} onChange={e => setShowB(e.target.checked)} /> 显示第二个客户端</label>
    <span className={converged ? "board-ok" : "board-warn"}>{converged ? "两端一致" : online ? "同步中" : "离线，未同步"}</span>
    <button onClick={() => { indexedDB.deleteDatabase(STORE); location.reload(); }}>重置</button>
  </>} secondary={showB ? <section className="board-pane">
    <div className="board-pane-title">客户端 B（模拟另一台设备）</div>
    <BoardCanvas doc={b} undo={undoB} />
  </section> : undefined} />;
}

export function BoardApp() {
  const [session, setSession] = useState<ServerSession>();
  const [error, setError] = useState("");
  useEffect(() => { serverSession?.then(setSession, reason => setError(reason instanceof Error ? reason.message : String(reason))); }, []);
  if (!serverSession) return <SimulatedBoardApp />;
  if (error) return <p className="board-loading">连接本机服务失败：{error}</p>;
  if (!session) return <p className="board-loading">正在连接本机服务…</p>;
  return <ServerBoardApp session={session} />;
}
