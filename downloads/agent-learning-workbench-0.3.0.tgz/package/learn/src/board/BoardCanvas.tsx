import { useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import {
  Background, Controls, MiniMap, ReactFlow, ReactFlowProvider, useReactFlow,
  type Connection, type Edge, type EdgeChangeset, type NodeChangeset,
} from "@xyflow/react";
import type * as Y from "yjs";
import {
  addCard, addEdge, boardScope, moveCards, moveFrame, removeCards, removeEdges, setMeasuredHeight, settleFrameMembership, snapshot,
  type ArrangePlan, type BoardSnapshot, type Point,
} from "../../../src/adapters/collaboration/board-model";
import { BoardDocContext, nodeTypes, type BoardNode } from "./nodes";

export type DragStats = { frames: number; avgMs: number; maxMs: number; writes: number };

export function useBoardSnapshot(doc: Y.Doc): BoardSnapshot {
  const [state, setState] = useState(() => snapshot(doc));
  useEffect(() => {
    const update = () => setState(snapshot(doc));
    const scope = boardScope(doc);
    scope.forEach(type => type.observeDeep(update));
    update();
    return () => scope.forEach(type => type.unobserveDeep(update));
  }, [doc]);
  return state;
}

type Props = {
  doc: Y.Doc;
  undo: Y.UndoManager;
  preview?: ArrangePlan;
  /** Changing this value fits the view to the whole board (e.g. after AI adds cards). */
  fitKey?: number;
  order?: Record<string, number>;
  onSelection?: (ids: string[]) => void;
  onDragStats?: (stats: DragStats) => void;
};

function Canvas({ doc, undo, preview, order, onSelection, onDragStats, fitKey }: Props) {
  const board = useBoardSnapshot(doc);
  const flow = useReactFlow();
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [measured, setMeasured] = useState<Record<string, { width: number; height: number }>>({});
  const drag = useRef<{ last: number; frames: number; total: number; max: number; writes: number } | null>(null);

  // A selected group stands for all of its cards.
  useEffect(() => { onSelection?.(board.cards.filter(c => selected.has(c.id) || (c.frameId && selected.has(c.frameId))).map(c => c.id)); }, [selected, board.cards, onSelection]);
  // Bring the arrange preview into view; it is laid out beside the current content and may be off screen.
  useEffect(() => { if (preview) requestAnimationFrame(() => void flow.fitView({ padding: 0.12, duration: 250 })); }, [preview, flow]);
  // Wait a frame so newly synced cards are measured before fitting.
  useEffect(() => { if (fitKey) requestAnimationFrame(() => requestAnimationFrame(() => void flow.fitView({ padding: 0.12, duration: 250 }))); }, [fitKey, flow]);

  const nodes = useMemo<BoardNode[]>(() => {
    const frameTitle = new Map(board.frames.map(f => [f.id, f.title]));
    const frames: BoardNode[] = board.frames.map(f => ({
      id: f.id, type: "frame", position: { x: f.x, y: f.y }, width: f.w, height: f.h, zIndex: -1,
      data: { title: f.title }, selected: selected.has(f.id), deletable: false,
    }));
    const cards: BoardNode[] = board.cards.map(c => ({
      id: c.id, type: "card", position: { x: c.x, y: c.y }, width: c.w, selected: selected.has(c.id),
      ...(measured[c.id] ? { measured: measured[c.id] } : {}),
      data: { text: c.text, color: c.color, status: c.status, author: c.author, order: order?.[c.id], frameTitle: c.frameId ? frameTitle.get(c.frameId) : undefined },
    }));
    const ghosts: BoardNode[] = preview ? [
      ...preview.frames.map((f, i) => ({ id: `ghost-frame-${i}`, type: "ghost" as const, position: { x: f.rect.x, y: f.rect.y }, width: f.rect.w, height: f.rect.h, zIndex: -1, draggable: false, selectable: false, data: { title: f.title } })),
      ...Object.entries(preview.positions).map(([id, p]) => ({ id: `ghost-${id}`, type: "ghost" as const, position: p, width: board.cards.find(c => c.id === id)?.w, draggable: false, selectable: false, data: { text: board.cards.find(c => c.id === id)?.text ?? "" } })),
    ] : [];
    return [...frames, ...cards, ...ghosts];
  }, [board, selected, measured, order, preview]);

  const edges = useMemo<Edge[]>(() => board.edges.map(e => ({ id: e.id, source: e.from, target: e.to, label: e.label, selected: selected.has(e.id), markerEnd: { type: "arrowclosed" as never } })), [board.edges, selected]);

  const onNodesChange = useCallback((changes: NodeChangeset<BoardNode>) => {
    const moves: Record<string, Point> = {};
    const movedFrames = new Set<string>();
    const nextSelected = new Set(selected);
    let selectionChanged = false;
    const removed: string[] = [];
    for (const change of changes.toArray()) {
      if (change.id.startsWith("ghost")) continue;
      if (change.type === "position" && change.position) {
        if (board.frames.some(f => f.id === change.id)) { moveFrame(doc, change.id, change.position); movedFrames.add(change.id); }
        else moves[change.id] = change.position;
      } else if (change.type === "dimensions" && change.dimensions) {
        const { width, height } = change.dimensions;
        setMeasured(prev => prev[change.id]?.width === width && prev[change.id]?.height === height ? prev : { ...prev, [change.id]: { width, height } });
        if (board.cards.some(c => c.id === change.id)) setMeasuredHeight(doc, change.id, height);
      } else if (change.type === "select") {
        selectionChanged = true;
        if (change.selected) nextSelected.add(change.id); else nextSelected.delete(change.id);
      } else if (change.type === "remove") removed.push(change.id);
    }
    // A frame drag already carries its members; skip their duplicate position changes.
    for (const card of board.cards) if (card.frameId && movedFrames.has(card.frameId)) delete moves[card.id];
    if (Object.keys(moves).length) {
      moveCards(doc, moves);
      if (drag.current) drag.current.writes += 1;
    }
    if (removed.length) removeCards(doc, removed.filter(id => board.cards.some(c => c.id === id)));
    if (selectionChanged) setSelected(nextSelected);
  }, [doc, board, selected]);

  const onEdgesChange = useCallback((changes: EdgeChangeset<Edge>) => {
    const removed: string[] = [];
    const nextSelected = new Set(selected);
    let selectionChanged = false;
    for (const change of changes.toArray()) {
      if (change.type === "remove") removed.push(change.id);
      if (change.type === "select") { selectionChanged = true; if (change.selected) nextSelected.add(change.id); else nextSelected.delete(change.id); }
    }
    if (removed.length) removeEdges(doc, removed);
    if (selectionChanged) setSelected(nextSelected);
  }, [doc, selected]);

  // Frame-interval sampler: proves (or disproves) that Yjs-driven rendering keeps drags smooth.
  const sample = useCallback(() => {
    const state = drag.current;
    if (!state) return;
    const now = performance.now();
    const delta = now - state.last;
    state.last = now; state.frames += 1; state.total += delta; state.max = Math.max(state.max, delta);
    requestAnimationFrame(sample);
  }, []);

  return <BoardDocContext.Provider value={doc}>
    <div className="board-canvas" tabIndex={0} onKeyDown={(event: KeyboardEvent) => {
      if ((event.target as HTMLElement).tagName === "TEXTAREA") return;
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "z") {
        event.preventDefault();
        if (event.shiftKey) undo.redo(); else undo.undo();
      }
    }}>
      <ReactFlow<BoardNode, Edge> nodes={nodes} edges={edges} nodeTypes={nodeTypes}
        onNodesChange={onNodesChange} onEdgesChange={onEdgesChange}
        onConnect={(c: Connection) => { if (c.source && c.target) addEdge(doc, c.source, c.target); }}
        onNodeDragStart={() => { drag.current = { last: performance.now(), frames: 0, total: 0, max: 0, writes: 0 }; requestAnimationFrame(sample); }}
        onNodeDragStop={(_, __, dragged) => {
          settleFrameMembership(doc, dragged.filter(n => n.type === "card").map(n => n.id));
          const state = drag.current; drag.current = null;
          if (state && state.frames > 1) onDragStats?.({ frames: state.frames, avgMs: state.total / state.frames, maxMs: state.max, writes: state.writes });
        }}
        onDoubleClick={event => {
          if (!(event.target as HTMLElement).classList.contains("react-flow__pane")) return;
          const p = flow.screenToFlowPosition({ x: event.clientX, y: event.clientY });
          addCard(doc, { text: "", x: p.x - 90, y: p.y - 30 });
        }}
        zoomOnDoubleClick={false} selectionOnDrag panOnDrag={[1, 2]} panOnScroll deleteKeyCode={["Backspace", "Delete"]}
        fitView minZoom={0.2} maxZoom={2}>
        <Background gap={16} size={1} />
        <MiniMap pannable zoomable />
        <Controls showInteractive={false} />
      </ReactFlow>
    </div>
  </BoardDocContext.Provider>;
}

export function BoardCanvas(props: Props) {
  return <ReactFlowProvider><Canvas {...props} /></ReactFlowProvider>;
}
