import { useMemo, useState } from "react";
import type { RefreshOutcome, SourceStatus } from "../../../src/ports/board-port";

/** Server operations on one source link; implemented over the space API in BoardApp. */
export type SourceActions = {
  documentHref(documentId: string): string;
  refresh(linkId: string, instruction: string, signal: AbortSignal): Promise<RefreshOutcome>;
  apply(linkId: string, markdown: string, baseHash: string): Promise<void>;
  keep(linkId: string): Promise<void>;
  unlink(linkId: string): Promise<void>;
  relink(linkId: string, blockId: string): Promise<void>;
  removeParagraph(linkId: string, baseHash: string): Promise<void>;
  paragraphs(linkId: string): Promise<{ blocks: Array<{ id: string; hash: string; markdown: string }>; current?: string }>;
};

const STATE_LABEL: Record<SourceStatus["state"], string> = {
  fresh: "来源未变", "card-changed": "来源已改", "both-changed": "来源已改 · 你也改过这段",
  "card-deleted": "来源已删除", "block-missing": "断链：段落已不在",
};
type Review = { linkId: string; previous: string; markdown: string; baseHash: string };
type Relink = { linkId: string; blocks: Array<{ id: string; markdown: string }> };
const firstLine = (markdown: string) => markdown.trim().split("\n")[0]!.replace(/^#+\s*/, "").slice(0, 40) || "（空段落）";

type Props = {
  sources: SourceStatus[];
  titles: Record<string, string>;
  cardText(id: string): string;
  actions: SourceActions;
  instruction: string;
  openDocument?: (documentId: string) => void;
  /** Re-read link states after any change. */
  reload(): Promise<void>;
};

export function SourcePanel({ sources, titles, cardText, actions, instruction, openDocument, reload }: Props) {
  const [busy, setBusy] = useState<{ linkId: string; controller?: AbortController }>();
  const [review, setReview] = useState<Review>();
  const [relink, setRelink] = useState<Relink>();
  const [error, setError] = useState("");
  const [note, setNote] = useState("");

  const byDocument = useMemo(() => {
    const groups = new Map<string, SourceStatus[]>();
    for (const status of sources) groups.set(status.documentId, [...(groups.get(status.documentId) ?? []), status]);
    return [...groups.entries()];
  }, [sources]);

  /** Runs one action for a link; errors stay visible next to the panel and nothing else changes. */
  const run = async (linkId: string, task: (signal: AbortSignal) => Promise<string | void>, cancellable = false) => {
    const controller = cancellable ? new AbortController() : undefined;
    setBusy({ linkId, controller }); setError(""); setNote("");
    try {
      const message = await task(controller?.signal ?? new AbortController().signal);
      if (message) setNote(message);
      await reload();
    } catch (reason) {
      if (!controller?.signal.aborted) setError(reason instanceof Error ? reason.message : String(reason));
    } finally { setBusy(undefined); }
  };

  const refresh = (item: SourceStatus) => run(item.linkId, async signal => {
    const result = await actions.refresh(item.linkId, instruction, signal);
    if (result.applied) return `已按新卡片更新这一段（${result.adapter}）`;
    setReview({ linkId: item.linkId, previous: result.previous, markdown: result.markdown, baseHash: result.baseHash });
    return "你也改过这段，新版本没有直接写入，请对比后决定";
  }, true);

  const removeParagraph = (item: SourceStatus) => run(item.linkId, async () => {
    const { blocks, current } = await actions.paragraphs(item.linkId);
    const block = blocks.find(b => b.id === current);
    if (!block) throw new Error("段落已不在");
    if (!window.confirm(`删除文档里的这一段？\n\n${block.markdown.trim().slice(0, 200)}`)) return;
    await actions.removeParagraph(item.linkId, block.hash);
    return "已删除这一段";
  });

  const openRelink = (item: SourceStatus) => run(item.linkId, async () => {
    const { blocks } = await actions.paragraphs(item.linkId);
    setRelink({ linkId: item.linkId, blocks });
  });

  return <>
    {error && <p className="board-error" role="alert">{error}</p>}
    {note && <p className="board-ok" role="status">{note}</p>}
    {byDocument.map(([documentId, items]) => {
      const stale = items.filter(i => i.state !== "fresh");
      return <div key={documentId} className="board-source-doc" data-document-id={documentId}>
        <a href={actions.documentHref(documentId)} {...(openDocument ? { onClick: event => { event.preventDefault(); openDocument(documentId); } } : { target: "_blank", rel: "noreferrer" })}>{items[0]!.documentTitle ?? titles[documentId] ?? documentId}</a>
        <span className={stale.length ? "board-warn" : "board-ok"}>{stale.length ? `${stale.length} 段需要处理` : `${items.length} 段，来源未变`}</span>
        {stale.map(item => {
          const working = busy?.linkId === item.linkId;
          return <div key={item.linkId} className="board-source-stale" data-state={item.state} data-link-id={item.linkId}>
            <p>{STATE_LABEL[item.state]}{item.changedCards.length ? `：${item.changedCards.map(cardText).join("、")}` : ""}</p>
            <div className="board-source-actions">
              {(item.state === "card-changed" || item.state === "both-changed") && <>
                <button className="primary" disabled={!!busy} onClick={() => void refresh(item)}>{item.state === "card-changed" ? "按新卡片更新" : "生成新版本对比"}</button>
                <button disabled={!!busy} onClick={() => void run(item.linkId, async () => { await actions.keep(item.linkId); return "已保留原文"; })}>保留原文</button>
              </>}
              {item.state === "card-deleted" && <>
                <button disabled={!!busy} onClick={() => void removeParagraph(item)}>删掉这段</button>
                <button disabled={!!busy} onClick={() => void run(item.linkId, async () => { await actions.keep(item.linkId); return "已保留这一段并解除被删卡片的链接"; })}>保留并解除链接</button>
              </>}
              {item.state === "block-missing" && <>
                <button disabled={!!busy} onClick={() => void openRelink(item)}>重新关联…</button>
                <button disabled={!!busy} onClick={() => void run(item.linkId, async () => { await actions.unlink(item.linkId); return "已删除这条链接"; })}>删除链接</button>
              </>}
              {working && busy?.controller && <><span className="board-warn">AI 正在改写…</span><button onClick={() => busy.controller!.abort()}>取消</button></>}
            </div>
            {review?.linkId === item.linkId && <div className="board-review">
              <div><strong>现在的段落</strong><pre>{review.previous.trim()}</pre></div>
              <div><strong>按新卡片的版本（可修改）</strong>
                <textarea value={review.markdown} onChange={e => setReview({ ...review, markdown: e.target.value })} rows={6} aria-label="新版本" />
              </div>
              <button className="primary" disabled={!!busy} onClick={() => void run(item.linkId, async () => { await actions.apply(item.linkId, review.markdown, review.baseHash); setReview(undefined); return "已用新版本替换这一段"; })}>接受新版本</button>
              <button disabled={!!busy} onClick={() => setReview(undefined)}>放弃</button>
            </div>}
            {relink?.linkId === item.linkId && <div className="board-review">
              <label>关联到这篇文档的哪一段：
                <select defaultValue="" onChange={e => { const blockId = e.target.value; if (blockId) void run(item.linkId, async () => { await actions.relink(item.linkId, blockId); setRelink(undefined); return "已重新关联"; }); }} aria-label="选择段落">
                  <option value="" disabled>选择段落</option>
                  {relink.blocks.map(b => <option key={b.id} value={b.id}>{firstLine(b.markdown)}</option>)}
                </select>
              </label>
              <button onClick={() => setRelink(undefined)}>取消</button>
            </div>}
          </div>;
        })}
      </div>;
    })}
  </>;
}
