import "@xyflow/react/dist/style.css";
import "./board.css";
import { useEffect, useMemo, useState, useSyncExternalStore } from "react";
import type * as Y from "yjs";
import { humanUndoManager } from "../../../src/adapters/collaboration/board-model";
import { createSpaceApi } from "../api";
import { BoardWorkspace } from "./BoardWorkspace";
import { LiveBoard, type LiveBoardStatus } from "./live-board";
import { serverBoardActions } from "./server-board";

const statusText: Record<LiveBoardStatus, string> = { connecting: "正在连接…", syncing: "同步中…", saved: "已保存", offline: "服务不可达，修改保留在本机" };

/** A board opened as a tab of a learning space. Loaded lazily and only in the local workbench. */
export default function BoardTab({ spaceId, boardId, openDocument }: { spaceId: string; boardId: string; openDocument: (documentId: string) => void }) {
  const [session, setSession] = useState<{ live: LiveBoard; undo: Y.UndoManager }>();
  const [error, setError] = useState("");

  // One live replica per mounted tab; it subscribes to Yjs, so it is created in an effect and closed on cleanup.
  useEffect(() => {
    const live = new LiveBoard(createSpaceApi(spaceId), boardId);
    const undo = humanUndoManager(live.doc);
    let cancelled = false;
    setSession(undefined); setError("");
    live.start().then(() => { if (!cancelled) { undo.clear(); setSession({ live, undo }); } }, reason => { if (!cancelled) setError(reason instanceof Error ? reason.message : String(reason)); });
    return () => { cancelled = true; undo.destroy(); live.close(); };
  }, [spaceId, boardId]);

  if (error) return <p className="board-loading" role="alert">白板打开失败：{error}</p>;
  if (!session) return <p className="board-loading">正在打开白板…</p>;
  return <BoardTabView spaceId={spaceId} live={session.live} undo={session.undo} openDocument={openDocument} />;
}

function BoardTabView({ spaceId, live, undo, openDocument }: { spaceId: string; live: LiveBoard; undo: Y.UndoManager; openDocument: (documentId: string) => void }) {
  const status = useSyncExternalStore(cb => live.subscribe(cb), () => live.status);
  const actions = useMemo(() => serverBoardActions(createSpaceApi(spaceId), live, id => `#/space/${encodeURIComponent(spaceId)}/doc/${encodeURIComponent(id)}`), [spaceId, live]);
  return <div className="board-tab">
    <BoardWorkspace doc={live.doc} undo={undo} heading={live.meta?.title ?? "白板"} paneTitle={live.meta?.path ?? ""} assistant={actions.assistant} composer={actions.composer} openDocument={openDocument}
      controls={<span className={status === "saved" ? "board-ok" : "board-warn"} title={live.error}>{statusText[status]}</span>} />
  </div>;
}
