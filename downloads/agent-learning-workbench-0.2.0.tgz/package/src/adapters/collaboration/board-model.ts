import * as Y from "yjs";
import {
  CARD_MIN_HEIGHT, CARD_WIDTH, boundsOf, cardContentHash, estimateCardHeight, frameForCard, placeCards,
  type ArrangePlan, type BoardCard, type BoardEdge, type BoardFrame, type CardKind, type CardStatus, type Place, type Point, type Rect,
} from "../../domain/board";
import type { SourceLink } from "../../domain/board-compose";

export * from "../../domain/board";

// Transaction origins. Undo managers track origins by identity, so each is a unique object.
export const HUMAN_ORIGIN = { kind: "human" } as const;
export const MEASURE_ORIGIN = { kind: "measure" } as const;
export const REMOTE_ORIGIN = { kind: "remote" } as const;
export type TurnOrigin = { kind: "ai"; turnId: string };
export type BoardOrigin = typeof HUMAN_ORIGIN | typeof MEASURE_ORIGIN | typeof REMOTE_ORIGIN | TurnOrigin;
export const turnOrigin = (turnId: string): TurnOrigin => ({ kind: "ai", turnId });

export type CardColor = "y" | "b" | "g" | "p";
export type BoardCardView = BoardCard & { color: CardColor; author: "human" | "ai"; turnId?: string; hash: string };
export type BoardSnapshot = { cards: BoardCardView[]; frames: BoardFrame[]; edges: BoardEdge[] };

type CardMap = Y.Map<unknown>;
const cardsOf = (doc: Y.Doc) => doc.getMap<CardMap>("cards");
const framesOf = (doc: Y.Doc) => doc.getMap<Y.Map<unknown>>("frames");
const edgesOf = (doc: Y.Doc) => doc.getMap<BoardEdge>("edges");
export const boardScope = (doc: Y.Doc) => [cardsOf(doc), framesOf(doc), edgesOf(doc)];
const metaOf = (doc: Y.Doc) => doc.getMap<unknown>("meta");
// Source links sit outside the undo scope: undoing a card edit must not forget which paragraph it fed.
const linksOf = (doc: Y.Doc) => doc.getMap<SourceLink>("links");

export function sourceLinks(doc: Y.Doc): SourceLink[] {
  return [...linksOf(doc).values()].sort((a, b) => a.id.localeCompare(b.id));
}
export function addSourceLinks(doc: Y.Doc, links: SourceLink[], origin: unknown): void {
  doc.transact(() => { for (const link of links) linksOf(doc).set(link.id, link); }, origin);
}
export function removeSourceLinks(doc: Y.Doc, ids: string[], origin: unknown): void {
  doc.transact(() => { for (const id of ids) linksOf(doc).delete(id); }, origin);
}

export const boardTitle = (doc: Y.Doc): string => (metaOf(doc).get("title") as string | undefined) ?? "未命名白板";
export function setBoardTitle(doc: Y.Doc, title: string, origin: unknown = HUMAN_ORIGIN): void {
  doc.transact(() => metaOf(doc).set("title", title.trim().slice(0, 120) || "未命名白板"), origin);
}

export const BOARD_LIMITS = { cards: 2000, frames: 300, edges: 4000, links: 4000, textLength: 20000, coordinate: 1_000_000 } as const;

/** Structural validation for an untrusted merged board; throws with the first violation. */
export function validateBoardDoc(doc: Y.Doc): void {
  const finite = (value: unknown, min: number, max: number) => typeof value === "number" && Number.isFinite(value) && value >= min && value <= max;
  const { coordinate, textLength } = BOARD_LIMITS;
  const cards = cardsOf(doc), frames = framesOf(doc), edges = edgesOf(doc);
  if (cards.size > BOARD_LIMITS.cards || frames.size > BOARD_LIMITS.frames || edges.size > BOARD_LIMITS.edges) throw new Error("Board exceeds element limits");
  const title = metaOf(doc).get("title");
  if (title !== undefined && (typeof title !== "string" || title.length > 120)) throw new Error("Invalid board title");
  for (const [id, card] of cards.entries()) {
    if (!(card instanceof Y.Map)) throw new Error(`Card ${id} is not a map`);
    const text = card.get("text");
    if (!(text instanceof Y.Text) || text.length > textLength) throw new Error(`Card ${id} has invalid text`);
    if (!["note", "image", "docRef"].includes(card.get("kind") as string)) throw new Error(`Card ${id} has invalid kind`);
    if (!["live", "draft"].includes(card.get("status") as string)) throw new Error(`Card ${id} has invalid status`);
    if (!["y", "b", "g", "p"].includes(card.get("color") as string)) throw new Error(`Card ${id} has invalid colour`);
    if (!["human", "ai"].includes(card.get("author") as string)) throw new Error(`Card ${id} has invalid author`);
    if (!finite(card.get("x"), -coordinate, coordinate) || !finite(card.get("y"), -coordinate, coordinate) || !finite(card.get("w"), 40, 2000)) throw new Error(`Card ${id} has invalid geometry`);
    if (card.get("h") !== undefined && !finite(card.get("h"), 0, 5000)) throw new Error(`Card ${id} has invalid height`);
    const frameId = card.get("frameId");
    if (frameId !== undefined && typeof frameId !== "string") throw new Error(`Card ${id} has invalid frame`);
  }
  for (const [id, frame] of frames.entries()) {
    if (!(frame instanceof Y.Map) || typeof frame.get("title") !== "string" || (frame.get("title") as string).length > 120) throw new Error(`Frame ${id} is invalid`);
    if (!["x", "y"].every(k => finite(frame.get(k), -coordinate, coordinate)) || !["w", "h"].every(k => finite(frame.get(k), 1, 20000))) throw new Error(`Frame ${id} has invalid geometry`);
  }
  for (const [id, edge] of edges.entries()) {
    if (!edge || typeof edge !== "object" || typeof edge.from !== "string" || typeof edge.to !== "string") throw new Error(`Edge ${id} is invalid`);
    if (edge.label !== undefined && (typeof edge.label !== "string" || edge.label.length > 200)) throw new Error(`Edge ${id} has an invalid label`);
  }
  const links = linksOf(doc);
  if (links.size > BOARD_LIMITS.links) throw new Error("Board exceeds link limits");
  for (const [id, link] of links.entries()) {
    const short = (value: unknown) => typeof value === "string" && value.length > 0 && value.length <= 200;
    if (!link || typeof link !== "object" || link.id !== id || !["documentId", "blockId", "blockHash", "turnId", "at"].every(k => short((link as Record<string, unknown>)[k]))) throw new Error(`Link ${id} is invalid`);
    if (!link.cards || typeof link.cards !== "object" || Object.entries(link.cards).length > 50 || Object.entries(link.cards).some(([k, v]) => !short(k) || !short(v))) throw new Error(`Link ${id} has invalid cards`);
  }
}

const newId = (prefix: string) => `${prefix}_${crypto.randomUUID().slice(0, 8)}`;

export function snapshot(doc: Y.Doc): BoardSnapshot {
  const cards = [...cardsOf(doc).entries()].map(([id, m]) => {
    const text = (m.get("text") as Y.Text).toString();
    const kind = m.get("kind") as CardKind;
    return {
      id, text, kind, x: m.get("x") as number, y: m.get("y") as number, w: m.get("w") as number, h: (m.get("h") as number | undefined) ?? CARD_MIN_HEIGHT,
      frameId: m.get("frameId") as string | undefined, status: m.get("status") as CardStatus, color: m.get("color") as CardColor,
      author: m.get("author") as "human" | "ai", turnId: m.get("turnId") as string | undefined, hash: cardContentHash(kind, text),
    };
  });
  const frames = [...framesOf(doc).entries()].map(([id, m]) => ({ id, title: m.get("title") as string, x: m.get("x") as number, y: m.get("y") as number, w: m.get("w") as number, h: m.get("h") as number }));
  const edges = [...edgesOf(doc).entries()].map(([id, e]) => ({ ...e, id }));
  // Y.Map iteration order is replica-dependent; sort so converged replicas yield identical snapshots.
  const byId = (x: { id: string }, y: { id: string }) => x.id.localeCompare(y.id);
  return { cards: cards.sort(byId), frames: frames.sort(byId), edges: edges.sort(byId) };
}

type NewCard = { text: string; x: number; y: number; w?: number; color?: CardColor; frameId?: string; status?: CardStatus };

function insertCard(doc: Y.Doc, input: NewCard, author: "human" | "ai", turnId?: string): string {
  const id = newId("c");
  const map = new Y.Map<unknown>();
  map.set("text", new Y.Text(input.text));
  map.set("kind", "note");
  map.set("x", Math.round(input.x)); map.set("y", Math.round(input.y));
  map.set("w", input.w ?? CARD_WIDTH);
  map.set("color", input.color ?? "y");
  map.set("status", input.status ?? "live");
  map.set("author", author);
  if (input.frameId) map.set("frameId", input.frameId);
  if (turnId) map.set("turnId", turnId);
  cardsOf(doc).set(id, map);
  return id;
}

export function addCard(doc: Y.Doc, input: NewCard): string {
  let id = "";
  doc.transact(() => { id = insertCard(doc, input, "human"); }, HUMAN_ORIGIN);
  return id;
}

export function removeCards(doc: Y.Doc, ids: string[]): void {
  doc.transact(() => {
    for (const id of ids) cardsOf(doc).delete(id);
    for (const [edgeId, edge] of edgesOf(doc).entries()) if (ids.includes(edge.from) || ids.includes(edge.to)) edgesOf(doc).delete(edgeId);
  }, HUMAN_ORIGIN);
}

export function moveCards(doc: Y.Doc, moves: Record<string, Point>, origin: BoardOrigin = HUMAN_ORIGIN): void {
  doc.transact(() => {
    for (const [id, p] of Object.entries(moves)) {
      const card = cardsOf(doc).get(id);
      if (!card) continue;
      if (card.get("x") !== Math.round(p.x)) card.set("x", Math.round(p.x));
      if (card.get("y") !== Math.round(p.y)) card.set("y", Math.round(p.y));
    }
  }, origin);
}

/** Called when a drag ends: a card dropped inside a frame joins it, dropped outside leaves it. */
export function settleFrameMembership(doc: Y.Doc, ids: string[]): void {
  const { cards, frames } = snapshot(doc);
  doc.transact(() => {
    for (const card of cards.filter(c => ids.includes(c.id))) {
      const target = frameForCard(card, frames);
      if (target !== card.frameId) {
        const map = cardsOf(doc).get(card.id)!;
        if (target) map.set("frameId", target); else map.delete("frameId");
      }
    }
  }, HUMAN_ORIGIN);
}

export function moveFrame(doc: Y.Doc, frameId: string, to: Point): void {
  const frame = framesOf(doc).get(frameId);
  if (!frame) return;
  const dx = Math.round(to.x) - (frame.get("x") as number), dy = Math.round(to.y) - (frame.get("y") as number);
  if (!dx && !dy) return;
  doc.transact(() => {
    frame.set("x", (frame.get("x") as number) + dx); frame.set("y", (frame.get("y") as number) + dy);
    for (const card of cardsOf(doc).values()) {
      if (card.get("frameId") !== frameId) continue;
      card.set("x", (card.get("x") as number) + dx); card.set("y", (card.get("y") as number) + dy);
    }
  }, HUMAN_ORIGIN);
}

export function setCardText(doc: Y.Doc, id: string, text: string): void {
  const yText = cardsOf(doc).get(id)?.get("text") as Y.Text | undefined;
  if (!yText || yText.toString() === text) return;
  doc.transact(() => { yText.delete(0, yText.length); yText.insert(0, text); }, HUMAN_ORIGIN);
}

/** Rendered height is layout data, not an edit: it is excluded from both undo stacks. */
export function setMeasuredHeight(doc: Y.Doc, id: string, h: number): void {
  const card = cardsOf(doc).get(id);
  if (!card || card.get("h") === Math.round(h)) return;
  doc.transact(() => card.set("h", Math.round(h)), MEASURE_ORIGIN);
}

export function addEdge(doc: Y.Doc, from: string, to: string, label?: string): void {
  if (from === to || [...edgesOf(doc).values()].some(e => e.from === from && e.to === to)) return;
  const id = newId("e");
  doc.transact(() => edgesOf(doc).set(id, { id, from, to, ...(label ? { label } : {}) }), HUMAN_ORIGIN);
}

export function removeEdges(doc: Y.Doc, ids: string[]): void {
  doc.transact(() => { for (const id of ids) edgesOf(doc).delete(id); }, HUMAN_ORIGIN);
}

function insertFrame(doc: Y.Doc, title: string, rect: Rect): string {
  const id = newId("f");
  const map = new Y.Map<unknown>();
  map.set("title", title);
  for (const key of ["x", "y", "w", "h"] as const) map.set(key, Math.round(rect[key]));
  framesOf(doc).set(id, map);
  return id;
}

export function addFrame(doc: Y.Doc, title: string, rect: Rect): string {
  let id = "";
  doc.transact(() => { id = insertFrame(doc, title, rect); }, HUMAN_ORIGIN);
  return id;
}

// ---- AI operations: always under a turn origin, new cards always start as drafts ----

export function addDraftCards(doc: Y.Doc, origin: TurnOrigin, place: Place, items: Array<string | { text: string; color?: CardColor }>, viewportOrigin?: Point): string[] {
  const { cards, frames } = snapshot(doc);
  const drafts = items.map(item => typeof item === "string" ? { text: item, color: "b" as CardColor } : { text: item.text, color: item.color ?? "b" });
  const sizes = drafts.map(d => ({ w: CARD_WIDTH, h: estimateCardHeight(d.text, true) }));
  const positions = placeCards(place, sizes, [...cards, ...frames], viewportOrigin);
  const ids: string[] = [];
  doc.transact(() => {
    drafts.forEach((draft, i) => ids.push(insertCard(doc, { ...draft, ...positions[i], status: "draft" }, "ai", origin.turnId)));
  }, origin);
  return ids;
}

export function acceptDrafts(doc: Y.Doc, ids: string[]): void {
  doc.transact(() => { for (const id of ids) cardsOf(doc).get(id)?.set("status", "live"); }, HUMAN_ORIGIN);
}

export function discardDrafts(doc: Y.Doc, ids: string[]): void {
  doc.transact(() => { for (const id of ids) if (cardsOf(doc).get(id)?.get("status") === "draft") cardsOf(doc).delete(id); }, HUMAN_ORIGIN);
}

/** Applies an accepted arrange preview in one transaction under the AI turn, so "undo this turn" restores it. */
export function applyArrange(doc: Y.Doc, origin: TurnOrigin, plan: ArrangePlan, moves: Record<string, Point>): void {
  doc.transact(() => {
    for (const [id, p] of Object.entries(moves)) {
      const card = cardsOf(doc).get(id);
      if (card) { card.set("x", Math.round(p.x)); card.set("y", Math.round(p.y)); }
    }
    for (const frame of plan.frames) {
      const members = frame.cardIds.filter(id => moves[id]);
      if (!members.length) continue;
      const rect = boundsOf(members.map(id => ({ ...moves[id], w: CARD_WIDTH, h: (cardsOf(doc).get(id)?.get("h") as number) ?? CARD_MIN_HEIGHT }))) ?? frame.rect;
      const frameId = insertFrame(doc, frame.title, { x: rect.x - 28, y: rect.y - 36, w: rect.w + 56, h: rect.h + 64 });
      for (const id of members) cardsOf(doc).get(id)?.set("frameId", frameId);
    }
  }, origin);
}

export function humanUndoManager(doc: Y.Doc): Y.UndoManager {
  return new Y.UndoManager(boardScope(doc), { trackedOrigins: new Set([HUMAN_ORIGIN]), captureTimeout: 400 });
}

export function turnUndoManager(doc: Y.Doc, origin: TurnOrigin): Y.UndoManager {
  // One undo step per turn: everything the turn did is reverted together.
  return new Y.UndoManager(boardScope(doc), { trackedOrigins: new Set([origin]), captureTimeout: Number.MAX_SAFE_INTEGER });
}
