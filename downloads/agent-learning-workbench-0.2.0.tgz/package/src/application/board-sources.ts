import { randomUUID } from "node:crypto";
import { cardContentHash, type CardKind } from "../domain/board";
import { sourceStatus, type SourceLink, type SourceStatus } from "../domain/board-compose";
import { buildRefreshTask, rebaseLink, refreshableState, validateRefreshResult, type RefreshOutcome } from "../domain/board-refresh";
import { LearnError } from "../domain/errors";
import type { BoardPort, BoardProjection } from "../ports/board-port";
import type { DocumentBlock } from "../ports/collaboration-port";
import type { ComposeSpace } from "./board-composer";

const cardHashes = (board: BoardProjection) => Object.fromEntries(board.cards.map(c => [c.id, cardContentHash(c.kind as CardKind, c.text)]));
const ending = (markdown: string) => `${markdown.trim()}\n\n`;

/**
 * Everything that happens to a paragraph after it was composed: status, refresh from the updated cards,
 * review of a proposal when the person also edited the paragraph, keep the original, unlink, relink,
 * and removing a paragraph whose cards were deleted. Each document write replaces or deletes exactly the
 * linked block, guarded by the hash the person last saw, so no other paragraph can change.
 */
export class BoardSources {
  constructor(private readonly boards: BoardPort, private readonly space: ComposeSpace) {}

  private collaboration() {
    if (!this.space.collaboration) throw new LearnError("COLLABORATION_UNAVAILABLE", "来源同步需要块级协作", 409);
    return this.space.collaboration;
  }

  private async blocksOf(documentId: string): Promise<DocumentBlock[] | undefined> {
    try { return (await this.collaboration().read(documentId)).blocks; } catch { return undefined; }
  }

  async list(boardId: string): Promise<SourceStatus[]> {
    const board = await this.boards.projection(boardId);
    const blocks: Record<string, DocumentBlock[] | undefined> = {};
    for (const documentId of new Set(board.links.map(l => l.documentId))) blocks[documentId] = await this.blocksOf(documentId);
    const titles = new Map(this.space.store.listDocuments().map(d => [d.id, d.title]));
    return sourceStatus(board.links, cardHashes(board), blocks).map(s => titles.has(s.documentId) ? { ...s, documentTitle: titles.get(s.documentId) } : s);
  }

  private async load(boardId: string, linkId: string) {
    const board = await this.boards.projection(boardId);
    const link = board.links.find(l => l.id === linkId);
    if (!link) throw new LearnError("LINK_NOT_FOUND", "这条来源链接已不存在", 404);
    const blocks = await this.blocksOf(link.documentId);
    const hashes = cardHashes(board);
    const [status] = sourceStatus([link], hashes, { [link.documentId]: blocks });
    const index = blocks?.findIndex(b => b.id === link.blockId) ?? -1;
    return { board, link, hashes, status: status!, blocks: blocks ?? [], index };
  }

  private async record(documentId: string, source: "proposal" | "human", summary: string): Promise<void> {
    const path = this.space.store.listDocuments().find(d => d.id === documentId)?.path;
    if (path) await this.space.recordMutation(source, summary, [path]);
  }

  /** Card changed, paragraph untouched → write directly. Both changed → return a proposal for review, write nothing. */
  async refresh(boardId: string, linkId: string, input: Record<string, unknown>, signal: AbortSignal): Promise<RefreshOutcome> {
    const { board, link, hashes, status, blocks, index } = await this.load(boardId, linkId);
    const mode = refreshableState(status);
    const health = this.space.getWorkspace().runtime;
    const port = this.space.runtime;
    if (!health.available) throw new LearnError("RUNTIME_UNAVAILABLE", health.message ?? "Agent Runtime 当前不可用", 503);
    if (!port.structured) throw new LearnError("ASSIST_UNSUPPORTED", `${health.adapter} 不支持按新卡片更新`, 501);
    const block = blocks[index]!;
    const cards = board.cards.filter(c => c.id in link.cards && c.id in hashes).map(c => ({ id: c.id, text: c.text }));
    const title = this.space.store.listDocuments().find(d => d.id === link.documentId)?.title ?? link.documentId;
    const instruction = typeof input.instruction === "string" ? input.instruction.trim().slice(0, 500) : "";
    const task = buildRefreshTask({ documentTitle: title, paragraph: block.markdown, before: blocks[index - 1]?.markdown, after: blocks[index + 1]?.markdown, cards, ...(instruction ? { instruction } : {}) });
    const result = validateRefreshResult(await port.structured(task, signal));
    if (signal.aborted) throw new LearnError("TURN_CANCELLED", "更新已取消", 409);
    const base = { linkId, documentId: link.documentId, blockId: link.blockId, markdown: result.markdown, previous: block.markdown, summary: result.summary, adapter: health.adapter };
    if (mode === "review") return { ...base, applied: false, baseHash: block.hash };
    await this.write(boardId, link, hashes, block.hash, result.markdown, "proposal", `Refresh paragraph from updated cards`);
    return { ...base, applied: true };
  }

  /** The person accepted a reviewed proposal (or their own edit of it). Guarded by the paragraph hash they reviewed. */
  async apply(boardId: string, linkId: string, input: Record<string, unknown>): Promise<SourceStatus> {
    const markdown = typeof input.markdown === "string" ? input.markdown.trim() : "";
    const baseHash = typeof input.baseHash === "string" ? input.baseHash : "";
    if (!markdown || markdown.length > 8000 || !baseHash) throw new LearnError("INVALID_REFRESH", "需要非空的段落和审阅时的段落哈希", 422);
    const { link, hashes, status } = await this.load(boardId, linkId);
    if (status.state === "block-missing") throw new LearnError("BLOCK_NOT_FOUND", "段落已不在，不能写入", 409);
    await this.write(boardId, link, hashes, baseHash, markdown, "proposal", "Accept reviewed paragraph refresh");
    return (await this.list(boardId)).find(s => s.linkId === linkId)!;
  }

  private async write(boardId: string, link: SourceLink, hashes: Record<string, string>, ifHash: string, markdown: string, source: "proposal" | "human", summary: string) {
    const next = await this.collaboration().operate(link.documentId, [{ type: "replace", blockId: link.blockId, ifHash, markdown: ending(markdown) }]);
    const block = next.blocks.find(b => b.id === link.blockId)!;
    await this.boards.addLinks(boardId, [{ ...rebaseLink(link, hashes, block.hash, new Date().toISOString()), turnId: randomUUID() }]);
    await this.record(link.documentId, source, summary);
  }

  /** "保留原文": the current cards and paragraph become the baseline; deleted cards leave the link, and an empty link is removed. */
  async keep(boardId: string, linkId: string): Promise<{ removed: boolean }> {
    const { link, hashes, status, blocks, index } = await this.load(boardId, linkId);
    if (status.state === "block-missing") throw new LearnError("BLOCK_NOT_FOUND", "段落已不在，请重新关联或删除链接", 409);
    const next = rebaseLink(link, hashes, blocks[index]!.hash, new Date().toISOString());
    if (!Object.keys(next.cards).length) { await this.boards.removeLinks(boardId, [linkId]); return { removed: true }; }
    await this.boards.addLinks(boardId, [next]);
    return { removed: false };
  }

  async unlink(boardId: string, linkId: string): Promise<void> {
    await this.load(boardId, linkId);
    await this.boards.removeLinks(boardId, [linkId]);
  }

  /** Broken link → point it at another paragraph of the same document, taking that paragraph as the new baseline. */
  async relink(boardId: string, linkId: string, input: Record<string, unknown>): Promise<SourceStatus> {
    const { link, hashes, blocks } = await this.load(boardId, linkId);
    const target = blocks.find(b => b.id === input.blockId);
    if (!target) throw new LearnError("BLOCK_NOT_FOUND", "要关联的段落不在这篇文档里", 404);
    await this.boards.addLinks(boardId, [rebaseLink(link, hashes, target.hash, new Date().toISOString(), target.id)]);
    return (await this.list(boardId)).find(s => s.linkId === linkId)!;
  }

  /** Card deleted → the person chose to delete the paragraph too. Only that block, guarded by the hash they saw. */
  async removeParagraph(boardId: string, linkId: string, input: Record<string, unknown>): Promise<void> {
    const { link, status } = await this.load(boardId, linkId);
    if (status.state !== "card-deleted") throw new LearnError("INVALID_REFRESH", "只有来源卡片被删除的段落可以这样删除", 409);
    const ifHash = typeof input.baseHash === "string" ? input.baseHash : "";
    if (!ifHash) throw new LearnError("PRECONDITION_REQUIRED", "需要段落哈希", 428);
    await this.collaboration().operate(link.documentId, [{ type: "delete", blockId: link.blockId, ifHash }]);
    await this.boards.removeLinks(boardId, [linkId]);
    await this.record(link.documentId, "human", "Delete paragraph whose source cards were deleted");
  }

  /** Paragraphs of the linked document, for the review and relink views. */
  async paragraphs(boardId: string, linkId: string): Promise<{ blocks: Array<Pick<DocumentBlock, "id" | "hash" | "markdown">>; current?: string }> {
    const { link, blocks, index } = await this.load(boardId, linkId);
    return { blocks: blocks.map(({ id, hash, markdown }) => ({ id, hash, markdown })), ...(index >= 0 ? { current: link.blockId } : {}) };
  }
}
